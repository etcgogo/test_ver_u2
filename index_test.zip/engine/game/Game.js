'use strict';
const BaseRules = require('./baseRules');
const Player = require('./player');
const Team = require('./team');
const Dart = require('./dart');
const GameStatus = require('./gameStatus');

module.exports = class Game {
	constructor() {
		this.numberOfPlayers = 0;
		this.players = [];
		this.rules = {};
		this.uniqueId;
		this.gameStatus = {};
		this.logToConsole = true;
		this.darts = [];
		this.playerApproached = false;
		this.awaitApproach = false;
		this.maxNumberOfPlayers = 8;
		this.dartsPerRound = 3;
		this.gameStatusHistory = [];
		this.gameStatusFuture = [];
		this.dartsFuture = [];
		this.playOffHistory = [];
		this.playOffStarted = false;
		this.playoffGame = null;
		this.isPlayoff = false;
	}
	// REGION Public
	// Create new game
	create(rules, players, teams, keepPlayersAsIs) {
		if (!(rules instanceof BaseRules) || rules.validate() === false) {
			// Check if rules are valid
			return false;
		}
		if (players.length <= 0 || players.length > this.maxNumberOfPlayers) {
			// Check if players are valid
			return false;
		}
		if (players.some((_player) => (!(_player instanceof Player)))) {
			return false;
		}
		// Set parameters to variables
		this.rules = rules;
		this.uniqueId = rules.uniqueId;
		let finalPlayers = players;
		if (rules.teamRules && !keepPlayersAsIs) {
			// Handle team rules
			finalPlayers = [];
			let teamsCounter = {
				t0: 0,
				t1: 0,
				t2: 0,
				t3: 0
			};
			players.forEach((_player) => {
				teamsCounter['t' + _player.teamId]++;
			});
			let playersPerTeam = 0;
			for (let i = 0; i < rules.teamRules.count; i++) {
				if ((playersPerTeam && teamsCounter['t' + i] && playersPerTeam !== teamsCounter['t' + i]) ||
					teamsCounter['t' + i] < 2) {
					return false;
				}
				else {
					playersPerTeam = playersPerTeam || teamsCounter['t' + i];
				}
			}
			players.forEach((_player, _index) => {
				const arrayIndex = (_index % playersPerTeam) * rules.teamRules.count + _player.teamId;
				finalPlayers[arrayIndex] = _player;
			});
			finalPlayers = finalPlayers.filter((_player) => (!!_player));
		}
		this.players = finalPlayers; // keepPlayersAsIs === true if playoff is being created
		console.log('OVO SU IGRAČI POSLIJE CREATEA', this.players);
		this.numberOfPlayers = this.players.length;
		this.teams = teams.map((_team) => (new Team(_team)));
		return true;
	}
	// Add dart to game
	addDart(dart) {
		this.gameStatus.message = '';
		if (!(dart instanceof Dart)) {
			this.log('Wrong parameter type: dart.');
			return null;
		}
		/*if (this.awaitApproach === true) {
			this.gameStatus.message = 'Awaiting player to approach.';
			this.log(this.gameStatus.message);
			return null;
		}
		if (this.playerApproached === true) {
			this.gameStatus.message = 'Player approached board.';
			this.log(this.gameStatus.message);
			return null;
		}*/
		// Display message for miss/tup
		if (dart.hitEnum === -1) {
			this.gameStatus.message = 'MISS';
		}
		else if (dart.hitEnum === 0) {
			this.gameStatus.message = 'TUP';
		}
		let player = this.gameStatus.getCurrentPlayer();
		// Save dart to list for possible reconstruction
		dart.player = player.id;
		player.darts.push(dart);
		if (dart.score > 0) {
			player.numbersHit++;
		}
		this.darts.push(dart);
		this.addStatusHistory();
		return this.gameStatus;
	}
	irApproach() {
		if (this.rules.playOff === true &&
			this.gameStatus.gameOver === true &&
			this.playOffStarted === true) {
			this.playoffGame.irApproach();
			return;
		}
		this.playerApproached = true;
		this.awaitApproach = false;
		this.gameStatus.message = 'Player approached.';
		this.log(this.gameStatus.message);
	}
	irLeave() {
		if (this.rules.playOff === true &&
			this.gameStatus.gameOver === true &&
			this.playOffStarted === true) {
			this.playoffGame.irLeave();
			return;
		}
		if (this.playerApproached === true) {
			this.playerApproached = false;
			this.gameStatus.message = 'Player left.';
			this.log(this.gameStatus.message);
		}
	}
	undoLastDart() {
		if (this.gameStatusHistory.length > 0) {
			let previousStatus = this.gameStatusHistory.pop();
			this.dartsFuture.push(this.darts.pop());
			this.gameStatusFuture.push(this.gameStatus);
			this.gameStatus = previousStatus;
			this.players = this.gameStatus.players;
			if (this.playOffStarted === true && this.playoffGame !== null) {
				this.playoffGame.undoLastDart();
			}
			let playOffItem = this.playOffHistory.pop();
			this.playOffStarted = playOffItem.playOffStarted;
			this.isPlayoff = playOffItem.isPlayoff;
			if (this.playOffStarted === false) {
				this.playoffGame = null;
			}
			this.awaitApproach = playOffItem.awaitApproach;
			this.playerApproached = playOffItem.playerApproached;
		}
		else {
			this.log('No darts to undo.');
		}
	}
	redoLastDart() {
		if (this.gameStatusFuture.length > 0) {
			let futureStatus = this.gameStatusFuture.pop();
			this.addStatusHistory();
			this.darts.push(this.dartsFuture.pop());
			this.gameStatus = futureStatus;
			this.players = this.gameStatus.players;
			console.log('Zadnji u UNDO stacku je : ', this.gameStatusHistory[this.gameStatusHistory.length-1]);
			console.log('Ovo pišem u UNDO STACK : ', futureStatus);
		}
		else {
			this.log('No darts to redo.');
		}
	}
	getLeaderBoard() { }
	//ENDREGION public
	//REGION Private
	startPlayoff(leader) {
		var playoffRules = new x01Rules(GameTypeEnum.x01, // gameType
			0, // score
			false, // parcheesi
			1000, // rounds
			false, // runAndGun
			0, // runAndGunTime
			false, // playOff
			false, // doubleIn
			false, // doubleOut
			false, // masterOut
			false, // equalOption
			false, // endOption
			this.rules.quatro, // quatro
			false, // undo
			false, // handicap
			false, // bull
			this.rules.teamRules // teamRules
		);
		let playoffPlayers = [];
		let message = 'No more rounds, play off started between: ';
		console.log(message);
		leader.forEach((_p, _index) => {
			message += _p.name;
			if (_index !== leader.length - 1) {
				message += ', ';
			}
			playoffPlayers.push(new Player(_p.id, _p.name, 0, _p.teamId, _p.copyOfType, _p.owner, _p.avgStatistic, _p.numbersHit, _p.totalscore, _p.roundScores));
		});
		this.playoffGame = new x01Game();
		this.playoffGame.logToConsole = this.logToConsole;
		this.playoffGame.create(playoffRules, playoffPlayers, this.teams, true);
		this.playoffGame.dartsPerRound = 1;
		this.playoffGame.isPlayoff = true;
		this.playoffGame.awaitApproach = true;
		this.playoffGame.realCurrentPlayer = playoffPlayers[0].id;
		this.awaitApproach = false;
		this.playOffStarted = true;
		this.gameStatus.message = message;
		this.log(message);
	}
	addStatusHistory() {
		const currentPlayers = JSON.parse(JSON.stringify(this.gameStatus.players));
		const currentTeams = JSON.parse(JSON.stringify(this.gameStatus.teams));
		var gameStatusCopy = new GameStatus(currentPlayers, currentTeams);
		gameStatusCopy.currentDart = this.gameStatus.currentDart;
		gameStatusCopy.currentPlayer = this.gameStatus.currentPlayer;
		gameStatusCopy.round = this.gameStatus.round;
		gameStatusCopy.gameOver = this.gameStatus.gameOver;
		gameStatusCopy.roundStartScore = [...gameStatusCopy.roundStartScore, ...this.gameStatus.roundStartScore];
		this.gameStatusHistory.push(gameStatusCopy);
		const playOffHistoryPoint = {
			playOffStarted: this.playOffStarted,
			isPlayoff: this.isPlayoff,
			awaitApproach: this.awaitApproach,
			playerApproached: this.playerApproached
		};
		this.playOffHistory.push(playOffHistoryPoint);
	}
	log(message) {
		if (this.logToConsole) {
			console.log(message);
		}
	}
	getNumbersToClose() { }
}










