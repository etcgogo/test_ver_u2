"use strict";

const BaseRules = require('./baseRules');

module.exports = class OtherRules extends BaseRules {
    constructor(gameType, score, parcheesi, rounds, runAndGun, runAndGunTime, playOff, doubleIn, doubleOut, masterOut, equalOption, endOption, quatro, undo, handicap, bull, teamRules) {
        super();
        this.otherGameType = gameType || 0;
        if (gameType === 1 || gameType === 2 || gameType === 3 || gameType === 5 || gameType === 13) {
            gameType = 1;
        }
        else {
            gameType = 2;
        }
        this.gameType = gameType;
        this.score = score;
        this.rounds = rounds;
        this.parcheesi = parcheesi;
        this.runAndGun = runAndGun;
        this.runAndGunTime = (this.runAndGun === true) ? runAndGunTime : 60;
        this.playOff = playOff;
        this.doubleIn = doubleIn;
        this.doubleOut = doubleOut;
        this.masterOut = masterOut;
        this.equalOption = equalOption;
        this.endOption = endOption;
        this.bull = bull;
        if (this.otherGameType === 5) {
            this.runAndGun = true;
            this.runAndGunTime = 15;
        }
        if (gameType === 2) {
            this.numbersToClose = [];
            this.numbersChosen = false;
            this.overCountDart = 0;
            this.numberOfNumbers = 7;
            this.currentPigDart = 20;
            if (this.otherGameType === 4) {
                if (quatro === true && bull === false) {
                    this.numberOfNumbers = 12;
                    this.numbersToClose = [13, 14, 22, 15, 16, 23, 17, 18, 24, 19, 20, 25];
                    this.numbersChosen = true;
                }
                else if (quatro === true && bull === true) {
                    this.numberOfNumbers = 12;
                    this.numbersToClose = [13, 14, 22, 15, 16, 23, 17, 18, 24, 19, 20, 50];
                    this.numbersChosen = true;
                }
                else if (quatro === false && bull === true) {
                    this.numberOfNumbers = 9;
                    this.numbersToClose = [15, 16, 22, 17, 18, 23, 19, 20, 50];
                    this.numbersChosen = true;
                }
                else {
                    this.numberOfNumbers = 9;
                    this.numbersToClose = [15, 16, 22, 17, 18, 23, 19, 20, 25];
                    this.numbersChosen = true;
                }
            }
            else if (this.otherGameType === 8) {
                if (bull === true) {
                    this.numberOfNumbers = 21;
                    this.numbersToClose = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 50];
                    this.numbersChosen = true;
                }
                else {
                    this.numberOfNumbers = 21;
                    this.numbersToClose = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 25];
                    this.numbersChosen = true;
                }
            }
            else if (this.otherGameType === 6) {
                this.numberOfNumbers = 21;
                this.numbersToClose = [25, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10];
                this.numbersChosen = true;
            }
            else if (this.otherGameType === 7) {
                this.numberOfNumbers = 21;
                this.numbersToClose = [25, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1];
                this.numbersChosen = true;
            }
            else if (this.otherGameType === 9) {
                this.numberOfNumbers = 9;
                this.numbersToClose = [1, 2, 3, 4, 5, 6, 7, 8, 9];
                this.numbersChosen = true;
            }
            else if (this.otherGameType === 10) {
                this.numberOfNumbers = this.rounds;
                this.numbersToClose = [];
                for (let index = 0; index < this.rounds; index++) {
                    this.numbersToClose[index] = Math.floor(Math.random() * 20) + 1;
                }
            }
        }
    }
    validate() {
        if (BaseRules.prototype.validate.call(this) === false) {
			return false;
		}
        return true;
    }
}


const OtherGameTypeEnum = {
    "hiscore": 1,
    "lowscore": 2,
    "superscore": 3,
    "splitscore": 4,
    "pubgame": 5,
    "minimarathon": 6,
    "marathon": 7,
    "shangai": 8,
    "baseball": 9,
    "roulette": 10,
    "roulettedouble": 11,
    "scram": 12,
    "super100": 13,
};