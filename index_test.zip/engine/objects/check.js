function hexify(unfullHex) {
    if (!unfullHex && unfullHex !== 0) {
		console.log('Wrong hexify input');
        return;
    }
	return ('00' + unfullHex.toString(16).toUpperCase()).slice(-2)
}

function cricketLED (player, position, marks) {
	// FirstByte + Lenght + commandByte + player + position + marks + checksum + LastByte
	let length = '05';
	let commandByte = 'D128';
	let playerByte = hexify(player);
	let positionByte = hexify(position);
	let markByte;
	let checksum = 254 + player + position; 
	// Value of commandByte+length in decimal is 254
	let firstByte = 'AB';
	let lastByte = 'BA';
	let finished;
  
	if (marks === 1) {
	  markByte = '01';
	  checksum += 1;
	} else if (marks === 2) {
	  markByte = '03';
	  checksum += 3;
	} else if (marks === 3) {
	  markByte = '07';
	  checksum += 7;
	}
  
	finished = firstByte + length + commandByte + playerByte + positionByte + markByte + hexify(checksum) + lastByte;
  
	return finished;
}

function displayLED (type, display, data) {
    //type 1 stands for numbers (data parameter is number), type 2 stands for strings (data parameter is string)
    //displays 1-8 are for players, display 9 is temporary, 10 is for left yellow display, 11 is for right yellow display, 12 is for round display, 13 is for credit display
	let length;
	let checksum = 0;
	let commandByte;
	let dataBytes = '';
  	let firstByte = 'AB';
  	let lastByte = 'BA';

	if (type === 1) {
		let multiplierByte = Math.floor(data/256);
		let modByte = data - (multiplierByte * 256);
		checksum += multiplierByte + modByte;

		switch (display) {
			case 1:
				commandByte = 'D12101' + hexify(multiplierByte) + hexify(modByte);
				checksum += parseInt('D1', 16) + parseInt('21', 16) + parseInt('01', 16);
				break;
			case 2:
				commandByte = 'D12102' + hexify(multiplierByte) + hexify(modByte);
				checksum += parseInt('D1', 16) + parseInt('21', 16) + parseInt('02', 16);
				break;
			case 3:
				commandByte = 'D12103' + hexify(multiplierByte) + hexify(modByte);
				checksum += parseInt('D1', 16) + parseInt('21', 16) + parseInt('03', 16);
				break;
			case 4:
				commandByte = 'D12104' + hexify(multiplierByte) + hexify(modByte);
				checksum += parseInt('D1', 16) + parseInt('21', 16) + parseInt('04', 16);
				break;
			case 5:
				commandByte = 'D12105'+ hexify(multiplierByte) + hexify(modByte);
				checksum += parseInt('D1', 16) + parseInt('21', 16) + parseInt('05', 16);
				break;
			case 6:
				commandByte = 'D12106' + hexify(multiplierByte) + hexify(modByte);
				checksum += parseInt('D1', 16) + parseInt('21', 16) + parseInt('06', 16);
				break;
			case 7:
				commandByte = 'D12107' + hexify(multiplierByte) + hexify(modByte);
				checksum += parseInt('D1', 16) + parseInt('21', 16) + parseInt('07', 16);
				break;
			case 8:
				commandByte = 'D12108' + hexify(multiplierByte) + hexify(modByte);
				checksum += parseInt('D1', 16) + parseInt('21', 16) + parseInt('08', 16);
                break;
            case 9:
                commandByte = 'D12109' + hexify(multiplierByte) + hexify(modByte);
                checksum += parseInt('D1', 16) + parseInt('21', 16) + parseInt('09', 16);
                break;
            case 12:
                commandByte = 'D125' + hexify(modByte);
                checksum += parseInt('D1', 16) + parseInt('25', 16);
                break;
            case 13:
                //$AB$03$D1$23$11$08$BA
                commandByte = 'D123' + hexify(modByte);
                checksum += parseInt('D1', 16) + parseInt('23', 16);
                break;
			default:
				console.log('Wrong input of displays');
		}
	} else if (type === 2) {
		for (let i = 0; i < data.length; i++) {
			dataBytes += data[i].toUpperCase().charCodeAt().toString(16);
			checksum += data[i].toUpperCase().charCodeAt();
		}

		switch(display) {
			case 9:
				commandByte = 'D12009' + dataBytes;
				checksum += parseInt('D1', 16) + parseInt('20', 16) + parseInt('09', 16);
				break;
			case 10:
				commandByte = 'D12901' + dataBytes;
				checksum += parseInt('D1', 16) + parseInt('29', 16) + parseInt('01', 16);
				break;
			case 11:
				commandByte = 'D1290F' + dataBytes;
				checksum += parseInt('D1', 16) + parseInt('29', 16) + parseInt('0F', 16);
				break;
			default:
				console.log('Wrong input of displays');
		}
	}
	length = hexify(commandByte.length / 2);
	checksum += parseInt(length, 16)
	let finished = firstByte + length + commandByte + hexify(checksum) + lastByte;

  	return finished;
}

console.log(cricketLED(1,7,2))
console.log(-15 + 35);
console.log(-15 - 35);
console.log(35 - -15);