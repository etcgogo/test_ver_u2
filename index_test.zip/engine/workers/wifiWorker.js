//const WiFiControl = require('wifi-control');
const exec = require('child_process').exec;
const ErrorHandeler = require('../objects/errorHandeler');
const network = require("node-network-manager");

//const wifiSettings = {
//	debug: true,
//	iface: 'wlan0',
//	connectionTimeout: 10000,
//};

//WiFiControl.init(wifiSettings);

function scanWifi() {
	  network
		.getWifiList(true)
		.then((data) => console.log(data))
		.catch((error) => console.log(error));
}

function connectToWifi(ssid, password) {

	console.log('connectToWifi',ssid, password)
	network
		.wifiConnect(ssid, password)
		.then((data) => console.log(data))
		.catch((error) => console.log(error));
}

// function switchWifi(switcho, callback) {
// 	if (switcho) {
// 		exec('sudo nmcli radio wifi on', function(error, stdout, stderr) {
// 			if (error) {
// 				ErrorHandeler.newError(143, error);
// 				callback(false);
// 			} else {
// 				callback(true);
// 			}
// 		});
// 	} else {
// 		exec('sudo nmcli radio wifi off', function(error, stdout, stderr) {
// 			if (error) {
// 				ErrorHandeler.newError(144, error);
// 				callback(false);
// 			} else {
// 				callback(true);
// 			}
// 		});
// 	}
// }

// function getWifiStatus(callback) {
// 	exec('sudo nmcli radio wifi', function(error, stdout, stderr) {
// 		if (error) {
// 			ErrorHandeler.newError(145, error);
// 		} else {
// 			if (stdout[0].toString() === 'e') {
// 				callback(true);
// 			} else {
// 				callback(false);
// 			}
// 		}
// 	});
// }

module.exports = {
    scanWifi: scanWifi,
    connectToWifi: connectToWifi,
    //switchWifi: switchWifi,
    //getWifiStatus: getWifiStatus,
}
