const MenuService = require('../objects/MenuService');

let data = {};
let isX01 = MenuService.isX01;
let isCricket = MenuService.isCricket;
let isOther = MenuService.isOther;
let rules = MenuService.rules;
let isTeam = MenuService.teamCount > 1;
let isPublic = MenuService.isPub;
let creditNumber = MenuService.creditNumber;
let creditBuffer = MenuService.creditBuffer;
let bufferValute = $localStorage.bufferValute;
let gamPrice = $localStorage.gamePrice;
let gamePrice = 0;
let datum = new Date();
let date = $scope.datum.toLocaleString();
let hour = $scope.datum.getHours();
let minute = $scope.datum.getMinutes();
let undoHappy = false;
let change = 0;
let timedGame = $localStorage.timeGame;
let timeLeft = $localStorage.timeLeft;

/* DEFAULT */
data.killer = false;
data.master = false;
data.cutthroat = false;
data.playOff = false;
data.marks = false;
data.option200 = false;
data.quatro = false;
data.undo = false;
data.handicap = false;
data.parcheesi = false;
data.runAndGun = false;
data.doubleIn = false;
data.doubleOut = false;
data.masterOut = false;
data.equal = false;
data.end = false;
data.bull = false;
data.stacked = false;
let quattroMode = MenuService.activeMode.gameSettings.quattroMode;
let returnDart = MenuService.activeMode.gameSettings.returnDart;

data.scoreTypes = [{
        text: '301',
        score: 301,
        rounds: MenuService.activeMode.gameSettings.gameList[0].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[0].rounds,
        runAndGunTime: 45,
    },
    {
        text: '501',
        score: 501,
        rounds: MenuService.activeMode.gameSettings.gameList[1].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[1].rounds,
        runAndGunTime: 60,
    },
    {
        text: '701',
        score: 701,
        rounds: MenuService.activeMode.gameSettings.gameList[2].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[2].rounds,
        runAndGunTime: 90,
    },
    {
        text: '901',
        score: 901,
        rounds: MenuService.activeMode.gameSettings.gameList[3].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[3].rounds,
        runAndGunTime: 120,
    },
    {
        text: '1001',
        score: 1001,
        rounds: MenuService.activeMode.gameSettings.gameList[4].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[4].rounds,
        runAndGunTime: 150,
    },
];

$scope.data.cricketGameTypes = [{
        text: 'Cricket',
        type: CricketGameTypeEnum.cricket,
        rounds: MenuService.activeMode.gameSettings.gameList[5].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[5].rounds,
    },
    {
        text: 'Pickit',
        type: CricketGameTypeEnum.cricketPickit,
        rounds: MenuService.activeMode.gameSettings.gameList[6].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[6].rounds,
    },
    {
        text: 'Random',
        type: CricketGameTypeEnum.cricketRandom,
        rounds: MenuService.activeMode.gameSettings.gameList[7].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[7].rounds,
    },
    {
        text: 'Crazy',
        type: CricketGameTypeEnum.cricketCrazy,
        rounds: MenuService.activeMode.gameSettings.gameList[8].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[8].rounds,
    },

];

$scope.data.otherGameTypes = [{
        text: 'High Score',
        type: OtherGameTypeEnum.hiscore,
        active: 'btn-active',
        exist: true,
        rounds: $scope.isPublic ? (MenuService.activeMode.gameSettings.onlineGameList[10].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.onlineGameList[10].rounds) : (MenuService.activeMode.gameSettings.gameList[10].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[10].rounds),
        runAndGunTime: 60,
        score: 0
    },
    {
        text: 'Low Score',
        type: OtherGameTypeEnum.lowscore,
        active: '',
        exist: true,
        rounds: $scope.isPublic ? (MenuService.activeMode.gameSettings.onlineGameList[11].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.onlineGameList[11].rounds) : (MenuService.activeMode.gameSettings.gameList[11].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[11].rounds),
        runAndGunTime: 60,
        score: 0
    },
    {
        text: 'Super Score',
        type: OtherGameTypeEnum.superscore,
        active: '',
        exist: true,
        rounds: $scope.isPublic ? (MenuService.activeMode.gameSettings.onlineGameList[12].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.onlineGameList[12].rounds) : (MenuService.activeMode.gameSettings.gameList[12].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[12].rounds),
        runAndGunTime: 60,
        score: 0
    },
    {
        text: 'Split Score',
        type: OtherGameTypeEnum.splitscore,
        active: '',
        exist: true,
        rounds: $scope.isPublic ? (MenuService.activeMode.gameSettings.onlineGameList[13].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.onlineGameList[13].rounds) : (MenuService.activeMode.gameSettings.gameList[13].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[13].rounds),
        score: 40
    },
    {
        text: 'Pub Game',
        type: OtherGameTypeEnum.pubgame,
        active: '',
        exist: true,
        rounds: 1,
        score: 0,
        runAndGunTime: 15
    },
    {
        text: 'Mini Marathon',
        type: OtherGameTypeEnum.minimarathon,
        active: '',
        exist: true,
        rounds: 15
    },
    {
        text: 'Marathon',
        type: OtherGameTypeEnum.marathon,
        active: '',
        exist: true,
        rounds: 30
    },
    {
        text: 'Shangai',
        type: OtherGameTypeEnum.shangai,
        active: '',
        exist: true,
        rounds: 7
    },
    {
        text: 'Baseball',
        type: OtherGameTypeEnum.baseball,
        active: '',
        exist: true,
        rounds: 9
    },
    {
        text: 'Roulette',
        type: OtherGameTypeEnum.roulette,
        active: '',
        exist: false,
        rounds: $scope.isPublic ? (MenuService.activeMode.gameSettings.onlineGameList[14].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.onlineGameList[14].rounds) : (MenuService.activeMode.gameSettings.gameList[14].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[14].rounds),
    },
    {
        text: 'Roulette Double',
        type: OtherGameTypeEnum.baseball,
        active: '',
        exist: false,
        rounds: $scope.isPublic ? (MenuService.activeMode.gameSettings.onlineGameList[15].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.onlineGameList[15].rounds) : (MenuService.activeMode.gameSettings.gameList[15].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[15].rounds),
    },
    {
        text: 'Scram',
        type: OtherGameTypeEnum.scram,
        active: '',
        exist: false,
        rounds: $scope.isPublic ? (MenuService.activeMode.gameSettings.onlineGameList[16].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.onlineGameList[16].rounds) : (MenuService.activeMode.gameSettings.gameList[16].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[16].rounds),
    },
];

if (!$scope.isTeam) {
    $scope.data.cricketGameTypes.push( {
        text: 'Pig',
        type: CricketGameTypeEnum.cricketPig,
        rounds: $scope.isPublic ? (MenuService.activeMode.gameSettings.onlineGameList[9].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.onlineGameList[9].rounds) : (MenuService.activeMode.gameSettings.gameList[9].rounds === 'Unlimited' ? 999999 : MenuService.activeMode.gameSettings.gameList[8].rounds),
        active: '',
        exist: true
    });
}

if ($scope.isX01) {
    $scope.data.isX01 = true;
    $scope.data.isCricket = false;
    $scope.data.isOther = false;
    $scope.currentGameType = $scope.data.scoreTypes[0];
    $scope.data.numberOfRounds = $scope.currentGameType.rounds;
} else if ($scope.isCricket) {
    $scope.data.isX01 = false;
    $scope.data.isCricket = true;
    $scope.data.isOther = false;
    $scope.currentGameType = $scope.data.cricketGameTypes[0];
    $scope.data.numberOfRounds = $scope.currentGameType.rounds;
} else if ($scope.isOther){
    $scope.data.isX01 = false;
    $scope.data.isCricket = false;
    $scope.data.isOther = true;
    $scope.data.handicap = false;
    $scope.currentGameType = $scope.data.otherGameTypes[0];
    $scope.data.numberOfRounds = $scope.currentGameType.rounds;
}
$scope.data.gameTypes = [{
        text: 'X01',
        gameType: GameTypeEnum.x01,
        active: 'btn-active'
    },
    {
        text: 'Cricket',
        gameType: GameTypeEnum.cricket,
        active: ''
    },
    {
        text: 'Other Games',
        active: ''
    }
];

MenuService.activeMode.moneyCredits.gamePrice.gameList.forEach(function(element) {
    if ($scope.currentGameType.text === element.name) {
        if (MenuService.activeMode.moneyCredits.creditMode) {
            if ($scope.isPublic) {
                $scope.gamePrice = element.onlinePrice;
            } else { 
                $scope.gamePrice = element.price;
            }
        } else {
            if ($scope.isPublic) {
                for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                    if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                        $scope.gamePrice = element.moneyOnlinePrice[i].price;
                        break;
                    }
                }
            } else {
                for (var i = 0; i < element.moneyPrice.length; i++) {
                    if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                        $scope.gamePrice = element.moneyPrice[i].price;
                        break;
                    }
                }
            }
        }
    }
    if (MenuService.activeMode.moneyCredits.freeplayMode) {
        $scope.gamePrice = 'Freeplay';
    }
});

// SCOPE EVENTS

$scope.backButton = function() {
    MediaService.playBackButtonClick();
    MenuService.teamCount = (MenuService.teamCount > 1) ? 0 : 1;
    $state.go(_return);
};

$scope.homeButton = function() {
    MediaService.playBackButtonClick();
    $state.go('menu');
};

$scope.cutthroatSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.killer === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Killer') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else if (MenuService.activeMode.moneyCredits.creditMode === false) {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.killer = false;

    if ($scope.data.master === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Master') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else if (MenuService.activeMode.moneyCredits.creditMode === false) {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.master = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Cut-throat') {
            if ($scope.data.cutthroat === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });

    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.doubleInSelected = function() {
    MediaService.playSliderSound();
    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Double in') {
            if ($scope.data.doubleIn === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.doubleOutSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.masterOut === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Master out') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else if (MenuService.activeMode.moneyCredits.creditMode === false) {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.masterOut = false;
    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Double out') {
            if ($scope.data.doubleOut === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.quatroSelected = function() {
    MediaService.playSliderSound();
    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Quattro') {
            if ($scope.data.quatro === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.handicapSelected = function() {
    MediaService.playSliderSound();
    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Handicap') {
            if ($scope.data.handicap === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.marksSelected = function() {
    MediaService.playSliderSound();
    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Marks') {
            if ($scope.data.marks === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.option200Selected = function() {
    MediaService.playSliderSound();
    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === '200') {
            if ($scope.data.option200 === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.endSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.equal === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Equal') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.equal = false;

    if ($scope.data.playOff === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Playoff') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.playOff = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'End') {
            if ($scope.data.end === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.bullSelected = function() {
    MediaService.playSliderSound();
    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'BE(25/50)') {
            if ($scope.data.bull === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.equalSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.end === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'End') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.end = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Equal') {
            if ($scope.data.equal === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.killerSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.master === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Master') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.master = false;

    if ($scope.data.cutthroat === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Cut-throat') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.cutthroat = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Killer') {
            if ($scope.data.killer === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.masterOutSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.doubleOut === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Double out') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.doubleOut = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Master out') {
            if ($scope.data.masterOut === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.masterSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.killer === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Killer') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.killer = false;

    if ($scope.data.cutthroat === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Cut-throat') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.cutthroat = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Master') {
            if ($scope.data.master === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.undoSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.runAndGun === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Run & Gun') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.runAndGun = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Undo') {
            if ($scope.data.undo === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });

    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.parcheesiSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.runAndGun === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Run & Gun') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.runAndGun = false;

    if ($scope.data.playOff === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Playoff') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.playOff = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Parcheesi') {
            if ($scope.data.parcheesi === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });

    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.playOffSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.end === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'End') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.end = false;

    if ($scope.data.runAndGun === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Run & Gun') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.runAndGun = false;

    if ($scope.data.parcheesi === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Parcheesi') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.parcheesi = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Playoff') {
            if ($scope.data.playOff === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });

    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.runAndGunSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.parcheesi === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Parcheesi') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.parcheesi = false;

    if ($scope.data.playOff === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Playoff') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.playOff = false;

    if ($scope.data.undo === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Undo') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.undo = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Run & Gun') {
            if ($scope.data.runAndGun === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });

    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.stackedSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.freeze === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Freeze') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.freeze = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Stacked') {
            if ($scope.data.stacked === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });

    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.freezeSelected = function() {
    MediaService.playSliderSound();
    if ($scope.data.stacked === true) {
        MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
            if (element.name === 'Stacked') {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
    $scope.data.stacked = false;

    MenuService.activeMode.moneyCredits.gamePrice.optionList.forEach(function(element) {
        if (element.name === 'Freeze') {
            if ($scope.data.freeze === true) {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice += element.onlinePrice;
                    } else {
                        $scope.gamePrice += element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice += element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            } else {
                if (MenuService.activeMode.moneyCredits.creditMode === true) {
                    if ($scope.isPublic) {
                        $scope.gamePrice -= element.onlinePrice;
                    } else {
                        $scope.gamePrice -= element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice -= element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
        }
    });

    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        $scope.gamePrice = 'Freeplay';
    }
    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }
};

$scope.navigateToPlayersMenu = function() {
    MediaService.playButtonClick();
    var gameType = 0;
    for (var i = 0; i < $scope.data.gameTypes.length; i++) {
        var item = $scope.data.gameTypes[i];
        if (item.active !== '') {
            gameType = item.gameType;
            break;
        }
    }
    if ($scope.isTeam) {
        MenuService.setTeamRules({
            stacked: $scope.data.stacked,
            freeze: $scope.data.freeze
        });
    }
    if ($scope.isX01) {
        MenuService.setX01Rules(GameTypeEnum.x01,
            $scope.currentGameType.score,
            $scope.data.parcheesi,
            $scope.data.numberOfRounds,
            $scope.data.runAndGun,
            $scope.currentGameType.runAndGunTime,
            $scope.data.playOff,
            $scope.data.doubleIn,
            $scope.data.doubleOut,
            $scope.data.masterOut,
            $scope.data.equal,
            $scope.data.end,
            $scope.data.quatro,
            $scope.data.undo,
            $scope.data.handicap,
            $scope.data.bull);
        $scope.rules = MenuService.rules;
    } else if ($scope.isCricket) {
        var cricketOption = CricketOptionEnum.NoOption;
        if ($scope.data.killer === true) {
            cricketOption = CricketOptionEnum.Killer;
        } else if ($scope.data.master === true) {
            cricketOption = CricketOptionEnum.Master;
        } else if ($scope.data.cutthroat === true) {
            cricketOption = CricketOptionEnum.CutThroat;
        }
        MenuService.setCricketRules(GameTypeEnum.cricket,
            $scope.data.numberOfRounds,
            $scope.currentGameType.type,
            cricketOption,
            $scope.data.playOff,
            $scope.data.marks,
            $scope.data.option200,
            $scope.data.quatro,
            $scope.data.undo,
            $scope.data.handicap);
        $scope.rules = MenuService.rules;
    } else if ($scope.isOther){
        MenuService.setOtherRules($scope.currentGameType.type,
            $scope.currentGameType.score,
            $scope.data.parcheesi,
            $scope.data.numberOfRounds,
            $scope.data.runAndGun,
            $scope.currentGameType.runAndGunTime,
            $scope.data.playOff,
            $scope.data.doubleIn,
            $scope.data.doubleOut,
            $scope.data.masterOut,
            $scope.data.equal,
            $scope.data.end,
            $scope.data.quatro,
            $scope.data.undo,
            $scope.data.handicap,
            $scope.data.bull);
        $scope.rules = MenuService.rules;
    }
    if (MenuService.activeMode.moneyCredits.freeplayMode === true) {
        MenuService.gameCost = 0;
    } else {
        MenuService.gameCost = $scope.gamePrice;
    }
    MenuService.currentGameName = $scope.currentGameType.text;
    $state.go(_redirect);
};

$scope.nextGameType = function() {
    MediaService.playButtonClick();
    var index;
    if ($scope.isX01) {
        index = $scope.data.scoreTypes.indexOf($scope.currentGameType);
        index = (index + 1) % $scope.data.scoreTypes.length;
        $scope.currentGameType = $scope.data.scoreTypes[index];
        $scope.data.numberOfRounds = $scope.currentGameType.rounds;
    } else if ($scope.isCricket) {
        index = $scope.data.cricketGameTypes.indexOf($scope.currentGameType);
        index = (index + 1) % $scope.data.cricketGameTypes.length;
        $scope.currentGameType = $scope.data.cricketGameTypes[index];
        $scope.data.numberOfRounds = $scope.currentGameType.rounds;
    } else if ($scope.isOther) {
        index = $scope.data.otherGameTypes.indexOf($scope.currentGameType);
        index = (index + 1) % $scope.data.otherGameTypes.length;
        $scope.currentGameType = $scope.data.otherGameTypes[index];
        $scope.data.numberOfRounds = $scope.currentGameType.rounds;
    }

    MenuService.activeMode.moneyCredits.gamePrice.gameList.forEach(function(element) {
        if ($scope.currentGameType.text === element.name) {
            if (MenuService.activeMode.moneyCredits.creditMode) {
                if ($scope.isPublic) {
                    $scope.gamePrice = element.onlinePrice;
                } else { 
                    $scope.gamePrice = element.price;
                }
            } else {
                if ($scope.isPublic) {
                    for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                        if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                            $scope.gamePrice = element.moneyOnlinePrice[i].price;
                            break;
                        }
                    }
                } else {
                    for (var i = 0; i < element.moneyPrice.length; i++) {
                        if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                            $scope.gamePrice = element.moneyPrice[i].price;
                            break;
                        }
                    }
                }
            }
        }
        if (MenuService.activeMode.moneyCredits.freeplayMode) {
            $scope.gamePrice = 'Freeplay';
        }
    });

    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }

    $scope.data.killer = false;
    $scope.data.master = false;
    $scope.data.cutthroat = false;
    $scope.data.playOff = false;
    $scope.data.marks = false;
    $scope.data.option200 = false;
    $scope.data.quatro = false;
    $scope.data.undo = false;
    $scope.data.handicap = false;
    $scope.data.parcheesi = false;
    $scope.data.runAndGun = false;
    $scope.data.doubleIn = false;
    $scope.data.doubleOut = false;
    $scope.data.masterOut = false;
    $scope.data.equal = false;
    $scope.data.end = false;
    $scope.data.bull = false;
    $scope.data.stacked = false;
};

$scope.previousGameType = function() {
    MediaService.playButtonClick();
    var index;
    if ($scope.isX01) {
        index = $scope.data.scoreTypes.indexOf($scope.currentGameType);
        index = (index + $scope.data.scoreTypes.length - 1) % $scope.data.scoreTypes.length;
        $scope.currentGameType = $scope.data.scoreTypes[index];
        $scope.data.numberOfRounds = $scope.currentGameType.rounds;
    } else if ($scope.isCricket) {
        index = $scope.data.cricketGameTypes.indexOf($scope.currentGameType);
        index = (index + $scope.data.cricketGameTypes.length - 1) % $scope.data.cricketGameTypes.length;
        $scope.currentGameType = $scope.data.cricketGameTypes[index];
        $scope.data.numberOfRounds = $scope.currentGameType.rounds;
    } else if ($scope.isOther) {
        index = $scope.data.otherGameTypes.indexOf($scope.currentGameType);
        index = (index + $scope.data.otherGameTypes.length - 1) % $scope.data.otherGameTypes.length;
        $scope.currentGameType = $scope.data.otherGameTypes[index];
        $scope.data.numberOfRounds = $scope.currentGameType.rounds;
    }

    MenuService.activeMode.moneyCredits.gamePrice.gameList.forEach(function(element) {
        if ($scope.currentGameType.text === element.name) {
            if (MenuService.activeMode.moneyCredits.creditMode) {
                if ($scope.isPublic) {
                    $scope.gamePrice = element.onlinePrice;
                } else { 
                    $scope.gamePrice = element.price;
                }
            } else {
                if ($scope.isPublic) {
                    for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                        if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                            $scope.gamePrice = element.moneyOnlinePrice[i].price;
                            break;
                        }
                    }
                } else {
                    for (var i = 0; i < element.moneyPrice.length; i++) {
                        if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                            $scope.gamePrice = element.moneyPrice[i].price;
                            break;
                        }
                    }
                }
            }
        }
        if (MenuService.activeMode.moneyCredits.freeplayMode) {
            $scope.gamePrice = 'Freeplay';
        }
    });

    setRules();
    $scope.isHappy = checkHappy();
    if ($scope.undoHappy) {
        $scope.gamePrice += $scope.change;
        $scope.change = 0;
        $scope.undoHappy = false;
    }

    $scope.data.killer = false;
    $scope.data.master = false;
    $scope.data.cutthroat = false;
    $scope.data.playOff = false;
    $scope.data.marks = false;
    $scope.data.option200 = false;
    $scope.data.quatro = false;
    $scope.data.undo = false;
    $scope.data.handicap = false;
    $scope.data.parcheesi = false;
    $scope.data.runAndGun = false;
    $scope.data.doubleIn = false;
    $scope.data.doubleOut = false;
    $scope.data.masterOut = false;
    $scope.data.equal = false;
    $scope.data.end = false;
    $scope.data.bull = false;
    $scope.data.stacked = false;
};

$scope.switchValute = function () {
    if ($scope.creditMode === false) {
        for (var index = 0; index < MenuService.activeMode.moneyCredits.credits.creditPrice.length; index++) {
            if (MenuService.activeMode.moneyCredits.credits.creditPrice[index].valute === $scope.bufferValute) {
                if ((index + 1) <= (MenuService.activeMode.moneyCredits.credits.creditPrice.length - 1)) {
                    $scope.bufferValute = MenuService.activeMode.moneyCredits.credits.creditPrice[index+1].valute;
                    $localStorage.bufferValute = MenuService.activeMode.moneyCredits.credits.creditPrice[index+1].valute;
                    break;
                } else {
                    $scope.bufferValute = MenuService.activeMode.moneyCredits.credits.creditPrice[0].valute;
                    $localStorage.bufferValute = MenuService.activeMode.moneyCredits.credits.creditPrice[0].valute;
                    break;
                }
            }
        }
        for (var i = 0; i < MenuService.activeMode.moneyCredits.credits.creditBuffer.length; i++) {
            if ($scope.bufferValute === MenuService.activeMode.moneyCredits.credits.creditBuffer[i].valute) {
                $scope.creditBuffer = MenuService.activeMode.moneyCredits.credits.creditBuffer[i].buffer.toFixed(2);
                $localStorage.creditBuffer = MenuService.activeMode.moneyCredits.credits.creditBuffer[i].buffer.toFixed(2);
                break;
            }
        }
        
        MenuService.activeMode.moneyCredits.gamePrice.gameList.forEach(function(element) {
            if ($scope.currentGameType.text === element.name) {
                if (MenuService.activeMode.moneyCredits.creditMode) {
                    if ($scope.isPublic) {
                        $scope.gamePrice = element.onlinePrice;
                    } else { 
                        $scope.gamePrice = element.price;
                    }
                } else {
                    if ($scope.isPublic) {
                        for (var i = 0; i < element.moneyOnlinePrice.length; i++) {
                            if (element.moneyOnlinePrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice = element.moneyOnlinePrice[i].price;
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < element.moneyPrice.length; i++) {
                            if (element.moneyPrice[i].valute === $localStorage.bufferValute) {
                                $scope.gamePrice = element.moneyPrice[i].price;
                                break;
                            }
                        }
                    }
                }
            }
            if (MenuService.activeMode.moneyCredits.freeplayMode) {
                $scope.gamePrice = 'Freeplay';
            }
        });

        $scope.data.killer = false;
        $scope.data.master = false;
        $scope.data.cutthroat = false;
        $scope.data.playOff = false;
        $scope.data.marks = false;
        $scope.data.option200 = false;
        $scope.data.quatro = false;
        $scope.data.undo = false;
        $scope.data.handicap = false;
        $scope.data.parcheesi = false;
        $scope.data.runAndGun = false;
        $scope.data.doubleIn = false;
        $scope.data.doubleOut = false;
        $scope.data.masterOut = false;
        $scope.data.equal = false;
        $scope.data.end = false;
        $scope.data.bull = false;
        $scope.data.stacked = false;
    }
};

function creditChanged () {
    $scope.creditNumber = $localStorage.creditNumber;
}

function bufferChanged () {
    $scope.creditBuffer = $localStorage.creditBuffer;
    $scope.bufferValute = $localStorage.bufferValute;
    let found = false;
    for (var index = 0; index < MenuService.activeMode.moneyCredits.credits.creditPrice.length; index++) {
        if (MenuService.activeMode.moneyCredits.credits.creditPrice[index].valute === $scope.bufferValute) {
            $scope.gamPrice = MenuService.activeMode.moneyCredits.credits.creditPrice[index].price;
            $localStorage.gamePrice = $scope.gamPrice;
            found = true;
        }
        if (found === true) {
            break;
        }
    }
    $scope.output = $scope.creditBuffer / $scope.gamPrice;
}

function timerChanged () {
    $scope.timeLeft = $localStorage.timeLeft;
    $scope.timedGame = $localStorage.timeGame;
}

function checkHappy () {
    if (MenuService.activeMode.moneyCredits.happyHourMode === false) {
        return false;
    }

    $scope.gameName = stringifyGameTitle(MenuService.rules);
    let isHappy = false;
    let index = 0;
    for (var i = 0; i < MenuService.activeMode.moneyCredits.happyHour.length; i++) {
        if ($scope.gameName === MenuService.activeMode.moneyCredits.happyHour[i].gameName) {
            if (Date.parse(MenuService.activeMode.moneyCredits.happyHour[i].date) === Date.parse($scope.date.slice(0,10)) || (MenuService.activeMode.moneyCredits.happyHour[i].repeat && MenuService.activeMode.moneyCredits.happyHour[i].date.getDay() === $scope.date.getDay())) {
                if (Number(MenuService.activeMode.moneyCredits.happyHour[i].from.slice(0,2)) <= Number($scope.hour) <= Number(MenuService.activeMode.moneyCredits.happyHour[i].to.slice(0,2))) {
                    if ($scope.hour !== MenuService.activeMode.moneyCredits.happyHour[i].from.slice(0,2) && $scope.hour !== MenuService.activeMode.moneyCredits.happyHour[i].to.slice(0,2)) {
                        isHappy = true;
                        index = i;
                        break;
                    } else if ($scope.hour === MenuService.activeMode.moneyCredits.happyHour[i].from.slice(0,2)) {
                        if (MenuService.activeMode.moneyCredits.happyHour[i].from.slice(3,5) < $scope.minute) {
                            isHappy = true;
                            index = i;
                            break;
                        }
                    } else if ($scope.hour === MenuService.activeMode.moneyCredits.happyHour[i].to.slice(0,2)) {
                        if (MenuService.activeMode.moneyCredits.happyHour[i].to.slice(3,5) > $scope.minute) {
                            isHappy = true;
                            index = i;
                            break;
                        }
                    }
                }
            }
        }
    }
    if (isHappy === true) {
        console.log('promjenio sam cijenu jer je happy');
        if (MenuService.activeMode.moneyCredits.happyHour[index].price !== 'Free') {
            $scope.change = $scope.gamePrice - MenuService.activeMode.moneyCredits.happyHour[index].price;
        } else if (MenuService.activeMode.moneyCredits.happyHour[index].price === 'Free') {
            $scope.change = $scope.gamePrice
        }
        $scope.gamePrice = MenuService.activeMode.moneyCredits.happyHour[index].price === 'Free' ? 0 : MenuService.activeMode.moneyCredits.happyHour[index].price;
        console.log($scope.gamePrice, 'cijena sad');
        console.log(MenuService.activeMode.moneyCredits.happyHour[index].price, 'cijena u listi');
    } else if (isHappy === false && $scope.change !== 0) {
        $scope.undoHappy = true;
    }
    return isHappy;
}

function setRules () {
    if ($scope.isX01) {
        MenuService.setX01Rules(GameTypeEnum.x01,
            $scope.currentGameType.score,
            $scope.data.parcheesi,
            $scope.data.numberOfRounds,
            $scope.data.runAndGun,
            $scope.currentGameType.runAndGunTime,
            $scope.data.playOff,
            $scope.data.doubleIn,
            $scope.data.doubleOut,
            $scope.data.masterOut,
            $scope.data.equal,
            $scope.data.end,
            $scope.data.quatro,
            $scope.data.undo,
            $scope.data.handicap,
            $scope.data.bull);
        $scope.rules = MenuService.rules;
    } else if ($scope.isCricket) {
        var cricketOption = CricketOptionEnum.NoOption;
        if ($scope.data.killer === true) {
            cricketOption = CricketOptionEnum.Killer;
        } else if ($scope.data.master === true) {
            cricketOption = CricketOptionEnum.Master;
        } else if ($scope.data.cutthroat === true) {
            cricketOption = CricketOptionEnum.CutThroat;
        }
        MenuService.setCricketRules(GameTypeEnum.cricket,
            $scope.data.numberOfRounds,
            $scope.currentGameType.type,
            cricketOption,
            $scope.data.playOff,
            $scope.data.marks,
            $scope.data.option200,
            $scope.data.quatro,
            $scope.data.undo,
            $scope.data.handicap);
        $scope.rules = MenuService.rules;
    } else if ($scope.isOther){
        MenuService.setOtherRules($scope.currentGameType.type,
            $scope.currentGameType.score,
            $scope.data.parcheesi,
            $scope.data.numberOfRounds,
            $scope.data.runAndGun,
            $scope.currentGameType.runAndGunTime,
            $scope.data.playOff,
            $scope.data.doubleIn,
            $scope.data.doubleOut,
            $scope.data.masterOut,
            $scope.data.equal,
            $scope.data.end,
            $scope.data.quatro,
            $scope.data.undo,
            $scope.data.handicap,
            $scope.data.bull);
        $scope.rules = MenuService.rules;
    }
    console.log(MenuService.rules);
}