const Game = require('./Game');
const CricketRules = require('./cricketRules');
const OtherRules = require('./otherGamerules');
const GameStatus = require('./gameStatus');
const Sounds = require('../workers/soundWorker');

module.exports = class CricketGame extends Game {
	constructor() {
		super();
		this.dartsToCloseNumber = 3;
		this.rules.currentPigDart = 20;
		this.numbersHistory = [];
	}
	resumeGameData(gameService, darts, rules, awaitApproach) {
		console.log('uđe u resumeGameStatus u engineu');
		this.gameStatus.currentDart = gameService.currentDart;
		this.gameStatus.currentPlayer = gameService.currentPlayer;
		this.gameStatus.gameOver = gameService.gameOver;
		this.gameStatus.message = gameService.message;
		this.gameStatus.players = gameService.players;
		this.players = gameService.players;
		this.gameStatus.round = gameService.round;
		this.gameStatus.roundStartScore = gameService.roundStartScore;
		this.gameStatus.teamRoundStartScore = gameService.teamRoundStartScore;
		this.gameStatus.teams = gameService.teams;
		this.gameStatus.darts = darts;
		this.rules.numbersToClose = rules.numbersToClose;
		this.awaitApproach = awaitApproach;
	}
	create(rules, players, teams, keepPlayersAsIs) {
		if (!(rules instanceof CricketRules || rules instanceof OtherRules)) {
			// Rules not valid
			return false;
		}
		if (!Game.prototype.create.call(this, rules, players, teams, true)) {
			// Unable to create the game
			return false;
		}
		if (this.rules.otherGameType === 4 || this.rules.otherGameType === 9) {
			this.rules.currentPigDart = this.rules.numbersToClose[0];
			this.splitHit = false;
			if (this.rules.quatro === true && this.rules.otherGameType === 4) {
				this.rules.rounds = 12;
			}
			else {
				this.rules.rounds = 9;
			}
		} else if (this.rules.otherGameType === 10) {
			this.rules.currentPigDart = this.rules.numbersToClose[0];
			this.rules.numbersChosen = true;
		}
		if (this.rules.otherGameType === 8 || this.rules.otherGameType === 7 || this.rules.otherGameType === 6) {
			this.wassingle = false;
			this.wasdouble = false;
			this.wastriple = false;
			this.wasquatro = false;
			this.rules.currentPigDart = this.rules.numbersToClose[0];
			this.splitHit = false;
		}
		this.setPlayerStartingScore();
		this.setTeamStartingScores();
		this.setHandicapScores();
		this.gameStatus = new GameStatus(this.players, this.teams);
		return true;
	}
	setPlayerStartingScore() {
		// Set starting number of darts to players
		if (this.rules.otherGameType === 4) {
			this.dartsToCloseNumber = 3;
			this.players.forEach((_player) => {
				_player.score = 40;
				this.rules.numbersToClose.forEach((_number) => {
					_player.numbersToHit[_number] = 0;
					_player.noOfDartsRemaining += 3;
				});
			});
		}
		this.players.forEach((_player) => {
			this.rules.numbersToClose.forEach((_number) => {
				_player.numbersToHit[_number] = this.dartsToCloseNumber;
				_player.noOfDartsRemaining += this.dartsToCloseNumber;
			});
		});
	}
	setTeamStartingScores() {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		if (!isTeamGame) {
			// Not a team game
			return;
		}
		const requiredHits = (!isStacked) ? this.players.filter((_player) => (_player.teamId === 0)).length * this.dartsToCloseNumber : this.dartsToCloseNumber;
		this.teams.forEach((_team) => {
			_team.numbersToHit = {};
			this.rules.numbersToClose.forEach((_number) => {
				_team.numbersToHit[_number] = requiredHits;
			});
		});
		if (this.rules.otherGameType === 4) {
			this.teams.forEach((_team) => {
				_team.numbersToHit = {};
				_team.score = 40;
				this.rules.numbersToClose.forEach((_number) => {
					_team.numbersToHit[_number] = requiredHits;
				});
			});
		}
	}
	setHandicapScores() {
		if (!this.rules.handicap) {
			return;
		}
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		let teamsOver3 = false;
		if (isTeamGame) {
			this.teams.forEach(_team => {
				let teammates = this.players.filter(_player => _player.teamId === _team.id);
				let totalMPR = 0;
				teammates.forEach(_player => totalMPR += +_player.owner.mpr || 0);
				_team.mpr = totalMPR / teammates.length;
			});
			teamsOver3 = this.teams.every(_team => _team.mpr >= 3.0);
			if (isStacked) {
				const highMPR = Math.max(...this.teams.map(_team => _team.mpr));
				if (highMPR > 0) {
					this.teams.forEach(_team => {
						let handicapDarts = this.getHandicapDarts(_team.mpr, highMPR - _team.mpr, teamsOver3);
						this.allocateHandicapDarts(_team, handicapDarts);
						this.players.filter(_player => _player.teamId === _team.id)
							.forEach(_player => this.allocateHandicapDarts(_player, handicapDarts));
					});
				}
				return;
			}
		}
		const highMPR = Math.max(...this.players.map(_player => +_player.owner.mpr || 0));
		if (highMPR > 0) {
			this.players.forEach(_player => {
				let handicapDarts = this.getHandicapDarts(_player.owner.mpr, highMPR - _player.owner.mpr, teamsOver3);
				this.allocateHandicapDarts(_player, handicapDarts);
				if (isTeamGame) { // non-stacked team
					let team = this.teams.find(_team => _team.id === _player.teamId);
					this.allocateHandicapDarts(team, handicapDarts);
				}
			});
		}
	}
	getHandicapDarts(entityMPR, diffMPR, teamsHighMPR) {
		diffMPR = +diffMPR.toFixed(2);
		let darts = Math.floor(diffMPR * 10); // first column
		darts = (entityMPR > 2.0) ? Math.round(diffMPR * 10 / 1.5) : darts; // second column
		darts = teamsHighMPR ? Math.floor(diffMPR * 10 / 2) : darts; // third column
		darts = darts > 14 ? 14 : darts;
		return darts;
	}
	allocateHandicapDarts(entity, handicapDarts) {
		let firstIteration = true; // used to make the second handicap dart go to the final number
		while (handicapDarts) {
			this.rules.numbersToClose.every((_number, _index) => {
				if (firstIteration && _index === 1) {
					// second dart goes to final number
					let finalNumber = this.rules.numbersToClose[this.rules.numbersToClose.length - 1];
					entity.numbersToHit[finalNumber]--;
					entity.noOfDartsRemaining = entity.noOfDartsRemaining ? entity.noOfDartsRemaining - 1 : undefined; // team does not have this
					handicapDarts--;
				}
				if (firstIteration && _index === this.rules.numbersToClose.length - 1) {
					// final number has been reached in first iteration
					// a dart has already been allocated to it
					firstIteration = false;
					return true;
				}
				if (handicapDarts && entity.numbersToHit[_number] !== 1) {
					// standard handicap dart allocation
					entity.numbersToHit[_number]--;
					entity.noOfDartsRemaining = entity.noOfDartsRemaining ? entity.noOfDartsRemaining - 1 : undefined; // team does not have this
					handicapDarts--;
				}
				return handicapDarts;
			});
		}
	}
	// Add dart to game
	addDart(dart) {
		if (Game.prototype.addDart.call(this, dart) === null) {
			return null;
		}
		if (this.rules.playOff && this.gameStatus.gameOver && this.playOffStarted) {
			// Playoff
			this.playoffGame.addDart(dart);
			return this.playoffGame.gameStatus;
		}
		const isPickit = this.rules.cricketGameTypeEnum === 2;
		if (isPickit && !this.rules.numbersChosen) {
			// Choose numbers before starting the game
			if (dart.hitEnum <= 0) {
				// Invalid number selected
			}
			else if (this.rules.numbersToClose.indexOf(dart.hitEnum) < 0) {
				// Add the new number to the list: dart.hitEnum
				this.rules.numbersToClose.push(dart.hitEnum);
				this.rules.numbersToClose.sort((a, b) => (a - b));
				if (this.rules.numbersToClose.length === this.rules.numberOfNumbers) {
					// All numbers chosen
					this.rules.numbersChosen = true;
					this.setPlayerStartingScore();
				}
			}
			else {
				// Number already chosen
				this.rules.overCountDart++;
			}
			return this.gameStatus;
		}
		// Update scores and dart numbers
		const player = this.gameStatus.getCurrentPlayer();
		const firstPlayer = this.players[0];
		this.setDartCount(player, dart);
		this.nextDart();
		this.updatePigDart(dart.hitEnum);
		this.players.forEach((_player) => {
			const remainingRequiredHits = this.remainingRequiredHits(_player);
			if (remainingRequiredHits === 0 && this.rules.otherGameType !== 8) {
				this.handleAllNumbersClosed(_player);
			}
		});
		if (this.gameStatus.round > this.rules.rounds) {
			// No more rounds - Game over
			this.handleNoMoreRounds();
		}
		let totalPlayerDarts = this.darts.filter((_dart) => (_dart.player === player.id && [-2, -3, -4, -5].indexOf(_dart.hitEnum) < 0)).length;
		if (player.id === firstPlayer.id && isPickit && this.rules.numbersChosen) {
			totalPlayerDarts = totalPlayerDarts - (7 + this.rules.overCountDart);
		}
		player.avgStatistic = (totalPlayerDarts > 0) ? (player.totalScore * 3 / totalPlayerDarts).toFixed(2) : '-';
		return this.gameStatus;
	}
	handleNoMoreRounds() {
		// No more rounds - Game Over / Playoff
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		const isPlayOff = this.rules.playOff;
		this.gameStatus.gameOver = true;
		this.gameStatus.round = this.rules.rounds;
		this.gameStatus.message = 'No more rounds';
		if (!isStacked && isPlayOff) {
			const leaders = this.getLeader();
			if (leaders.length > 1) {
				this.startPlayoff(leaders);
			}
		}
	}
	handleAllNumbersClosed(player) {
		// Scenario where player or a team closed all the numbers they needed
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		const isMarks = this.rules.marks;
		if (isMarks) {
			this.gameStatus.gameOver = true;
			this.gameStatus.message = 'Game over! ' + (isStacked ? 'Team' : 'Player') + ' wins!';
			return;
		}
		if (isStacked) {
			const leaders = this.getLeadingTeamsIds();
			if (leaders.indexOf(player.teamId) >= 0) {
				this.gameStatus.gameOver = true;
				this.gameStatus.message = 'Game over! Team wins!';
			}
			return;
		}
		const leaders = this.getLeader();
		if (!isTeamGame && leaders.indexOf(player) >= 0) {
			this.gameStatus.gameOver = true;
			this.gameStatus.message = 'Game over! Player wins!';
		}
		const leadingTeams = this.getLeadingTeamsIds();
		if (isTeamGame && leadingTeams.indexOf(player.teamId) >= 0) {
			let teammates = this.players.filter((_player) => (_player.teamId === player.teamId));
			let winCondition = !teammates.some((_player) => (_player.numbersToHit.some((hitEnum) => (hitEnum > 0))));
			if (winCondition) {
				this.gameStatus.gameOver = true;
				this.gameStatus.message = 'Game over! Team wins!';
			}
		}
	}
	irApproach() {
		// Override for when a player approaches the board
		if (!this.rules.numbersChosen) {
			return;
		}
		Game.prototype.irApproach.call(this);
	}
	irLeave() {
		// Override for when a player leaves the board
		Game.prototype.irLeave.call(this);
	}
	setDartCount(player, dart) {
		// Update dart count and score for dart thrown
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		const isPig = this.rules.cricketGameTypeEnum === 5;
		const isSplit = this.rules.otherGameType === 4;
		const isBaseball = this.rules.otherGameType === 9;
		const isRoulette = this.rules.otherGameType === 10;
		const isShangai = this.rules.otherGameType === 8;
		const isMarathon = this.rules.otherGameType === 7;
		const isMiniMarathon = this.rules.otherGameType === 6;
		const isCutThroat = this.rules.cricketOptionEnum === 4;
		const isMaster = this.rules.cricketOptionEnum === 3;
		const isKiller = this.rules.cricketOptionEnum === 2;
		const invertScore = isCutThroat || isMaster || isKiller;
		const currentPlayer = this.gameStatus.getCurrentPlayer();
		let scoreToSelf = false;
		let scoreToOthers = false;
		let score = 0;
		let overhit = 0;
		let team = (isTeamGame) ? this.teams.find((_team) => (_team.id === player.teamId)) : undefined;
		if (isShangai || isMarathon || isMiniMarathon) {
			this.rules.currentPigDart = this.rules.numbersToClose[player.shangaiNo];
		}
		// For Pig games and Split Score, only current number to hit is allowed, for other games any number from the list
		var isAllowedNumber = (isPig || isSplit || isShangai || isMarathon || isMiniMarathon || isBaseball || isRoulette) ? dart.hitEnum === this.rules.currentPigDart : this.rules.numbersToClose.indexOf(dart.hitEnum) >= 0;
		if ((isMiniMarathon || isMarathon) && isAllowedNumber && dart.isDouble === false) {
			isAllowedNumber = false;
		}
		if (this.rules.currentPigDart === 22 || this.rules.currentPigDart === 23 || this.rules.currentPigDart === 24) {
			isAllowedNumber = true;
		}
		if (isAllowedNumber) {
			let hitMarksRemaining = (isStacked) ? team.numbersToHit[dart.hitEnum] : player.numbersToHit[dart.hitEnum];
			if (isSplit || isShangai || isMarathon || isMiniMarathon || isBaseball || isRoulette) {
				hitMarksRemaining = 0;
				if ((isShangai && !isStacked) || (isMarathon && !isStacked) || (isMiniMarathon && !isStacked)) {
					player.shangaiNo += 1;
					if (player.shangaiNo === 21 && this.rules.bull === false) {
						player.shangaiNo += 4;
					}
					else if (player.shangaiNo === 21 && this.rules.bull === true) {
						player.shangaiNo += 29;
					}
				}
				else if ((isShangai && isStacked) || (isMarathon && isStacked) || (isMiniMarathon && isStacked)) {
					this.players.forEach((_player) => {
						if (_player.teamId === currentPlayer.teamId) {
							_player.shangaiNo += 1;
							if (_player.shangaiNo === 21 && this.rules.bull === false) {
								_player.shangaiNo += 4;
							}
							else if (_player.shangaiNo === 21 && this.rules.bull === true) {
								_player.shangaiNo += 29;
							}
						}
					});
				}
			}
			if (hitMarksRemaining === 0) {
				// Number already closed
				score = dart.score;
				if (isPig || invertScore) {
					// For Pig games, score goes to other players that haven't closed the number
					scoreToOthers = true;
				}
				else {
					// Otherwise score applied to self
					Sounds.playCricketHitSound(1);
					overhit = 1;
					if (dart.isDouble === true) {
						overhit = 2;
						this.wasdouble = true;
					}
					else if (dart.isTriple === true) {
						overhit = 3;
						this.wastriple = true;
					}
					else if (this.rules.quatro === true && dart.isQuatro === true) {
						overhit = 4;
						this.wasquatro = true;
					}
					else {
						this.wassingle = true;
					}
					if (isSplit && this.rules.currentPigDart === 22) {
						if (dart.isDouble) {
							if (isStacked) {
								team.numbersToHit[22] = hitMarksRemaining;
								player.totalScore += overhit;
							}
							else {
								player.numbersToHit[22] = hitMarksRemaining;
								player.totalScore += overhit;
							}
							this.splitHit = true;
						}
						else {
							score = 0;
						}
					}
					else if (isSplit && this.rules.currentPigDart === 23) {
						if (dart.isTriple) {
							if (isStacked) {
								team.numbersToHit[23] = hitMarksRemaining;
								player.totalScore += overhit;
							}
							else {
								player.numbersToHit[23] = hitMarksRemaining;
								player.totalScore += overhit;
							}
							this.splitHit = true;
						}
						else {
							score = 0;
						}
					}
					else if (isSplit && this.rules.currentPigDart === 24) {
						if (dart.isQuatro) {
							if (isStacked) {
								team.numbersToHit[24] = hitMarksRemaining;
								player.totalScore += overhit;
							}
							else {
								player.numbersToHit[24] = hitMarksRemaining;
								player.totalScore += overhit;
							}
							this.splitHit = true;
						}
						else {
							score = 0;
						}
					}
					scoreToSelf = true;
					if ((isShangai || isSplit || isMarathon || isMiniMarathon || isBaseball || isRoulette) && (this.rules.currentPigDart !== 22 && this.rules.currentPigDart !== 23 && this.rules.currentPigDart !== 24)) {
						if (isStacked) {
							player.totalScore += overhit;
							team.numbersToHit[dart.hitEnum] = hitMarksRemaining;
						}
						else {
							player.totalScore += overhit;
							player.numbersToHit[dart.hitEnum] = hitMarksRemaining;
						}
						this.splitHit = true;
					}
					let totalPlayerDarts = this.darts.filter((_dart) => (_dart.player === player.id && [-2, -3, -4, -5].indexOf(_dart.hitEnum) < 0)).length;
					player.avgStatistic = (totalPlayerDarts > 0) ? (player.totalScore * 3 / totalPlayerDarts).toFixed(2) : '-';
				}
			}
			else {
				// Number not yet scored
				let toSubstract = 1;
				if (dart.isDouble) {
					toSubstract = 2;
				}
				else if (dart.isTriple) {
					toSubstract = 3;
				}
				else if (this.rules.quatro && dart.isQuatro) {
					toSubstract = 4;
				}
				if (toSubstract >= hitMarksRemaining) {
					Sounds.playCricketHitSound(hitMarksRemaining);
				} else {
					Sounds.playCricketHitSound(toSubstract);
				}
				hitMarksRemaining -= toSubstract;
				player.totalScore += toSubstract;
				// If number 'overhit', the score over the number of darts that is required to close the number is applied to score
				if (hitMarksRemaining < 0) {
					score = -1 * hitMarksRemaining * dart.hitEnum;
					player.totalScore += hitMarksRemaining;
					overhit = -hitMarksRemaining;
					if (isPig || invertScore) {
						// For Pig games apply score to others
						scoreToOthers = true;
					}
					else {
						// Otherwise apply to self
						scoreToSelf = true;
					}
					// Remaining darts cannot be lower than 0 :)
					hitMarksRemaining = 0;
				}
				// hitMarksRemaining === 0 => Number closed: dart.hitEnum
				// hitMarksRemaining !== 0 => Number needs more hits: dart.hitEnum
				player.noOfDartsRemaining -= player.numbersToHit[dart.hitEnum] - hitMarksRemaining;
				if (isStacked) {
					team.numbersToHit[dart.hitEnum] = hitMarksRemaining;
				}
				else {
					player.numbersToHit[dart.hitEnum] = hitMarksRemaining;
				}
			}
		}
		else {
			// Number that isn't supposed to be closed is hit
			Sounds.playHitSound(-1, 1);
			if (isPig || isMaster || isKiller) {
				scoreToSelf = true;
				if ((isMaster || isKiller) && [-1, 0].indexOf(dart.hitEnum) >= 0) {
					score = 0; // HitEnum.P25; => this causes problems when calculating Master score (numberg gets multiplied),
					// same logic instead added in updateOtherPlayersScore and updateOtherTeamsScore while updatePlayerScore already covered use case
				}
				else {
					score = dart.score;
				}
			}
			if (isShangai || isMarathon || isMiniMarathon || isBaseball || isRoulette) {
				score = 0;
			}
		}
		if (scoreToSelf) {
			this.updatePlayerScore(player, dart.hitEnum, score, overhit);
			if (!invertScore) { // can fill self over limit in invertScore
				this.resetScoreToMaxPossible(isStacked ? team : player);
			}
			if (isTeamGame && !isStacked) {
				team.score = this.calculateNonStackedTeamScore(team.id);
			}
		}
		else if (scoreToOthers) {
			this.updateOtherPlayersScore(player, dart.hitEnum, score);
			this.updateOtherTeamsScore(player.teamId, dart.hitEnum, score);
		}
	}
	updatePlayerScore(player, hitEnum, score, overhit) {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		const isPig = this.rules.cricketGameTypeEnum === 5;
		const isSplit = this.rules.otherGameType === 4;
		const isBaseball = this.rules.otherGameType === 9;
		const isRoulette = this.rules.otherGameType === 10;
		const isShangai = this.rules.otherGameType === 8;
		const isMarathon = this.rules.otherGameType === 7;
		const isMiniMarathon = this.rules.otherGameType === 6;
		const isMaster = this.rules.cricketOptionEnum === 3;
		const isKiller = this.rules.cricketOptionEnum === 2;
		let teamPointsDeserved = true;
		let isFullyClosed = true;
		let addScore = true;
		const team = (isTeamGame) ? this.teams.find((_team) => (_team.id === player.teamId)) : undefined;
		const toUpdate = !this.players.some((_player, _index) => {
			if (_index === this.gameStatus.currentPlayer) {
				return;
			}
			if (isPig && hitEnum === this.rules.currentPigDart && _player.numbersToHit[hitEnum] !== 0) {
				//ako je pig i igrač je pogodio pig broj, a nema zatvoren taj broj
				return true;
			}
			else if (((isSplit || isBaseball || isRoulette) && (player.numbersToHit[this.rules.currentPigDart] === 0 || typeof player.numbersToHit[this.rules.currentPigDart] === 'undefined')) && !isStacked) {
				if (isSplit) {
					player.score += score;
				}
				else {
					console.log('Dodao sam ', overhit, 'u player score');
					player.score += overhit;
				}
				return true;
			}
			else if ((isSplit || isBaseball || isRoulette) && isTeamGame && isStacked) {
				if (team.numbersToHit[this.rules.currentPigDart] === 0 && isSplit) {
					team.score += score;
				}
				else if (team.numbersToHit[this.rules.currentPigDart] === 0 && (isBaseball || isRoulette)) {
					console.log('Dodao sam ', overhit, 'u teamscore');
					team.score += overhit;
				}
				return true;
			}
			else if ((isShangai && !isStacked) || (isMarathon && !isStacked) || (isMiniMarathon && !isStacked)) {
				if (isShangai) {
					player.score += score;
					return true;
				} else {
					player.score += 1;
					return true;
				}
			}
			else if ((isShangai && isStacked) || (isMarathon && isStacked) || (isMiniMarathon && isStacked)) {
				if (isShangai) {
					team.score += score;
					return true;	
				} else {
					team.score += 1;
					return true;
				}
			}
			else if (!isPig && isMaster) {
				if (score < 15) {
					// for master: if under 15, points don't multiply
					return false;
				}
				player.score += (score > 0) ? score : 25;
				player.penaltyScore += (score > 0) ? score : 25;
			}
			else if (!isPig && !isSplit && (isBaseball || isRoulette) && _player.numbersToHit[hitEnum] > 0) {
				isFullyClosed = false;
				return true;
			}
			else if (!isMaster && !isKiller && !isPig && !isTeamGame) {
				for (let index = 0; index < this.players.length; index++) {
					var element = this.players[index].numbersToHit[hitEnum];
					if (player.id === this.players[index].id) {
						continue;
					}
					else if (element > 0 && addScore) {
						player.score += score;
						addScore = false;
						console.log('CRICKET, DAO SAM SCORE');
						break;
					}
				}
			}
			else if (!isMaster && !isKiller && !isPig && isTeamGame) {
				isFullyClosed = true;
				for (let index = 0; index < this.players.length; index++) {
					var element = this.players[index].numbersToHit[hitEnum];
					if (element && element > 0) {
						isFullyClosed = false;
						break;
					}
				}
			}
		});
		if (isTeamGame && !isStacked && !isFullyClosed) {
			// Number mustn't be fully closed, but all teammates must have it closed in order to get points
			const teammates = this.players.filter((_player) => (_player.teamId === player.teamId));
			teamPointsDeserved = !teammates.some((_player) => (_player.numbersToHit[hitEnum] > 0));
		}
		else if (isTeamGame && isStacked && !isFullyClosed && !isSplit && !isBaseball && !isRoulette) {
			isFullyClosed = !this.teams.some((_team) => (!!_team.numbersToHit[hitEnum]));
			teamPointsDeserved = !team.numbersToHit[hitEnum];
		}
		if (!isPig && (isMaster || isKiller) && toUpdate) { // if under 15
			if (!this.gameStatus.autoNext) {
				player.score += (score > 0) ? score : 25;
				player.penaltyScore += (score > 0) ? score : 25;
			}
		}
		if ((isPig && toUpdate) || (!isPig && !isFullyClosed && teamPointsDeserved)) {
			player.score += score;
			player.totalScore += overhit;
			if (isTeamGame) {
				team.score += score;
			}
		}
	}
	updateOtherPlayersScore(player, hitEnum, score) {
		const isKiller = this.rules.cricketOptionEnum === 2;
		const isMaster = this.rules.cricketOptionEnum === 3;
		const isCutThroat = this.rules.cricketOptionEnum === 4;
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		const teammates = isTeamGame ? this.players.filter((_player) => _player.id !== player.id && _player.teamId === player.teamId) : undefined;
		if (isStacked) {
			// Player scores in stacked team game are updated in updateOtherTeamsScore
			return;
		}
		score = ((isMaster || isKiller) && [-1, 0].indexOf(hitEnum) >= 0) ? 25 : score;
		// in team cut-throat/master/killer: a player can fill other players if all teammates have closed that hit
		const isCanFillTeamGame = isCutThroat || isMaster || isKiller;
		const canFillTeam = isTeamGame && isCanFillTeamGame && !teammates.some((_player, _index) => {
			const requiredHits = _player.numbersToHit[hitEnum];
			return requiredHits > 0;
		});
		let anyPlayerClosed = false;
		this.players.forEach((_player, _index) => {
			if (_index === this.gameStatus.currentPlayer) {
				return;
			}
			const requiredHits = _player.numbersToHit[hitEnum];
			if (requiredHits > 0) {
				anyPlayerClosed = true;
				if (isTeamGame && isCanFillTeamGame) {
					if (_player.teamId === player.teamId) {
						// don't fill teammates in cut-throat
						return;
					}
					if (!canFillTeam) {
						return;
					}
				}
				// When Killer is enabled, score is multiplied with the number of remainig darts for the player
				_player.score += (isKiller) ? score * requiredHits : score;
				this.gameStatus.fillScore += (isKiller) ? score * requiredHits : score;
			}
		});
		this.players.forEach((_player, _index) => {
			if (_index === this.gameStatus.currentPlayer) {
				return;
			}
			this.resetScoreToMinPossible(_player);
		});
		if ((isMaster || isKiller) && !anyPlayerClosed) {
			player.score += score;
			player.penaltyScore += (score > 0) ? score : 25;
		}
	}
	updateOtherTeamsScore(teamId, hitEnum, score) {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		const isKiller = this.rules.cricketOptionEnum === 2;
		const isMaster = this.rules.cricketOptionEnum === 3;
		const isCutThroat = this.rules.cricketOptionEnum === 4;
		if (!isTeamGame) {
			return;
		}
		if (!isStacked) {
			// no point to do special calculations, just update everyone
			this.updateAllTeamsScore();
			return;
		}
		score = ((isMaster || isKiller) && [-1, 0].indexOf(hitEnum) >= 0) ? 25 : score;
		const team = this.teams.find((_team) => (_team.id === teamId));
		let anyTeamClosed = false;
		this.teams.forEach((_team, _index) => {
			if (_team.id === teamId) {
				return;
			}
			const requiredHits = _team.numbersToHit[hitEnum];
			if (requiredHits > 0) {
				// When Killer is enabled, score is multiplied with the number of remainig darts for the player
				_team.score += (isKiller) ? score * requiredHits : score;
				anyTeamClosed = true;
			}
		});
		this.teams.forEach(_team => {
			if (_team.id === teamId) {
				return;
			}
			resetScoreToMinPossible(_team);
		});
		if ((isMaster || isKiller) && !anyTeamClosed) {
			team.score += score;
			team.penaltyScore += (score > 0) ? score : 25;
		}
	}
	calculateNonStackedTeamScore(teamId) {
		const teammates = this.players.filter(_player => _player.teamId === teamId);
		let newScore = 0;
		teammates.forEach(_player => newScore += _player.score || 0);
		return newScore;
	}
	updateAllTeamsScore() {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		if (!isTeamGame || isStacked) {
			return;
		}
		// in a non stacked team game: team score is the sum of all the players in the team
		this.teams.forEach((_team) => _team.score = this.calculateNonStackedTeamScore(_team.id));
	}
	resetScoreToMaxPossible(entity) {
		console.log('USAO U RESET TO MAX SCORE', this.rules.option200);
		if (!this.rules.option200) {
			return;
		}
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		let entities = isStacked ? this.teams : this.players;
		entities = entities.filter(_e => _e.id !== entity.id); // don't check self
		let maxScore = Math.max(...entities.map(_e => _e.score || 0)) + 200 + entity.penaltyScore;
		console.log('maxScore za trenutnog igrača je: ', maxScore);
		if (entity.score > maxScore) {
			entity.score = maxScore;
		}
	}
	resetScoreToMinPossible(entity) {
		console.log('USAO U RESET TO MIN SCORE', this.rules.option200);
		if (!this.rules.option200) {
			return;
		}
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		let entities = isStacked ? this.teams : this.players;
		let minScore = Math.min(...entities.map(_e => _e.score || 0)) + 200 + entity.penaltyScore;
		console.log('minScore za trenutnog igrača je: ', minScore);
		if (entity.score > minScore) {
			entity.score = minScore;
		}
	}
	// Switch the game status to next dart
	nextDart() {
		var updatePlayer = false;
		const player = this.gameStatus.getCurrentPlayer();
		let team = (this.rules.teamRules && this.teams) ? this.teams.find((_team) => (_team.id === player.teamId)) : undefined;
		// Set next dart, if last update next player
		var currentDart = this.gameStatus.currentDart + 1;
		if (currentDart > this.dartsPerRound) {
			currentDart = 1;
			updatePlayer = true;
			if (this.rules.otherGameType === 4) {
				currentDart = 1;
				updatePlayer = true;
				if (this.rules.teamRules && this.teams) {
					if (this.splitHit === false && (this.rules.teamRules && this.teams && !this.rules.teamRules.stacked)) {
						player.score = parseInt((player.score / 2), 10);
					}
					else if (this.splitHit === false && (this.rules.teamRules && this.teams && this.rules.teamRules.stacked)) {
						team.score = parseInt((team.score / 2), 10);
					}
				}
				else {
					if (this.splitHit === false) {
						player.score = parseInt((player.score / 2), 10);
					}
				}
				if (this.rules.teamRules && this.teams && !this.rules.teamRules.stacked) {
					team.score = this.calculateNonStackedTeamScore(team.id);
				}
				this.splitHit = false;
			}
			else if (this.rules.otherGameType === 8) {
				if (this.rules.quatro === true) {
					if (this.wasdouble && this.wastriple && this.wasquatro) {
						player.shangaiWin -= 1;
						this.gameStatus.gameOver = true;
						this.gameStatus.round = this.rules.rounds;
						// Game over
						this.gameStatus.message = 'SHANGAI WIN';
						if (this.rules.teamRules && this.teams) {
							var leader = team;
						}
						else {
							var leader = player;
						}
						if (this.rules.playOff && leader.length > 1) {
							this.startPlayoff(leader);
						}
					}
				}
				else {
					if (this.wassingle && this.wasdouble && this.wastriple) {
						player.shangaiWin -= 1;
						this.gameStatus.gameOver = true;
						this.gameStatus.round = this.rules.rounds;
						// Game over
						this.gameStatus.message = 'SHANGAI WIN';
						var leader = this.getLeader();
						if (this.rules.playOff && leader.length > 1) {
							this.startPlayoff(leader);
						}
					}
				}
				if (this.rules.teamRules && this.teams && !this.rules.teamRules.stacked) {
					team.score = this.calculateNonStackedTeamScore(team.id);
				}
				this.wassingle = false;
				this.wasdouble = false;
				this.wastriple = false;
				this.wasquatro = false;
			}
			else if (this.rules.otherGameType === 7 || this.rules.otherGameType === 6 || this.rules.otherGameType === 9 || this.rules.otherGameType === 10) {
				if (this.rules.teamRules && this.teams && !this.rules.teamRules.stacked) {
					team.score = this.calculateNonStackedTeamScore(team.id);
				}
			}
			this.awaitApproach = true;
		}
		this.gameStatus.currentDart = currentDart;
		if (updatePlayer === true) {
			console.log('DOGODI SE UPDATE PLAYER U LOGICI!!!');
			this.nextPlayer();
		}
	}
	// Switch the game status to next player
	nextPlayer() {
		var updateRound = false;
		var currentPlayer = this.gameStatus.currentPlayer;
		var newPlayer = this.getNextPlayer(currentPlayer);
		if (newPlayer <= currentPlayer) {
			updateRound = true;
		}
		currentPlayer = newPlayer;
		this.gameStatus.currentDart = 1;
		this.gameStatus.currentPlayer = currentPlayer;
		if (updateRound === true) {
			this.updateCrazyNumbers();
			this.gameStatus.round++;
		}
		if (this.gameStatus.autoNext) {
			this.gameStatus.autoNext = false;
		}
		// If there are no more rounds, game ends
		if (this.gameStatus.round > this.rules.rounds) {
			this.gameStatus.gameOver = true;
			this.gameStatus.round = this.rules.rounds;
			// Game over
			this.gameStatus.message = 'No more rounds';
			// No more rounds
			var leader = this.getLeader();
			if (this.rules.playOff && leader.length > 1) {
				this.startPlayoff(leader);
			}
		}
		//Sounds.playNextPlayerSound();
	}
	// Get the next player index
	getNextPlayer(currentPlayer) {
		if (currentPlayer < this.numberOfPlayers - 1) {
			currentPlayer++;
		}
		else {
			currentPlayer = 0;
		}
		return currentPlayer;
	}
	// Update numbers to hit for Crazy games, numbers that have not been hit yet by anyone at the end of a round get switched
	updateCrazyNumbers() {
		// TODO: Refactor to ES6
		if (this.rules.cricketGameTypeEnum === 4) {
			var closedNumbers = [];
			var ineligibleNumbers = this.rules.numbersToClose.slice();
			// Update all numbers that are not closed by anyone
			for (var i = 0; i < this.rules.numbersToClose.length; i++) {
				var number = this.rules.numbersToClose[i];
				var numberClosed = false;
				var player;
				for (var j = 0; j < this.players.length; j++) {
					player = this.players[j];
					if (player.numbersToHit[number] === 0) {
						numberClosed = true;
						closedNumbers.push(number);
						break;
					}
				}
				// Find numbers that have not been hit yet
				if (numberClosed === false) {
					for (j = 0; j < this.players.length; j++) {
						player = this.players[j];
						delete player.numbersToHit[number];
					}
					var index = this.rules.numbersToClose.indexOf(number);
					if (index > -1) {
						var newNumber = number;
						// Find a number not already in the list
						do {
							newNumber = this.rules.getRandomNumber();
						} while (ineligibleNumbers.indexOf(newNumber) !== -1);
						ineligibleNumbers.push(newNumber);
						// Crazy numbers! number replaced with newNumber
						// Replace number in rules and player scores
						this.rules.numbersToClose.splice(index, 1, newNumber);
						for (j = 0; j < this.players.length; j++) {
							player = this.players[j];
							player.numbersToHit[newNumber] = 3;
						}
					}
				}
			}
			this.rules.numbersToClose.sort((a, b) => (a - b));
			for (let j = 0; j < this.players.length; j++) {
				var player = this.players[j];
				var keys = Object.keys(player.numbersToHit);
				for (var k = 0; k < player.numbersToHit.length; k++) {
					if (player.numbersToHit[k] > 0) {
						var update = true;
						for (var l = 0; l < closedNumbers.length; l++) {
							keys.forEach(function (p) {
								closedNumbers[l].toString();
								if (p === closedNumbers[l].toString()) {
									update = false;
								}
							});
						}
						if (update) {
							player.numbersToHit[k] = this.dartsToCloseNumber;
						}
					}
				}
			}
		}
	}
	// Set the next number as the dart to hit in Pig games
	updatePigDart(hitEnum) {
		if ((this.rules.cricketGameTypeEnum === 5) && this.rules.otherGameType !== 4) {
			if (hitEnum === this.rules.currentPigDart) {
				var remaining = 0;
				for (var i = 0; i < this.players.length; i++) {
					remaining += this.players[i].numbersToHit[hitEnum];
				}
				// If noone has this number to hit anymore, switch to next number in the list
				if (remaining === 0) {
					var pigIndex = this.rules.numbersToClose.indexOf(this.rules.currentPigDart);
					if (pigIndex + 1 < this.rules.numbersToClose.length) {
						this.rules.currentPigDart = this.rules.numbersToClose[pigIndex + 1];
					}
				}
			}
		}
		else if (this.rules.otherGameType === 4 || this.rules.otherGameType === 9 || this.rules.otherGameType === 10) {
			this.rules.currentPigDart = this.rules.numbersToClose[this.gameStatus.round - 1];
		}
	}
	// Get leader(s) by their score
	getLeader() {
		if (this.playOffStarted === true) {
			return this.playoffGame.getLeader();
		}
		var isPig = this.rules.cricketGameTypeEnum === 5;
		var invertScore = this.rules.cricketOptionEnum === 4 ||
			this.rules.cricketOptionEnum === 3 ||
			this.rules.cricketOptionEnum === 2;
		var leader = [];
		// Smaller score, in Pig games the scores are 'negative' and smaller score wins
		if (isPig || invertScore) {
			let minScore = Number.MAX_VALUE;
			this.players.forEach((_player) => {
				if (_player.score === minScore) {
					leader.push(_player);
				}
				else if (_player.score < minScore) {
					leader = [_player];
					minScore = _player.score;
				}
			});
		}
		else {
			// Larger score
			let maxScore = 0;
			this.players.forEach((_player) => {
				if (_player.score === maxScore) {
					leader.push(_player);
				}
				else if (_player.score > maxScore) {
					leader = [_player];
					maxScore = _player.score;
				}
			});
		}
		return leader;
	}
	getLeadingTeamsIds() {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isPig = this.rules.cricketGameTypeEnum === 5;
		const isCutThroat = this.rules.cricketOptionEnum === 4;
		const isMaster = this.rules.cricketOptionEnum === 3;
		const isKiller = this.rules.cricketOptionEnum === 2;
		const invertScore = isCutThroat || isMaster || isKiller;
		if (!isTeamGame) {
			return;
		}
		if (this.playOffStarted) {
			return this.playoffGame.getLeader();
		}
		let leaders = [];
		if (isPig || invertScore) {
			// Smaller score, in Pig games the scores are 'negative' and smaller score wins
			let minScore = Number.MAX_VALUE;
			this.teams.forEach((_team) => {
				if (_team.score === minScore) {
					leaders.push(_team);
				}
				else if (_team.score < minScore) {
					leaders = [_team];
					minScore = _team.score;
				}
			});
		}
		else {
			// Larger score
			let maxScore = 0;
			this.teams.forEach((_team) => {
				if (_team.score === maxScore) {
					leaders.push(_team);
				}
				else if (_team.score > maxScore) {
					leaders = [_team];
					maxScore = _team.score;
				}
			});
		}
		return leaders.map((_team) => (_team.id));
	}
	// The total remaining number of darts a player needs to hit
	remainingRequiredHits(player) {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStacked = isTeamGame && this.rules.teamRules.stacked;
		let count = 0;
		if (isStacked) {
			const team = this.teams.find((_team) => (_team.id === player.teamId));
			Object.keys(team.numbersToHit).forEach((_number) => {
				count += team.numbersToHit[_number];
			});
		}
		else if (this.rules.otherGameType === 6 && player.shangaiNo === 12) {
			return 0;
		} else {
			player.numbersToHit.forEach((_hits) => (count += _hits));
		}
		return count;
	}
	// Get the current number to hit for Pig game, returns -1 if all have been closed already
	numberToHitPig() {
		var numberToHit = -1;
		if (this.rules.cricketGameTypeEnum === 5) {
			// Find the first number that has not been closed by everyone yet
			for (var i = 0; i < this.rules.numbersToClose.length; i++) {
				var number = this.rules.numbersToClose[i];
				for (var j = 0; j < this.players.length; j++) {
					var player = this.players[j];
					if (player.numbersToHit[number] > 0) {
						numberToHit = number;
						break;
					}
				}
				if (numberToHit !== -1) {
					break;
				}
			}
		}
		return numberToHit;
	}
	undoLastDart() {
		// Override from Game, in addition to game status we need the history of numbers to hit for Crazy and Pickit games
		Game.prototype.undoLastDart.call(this);
		if (this.gameStatusHistory.length > 0) {
			var historyItem = this.numbersHistory.pop();
			this.rules.numbersToClose = historyItem.numbers;
			this.rules.currentPigDart = historyItem.pigDart;
		}
	}
	addStatusHistory() {
		// Override from Game, in addition to game status we need the history of numbers to hit for Crazy and Pickit games
		Game.prototype.addStatusHistory.call(this);
		var historyItem = {};
		historyItem.pigDart = this.rules.currentPigDart;
		var numbers = [];
		for (var i = 0; i < this.rules.numbersToClose.length; i++) {
			var number = this.rules.numbersToClose[i];
			numbers.push(number);
		}
		historyItem.numbers = numbers;
		this.numbersHistory.push(historyItem);
	}
    /*
    CricketGame.prototype.getLeaderBoard = function() {
        if (this.players[0].index === undefined) {
            this.players.forEach(function(p, index) {
                p.index = index;
            });
        }
        if (this.playOffStarted === true && this.playoffGame !== null) {
            var returnList = [];
            // get players in playoff, sort them in the playoff game
            var playOffPlayers = this.playoffGame.getLeaderBoard();
            for (var i = 0; i < playOffPlayers.length; i++) {
                var pop = playOffPlayers[i];
                pop.playOffScore = pop.score;
                this.players.forEach(function(p) {
                    if (pop.id === p.id) {
                        pop.score = p.score;
                    }
                });
                returnList.push(pop);
            }
            // get all other players and sort them here
            var nonPlayOffPlayers = [];
            for (let i = 0; i < this.players.length; i++) {
                var p = this.players[i];
                var found = false;
                for (var j = 0; j < playOffPlayers.length; j++) {
                    var pp = playOffPlayers[j];
                    if (pp.id === p.id) {
                        found = true;
                        break;
                    }
                }
                if (found === false) {
                    nonPlayOffPlayers.push(p);
                }
            }
            nonPlayOffPlayers = this.sortByRules(nonPlayOffPlayers);
            for (let i = 0; i < nonPlayOffPlayers.length; i++) {
                returnList.push(nonPlayOffPlayers[i]);
            }
            return returnList;
        } else {
            var players = this.sortByRules(this.players);
            players.forEach(function(p, i) {
                p.positionIndex = i;
            });
            return players;
        }
    };
    */
	// NOTE: this function (when TODO is resolved) is identical to the one in x01Game,
	// consider moving the code into the base class
	getLeaderBoard() {
		// TODO: team leaderboard and sort
		const isTeamGame = this.rules.teamRules && this.teams;
		const entities = isTeamGame ? this.teams : this.players;
		const sortByEntityRules = isTeamGame ? this.sortByTeamRules.bind(this) : this.sortByRules.bind(this);
		if (entities[0].index === undefined) {
			entities.forEach((_e, _i) => _e.index = _i);
		}
		if (this.playOffStarted && this.playoffGame !== null) {
			let playOffEntities = this.playoffGame.getLeaderBoard();
			playOffEntities.forEach(_entity => {
				_entity.playOffScore = _entity.score;
				_entity.score = entities.find(_e => _e.id === _entity.id).score;
			});
			let playOffEntitiesIds = playOffEntities.map(_entity => _entity.id);
			// get all other players/teams and sort them here
			let nonPlayOffEntities = entities.filter(_entity => playOffEntitiesIds.indexOf(_entity.id) === -1);
			nonPlayOffEntities = sortByEntityRules(nonPlayOffEntities);
			return playOffEntities.concat(nonPlayOffEntities);
		}
		let result = sortByEntityRules(entities);
		result.forEach((_e, i) => _e.positionIndex = i);
		return result;
	}
	sortByRules(players) {
		const scoreSort = {
			name: 'score',
			primer: parseInt,
			reverse: true
		};
		const isPig = this.rules.cricketGameTypeEnum === 5;
		const invertScore = this.rules.cricketOptionEnum === 4 ||
			this.rules.cricketOptionEnum === 3 ||
			this.rules.cricketOptionEnum === 2;
		if (isPig || invertScore) {
			scoreSort.reverse = false;
		}
		const isMarks = this.rules.marks;
		const isShangai = this.rules.otherGameType === 8;
		// broj strelica za zatvoriti
		const noRemainingSort = {
			name: 'noOfDartsRemaining',
			primer: parseInt,
			reverse: false
		};
		const dartNoSort = {
			name: 'darts.length',
			primer: parseInt,
			reverse: false
		};
		const shangaiSort = {
			name: 'shangaiWin',
			primer: parseInt,
			reverse: false
		};
		if (isMarks) {
			return players.sort(sort_by(noRemainingSort, scoreSort, dartNoSort));
		}
		else if (isShangai) {
			return players.sort(sort_by(shangaiSort, scoreSort, dartNoSort));
		}
		else {
			return players.sort(sort_by(scoreSort, noRemainingSort, dartNoSort));
		}
	}
	sortByTeamRules(teams) {
		const scoreSort = {
			name: 'score',
			primer: parseInt,
			reverse: true
		};
		const isPig = this.rules.cricketGameTypeEnum === 5;
		const invertScore = this.rules.cricketOptionEnum === 4 ||
			this.rules.cricketOptionEnum === 3 ||
			this.rules.cricketOptionEnum === 2;
		if (isPig || invertScore) {
			scoreSort.reverse = false;
		}
		const isMarks = this.rules.marks;
		const isShangai = this.rules.otherGameType === 8;
		// broj strelica za zatvoriti
		const noRemainingSort = {
			name: 'noOfDartsRemaining',
			primer: parseInt,
			reverse: false
		};
		const dartNoSort = {
			name: 'darts.length',
			primer: parseInt,
			reverse: false
		};
		const shangaiSort = {
			name: 'shangaiWin',
			primer: parseInt,
			reverse: false
		};
		if (isMarks) {
			return teams.sort(sort_by(noRemainingSort, scoreSort, dartNoSort));
		}
		else if (isShangai) {
			return teams.sort(sort_by(shangaiSort, scoreSort, dartNoSort));
		}
		else {
			return teams.sort(sort_by(scoreSort, noRemainingSort, dartNoSort));
		}
	}
	getNumbersToClose() {
		Game.prototype.getNumbersToClose.call(this);
		var numbersToClose = [];
		var player = this.gameStatus.getCurrentPlayer();
		for (var i = 0; i < this.rules.numbersToClose.length; i++) {
			var number = this.rules.numbersToClose[i];
			if (player.numbersToHit[number] > 0) {
				numbersToClose.push(number);
			}
		}
		return numbersToClose;
	}
}


































