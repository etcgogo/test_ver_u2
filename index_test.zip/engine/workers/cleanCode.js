const axios = require('axios');
const bookkeeping = require('../../current_data/bookkeeping.json');
const statistics = require('../../current_data/statistics.json');
const settings = require ('../../current_data/defaultMode.json');

axios.post('https://cyber-tourney.herokuapp.com/updateSettings', {
    data: settings, 
    id: 15
}).catch((error) => {
    console.error(error)
})