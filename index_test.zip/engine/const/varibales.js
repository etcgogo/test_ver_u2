let Cpu_data = {    //prikaz
            lenght:null, //ok
			command :null,//ok
			game_mode:null,//ok
			player:null, //ok
			currentRoundScore:null, //ok
			dart:null, //ok
			round:null, //ok
			player_throw:null, //ok
			credit:null, //ok
			game:null, //ok
			option:null, //ok
			num_players:null, //ok
			cricket_numbers_closed:null,
			cricket_numbers:null,
			player_rank:null, //ok
			playoff_flag:null,
            team_num:null,
			flags_data:null,
            rfid:[]
};
let Display_data = {        //prikaz
    gameName:null, //ok
    sub_game:null, //ok
    GameOptionName:'', //ok
    isDeviceOnline: false, //ok
    Quatro:false, //ok
    teamOption:''
};

//server podaci

let Game_data = {
    game:{
        gameStatus:{
        	players: [], //ok//
        	teams: [],
        	round: 0, //ok//
        	currentPlayer: 0,//
        	currentDart: 0,
        	gameOver: false,
        	message: "",
        	roundStartScore: [],
        	teamRoundStartScore: [],
        	victor: "",
        	bustScore: 0,
        	fillScore: 0
        },
        playOffStarted: false,
        playoffGame: { ///provjeri ovo
            playOff_postion: 0,
            playOff_nextplayer: 0,
            players:[]
        },
        rules: {
        	gameType: 0,
        	rounds: 0,
        	quatro: false, //ok
        	undo: false,
        	handicap: false,
        	uniqueId: '',
        	score: 0,
        	parcheesi: false, //ok
        	runAndGun: false, //ok
        	runAndGunTime: 0,
        	playOff: false,
            doubleIn: false, //ok
            doubleOut: false, //ok
            masterOut: false, //ok
        	equalOption: false, //ok
        	endOption: false, //ok
        	bull: 0
        },
        isX01: false,
        isCricket: false,
        isOther: false,
        teamCount: 0,
        darts: [],
        awaitApproach: false,
        lastPrice: 0,
        hit: {},
        isFullyClosed: false,
        dart1: '',
        dart2: '',
        dart3: '',
        roundScore: 0,
        suggestNumbers: [],
        isOnline: false,
        dartsThrown: 0
    },
    activeGame:{
        active: false, //odradeno // nije dobro definirano
        gameType: 0,// neznas sta je ovo
        score: 0,
        parcheesi: false, //ok
        rounds: null, //ok
        runAndGun: false, //ok
        runAndGunTime: 0,
        playOff: false,
        doubleIn: false, //ok
        doubleOut: false, //ok
        masterOut: false, //ok
        equalOption: false, //ok
        endOption: false, //ok
        quatro: false, //ok
        undo: false,
        handicap: false,
        bull: 0,
        price: 0
    },
    playoffStarted:false,
    isPlayoff:false
};

let firstBoot = true;


//// Definicija objekta koji predstavlja konfiguracijske podatke
//aparat settings
let Cpu_settings_turnir_data = {
    ee_round_turnir_adjust: new Uint8Array(30)
};

let Cpu_settings_data = {
    ee_price_adjust: new Uint8Array(30),
    ee_happy_price_adjust: new Uint8Array(30),
    ee_round_adjust: new Uint8Array(30),
    ee_happy_round_adjust: new Uint8Array(30),
    ee_setup_time: new Uint8Array(3),
    ee_happy_setup_time: new Uint8Array(4),
    ee_time_limit: 0,
    ee_counter_pulses: 0,
    ee_switch_credits: 0,
    ee_tcr: 0,
    ee_bonus_credit: 0,
    ee_bonus_percent: 0,
    ee_lottery: 0,
    ee_option_remember: 0,
    ee_demo_sound: 0,
    ee_quatro_mode_on: 0,
    ee_return_dart: 0,
    ee_bull_value: 0,
    ee_play_off: 0,
    ee_lamp_on: 0,
    ee_main_lamp: 0,
    ee_back_light: 0,
    ee_infra_adjust: 0,
    ee_acceptor_time_adjust: 0,
    ee_ppd_statistics: new Uint8Array(8),
    ee_ppr_statistics: new Uint8Array(8),
    ee_location: 0,
    ee_coin_value: 0,
    ee_led_light: 0,
    ee_sett_language: 0,
    ee_sett_num_acceptors: 0,
    ee_sett_num_counters: 0,
    ee_sett_led_mount: 0,
    ee_sett_happy_day: 0,
    ee_money_for_credit: 0,
    ee_sett_target_quattro_on: 0,
    ee_model_type: 0,
    ee_model_target: 0,
    ee_tup_sense: 0,
    ee_vrijednost_kanala_cctalka: new Uint8Array(32),
    ee_vrijednost_impulsa_kanala: new Uint8Array(2),
    ee_cijena_jednog_kredita: 0,
    ee_coin_channel_inhibit: 0,
    ee_bill_channel_inhibit: 0,
    ee_coin_bill_table_extra_credits: new Uint8Array(32)
};

// Definicija objekta koji predstavlja podatke igre
//aparat podaci
let Cpu_game_data = {
    c_game_mode: 0,
    c_player_value: new Array(8),
    c_score: 0, //new Uint16Array(1),
    c_dart: 0,
    c_round: 0,
    c_player_throw: 0,
    c_credit: 0,
    c_game: 0,
    c_option: 0, //new Uint16Array(1),
    c_num_players: 0,
    c_player_cricket: new Uint8Array(24),
    c_player_rank: new Uint8Array(8),
    c_playoff_flag: 0,
    c_sub_game: 0,
    c_team_num: 0,
    c_flags_data: 0,
    c_cricket_broj: new Uint8Array(8),
    c_baceno_strelica: 0, //new Uint16Array(1),
    c_max_strelica: 0, //new Uint16Array(1),
    c_hits: new Uint8Array(3),
    c_dijelova_kredita_u_aparatu: 0,
    c_cijena_igre: 0,
	c_max_rounds: 0,
    c_show_msg: 0,
    c_jumpers: 0,
    c_ver_cpu: new Uint8Array(2),
    c_ver_target: new Uint8Array(2),
    c_ver_cctalk: new Uint8Array(2)
};

let Cpu_other_data = {
    c_podaci: new Uint8Array(255)
};

/*
<div id="player_score_list"></div>
            <script>
                // Varijabla koja određuje broj igrača
                var num_players = 8; // Promijenite ovaj broj prema potrebi
                var razmak = 100 / num_players;
                var razmak_g = razmak / 2 - 6;
                var positions = [0, 0, 0, 0, 0];
        
                // Funkcija za generiranje HTML elemenata za igrače
                function generatePlayerList(numPlayers) {
                    var container = document.getElementById('player_score_list');
                    container.innerHTML = ''; // Prazni prethodni sadržaj
        
    
                    for (var i = 1; i <= numPlayers; i++) {
                        if (i == 1) positions[0] = razmak_g;
                        else if (i == numPlayers) positions[i - 1] = 100 - razmak_g - 12;
                        else 
                        {
                            positions[i - 1] = razmak_g + razmak * (i - 1);
                        }
                        var playerRow = document.createElement('p');
                        playerRow.textContent = 'Igrač ' + i;
    
                        // Postavljanje pozicije za svakog igrača
                        if (i <= positions.length) {
                            playerRow.style.top = positions[i - 1] + '%';
                        }
    
                        container.appendChild(playerRow);
                    }
                }
    
                // Poziv funkcije za generiranje liste igrača
                generatePlayerList(num_players);
            </script>
            */








//let gameActive = false;
//let selectGame = true;// nigdje se ne koristi

//let credit = '0';
//let gameName = '180';
//let game = 0;
//let GameOptionName = '';
//let round = '';
//let num_players = ''; 
//let currentRoundScore = '';
//let dart =  '';
//let isDeviceOnline = false;
//let gameMode = 0;
//let player = [];
//let player_throw = 0;
//let cricket_numbers = [];
//let player_rank = [];




module.exports = {
    Display_data:Display_data,
    Game_data:Game_data,
    Cpu_data:Cpu_data,
    Cpu_settings_turnir_data:Cpu_settings_turnir_data,
    Cpu_settings_data:Cpu_settings_data,
    Cpu_game_data:Cpu_game_data,
    Cpu_other_data:Cpu_other_data,
    //player_rank:player_rank,
    //selectGame: selectGame,
    //gameActive: gameActive,
    //cricket_numbers: cricket_numbers,
    //player_throw: player_throw,
    //player: player,
    //gameMode: gameMode,
    //isDeviceOnline: isDeviceOnline,
    //dart: dart,
    //currentRoundScore: currentRoundScore,
    //num_players: num_players,
    //round: round,
    //GameOptionName:GameOptionName,
    //game: game,
    //credit: credit,
    //gameName: gameName,
    firstBoot: firstBoot,
}

/*
upute za polje za backup strelice, chat gpt odabir
Ako želiš da napraviš polje koje čuva do 100 backup podataka, možeš koristiti niz sa maksimalno 100 elemenata i dodavati podatke FIFO (First-In, First-Out) stilom.

1️⃣ Kreiranje polja za backup
Dodaj novi niz koji će čuvati do 100 backupova:

javascript
Copy
Edit
$scope.statisticsBackupArray = [];
2️⃣ Funkcija za dodavanje backupa u niz
Ova funkcija će dodati novi set podataka u backup niz i osigurati da ne pređe 100 elemenata:

javascript
Copy
Edit
$scope.saveStatisticsBackup = function() {
    // Kreiraj duboku kopiju trenutnog niza
    let backup = $scope.statisticsDataX01Array.map(obj => Object.assign(new StatisticsDataX01(), obj));

    // Dodaj kopiju u niz
    $scope.statisticsBackupArray.push(backup);

    // Ako imamo više od 100 elemenata, ukloni najstariji
    if ($scope.statisticsBackupArray.length > 100) {
        $scope.statisticsBackupArray.shift();
    }

    console.log("Backup sačuvan! Trenutni broj backupa:", $scope.statisticsBackupArray.length);
};
📌 Kako ovo radi?

Dodaje novi backup u niz
Ako niz pređe 100 backupa, briše najstariji (FIFO stil)
3️⃣ Kako vratiti određeni backup?
Ako želiš da vratiš određeni backup po indeksu, koristi ovu funkciju:

javascript
Copy
Edit
$scope.restoreStatisticsBackup = function(index) {
    if (index >= 0 && index < $scope.statisticsBackupArray.length) {
        // Vratimo kopiju backupa u glavni niz
        $scope.statisticsDataX01Array = $scope.statisticsBackupArray[index].map(obj => Object.assign(new StatisticsDataX01(), obj));
        console.log("Vraćen backup sa indeksom:", index);
    } else {
        console.log("Neispravan indeks backupa!");
    }
};
📌 Kako pozvati funkciju?

javascript
Copy
Edit
$scope.restoreStatisticsBackup(5); // Vrati podatke iz 6. backupa (indeks počinje od 0)
4️⃣ Kako koristiti?
Sačuvaj trenutne podatke:
javascript
Copy
Edit
$scope.saveStatisticsBackup();
Vrati podatke iz određenog backupa:
javascript
Copy
Edit
$scope.restoreStatisticsBackup(10);
Pregledaj sve sačuvane backupove:
javascript
Copy
Edit
console.log($scope.statisticsBackupArray);
📌 Rezime
✅ Kreirao si polje za 100 backupa
✅ FIFO sistem osigurava da nema više od 100 sačuvanih podataka
✅ Možeš sačuvati i vratiti bilo koji backup
✅ Svi podaci su kopirani bez povezivanja sa originalnim nizom

🚀 Sada imaš sistem backupa koji pamti do 100 setova podataka! 🎯
*/
