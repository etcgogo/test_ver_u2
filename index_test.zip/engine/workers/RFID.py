#!/usr/bin/env python
import sys
import RPi.GPIO as GPIO
from mfrc522 import SimpleMFRC522
import time
import json

run = True
reader = SimpleMFRC522()

def end_read():
    global run
    print("\nCtrl+C captured, ending read.")
    run = False
    GPIO.cleanup()

while run:
    id, text = reader.read()
    #print(id)
    #print(text)
    print(json.dumps({'name': text,'player_position': 0}))
    sys.stdout.flush()
    time.sleep(2)