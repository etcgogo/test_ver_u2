const exec = require('child_process').exec;
const ErrorHandeler = require('../objects/errorHandeler');

// CUSTOM EVENTS
let counter = 0;

function tryAgain (err) {
    exec('sudo killall python3', (error, stdout, stderr) => {
        if (!error) {
            if (err.code !== 143) {
                setTimeout(() => {
                    exec(err.cmd, function(error, stdout, stderr) {
                        if (error) {
                            ErrorHandeler.newError(147, error);
                            if (counter < 10) {
                                tryAgain(error)
                                counter++;
                            } else {
                                counter = 0;
                            }
                        } else {
                            counter = 0;
                        }
                    });
                }, 30);
            }
        }
    });
}

function playDemoSound() {
    exec('python3 ./sounds/play_file.py "./sounds/demoSound.wav"' + ' -d 1', function(error, stdout, stderr) {
        if (error) {
            ErrorHandeler.newError(147, error);
            tryAgain(error);
            console.log(error);
        } else {
        }
    });
}

function playBustSound() {
    exec('python3 ./sounds/play_file.py "./sounds/bust.wav"' + ' -d 1', function(error, stdout, stderr) {
        if (error) {
            ErrorHandeler.newError(147, error);
            tryAgain(error)
            console.log(error);
        } else {
        }
    });
}

/*function playCashInSound() {
    playSound(SoundPaths.cashIn);
}*/

function playCricketHitSound(multiplier) {
    let stringHelper = '';
    if (multiplier === 1) {
        stringHelper = 'python3 ./sounds/play_file.py "./sounds/cricket_single.wav"' + ' -d 1';
    } else if (multiplier === 2) {
        stringHelper = 'python3 ./sounds/play_file.py "./sounds/cricket_double.wav"' + ' -d 1';
    } else if (multiplier === 3) {
        stringHelper = 'python3 ./sounds/play_file.py "./sounds/cricket_triple.wav"' + ' -d 1';
    } else if (multiplier === 4) {
        stringHelper = 'python3 ./sounds/play_file.py "./sounds/cricket_quatro.wav"' + ' -d 1';
    }
    exec(stringHelper, function(error, stdout, stderr) {
        if (error) {
            ErrorHandeler.newError(147, error);
            tryAgain(error);
            console.log(error);
        } else {
        }
    });
}

function playEndGameSound() {
    exec('python3 ./sounds/play_file.py "./sounds/Pobjeda.wav"' + ' -d 1', function(error, stdout, stderr) {
        if (error) {
            ErrorHandeler.newError(147, error);
            tryAgain(error);
            console.log(error);
        } else {
        }
    });
}

function playGameStartSound() {
    exec('python3 ./sounds/play_file.py "./sounds/pocetak.wav"' + ' -d 1', function(error, stdout, stderr) {
        if (error) {
            ErrorHandeler.newError(147, error);
            tryAgain(error);
            console.log(error);
        } else {
        }
    });
}

function playTestSound () {
    exec('python3 ./sounds/play_file.py "./sounds/single.wav"' + ' -d 1', function(error, stdout, stderr) {
        if (error) {
            ErrorHandeler.newError(147, error);
            tryAgain(error);
            console.log(error);
        } else {
        }
    });
}

function playHitSound(value, multiplier) {
    console.log('U sound f: ', value,multiplier);
    var soundPath = '';
    if (value === -1) {
        soundPath = './sounds/tup.wav';
    } else {
        switch (multiplier) {
            case 1:
                switch (value) {
                    case 50:
                        soundPath = './sounds/doubleBull.wav';
                        break;
                    case 25:
                        soundPath = './sounds/doubleBull.wav';
                        break;
                    default:
                        soundPath = './sounds/single.wav';
                }
                break;
            case 2:
                switch (value) {
                    case 25:
                        soundPath = './sounds/doubleBull.wav';
                        break;
                    case 20:
                        soundPath = './sounds/double20.wav';
                        break;
                    default:
                        soundPath = './sounds/double.wav';
                        break;
                }
                break;
            case 3:
                switch (value) {
                    case 20:
                        soundPath = './sounds/triple20.wav';
                        break;
                    case 19:
                        soundPath = './sounds/triple19.wav';
                        break;
                    case 18:
                        soundPath = './sounds/triple18.wav';
                        break;
                    case 17:
                        soundPath = './sounds/triple17.wav';
                        break;
                    default:
                        soundPath = './sounds/triple.wav';
                        break;
                }
                break;
            case 4:
                switch (value) {
                    case 20:
                        soundPath = './sounds/quatro_20.wav';
                        break;
                    case 19:
                        soundPath = './sounds/quatro_19.wav';
                        break;
                    case 18:
                        soundPath = './sounds/quatro_18.wav';
                        break;
                    case 17:
                        soundPath = './sounds/quatro_17.wav';
                        break;
                    default:
                        soundPath = './sounds/quattro.wav';
                        break;
                }
                break;
            default:
                break;
        }
    }
    if (soundPath) {
        let stringHelper = 'python3 ./sounds/play_file.py ' + '"' + soundPath + '"' + ' -d 1';
        exec(stringHelper, function(error, stdout, stderr) {
            if (error) {
                ErrorHandeler.newError(147, error);
                tryAgain(error);
                console.log(error);
            } else {
            }
        });
    }
}

function playTestHitSound(value, multiplier) {
    let soundPath = '';
    switch (multiplier) {
        case 1:
            switch (value) {
                case 50:
                    soundPath = './sounds/doubleBull.wav';
                    break;
                case 25:
                    soundPath = './sounds/doubleBull.wav';
                    break;
                default:
                    soundPath = './sounds/single.wav';
            }
            break;
        case 2:
            soundPath = './sounds/double.wav';
            if (value === 25) {
                soundPath = './sounds/doubleBull.wav';
            }
            break;
        case 3:
            soundPath = './sounds/triple.wav';
            break;
        case 4:
            soundPath = './sounds/quattro.wav';
            break;
        default:
            break;
    }
    if (soundPath) {
        let stringHelper = 'python3 ./sounds/play_file.py ' + '"' + soundPath + '"' + ' -d 1';
        exec(stringHelper, function(error, stdout, stderr) {
            if (error) {
                ErrorHandeler.newError(147, error);
                tryAgain(error);
                console.log(error);
            } else {
            }
        });
    }
}

function playNextPlayerSound() {
    exec('python3 ./sounds/play_file.py "./sounds/nextPlayer.wav"' + ' -d 1', function(error, stdout, stderr) {
        if (error) {
            ErrorHandeler.newError(147, error);
            tryAgain(error)
            console.log(error);
        } else {
        }
    });
}
/*
function playPlayerToppledSound() {
    playSound(SoundPaths.playerToppled);
}

function playThrowSound() {
    playSound(SoundPaths.throw);
}

function playTimerSound() {
    playSound(SoundPaths.timer);
}

function playUndoSound() {
    playSound(SoundPaths.undo);
}

function playSelectSound() {
    playSound(SoundPaths.select);
}
*/
module.exports = {
    playDemoSound:             playDemoSound,
    playHitSound:              playHitSound,
    playTestHitSound:          playTestHitSound,
    playBustSound:             playBustSound,
    playCricketHitSound:       playCricketHitSound,
    playEndGameSound:          playEndGameSound,
    playGameStartSound:        playGameStartSound,
    playNextPlayerSound:       playNextPlayerSound,
    playTestSound:             playTestSound,
    /*playSelectSound:           playSelectSound,
    playDartStuckSound:        playDartStuckSound,
    playCashInSound:           playCashInSound,*/
};