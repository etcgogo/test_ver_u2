'use strict';

module.exports = class Player {
	constructor(id, name, type, teamId, copyOfType, owner, avgStatistic, numbersHit, totalScore, roundScores) {
		this.id = id;
		this.name = name;
		this.type = type;
		this.copyOfType = copyOfType;
		this.owner = owner;
		this.avgStatistic = (avgStatistic) ? avgStatistic : '-';
		this.numbersHit = (numbersHit) ? numbersHit : 0;
		this.totalScore = (totalScore) ? totalScore : 0;
		this.roundScores = [];
		if (roundScores) {
			this.roundScores = this.roundScores.concat(roundScores);
		}
		this.score = 0;
		this.penaltyScore = 0;
		this.darts = [];
		this.numbersToHit = [];
		this.noOfDartsRemaining = 0;
		this.runAndGunEndTime = 0;
		this.teamId = teamId;
		this.isDoubledIn = false;
		this.shangaiWin = 1;
		this.shangaiNo = 0;
	}
}

