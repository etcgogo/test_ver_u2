from moviepy.editor import *
from pathlib import Path
import os




img_clips = []
path_list=[]




#accessing path of each image
for image in os.listdir('../../Images/input'):
    if image.endswith(".jpg"):
        path_list.append(os.path.join('../../Images/input', image))

#creating slide for each image
for img_path in path_list:
  slide = ImageClip(img_path,duration=10)
  img_clips.append(slide)

#concatenating slides
video_slides = concatenate_videoclips(img_clips, method='compose')
#exporting final video
video_slides.write_videofile("../../Video/input/slideshow.mp4", fps=1)



def list_full_paths(directory):
   return [os.path.join(directory, file) for file in os.listdir(directory)]
 

filenames = list_full_paths(r"../../Video/input")  # You could generate this from os.listdir or similar
print(filenames)
clips = []

for file in filenames:
    clips.append(VideoFileClip(file, target_resolution=(720, 1280)))

final_clip = concatenate_videoclips(clips,method="compose")  # method="chain" by default. This is fine because all clips are the same size
final_clip.write_videofile("../../Video/demo.mp4")

clip = VideoFileClip("../../Video/input/slideshow.mp4") 
value = clip.size
print(value)
