'use strict';

module.exports = class GameStatus {
	constructor(players, teams) {
		this.players = players;
		this.teams = teams;
		this.round = 1;
		this.currentPlayer = 0;
		this.currentDart = 1;
		this.gameOver = false;
		this.message = "";
		this.roundStartScore = [];
		this.teamRoundStartScore = [];
		this.victor = "";
		this.bustScore = 0;
		this.fillScore = 0;
	}
	getCurrentPlayer(awaitApproach) {
		return returnPlayer(awaitApproach, 0, this);
	}
}


function returnPlayer(awaitApproach2, iteration, self) {
	var returningPlayer;
	if (!(self.round === 1 && self.currentPlayer === 0) && self.currentDart === 1 && awaitApproach2) {
		returningPlayer = self.players[((self.players.length + self.currentPlayer) - (1 + iteration)) % self.players.length];
	} else {
		returningPlayer = self.players[self.currentPlayer];
	}
	if (iteration > self.players.length) {
		// all players are skip or wait
        self.gameOver = true;
        return returningPlayer;
    }
	if (returningPlayer.skip || returningPlayer.wait) {
		var newIteration = iteration + 1;
		return returnPlayer(awaitApproach2, newIteration, self);
	} else {
		return returningPlayer;
	}
}
