﻿"use strict";
const BaseRules = require('./baseRules');

// gameType     - x01/Cricket, GameTypeEnum
// rounds         - number of rounds to play
// cricketGameType    - 1-5, CricketGameTypeEnum
// cricketOption        - 1-4, CricketOptionEnum
// playOff    - true/false
// marks		- true/false
// quatro    - true/false
// undo		- true/false
// handicap		- true/false
// teamRules    - ...
module.exports = class CricketRules extends BaseRules {
	constructor(gameType, rounds, cricketGameType, cricketOption, playOff, marks, option200, quatro, undo, handicap, teamRules) {
		super(gameType, rounds, quatro, undo, handicap, teamRules);
		this.cricketGameTypeEnum = cricketGameType;
		this.cricketOptionEnum = cricketOption;
		this.playOff = playOff;
		this.marks = marks;
		this.option200 = option200;
		this.numbersToClose = [];
		this.numbersChosen = false;
		this.overCountDart = 0;
		this.currentPigDart = 20;
		this.numberOfNumbers = 7;
		if (cricketGameType === CricketGameTypeEnum.cricket) {
			this.numbersToClose = [15, 16, 17, 18, 19, 20, 25];
			this.numbersChosen = true;
		}
		else if (cricketGameType === CricketGameTypeEnum.cricketPig) {
			this.numbersToClose = [20, 19, 18, 17, 16, 15, 25];
			this.numbersChosen = true;
		}
		else if (cricketGameType === CricketGameTypeEnum.cricketPickit) {
			// game needs to let you pick
		}
		else if (cricketGameType === CricketGameTypeEnum.cricketRandom ||
			cricketGameType === CricketGameTypeEnum.cricketCrazy) {
			// get random
			while (this.numbersToClose.length !== this.numberOfNumbers) {
				var r = this.getRandomNumber();
				if (this.numbersToClose.indexOf(r) === -1) {
					this.numbersToClose.push(r);
				}
			}
			this.numbersToClose.sort((a, b) => (a - b));
			this.numbersChosen = true;
		}
	}
	validate() {
		// TODO: validate rules
		return BaseRules.prototype.validate.call(this);
	}
	getRandomNumber() {
		var r = Math.floor(Math.random() * (21 - 1 + 1) + 1);
		if (r === 21) {
			return 25;
		}
		return r;
	}
}


const CricketGameTypeEnum = {
	cricket: 1,
	cricketPickit: 2,
	cricketRandom: 3,
	cricketCrazy: 4,
	cricketPig: 5,
};

const CricketOptionEnum = {
	NoOption: 1,
	Killer: 2,
	Master: 3,
	CutThroat: 4,
};
