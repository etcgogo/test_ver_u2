const x01Rules = require('../game/x01Rules');
const CricketRules = require ('../game/cricketRules');
const OtherRules = require('../game/otherGamerules');
const Player = require('../game/player');

var data = {
    rules: {},
    isX01: false,
    isCricket: false,
    isOther: false,
    teamCount: 1,
    creditNumber: 0,
    acumulatedMoney: 0,
    gameCost: 0,
    bookkeeping: {
        coinValue: 10,
        coinCValue: 5,
        billValue: 10,
        billCValue: 5,
        tokenValue: 601,
        tokenCValue: 300,
        keyValue: 234,
        keyCValue: 34,
        bonusValue: 43,
        bonusCValue: 34,
        lotteryValue: 12,
        lotteryCValue: 5,
        moneyInput: {
            valute: "EUR",
            valuesList: [
                {
                    value: 0.5,
                    type: "coins",
                    count: 10
                },
                {
                    value: 1,
                    type: "coins",
                    count: 15
                },
                {
                    value: 2,
                    type: "coins",
                    count: 25
                },
                {
                    value: 10,
                    type: "bills",
                    count: 10
                },
                {
                    value: 20,
                    type: "bills",
                    count: 14
                },
                {
                    value: 50,
                    type: "bills",
                    count: 29
                },
                {
                    value: 100,
                    type: "bills",
                    count: 3
                }
            ]
        }
    },
    statistic: {
        topGames: {
            x01Count: 24,
            cricketCount: 23,
            otherCount: 23,
            topList: [
                {
                    gameName: "HIGH SCORE DI P ",
                    number: 9
                },
                {
                    gameName: "301 DI MO",
                    number: 7
                },
                {
                    gameName: "CRICKET KILLER QUATTRO",
                    number: 7
                },
                {
                    gameName: "501 DI DO",
                    number: 6
                },
                {
                    gameName: "1001 DI MO",
                    number: 5
                },
                {
                    gameName: "CRICKET MASTER",
                    number: 5
                },
                {
                    gameName: "CRICKET CUT-THROAT",
                    number: 5
                },
                {
                    gameName: "701 MO",
                    number: 4
                },
                {
                    gameName: "SHANGAI",
                    number: 4
                },
                {
                    gameName: "SPLIT SCORE MASTER",
                    number: 4
                },
                {
                    gameName: "CRICKET MASTER QUATTRO",
                    number: 3
                },
                {
                    gameName: "CRICKET KILLER 200",
                    number: 3
                },
                {
                    gameName: "301 RUN&GUN",
                    number: 2
                },
                {
                    gameName: "301 EQUAL",
                    number: 2
                },
                {
                    gameName: "PUB GAME",
                    number: 1
                },
                {
                    gameName: "MARATHON",
                    number: 1
                },
                {
                    gameName: "ROULETTE",
                    number: 1
                },
                {
                    gameName: "SUPER SCORE",
                    number: 1
                },
                {
                    gameName: "BASEBALL",
                    number: 1
                },
                {
                    gameName: "SCRAM",
                    number: 1
                }
            ]
        },
        recievedHits: [
            {
                number: 1,
                inner: 42,
                outter: 23,
                double: 12,
                triple: 31,
                quattro: 4
            },
            {
                number: 2,
                inner: 23,
                outter: 45,
                double: 13,
                triple: 21,
                quattro: 3
            },
            {
                number: 3,
                inner: 34,
                outter: 13,
                double: 5,
                triple: 3,
                quattro: 1
            },
            {
                number: 4,
                inner: 34,
                outter: 34,
                double: 12,
                triple: 14,
                quattro: 4
            },
            {
                number: 5,
                inner: 34,
                outter: 34,
                double: 41,
                triple: 31,
                quattro: 3
            },
            {
                number: 6,
                inner: 14,
                outter: 41,
                double: 32,
                triple: 41,
                quattro: 32
            },
            {
                number: 7,
                inner: 52,
                outter: 32,
                double: 13,
                triple: 41,
                quattro: 12
            },
            {
                number: 8,
                inner: 12,
                outter: 13,
                double: 41,
                triple: 13,
                quattro: 21
            },
            {
                number: 9,
                inner: 13,
                outter: 14,
                double: 12,
                triple: 11,
                quattro: 7
            },
            {
                number: 10,
                inner: 42,
                outter: 23,
                double: 12,
                triple: 31,
                quattro: 4
            },
            {
                number: 11,
                inner: 14,
                outter: 45,
                double: 12,
                triple: 45,
                quattro: 9
            },
            {
                number: 12,
                inner: 31,
                outter: 27,
                double: 19,
                triple: 21,
                quattro: 14
            },
            {
                number: 13,
                inner: 22,
                outter: 13,
                double: 13,
                triple: 45,
                quattro: 4
            },
            {
                number: 14,
                inner: 43,
                outter: 23,
                double: 45,
                triple: 12,
                quattro: 9
            },
            {
                number: 15,
                inner: 42,
                outter: 51,
                double: 19,
                triple: 24,
                quattro: 16
            },
            {
                number: 16,
                inner: 31,
                outter: 12,
                double: 41,
                triple: 42,
                quattro: 17
            },
            {
                number: 17,
                inner: 58,
                outter: 32,
                double: 30,
                triple: 25,
                quattro: 21
            },
            {
                number: 18,
                inner: 35,
                outter: 45,
                double: 34,
                triple: 23,
                quattro: 6
            },
            {
                number: 19,
                inner: 56,
                outter: 68,
                double: 47,
                triple: 34,
                quattro: 15
            },
            {
                number: 20,
                inner: 42,
                outter: 64,
                double: 53,
                triple: 48,
                quattro: 37
            },
            {
                number: 'BE',
                inner: 12,
                outter: 12,
                double: 7,
                triple: 0,
                quattro: 0
            },
            {
                number: 'TUP',
                inner: 23,
                outter: 23,
                double: 0,
                triple: 0,
                quattro: 0
            }
        ]
    },
    happyIndex: 0,
    teams: [],
    activeMode: {
        gameSettings: {
            roundDartNumber: 3,
            gameDartNumber: 30,
            quattroMode: true,
            optionRemember: false,
            underSound: false,
            numberSignal: true,
            returnDart: true,
            perGame: false,
            lastPrice: undefined,
            gameList: [
                {
                    name: '180 ',
                    rounds: 5,
                    score: 180,
                    unlimitedRounds: false
                },
                {
                    name: '301 ',
                    rounds: 10,
                    score: 301,
                    unlimitedRounds: false
                },
                {
                    name: '501 ',
                    rounds: 15,
                    score: 501,
                    unlimitedRounds: false
                },
                {
                    name: '701 ',
                    rounds: 20,
                    score: 701,
                    unlimitedRounds: false
                },
                {
                    name: '901 ',
                    rounds: 25,
                    score: 901,
                    unlimitedRounds: false
                },
                {
                    name: '1001',
                    rounds: 30,
                    score: 1001,
                    unlimitedRounds: false
                },
                {
                    name: 'Cricket',
                    rounds: 25,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Pickit',
                    rounds: 25,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Random',
                    rounds: 25,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Crazy',
                    rounds: 25,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Pig',
                    rounds: 25,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'High Score',
                    rounds: 7,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Low Score',
                    rounds: 7,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Super Score',
                    rounds: 7,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Super 100',
                    rounds: 7,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Split Score',
                    rounds: 7,
                    score: 40,
                    unlimitedRounds: false
                },
                {
                    name: 'Shangai',
                    rounds: 7,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Roullette',
                    rounds: 7,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Roullette double',
                    rounds: 7,
                    score: 0,
                    unlimitedRounds: false
                },
                {
                    name: 'Scram',
                    rounds: 7,
                    score: 0,
                    unlimitedRounds: false
                }
            ]
        },
        ledOptions: {
            target: 50,
            button: 50,
            circle: 50
        },
        wifiSettings: {
            wifiOn: true
        },
        networkSettings: {
            propertyList: [
                {
                    name: 'IP address',
                    content: '192.168.1.10'
                },
                {
                    name: 'Subnet mask',
                    content: '255.255.255.0'
                },
                {
                    name: 'Gateway',
                    content: '192.168.1.1'
                }
            ],
            internet: true
        },
        rfidSettings: {
            adminList: [
                {
                    firstName: 'Antonio',
                    lastName: 'Krivak',
                    cardId: 'CRO123456'
                },
                {
                    firstName: 'Branko',
                    lastName: 'Žulj',
                    cardId: 'CRO456789'
                },
                {
                    firstName: 'Vilim',
                    lastName: 'Vidanec',
                    cardId: 'CRO13579'
                }
            ],
            userList: [
                {
                    firstName: 'Božo',
                    lastName: 'Pub',
                    cardId: 'CRO64321'
                },
                {
                    firstName: 'Pero',
                    lastName: 'Kvržica',
                    cardId: 'CRO97654'
                },
                {
                    firstName: 'Com',
                    lastName: 'Truise',
                    cardId: 'CRO97531'
                }
            ]
        },
        otherSettings: {
            demoMode: false,
            demoSound: false,
            autoUpdate: true
        },
        moneyCredits: {
            happyHourMode: false,
            freeplayMode: false,
            gamePrice: {
                gameList: [
                    {
                        name: '180',
                        price: 1
                    },
                    {
                        name: '301',
                        price: 1
                    },
                    {
                        name: '501',
                        price: 2
                    },
                    {
                        name: '701',
                        price: 3
                    },
                    {
                        name: '901',
                        price: 3
                    },
                    {
                        name: '1001',
                        price: 3
                    },
                    {
                        name: 'Cricket',
                        price: 3
                    },
                    {
                        name: 'Pickit',
                        price: 3
                    },
                    {
                        name: 'Random',
                        price: 3
                    },
                    {
                        name: 'Crazy',
                        price: 3
                    },
                    {
                        name: 'Pig',
                        price: 3
                    },
                    {
                        name: 'High Score',
                        price: 2
                    },
                    {
                        name: 'Low Score',
                        price: 2
                    },
                    {
                        name: 'Super Score',
                        price: 2
                    },
                    {
                        name: 'Split Score',
                        price: 2
                    },
                    {
                        name: 'Pub Game',
                        price: 2
                    },
                    {
                        name: 'Mini marathon',
                        price: 2
                    },
                    {
                        name: 'Marathon',
                        price: 3
                    },
                    {
                        name: 'Shangai',
                        price: 3
                    },
                    {
                        name: 'Baseball',
                        price: 2
                    },
                    {
                        name: 'Roullette',
                        price: 2
                    },
                    {
                        name: 'Roullette double',
                        price: 2
                    },
                    {
                        name: 'Scram',
                        price: 2
                    }
                ],
                optionList: [
                    {
                        name: 'Double in',
                        price: 1
                    },
                    {
                        name: 'Double out',
                        price: 1
                    },
                    {
                        name: 'Master out',
                        price: 1
                    },
                    {
                        name: 'Undo',
                        price: 1
                    },
                    {
                        name: 'Run & Gun',
                        price: 1
                    },
                    {
                        name: 'Parcheesi',
                        price: 1
                    },
                    {
                        name: 'Playoff',
                        price: 1
                    },
                    {
                        name: 'BE(25/50)',
                        price: 0
                    },
                    {
                        name: 'Equal',
                        price: 1
                    },
                    {
                        name: 'End',
                        price: 1
                    },
                    {
                        name: 'Quattro',
                        price: 0
                    },
                    {
                        name: 'Handicap',
                        price: 1
                    },
                    {
                        name: 'Killer',
                        price: 1
                    },
                    {
                        name: 'Master',
                        price: 1
                    },
                    {
                        name: 'Cut-throat',
                        price: 1
                    },
                    {
                        name: 'Marks',
                        price: 1
                    },
                    {
                        name: '200',
                        price: 0
                    }
                ],
            },
            happyHour: [
                {
                    date: 'January 18, 2018',
                    from: '11:00',
                    to: '23:00',
                    gameName: '301 |DI',
                    price: 'Free',
                    repeat: true,
                    rounds: 10
                },
            ],
            extraCredits: {
                keyCredits: 10,
                bonusLimits: 10,
                bonusPercents: 20,
                lotteryPercents: 15,
                keyCredit: true,
                bonusLimit: true,
                lotteryPercent: false
            },
            credits: {
                billAcceptor: [
                    {
                        channel: 1,
                        value: 5,
                        valute: 'EU'
                    },
                    {
                        channel: 2,
                        value: 10,
                        valute: 'EU'
                    },
                    {
                        channel: 3,
                        value: 20,
                        valute: 'EU'
                    },
                    {
                        channel: 4,
                        value: 50,
                        valute: 'EU'
                    },
                    {
                        channel: 5,
                        value: 100,
                        valute: 'EU'
                    },
                    {
                        channel: 6,
                        value: 500,
                        valute: 'EU'
                    }
                ],
                coinAcceptor: [
                    {
                        channel: 1,
                        value: 0.5,
                        valute: 'EU'
                    },
                    {
                        channel: 2,
                        value: 1,
                        valute: 'EU'
                    },
                    {
                        channel: 3,
                        value: 2,
                        valute: 'EU'
                    },
                    {
                        channel: 4,
                        value: 5,
                        valute: 'EU'
                    },
                    {
                        channel: 5,
                        value: 1,
                        valute: 'HR'
                    },
                    {
                        channel: 6,
                        value: 2,
                        valute: 'HR'
                    },
                    {
                        channel: 7,
                        value: 5,
                        valute: 'HR'
                    },
                ],
                creditPrice: [
                    {
                        valute: 'HR',
                        price: 2,
                    },
                    {
                        valute: 'EU',
                        price: 0.5,
                    }
                ],
                valutes: [
                    'HR',
                    'EU'
                ],
                creditBuffer: [
                    {
                        valute: 'HR',
                        buffer: 0
                    },
                    {
                        valute: 'EU',
                        buffer: 0
                    }
                ]
            }
        }
    }
}

var teamRules = {};

function getTeamRules () {
    if (data.teamCount === 1 || data.teamCount === 0) {
        return undefined;
    } else {
        let teamRuls = {
            count: data.teamCount,
            stacked: false,
            freeze: false
        }
        console.log('Vracam teamRules', teamRuls);
        return teamRuls;
    }
}

function setTeamRules (teamRuless) {
    teamRules = teamRuless;
}

function setX01Rules (gameType, score, parcheesi, rounds, runAndGun, runAndGunTime, playOff, doubleIn, doubleOut, masterOut, equalOption, endOption, quatro, undo, handicap, bull) {
    data.rules = new x01Rules(gameType, score, parcheesi, rounds, runAndGun, runAndGunTime, playOff, doubleIn, doubleOut, masterOut, equalOption, endOption, quatro, undo, handicap, bull, getTeamRules());
}

function setCricketRules (gameType, rounds, cricketGameType, cricketOption, playOff, marks, option200, quatro, undo, handicap) {
    data.rules = new CricketRules(gameType, rounds, cricketGameType, cricketOption, playOff, marks, option200, quatro, undo, handicap, getTeamRules());
}

function setOtherRules (gameType, score, parcheesi, rounds, runAndGun, runAndGunTime, playOff, doubleIn, doubleOut, masterOut, equalOption, endOption, quatro, undo, handicap, bull) {
    data.rules = new OtherRules(gameType, score, parcheesi, rounds, runAndGun, runAndGunTime, playOff, doubleIn, doubleOut, masterOut, equalOption, endOption, quatro, undo, handicap, bull, getTeamRules());
}

function getRules() {
    return data.rules;
}

let players = [{
    id: 1,
    name: 'Player 1',
    type: 1,
    copyOfType: 1,
    owner: {
        id: 1,
        name: 'Player 1',
        type: 1,
        copyOfType: 1
    }
}, ...new Array(7)]

function setPlayers(players) {
    players = players;
}

function resetTeams() {
    data.teams = [];
    data.teamCount = 0;
}

function cleanPlayers() {
    let player = {
        id: 1,
        name: 'Player 1',
        type: 1,
        copyOfType: 1,
        owner: {
            id: 1,
            name: 'Player 1',
            type: 1,
            copyOfType: 1
        }
    };
    players = new Array(8);
    players[0] = player;
    for (let index = 0; index < players.length; index++) {
        if (index !== 0) {
            players[index] = undefined;
        }
    }
}

function setTeamSize(teamCount) {
    if (teamCount === 3 && players.length > 6) {
        players.splice(5, 2);
    }
    data.teamCount = teamCount;
}

function addPlayers(Players) {
    const filledSlots = players.filter((_player) => (!!_player)).length;
    const availableSlots = players.length - filledSlots;
    if (Players.length > availableSlots) {
        // Too many players
        return;
    }
    Players.forEach((_player, _index) => {
        if (!_player && Players[0]) {
            players[_index] = Players[0];
            Players.splice(0, 1);
        }
    });
}

function generateTeams() {
    if (data.teamCount > 1) {
        data.teams = [];
        for (let i = 0; i < data.teamCount; i++) {
            data.teams.push({
                id: i,
                name: 'Team ' + (i+1).toString()
            });
        }
    }
}

module.exports = {
   data: data,
   teamRules: teamRules,
   getTeamRules: getTeamRules,
   setTeamRules: setTeamRules,
   setX01Rules: setX01Rules,
   setCricketRules: setCricketRules,
   setOtherRules: setOtherRules,
   getRules: getRules,
   players: players,
   setPlayers: setPlayers,
   cleanPlayers: cleanPlayers,
   addPlayers: addPlayers,
   setTeamSize: setTeamSize,
   resetTeams: resetTeams,
   generateTeams: generateTeams,
}