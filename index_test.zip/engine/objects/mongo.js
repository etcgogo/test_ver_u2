try {
    var InitialData = require('../../current_data/defaultMode.json');
} catch {
    var InitialData = false;
}
var Statistic = require('../../current_data/statistics.json');
var Bookkeeping = require('../../current_data/bookkeeping.json');
const axios = require('axios');
const ErrorHandeler = require('../objects/errorHandeler');
const fs = require('fs');
const constant = require('../const/const');
let safeWrite = true;

const fset = require('../objects/fset');
const { date } = require('../const/const');
const serialPortWorker = require('../workers/serialPortWorker');

let dateExists = false;
let dateArrayLocation = 0;


function retriveInitialData(callback) {
    //console.log(process.env.FLEET_URL + '/getDevice');
    axios.get(process.env.FLEET_URL + 'getDevice', {params: { id: process.env.ID}})
    .then(response => {
        callback(response.data[0].settings);
    });
}

function createNew() {
    axios.post(process.env.FLEET_URL + 'updateBookkeepings', {
        data: Bookkeeping, 
        id: '14'
    }).catch((error) => {
        console.error(error)
    })
}

function retriveBookkeeping(callback) {
    axios.get(process.env.FLEET_URL + 'getDevice', {params: { id: process.env.ID}})
    .then(response => {
        console.log(response.data[0].bookkeeping);
        callback(response.data[0].bookkeeping);
    });
}

function retriveStatistic(callback) {
    axios.get(process.env.FLEET_URL + 'getDevice', {params: { id: process.env.ID}})
    .then(response => {
        console.log(response.data[0].statistics);
        callback(response.data[0].statistics);
    });
}

function getLocalBookkeeping() {   // ivan vukoja pripazi na ovo
    let rawdata = fs.readFileSync('/home/hybrid3/server/current_data/bookkeeping.json');
    //console.log('RAW DATA', rawdata);
    let data = JSON.parse(rawdata);
    return data;
}

function getLocalStatistics() {
    let rawdata = fs.readFileSync('/home/hybrid3/server/current_data/statistics.json');
    console.log('RAW DATA', rawdata);
    let data = JSON.parse(rawdata);
    return data;
}
function getSetupData() {
    let rawdata = fs.readFileSync('/home/hybrid3/server/current_data/Setup_data.json');
    //console.log('RAW DATA', rawdata);
    let data = JSON.parse(rawdata);
    return data;
}

function writeSetupData(data) {
    fs.writeFile('/home/hybrid3/server/current_data/Setup_data.json', JSON.stringify(data, null, 2), function (err) {
        if (err) {
            ErrorHandeler.newError(29, err);
            return;
        }
        console.log('writing to ' + '../current_data/Setup_data.json');
    });
}

function getHit() {
    let rawdata = fs.readFileSync('/home/hybrid3/server/current_data/gameResume.json');
    console.log('RAW DATA', rawdata);
    let data = JSON.parse(rawdata);
    return data;
}

function updateGameSave(data) {
    if (safeWrite) {
        safeWrite = false;
        fs.writeFile('/home/hybrid3/server/current_data/gameResume.json', JSON.stringify(data, null, 2), (err) => {
            if (err) throw err;
            safeWrite = true;
            console.log('GameData written to file');
        });
    }
}

function deleteGameSave(data) {
    safeWrite = false;
    fs.unlink('/home/pi/server/current_data/gameResume.json', (err) => {
        if (err) throw err;
        fs.writeFile('/home/pi/server/current_data/gameResume.json', JSON.stringify(data, null, 2), (err) => {
            if (err) throw err;
            safeWrite = true;
            console.log('GameData written to file');
        });
    });
}



function activateMode(callback) { // set other mode json as default
   
}

function updateMode(data) {
    fs.writeFile('/home/hybrid3/server/current_data/defaultMode.json', JSON.stringify(data, null, 2), function (err) {
        if (err) {
            ErrorHandeler.newError(29, err);
            return;
        }
        console.log('writing to ' + '../../current_data/defaultMode.json');
        // Test Rest
        axios.post(process.env.FLEET_URL + 'updateSettings', {
            data: data, 
            id: process.env.ID,
            device:true
        }).catch((error) => {
            console.error(error)
        })
    });
    let Setup_data = getSetupData()
    Setup_data.ee_round_adjust[0]=data.gameSettings.gameList[0].rounds
    Setup_data.ee_round_adjust[1]=data.gameSettings.gameList[1].rounds
    Setup_data.ee_round_adjust[2]=data.gameSettings.gameList[2].rounds
    Setup_data.ee_round_adjust[3]=data.gameSettings.gameList[3].rounds
    Setup_data.ee_round_adjust[4]=data.gameSettings.gameList[4].rounds
    Setup_data.ee_round_adjust[5]=data.gameSettings.gameList[5].rounds
    Setup_data.ee_round_adjust[6]=data.gameSettings.gameList[6].rounds
    Setup_data.ee_price_adjust[0]=data.moneyCredits.gamePrice.gameList[0].price
    Setup_data.ee_price_adjust[1]=data.moneyCredits.gamePrice.gameList[1].price
    Setup_data.ee_price_adjust[2]=data.moneyCredits.gamePrice.gameList[2].price
    Setup_data.ee_price_adjust[3]=data.moneyCredits.gamePrice.gameList[3].price
    Setup_data.ee_price_adjust[4]=data.moneyCredits.gamePrice.gameList[4].price
    Setup_data.ee_price_adjust[5]=data.moneyCredits.gamePrice.gameList[5].price
    Setup_data.ee_price_adjust[6]=data.moneyCredits.gamePrice.gameList[6].price
    setTimeout(() => {
        writeSetupData(Setup_data);
    }, 300);
    
}


function updateGameSaveBrankZulj(data) {
    if (safeWrite) {
        safeWrite = false;
        fs.writeFile('/home/pi/server/current_data/resume.json', JSON.stringify(data, null, 2), (err) => {
            if (err) throw err;
            safeWrite = true;
            console.log('GameData written to file');
        });
    }
}

function deleteGameSaveBrankoZulj(data) {
    safeWrite = false;
    fs.unlink('/home/pi/server/current_data/resume.json', (err) => {
        if (err) throw err;
        fs.writeFile('/home/pi/server/current_data/resume.json', JSON.stringify(data, null, 2), (err) => {
            if (err) throw err;
            safeWrite = true;
            console.log('GameData written to file');
        });
    });
}

function resetBookkeeping(id, type, callback) {
    Bookkeeping.findOne({ido: id}, function(err, bookkeeping) {
        if (err) {
            ErrorHandeler.newError(45, err);
            return;
        }

        if (bookkeeping) {
            if (type === 'admin') {
                let adminReset = {};
                adminReset.billCredits = bookkeeping.billCredits;
                adminReset.bonusCredits = bookkeeping.bonusCredits;
                adminReset.coinCredits = bookkeeping.coinCredits;
                adminReset.lotteryCredits = bookkeeping.lotteryCredits;
                adminReset.ido = bookkeeping.ido;
                adminReset.valuteList = bookkeeping.valuteList,

                bookkeeping.resetAdmin = adminReset;
                bookkeeping.markModified('resetAdmin');
            } else if (type === 'user') {
                let userReset = {};
                userReset.billCredits = bookkeeping.billCredits;
                userReset.bonusCredits = bookkeeping.bonusCredits;
                userReset.coinCredits = bookkeeping.coinCredits;
                userReset.lotteryCredits = bookkeeping.lotteryCredits;
                userReset.ido = bookkeeping.ido;
                userReset.valuteList = bookkeeping.valuteList,

                bookkeeping.resetUser = userReset;
                bookkeeping.markModified('resetUser');
            } else {
                ErrorHandeler.newError(46, constant.NO_MESS);
                if (callback) {
                    callback(false);
                    return;
                }
            }

            bookkeeping.save(function(err) {
                if (err) {
                    ErrorHandeler.newError(47, err);
                }
                if (callback) {
                    callback(bookkeeping);
                }
            });
        } else {
            ErrorHandeler.newError(48, constant.NO_MESS);
            callback(false);
        }
    });
}

function resetStatistics(id, type, callback) {
    Statistic.findOne({ido: id}, function(err, statistics) {
        if (err) {
            ErrorHandeler.newError(49, err);
            return;
        }

        if (statistics) {
            if (type === 'admin') {
                let adminReset = {};
                adminReset.CricketgamesPlayed = statistics.CricketgamesPlayed;
                adminReset.OtherGamesPlayed = statistics.OtherGamesPlayed;
                adminReset.X01gamesPlayed = statistics.X01gamesPlayed;
                adminReset.gamesPlayed = statistics.gamesPlayed;
                adminReset.ido = statistics.ido;
                adminReset.recivedHits = statistics.recivedHits,

                statistics.resetAdmin = adminReset;
                statistics.markModified('resetAdmin');
            } else if (type === 'user') {
                let userReset = {};
                userReset.CricketgamesPlayed = statistics.CricketgamesPlayed;
                userReset.OtherGamesPlayed = statistics.OtherGamesPlayed;
                userReset.X01gamesPlayed = statistics.X01gamesPlayed;
                userReset.gamesPlayed = statistics.gamesPlayed;
                userReset.ido = statistics.ido;
                userReset.recivedHits = statistics.recivedHits,

                statistics.resetUser = userReset;
                statistics.markModified('resetUser');
            } else {
                if (callback) {
                    ErrorHandeler.newError(50, constant.NO_MESS);
                    callback(false);
                    return;
                }
            }

            statistics.save(function(err) {
                if (err) {
                    ErrorHandeler.newError(51, err);
                }
                if (callback) {
                    callback(statistics);
                }
            });
        } else {
            ErrorHandeler.newError(52, constant.NO_MESS);
            callback(false);
        }
    });
}

function updateHitsStatistics(darts) {
    let data = getLocalStatistics();
    for (let i = 0; i < darts.length; i++) {
        let dart = darts[i];
        //console.log('ovo su strelice-----------------------',dart);
        if (dart.score < -1) {
            continue;
        } if (dart.score === -1) {
            //console.log('-1')
            data.recivedHits[0].outter += 1;
            data.resetUser.recivedHits[0].outter += 1;
        } else if (dart.score === 25 || dart.score === 50) {
            //console.log('bull')
            if (dart.multiplier === 2) {
                //console.log('bull double')
                data.recivedHits[21].double += 1;
                data.resetUser.recivedHits[21].double += 1;
            } else {
                //console.log('bull single')
                data.recivedHits[21].outter += 1;
                data.resetUser.recivedHits[21].outter += 1;
            }
        } else if (dart.multiplier === 2) {
            //console.log('double number',dart.score)
            data.recivedHits[dart.score].double += 1;
            data.resetUser.recivedHits[dart.score].double += 1;
        } else if (dart.multiplier === 3) {
            //console.log('triple number',dart.score)
            data.recivedHits[dart.score].triple += 1;
            data.resetUser.recivedHits[dart.score].triple += 1;
        } else if (dart.multiplier === 4) {
            //console.log('quatro number',dart.score)
            data.recivedHits[dart.score].quattro += 1;
            data.resetUser.recivedHits[dart.score].quattro += 1;
        } else {
            //console.log('single number',dart.score)
            data.recivedHits[dart.score].outter += 1;
            data.resetUser.recivedHits[dart.score].outter += 1;
        }
    }
    //update statistics
    //console.log('data.recivedHits[0].outter poslje',data.recivedHits[0].outter)
	fs.writeFile('/home/hybrid3/server/current_data/statistics.json', JSON.stringify(data, null, 2), function (err) {
         if (err) {
             ErrorHandeler.newError(29, err);
             return;
         }
         console.log('writing to ' + '../../current_data/statistics.json');
         // Test Rest
         axios.post(process.env.FLEET_URL + 'updateStatistics', {
             data: data, 
             id: process.env.ID
         }).catch((error) => {
             console.error(error)
         })
    });
}

function updateHit(darts,player_throw,game) {
//     // // // let data = getHit();
//     // // // //console.log('sta tu dobijemo',game);
//     // // // data.player[player_throw-1].darts.push(darts);
//     // // // data.player[player_throw-1].score = game.player[player_throw-1].score;
//     // // // data.gameActive = game.gameActive;
//     // // // data.dart = game.dart;
//     // // // data.player_throw = game.player_throw;
//     // // // //update statistics
// 	// // // fs.writeFile('/home/hybrid3/server/current_data/gameResume.json', JSON.stringify(data, null, 2), function (err) {
//     // // //     if (err) {
//     // // //         ErrorHandeler.newError(29, err);
//     // // //         return;
//     // // //     }
//     // // //     console.log('writing to ' + '../../current_data/gameResume.json');
//     // // // });
}

function updateGamesStatistics(Cpu_data) {
    //console.log('Display_data',Display_data,'Game_data',Game_data,'Cpu_data',Cpu_data);
    //console.log('Cpu_data',Cpu_data);
    let data = getLocalStatistics();
    let gameIndex = -1;
    if(Cpu_data.game <= 5){
        //console.log('Cpu_data.game',Cpu_data.game);
        switch (Cpu_data.game) {
            case 0:
            gameIndex = 0;
            break;
            case 1:
            gameIndex = 1
            break;
            case 2:
            gameIndex = 2;
            break;
            case 3:
            gameIndex = 3;
            break;
            case 4:
            gameIndex = 4;
            break;
            case 5:
            gameIndex = 5;
            break;
            default:
            gameIndex = -1;
            break
        }
        data.X01gamesPlayed += 1;
        data.resetUser.X01gamesPlayed += 1;
        if (gameIndex >= 0) {
            data.gamesPlayed[gameIndex].count += 1;
            data.resetUser.gamesPlayed[gameIndex].count += 1;
        }
        
    }
    else if(Cpu_data.game === 6){
        if(Cpu_data.sub_game === 26){
            gameIndex = 7;
        }else if(Cpu_data.sub_game === 27){
            gameIndex = 8;
        }
        else if(Cpu_data.sub_game === 28){
            gameIndex = 9;
        }
        data.CricketgamesPlayed += 1;
        data.resetUser.CricketgamesPlayed += 1;
        if (gameIndex >= 0) {
            data.gamesPlayed[gameIndex].count += 1;
            data.resetUser.gamesPlayed[gameIndex].count += 1;
        }
    }
    else if(Cpu_data.game >= 7){
        //gameIndex = 10 + rules.gameType;
        data.OtherGamesPlayed += 1;
        data.resetUser.OtherGamesPlayed += 1;
        // if (gameIndex >= 0) {
        //     data.gamesPlayed[gameIndex].count += 1;
        //     data.resetUser.gamesPlayed[gameIndex].count += 1;
        // }
    }
    // let gameIndex = -1;
    // switch (type) {
    //     case 1:
    //         switch (rules.score) {
    //             case 180:
    //                 gameIndex = 0;
    //                 break;
    //             case 301:
    //                 gameIndex = 1
    //                 break;
    //             case 501:
    //                 gameIndex = 2;
    //                 break;
    //             case 701:
    //                 gameIndex = 3;
    //                 break;
    //             case 901:
    //                 gameIndex = 4;
    //                 break;
    //             case 1001:
    //                 gameIndex = 5;
    //                 break;
    //             default:
    //                 gameIndex = -1;
    //                 break;
    //         }
    //         data.X01gamesPlayed += 1;
    //         data.resetUser.X01gamesPlayed += 1;
    //         if (gameIndex >= 0) {
    //             data.gamesPlayed[gameIndex].count += 1;
    //             data.resetUser.gamesPlayed[gameIndex].count += 1;
    //         }
    //         break;
    //     case 2:
    //         gameIndex = 5 + rules.cricketGameType;
    //         data.CricketgamesPlayed += 1;
    //         data.resetUser.CricketgamesPlayed += 1;
    //         if (gameIndex >= 0) {
    //             data.gamesPlayed[gameIndex].count += 1;
    //             data.resetUser.gamesPlayed[gameIndex].count += 1;
    //         }
    //         break;
    //     case 3:
    //         gameIndex = 10 + rules.gameType;
    //         data.OtherGamesPlayed += 1;
    //         data.resetUser.OtherGamesPlayed += 1;
    //         if (gameIndex >= 0) {
    //             data.gamesPlayed[gameIndex].count += 1;
    //             data.resetUser.gamesPlayed[gameIndex].count += 1;
    //         }
    //         break;
    //     default:
    //         break;
    // }


    /////////////////////////////
    //update statistics
    //console.log('Cpu_data update statistics',data);
	fs.writeFile('/home/hybrid3/server/current_data/statistics.json', JSON.stringify(data, null, 2), function (err) {
    if (err) {
        ErrorHandeler.newError(29, err);
        return;
    }
    console.log('writing to ' + '../../current_data/statistics.json');
         // Test Rest
         axios.post(process.env.FLEET_URL + 'updateStatistics', {
             data: data, 
             id: process.env.ID
         }).catch((error) => {
             console.error(error)
         })
    });
}

function updateBookeeping(bookkeeping) {
        console.log('Updateam bookkeeping');
        fs.writeFile('/home/hybrid3/server/current_data/bookkeeping.json', JSON.stringify(bookkeeping, null, 2), function (err) {
            if (err) {
                ErrorHandeler.newError(29, err);
                return;
            }
            console.log('writing to ' + '../../current_data/bookkeeping.json');
                 // Test Rest
                 axios.post(process.env.FLEET_URL + 'updateBookkeepings', {
                     data: bookkeeping, 
                     id: process.env.ID
                 }).catch((error) => {
                     console.error(error)
                 })
            });
        //console.log(JSON.stringify(bookkeeping));
        // Test Rest
}

function factoryReset(id, defaultMode, callback) {
    InitialData.findOne({ido: id}, function(err, initialData) {
        if (err) {
            ErrorHandeler.newError(73, err);
            return;
        }

        if (initialData) {
            initialData.modes = [];
            initialData.shortenModes = [];
            initialData.modes.push(defaultMode);
            initialData.shortenModes.push({
                ido: '0',
                name: 'Default',
                icon: 'img/default-mode.svg',
                custom: false,
                active: true,
			});
			initialData.activeModeId = defaultMode.ido;

            initialData.markModified('modes');
            initialData.markModified('shortenModes');
            initialData.save(function(err) {
                if (err) {
                    ErrorHandeler.newError(74, err);
                }
                callback(defaultMode, initialData.shortenModes);
            });
        } else {
            ErrorHandeler.newError(75, constant.NO_MESS);
            callback(false);
        }
    });
}


/* CREATE IF MISSING */

function createStatisticsDataIfMissing(id, callback) {
	let statistic = new Statistic;
	statistic.ido = id;
	statistic.recivedHits = [
		{number: 0, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 1, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 2, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 3, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 4, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 5, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 6, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 7, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 8, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 9, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 10, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 11, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 12, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 13, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 14, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 15, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 16, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 17, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 18, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 19, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 20, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
		{number: 25, inner: 0, outter: 0, double: 0, triple: 0, quattro: 0},
	];
	statistic.gamesPlayed = [
        {
			'name': '180',
			'count': 0,
		},
		{
			'name': '301',
			'count': 0,
		},
		{
			'name': '501',
			'count': 0,
		},
		{
			'name': '701',
			'count': 0,
		},
		{
			'name': '901',
			'count': 0,
		},
		{
			'name': '1001',
			'count': 0,
		},
		{
			'name': 'Cricket',
			'count': 0,
		},
		{
			'name': 'Pickit',
			'count': 0,
		},
		{
			'name': 'Random',
			'count': 0,
		},
		{
			'name': 'Crazy',
			'count': 0,
		},
		{
			'name': 'Pig',
			'count': 0,
		},
		{
			'name': 'High Score',
			'count': 0,
		},
		{
			'name': 'Low Score',
			'count': 0,
		},
		{
			'name': 'Super Score',
			'count': 0,
		},
		{
			'name': 'Split Score',
			'count': 0,
        },
        {
			'name': 'Pub Game',
			'count': 0,
		},
		{
			'name': 'Mini marathon',
			'count': 0,
		},
		{
			'name': 'Marathon',
			'count': 0,
		},
		{
			'name': 'Shangai',
			'count': 0,
		},
		{
			'name': 'Baseball',
			'count': 0,
		},
		{
			'name': 'Roullette',
			'count': 0,
		},
		{
			'name': 'Roullette double',
			'count': 0,
		},
		{
			'name': 'Scram',
			'count': 0,
        },
        {
			'name': 'Super 100',
			'count': 0,
		},
	];
	statistic.X01gamesPlayed = 0;
	statistic.CricketgamesPlayed = 0;
	statistic.OtherGamesPlayed = 0;

	statistic.save(function(err) {
        if (err) {
            ErrorHandeler.newError(92, err);
            callback(false);
            return;
        } else {
            callback(true);
        }
	});
}

function createBookkeepingDataIfMissing(id, callback) {
	let bookkeeping = new Bookkeeping;

	bookkeeping.ido = id;
	bookkeeping.tokens = 0;
	bookkeeping.bonus = 0;
	bookkeeping.lottery = 0;
	bookkeeping.coinCredits = 0;
    bookkeeping.billCredits = 0;
	bookkeeping.lotteryCredits = 0;
    bookkeeping.bonusCredits = 0;
	bookkeeping.save(function(err) {
        if (err) {
            ErrorHandeler.newError(93, err);
            callback(false);
            return;
        }
        callback(true);
	});
}

function addValuteList(coin){
//function addValuteList(type, valuteList) {
    let data = getLocalBookkeeping();
    //console.log('date',constant.date)
    
/*
    for (let i = 0; i < data.Inserted.length; i++) {
        if (data.Inserted[i].date === constant.date) {
          dateExists = true; // Date exists in the array
          dateArrayLocation = i;
          break; // No need to continue iterating
        }
    }*/

    if (dateExists) {
        if(coin){
            console.log('datum postoji')
            if(data.valuteList[4].count<coin.kanal_1){
                console.log('datum kovanica 1')
                data.Inserted[dateArrayLocation].value += data.valuteList[4].value
            }else if(data.valuteList[5].count<coin.kanal_2){
                console.log('datum kovanica 2')
                data.Inserted[dateArrayLocation].value += data.valuteList[5].value
            }else if(data.valuteList[6].count<coin.kanal_3){
                console.log('datum kovanica 4')
                data.Inserted[dateArrayLocation].value += data.valuteList[6].value
            }
        }
        // Date already exists in the array, do something
    } else {
        console.log('datum ne postoji')
        data.Inserted.push({date:constant.date,value:0});
        // Date does not exist in the array, push new object with the date
    }

    // if(data.valuteList[4].count<coin.kanal_1){
    //     console.log('datum kovanica 1')
    //     data.valuteList[4].Inserted.date.push(date);
    //     data.valuteList[4].Inserted.value = data.valuteList[4].value
    // }else if(data.valuteList[5].count<coin.kanal_2){
    //     console.log('datum kovanica 2')
    //     data.valuteList[5].Inserted.date.push(date);
    //     data.valuteList[5].Inserted.value = data.valuteList[5].value
    // }else if(data.valuteList[6].count<coin.kanal_3){
    //     console.log('datum kovanica 4')
    //     data.valuteList[6].Inserted.date.push(date);
    //     data.valuteList[6].Inserted.value = data.valuteList[6].value
    // }
    if (coin) {

        console.log('pisem kovanice',data.valuteList[4].count,coin.kanal_1)
        data.valuteList[4].count = coin.kanal_1;
        data.valuteList[5].count = coin.kanal_2;
        data.valuteList[6].count = coin.kanal_3;
    }
    
    // if (type === 2) {
    //     data.coinAcceptor = [];
    //     data.coinAcceptor = valuteList;
    // } else if (type === 3) {
    //     data.billAcceptor = [];
    //     data.billAcceptor = valuteList;
    // }
    setTimeout(() => {
        updateBookeeping(data);
    }, 200);
    
    //return data;
}

function sendCreditInfo(creditNumber, creditBuffer, type, money, channel, date, creditsGiven) {
    let data = getLocalBookkeeping();
    if (type === 'coin') {
        data.coinCredits += creditsGiven;
        data.creditNumber = creditNumber;
        data.creditBuffer = creditBuffer;
        for (let index = 0; index < data.valuteList.length; index++) {
            if(data.valuteList[index].channel === channel && data.valuteList[index].type === type) {
                data.valuteList[index].count++;
                break;
            }
        }
    } else if (type === 'bill') {
        data.billCredits += creditsGiven;
        data.creditNumber = creditNumber;
        data.creditBuffer = creditBuffer;
        for (let index = 0; index < data.valuteList.length; index++) {
            if(data.valuteList[index].channel === channel && data.valuteList[index].type === type) {
                data.valuteList[index].count++;
                break;
            }
        }
    } else if (type === 'bonus') {

    } else if (type === 'paid') {
        data.creditNumber = creditNumber;
    }
    updateBookeeping(data);
}

function createInitialDataIfMissing(id, callback) {
    let initialData = new InitialData;
    initialData.credits = 0;
    initialData.resume = {};
    initialData.ido = id;
    initialData.lastDate = new Date().toString();
    initialData.modes = [];
    initialData.shortenModes = [];
    initialData.activeModeId = 0;
    initialData.fingerprintList = [];

    initialData.save(function(err) {
        if (err) {
            ErrorHandeler.newError(100, err);
            callback(false);
            return;
        }
        callback(true);
	});
}
function sendSetup() {
    
    let data = getSetupData();
    //console.log('ovo je data od setupa',data)

	let order = 'A6';
	let decimalSum = 174 + parseInt(order, 16);
	let command = 'ABAE' + order;

    decimalSum = decimalSum
    //console.log('decimalSum -0',decimalSum)
    for (let i = 0; i < data.ee_price_adjust.length; i++) {
        if (data.ee_price_adjust[i] === 0.5) {
            data.ee_price_adjust[i] = 255;
        }
        //console.log('decimalSum for',decimalSum)
        decimalSum = decimalSum + data.ee_price_adjust[i];
        command += fset.hexify(data.ee_price_adjust[i])
    }
   //console.log('decimalSum -1',decimalSum,data.ee_price_adjust.length)
    for (let i = 0; i < data.ee_happy_price_adjust.length; i++) {
        if (data.ee_happy_price_adjust[i] === 0.5) {
            data.ee_happy_price_adjust[i] = 255;
        }
        decimalSum = decimalSum + data.ee_happy_price_adjust[i];
        command += fset.hexify(data.ee_happy_price_adjust[i]);
    }
    //console.log('decimalSum -2',decimalSum,data.ee_price_adjust.length)
    for (let i = 0; i < data.ee_round_adjust.length; i++) {
        command += fset.hexify(data. ee_round_adjust[i]);
        decimalSum = decimalSum + data.ee_round_adjust[i];
    }
    //console.log('decimalSum -3',decimalSum,data.ee_round_adjust.length)
    for (let i = 0; i < data.ee_happy_round_adjust.length; i++) {
        command += fset.hexify(data.ee_happy_round_adjust[i]);
        decimalSum = decimalSum + data.ee_happy_round_adjust[i];
    }
    for (let i = 0; i < data.ee_setup_time.length; i++) {
        command += fset.hexify(data.ee_setup_time[i]);
        decimalSum = decimalSum + data.ee_setup_time[i];
    }
    for (let i = 0; i < data.ee_happy_setup_time.length; i++) {
        command += fset.hexify(data.ee_happy_setup_time[i]);
        decimalSum = decimalSum + data.ee_happy_setup_time[i];
    }
    //console.log('decimalSum -4',decimalSum)
    command += fset.hexify(data.ee_time_limit)
    +fset.hexify(data.ee_counter_pulses)
    +fset.hexify(data.ee_switch_credits)
    +fset.hexify(data.ee_tcr)
    +fset.hexify(data.ee_bonus_credit)
    +fset.hexify(data.ee_bonus_percent)
    +fset.hexify(data.ee_lottery)
    +fset.hexify(data.ee_option_remember)
    +fset.hexify(data.ee_demo_sound)
    +fset.hexify(data.ee_quatro_mode_on)
    +fset.hexify(data.ee_return_dart)
    +fset.hexify(data.ee_bull_value)
    +fset.hexify(data.ee_play_off)
    +fset.hexify(data.ee_lamp_on)
    +fset.hexify(data.ee_main_lamp)
    +fset.hexify(data.ee_back_light)
    +fset.hexify(data.ee_infra_adjust)
    +fset.hexify(data.ee_acceptor_time_adjust);
  

    decimalSum = decimalSum + data.ee_time_limit + data.ee_counter_pulses + data.ee_switch_credits
    + data.ee_tcr + data.ee_bonus_credit + data.ee_bonus_percent + data.ee_lottery + data.ee_option_remember
    + data.ee_demo_sound + data.ee_quatro_mode_on + data.ee_return_dart + data.ee_bull_value
    + data.ee_play_off + data.ee_lamp_on + data.ee_main_lamp + data.ee_back_light
    + data.ee_infra_adjust + data.ee_acceptor_time_adjust;

    //console.log('decimalSum -5',decimalSum)

    for (let i = 0; i < data.ee_ppd_statistics.length; i++) {
        command += fset.hexify(data.ee_ppd_statistics[i]);
        decimalSum = decimalSum + data.ee_ppd_statistics[i];
    }
    for (let i = 0; i < data.ee_ppr_statistics.length; i++) {
        command += fset.hexify(data.ee_ppr_statistics[i]);
        decimalSum = decimalSum + data.ee_ppr_statistics[i];
    }
    //console.log('decimalSum -6',decimalSum)


    let language_hex = 0;
    command += fset.hexify(data.ee_location)
    +fset.hexify(data.ee_coin_value)
    +fset.hexify(data.ee_led_light)
    +fset.hexify(language_hex)
    +fset.hexify(data.ee_sett_num_acceptors)
    +fset.hexify(data.ee_sett_num_counters)
    +fset.hexify(data.ee_sett_led_mount)
    +fset.hexify(data.ee_sett_happy_day)
    +fset.hexify(data.ee_money_for_credit)
    +fset.hexify(data.ee_sett_target_quattro_on)+'0200';

    // console.log('decimalSum -7',decimalSum)

    decimalSum = decimalSum + data.ee_location + data.ee_coin_value + data.ee_led_light + language_hex
    + data.ee_sett_num_acceptors + data.ee_sett_num_counters + data.ee_sett_led_mount + data.ee_sett_happy_day
    + data.ee_money_for_credit + data.ee_sett_target_quattro_on + 2;
    //console.log('decimalSum -8',decimalSum)


    //console.log('decimalSum',decimalSum)
	var hexSum = decimalSum.toString(16).toUpperCase();
	command += (constant.ZEROS2 + hexSum).slice(-2) + constant.poclXEndByte;

	//console.log('Izgled komande: ', command);

    return command;
}
function sendGameData (data){
    //console.log('tu cu poslat game data',data)
    // Convert the hex string to a byte array
    let byteArray = new Uint8Array(data.match(/[\da-f]{2}/gi).map(function (h) {
    return parseInt(h, 16)
    }));
    
    // Update the 3rd byte to 0xA7
    byteArray[2] = 0xA7;
    byteArray[3] = 0x00;
    console.log('ovo je broj igraca',byteArray[29])
    if(byteArray[29] === 8){
        number = 0;
    }else{
        number = byteArray[29]
        number++
    }
    //number = 3;
    /////
    console.log('koliki je broj igraca',number ,byteArray[29]);
    console.log('koja je igra',byteArray[26]);
  
let decimalNumber = 180;
let hexNumber = decimalNumber.toString(16).toUpperCase().padStart(4, '0');
let littleEndianHex = hexNumber.slice(2, 4) + hexNumber.slice(0, 2);
console.log('sta dobijem ovdje ',littleEndianHex)
// Convert little endian hexadecimal string to byte array
byteArray[4] = parseInt(littleEndianHex.slice(0, 2), 16);
byteArray[5] = parseInt(littleEndianHex.slice(2, 4), 16);
byteArray[6] = parseInt(littleEndianHex.slice(0, 2), 16);
byteArray[7] = parseInt(littleEndianHex.slice(2, 4), 16);
byteArray[8] = parseInt(littleEndianHex.slice(0, 2), 16);
byteArray[9] = parseInt(littleEndianHex.slice(2, 4), 16);
byteArray[10] = parseInt(littleEndianHex.slice(0, 2), 16);
byteArray[11] = parseInt(littleEndianHex.slice(2, 4), 16);
byteArray[12] = parseInt(littleEndianHex.slice(0, 2), 16);
byteArray[13] = parseInt(littleEndianHex.slice(2, 4), 16);
byteArray[14] = parseInt(littleEndianHex.slice(0, 2), 16);
byteArray[15] = parseInt(littleEndianHex.slice(2, 4), 16);
byteArray[16] = parseInt(littleEndianHex.slice(0, 2), 16);
byteArray[17] = parseInt(littleEndianHex.slice(2, 4), 16);
byteArray[18] = parseInt(littleEndianHex.slice(0, 2), 16);
byteArray[19] = parseInt(littleEndianHex.slice(2, 4), 16);
// byteArray[22] = fset.hexify(0);
// byteArray[23] = fset.hexify(0);
// byteArray[24] = fset.hexify(0);
// Print new byte array
//console.log(newByteArray);

    
    byteArray[29] = fset.hexify(number);
    // Calculate the sum of all bytes except for the first and last two bytes
    let sum = byteArray.slice(1, byteArray.length - 2).reduce(function(a, b) { return a + b; }, 0) % 256;

    
    //console.log('suma',sum)
    // Update the second to last byte with the sum
    byteArray[byteArray.length - 2] = sum;
    
    // Convert the byte array back to a hex string
    let updatedHexString = Array.from(byteArray, function (byte) {
        return ('0' + (byte & 0xFF).toString(16)).slice(-2);
    }).join('').toUpperCase();;
    
    console.log('jel to rijesenje',updatedHexString);
    constant.setgamedata = updatedHexString;
   
    return updatedHexString
}


module.exports = {
    sendGameData:sendGameData,
    writeSetupData:writeSetupData,
    sendSetup:sendSetup,
	createInitialDataIfMissing: createInitialDataIfMissing,
	createStatisticsDataIfMissing: createStatisticsDataIfMissing,
    createBookkeepingDataIfMissing: createBookkeepingDataIfMissing,
    addValuteList: addValuteList,
    sendCreditInfo: sendCreditInfo,
    factoryReset: factoryReset,
    retriveInitialData: retriveInitialData,
    retriveBookkeeping: retriveBookkeeping,
    retriveStatistic: retriveStatistic,
    activateMode: activateMode,
    updateMode: updateMode,
    updateGameSave: updateGameSave,
    deleteGameSave: deleteGameSave,
    updateHitsStatistics: updateHitsStatistics,
    updateHit:updateHit,
    getHit:getHit,
    updateGamesStatistics: updateGamesStatistics,
    updateBookeeping: updateBookeeping,
    resetBookkeeping: resetBookkeeping,
    resetStatistics: resetStatistics,
    createNew: createNew,
}
