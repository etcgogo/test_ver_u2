const { gameName } = require("./varibales");

const HEX_B = 'hex';
const GameDataByte = 'A5'; //Ivan Vukoja
const GameSettingsByte = 'A4'; //Ivan Vukoja
const dip_switch_menu_Byte = 'AC'; //Ivan Vukoja
const dip_switch_menu_settings_Byte = 'AA'; //Ivan Vukoja
const dip_switch_test_menu_Byte = 'AF'; //Ivan Vukoja

const PREFIX1 = 0x5A;	//1 Byte
const PREFIX2 = 0xA5;	//2 Byte

const START_BYTE = 0xAB;	//1 Byte
const STOP_BYTE = 0xBA;	// zadnji Byte

const CMD_TIPKA_PRITISNUTA = 0xD2;
const CMD_JUMPER_AKTIVNI = 0xD3;

const CMD_OCITAJ_TIPKE = 0xD4;
const CMD_OCITAJ_JUMPERE = 0xD5;

const CMD_READ_ALL_SETUP_VALUE = 0xA0;		//vraca sve vrijednosti postavki u EEPROM-u
const CMD_WRITE_ALL_SETUP_VALUE = 0xA1;		//mijenja sve vrijednosti postavki u EEPROM-u i memoriji
const CMD_READ_SERIAL_ID_AT = 0xA2;		//cita serijski broj uC Atmel max 32B  $AB$01$A2$A3$BA
const CMD_WRITE_SERIAL_ID_AT = 0xA3;		//pise serijski broj uC Atmel max 32B

const CMD_RETURN_GAME_SETTINGS = 0xA4;		//return game settings
const CMD_RETURN_GAME_DATA = 0xA5;		//return game data
const CMD_SAVE_GAME_SETTINGS = 0xA6;		//save game settings
const CMD_SAVE_GAME_DATA = 0xA7;		//save game data
const CMD_RESET_UC = 0xA9;		//reset $AB$05$A9$A9$A9$A9$A9$4D$BA
const CMD_RETURN_GAME_TURNIR_SETTINGS = 0xB8; //return game turnir settings

// 0xAB se ne korsite, koristi protocolx kao START
const CMD_CURRENT_MENU_SETTINGS = 0xAC;		//return current menu settings and sub menu
const CMD_COUNTERS_MENU_SETTINGS = 0xAA;		//return counters menu data , step , min, max, value

const CMD_RETURN_MENU_SETTINGS_MAIN = 0xAD;		//return main keep booking
const CMD_RETURN_MENU_SETTINGS_SEC = 0xAE;		//return sec keep booking
const CMD_CURRENT_MENU_TEST = 0xAF;		//return current test settings
const CMD_CURRENT_MENU_SETUP = 0xBB;		//return current test settings

const CMD_RPI_TO_CPU_READY = 0xBC;


//nove konstante ovdje
const setgamedata ='';
const testdata = 'ABAEA6FF0102030405020101010101010201FF0101040100000000000100000000FF0102030405020101010101010201FF0101040100000000000000000000050A0F14191E140707070709070707010A0A1E0900000000000A00000000050A0F14191E140707070709070707010A0A1E0900000000000000000000000000000000FF0000010000000A010100010201010100020100000000000000000000000000000000010102000003FF0000010200A1BA';
const cmdReadGameData = 'AB01A5A6BA';		//cmdReadGameData   Ivan vukoja Statust data
const cmdReadGameSettings = 'AB01A4A5BA';		//cmdReadGameSettings   Ivan vukoja Statust data
const OPTION_NONE = 0x00;
const OPTION_DOUBLE_IN = 0x01;
const OPTION_DOUBLE_OUT = 0x02;
const OPTION_DBLIN_OUT = 0x03;
const OPTION_EQUAL = 0x20;
const OPTION_PARCHEESI = 0x1000;
const OPTION_MASTEROUT = 0x4000;
const OPTION_TEAM = 0x8000;
const OPTION_QUATTRO = 0x0200;


const GameNameSub_int = {'0':'',
					 '1':'Option Equal',
					 '2':'Option End',
					 '10':'Run and Gun',
					 '11':'Parchessi',
					 '12':'Parchessi/Equal',
					 '13':'Parchessi/End',
					 '25':'',
					 '26':'Pick it',
					 '27':'Random',
					 '28':'Crazy',
					 '35':'Cricket Master',
					 '36':'Pick it Master',
					 '37':'Random Master',
					 '38':'Crazy Master',
					 '45':'Cricket Killer',
					 '46':'Pick it Killer',
					 '47':'Random Killer',
					 '48':'Crazy Killer',
					 '55':'Cut-throat',
					 '56':'Pick it Cut',
					 '57':'Random Cut',
					 '58':'Crazy Cut',
					 '70':'Marathon Mini',
					};
const teamOptionName_int = {'0':'',
						'2':'2 Players',
						'3':'3 Players',
						'4':'4 Players'
					   };
const language_int =  	{'0':'hr',
					 '12':'en'
				  	};
const pod_menu_int =  	{'01':'price_adjust',
					 '02':'happy_price',
					 '03':'round_adjust',
					 '04':'happy_round',
					 '05':'setup_clock',
					 '06':'setup_happy_hour',
					 '07':'bonus_credit',
					 '08':'bonus_percent',
					 '09':'time_limit',
					 '0A':'counter_pulses',
					 '0B':'switch_credit',
					 '0C':'time_credits',
					 '0D':'publicity',
					 '0E':'lottery',
					 '0F':'options_remember',
					 '10':'demo_sound',
					 '11':'quatro_mode',
					 '12':'target_quatro',
					 '13':'return_dart',
					 '14':'bull_value',
					 '15':'play_off',
					 '16':'lamp_on',
					 '17':'main_lamp',
					 '18':'back_light',
					 '19':'led_light',
					 '1A':'infra_adjust',
					 '1B':'statistics',
					 '1C':'coin_cctalk',
					 '1D':'bill_cctalk',
					 '1E':'coin_pulse',
					 '1F':'bill_pulse',
					 '20':'money_credit',
					};

const pod_menu_value_int =  {'00':'',
						 '01':'180',
				   		 '02':'301',
						 '03':'501',
				   		 '04':'701',
						 '05':'901',
						 '06':'1001',
						 '07':'cricket',
				   		 '08':'hi_score',
						 '09':'lo_score',
						 '0A':'super_score',
						 '0B':'shangai',
						 '0C':'baseball',
						 '0D':'roulette',
						 '0E':'scram',
						 '0F':'super_100',
						 '10':'pub',
						 '11':'solo_hi_score',
						 '12':'solo_301',
						 '13':'marathon',
						 '14':'split_score',
						 '15':'double_in',
						 '16':'double_out',
						 '17':'double_in_out',
						 '18':'master_out',
						 '19':'cut_throat',
						 '1A':'shorty',
						 '1B':'pickit',
						 '1C':'random',
						 '1D':'crazy',
						 '1E':'killer'
				  		};


const GameName = ['180', '301', '501','701', '901', '1001','Cricket','Hi score ','Low score',
				'Super Score','Shanghai','Baseball','Roulette','Scram','Super 100','Pub game','Solo Hi Score','Solo 301','Marathon','Split score',
				'Solo 301','Marathon','Split score'];
const GameNameSub = {'0':'',
					 '1':'Option Equal',
					 '2':'Option End',
					 '10':'Run and Gun',
					 '11':'Parchessi',
					 '12':'Parchessi/Equal',
					 '13':'Parchessi/End',
					 '25':'',
					 '26':'Pick it',
					 '27':'Random',
					 '28':'Crazy',
					 '35':'Cricket Master',
					 '36':'Pick it Master',
					 '37':'Random Master',
					 '38':'Crazy Master',
					 '45':'Cricket Killer',
					 '46':'Pick it Killer',
					 '47':'Random Killer',
					 '48':'Crazy Killer',
					 '55':'Cut-throat',
					 '56':'Pick it Cut',
					 '57':'Random Cut',
					 '58':'Crazy Cut',
					 '70':'Marathon Mini',
					};
const teamOptionName = {'0':'',
						'2':'2 Players',
						'3':'3 Players',
						'4':'4 Players'
					   };
const language =  	{'0':'hr',
					 '12':'en'
				  	};
const pod_menu =  	{'01':'price_adjust',
					 '02':'happy_price',
					 '03':'round_adjust',
					 '04':'happy_round',
					 '05':'setup_clock',
					 '06':'setup_happy_hour',
					 '07':'bonus_credit',
					 '08':'bonus_percent',
					 '09':'time_limit',
					 '0A':'counter_pulses',
					 '0B':'switch_credit',
					 '0C':'time_credits',
					 '0D':'publicity',
					 '0E':'lottery',
					 '0F':'options_remember',
					 '10':'demo_sound',
					 '11':'quatro_mode',
					 '12':'target_quatro',
					 '13':'return_dart',
					 '14':'bull_value',
					 '15':'play_off',
					 '16':'lamp_on',
					 '17':'main_lamp',
					 '18':'back_light',
					 '19':'led_light',
					 '1A':'infra_adjust',
					 '1B':'statistics',
					 '1C':'coin_cctalk',
					 '1D':'bill_cctalk',
					 '1E':'coin_pulse',
					 '1F':'bill_pulse',
					 '20':'money_credit',
					};

const pod_menu_value =  {'00':'',
						 '01':'180',
				   		 '02':'301',
						 '03':'501',
				   		 '04':'701',
						 '05':'901',
						 '06':'1001',
						 '07':'cricket',
				   		 '08':'hi_score',
						 '09':'lo_score',
						 '0A':'super_score',
						 '0B':'shangai',
						 '0C':'baseball',
						 '0D':'roulette',
						 '0E':'scram',
						 '0F':'super_100',
						 '10':'pub',
						 '11':'solo_hi_score',
						 '12':'solo_301',
						 '13':'marathon',
						 '14':'split_score',
						 '15':'double_in',
						 '16':'double_out',
						 '17':'double_in_out',
						 '18':'master_out',
						 '19':'cut_throat',
						 '1A':'shorty',
						 '1B':'pickit',
						 '1C':'random',
						 '1D':'crazy',
						 '1E':'killer'
				  		};

const poclXStartByte = 'AB';
const poclXEndByte = 'BA'
const errorByte = '5B';
const firstPassByte = '5A';
const secondPassByte = 'A5';
const ZEROS2 = '00';

const NO_MESS = 'No extra message';

const now = new Date();
const year = now.getFullYear();
const month = String(now.getMonth() + 1).padStart(2, '0');
const day = String(now.getDate()).padStart(2, '0');
const date = `${year}-${month}-${day}`;
//const date = "2023-02-24"

module.exports = {
	date:date,
	pod_menu_value:pod_menu_value,
	pod_menu:pod_menu,
	language:language,
	GameNameSub_int:GameNameSub_int,
	teamOptionName_int:teamOptionName_int,
	language_int:language_int,
	pod_menu_int:pod_menu_int,
	pod_menu_value_int:pod_menu_value_int,
	OPTION_NONE:OPTION_NONE,
	OPTION_DOUBLE_IN:OPTION_DOUBLE_IN,
	OPTION_DOUBLE_OUT:OPTION_DOUBLE_OUT,
	OPTION_DBLIN_OUT:OPTION_DBLIN_OUT,
	OPTION_EQUAL:OPTION_EQUAL,
	OPTION_PARCHEESI:OPTION_PARCHEESI,
	OPTION_MASTEROUT:OPTION_MASTEROUT,
	OPTION_TEAM:OPTION_TEAM,
	OPTION_QUATTRO:OPTION_QUATTRO,
	GameDataByte: GameDataByte, //Ivan Vukoja
	GameSettingsByte:GameSettingsByte, //Ivan vukoja
	dip_switch_menu_Byte:dip_switch_menu_Byte,
	dip_switch_menu_settings_Byte:dip_switch_menu_settings_Byte,
	dip_switch_test_menu_Byte:dip_switch_test_menu_Byte,
	GameName:GameName,
	GameNameSub:GameNameSub,
	cmdReadGameData: cmdReadGameData,
	cmdReadGameSettings: cmdReadGameSettings,
	teamOptionName:teamOptionName,
	
	errorByte: errorByte,
	firstPassByte: firstPassByte,
	secondPassByte: secondPassByte,
	poclXStartByte: poclXStartByte,
	poclXEndByte: poclXEndByte,
	NO_MESS: NO_MESS,
	ZEROS2: ZEROS2,
	HEX_B: HEX_B,
	testdata: testdata,
	setgamedata:setgamedata,
	PREFIX1: PREFIX1,
    PREFIX2: PREFIX2,
    START_BYTE: START_BYTE,
    STOP_BYTE: STOP_BYTE,
    CMD_TIPKA_PRITISNUTA: CMD_TIPKA_PRITISNUTA,
    CMD_JUMPER_AKTIVNI: CMD_JUMPER_AKTIVNI,
    CMD_OCITAJ_TIPKE: CMD_OCITAJ_TIPKE,
    CMD_OCITAJ_JUMPERE: CMD_OCITAJ_JUMPERE,
    CMD_READ_ALL_SETUP_VALUE: CMD_READ_ALL_SETUP_VALUE,
    CMD_WRITE_ALL_SETUP_VALUE: CMD_WRITE_ALL_SETUP_VALUE,
    CMD_READ_SERIAL_ID_AT: CMD_READ_SERIAL_ID_AT,
    CMD_WRITE_SERIAL_ID_AT: CMD_WRITE_SERIAL_ID_AT,
    CMD_RETURN_GAME_SETTINGS: CMD_RETURN_GAME_SETTINGS,
	CMD_RPI_TO_CPU_READY:CMD_RPI_TO_CPU_READY,
    CMD_RETURN_GAME_DATA: CMD_RETURN_GAME_DATA,
    CMD_SAVE_GAME_SETTINGS: CMD_SAVE_GAME_SETTINGS,
    CMD_SAVE_GAME_DATA: CMD_SAVE_GAME_DATA,
    CMD_RESET_UC: CMD_RESET_UC,
	CMD_RETURN_GAME_TURNIR_SETTINGS: CMD_RETURN_GAME_TURNIR_SETTINGS,
    CMD_CURRENT_MENU_SETTINGS: CMD_CURRENT_MENU_SETTINGS,
    CMD_COUNTERS_MENU_SETTINGS: CMD_COUNTERS_MENU_SETTINGS,
    CMD_RETURN_MENU_SETTINGS_MAIN: CMD_RETURN_MENU_SETTINGS_MAIN,
    CMD_RETURN_MENU_SETTINGS_SEC: CMD_RETURN_MENU_SETTINGS_SEC,
    CMD_CURRENT_MENU_TEST: CMD_CURRENT_MENU_TEST,
	CMD_CURRENT_MENU_SETUP: CMD_CURRENT_MENU_SETUP
}
