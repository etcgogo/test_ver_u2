'use strict'

module.exports = class Team {
	constructor(team) {
		this.id = team.id;
		this.name = team.name;
		this.score = 0;
		this.penaltyScore = 0;
		this.roundScores = [];
		this.freezeBust = 0;
	}
}