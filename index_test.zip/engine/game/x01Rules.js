﻿"use strict";

const BaseRules = require('./baseRules');

// gameType     - x01/Cricket, GameTypeEnum
// score         - 301-1001, TargetScoreEnum
// parcheesi     - true/false
// rounds         - number of rounds to play
// runAndGun    - true/false
// playOff        - true/false
// doubleOut    - true/false
// masterOut    - true/false
// teamRules    - ...
module.exports = class x01Rules extends BaseRules {
	constructor(gameType, score, parcheesi, rounds, runAndGun, runAndGunTime, playOff, doubleIn, doubleOut, masterOut, equalOption, endOption, quatro, undo, handicap, bull, teamRules) {
		super(gameType, rounds, quatro, undo, handicap, teamRules);
		//new BaseRules();
		this.score = score;
		this.parcheesi = parcheesi;
		this.runAndGun = runAndGun;
		this.runAndGunTime = (this.runAndGun === true) ? runAndGunTime : 60;
		this.playOff = playOff;
		this.doubleIn = doubleIn;
		this.doubleOut = doubleOut;
		this.masterOut = masterOut;
		this.equalOption = equalOption;
		this.endOption = endOption;
		this.bull = bull;
	}
	validate() {
		if (BaseRules.prototype.validate.call(this) === false) {
			return false;
		}
		if (this.doubleOut === true && this.masterOut === true) {
			return false;
		}
		if (this.equalOption === true && this.endOption === true) {
			return false;
		}
		return true;
	}
}

const TargetScoreEnum = {
	g301: 301,
	g501: 501,
	g701: 701,
	g901: 901,
	g1001: 1001,
	playoff: 0,
};
