var io = require('socket.io-client');
let socket_server = io.connect(process.env.FLEET_URL, {reconnect: true});
const si = require('systeminformation');
const mongo = require('../objects/mongo');
const serialPort = require('./serialPortWorker');
const constant = require('../const/const');
const wifiWorker = require('./wifiWorker');
var uuid = 0;

si.uuid(function(data) {
  uuid = data.hardware;
})


module.exports = function (pio, jsonfile, log) {
    socket_server.on('connect', function (socket_server) {
        console.log('Connected!');
        //console.log('ovov je data',uuid)
    });
    setTimeout(() => {
        socket_server.emit('join', {user_id:process.env.ID,socket_id:null});   
    }, 100);
    

    socket_server.on("new_msg", function(data) {
        console.log(data.msg);
        mongo.retriveInitialData(function(data) {
             if (data) {
                 //console.log('ovo je data',data.gameSettings.gameList[0]);
                 mongo.updateMode(data);
                 setTimeout(() => {
                     //console.log('pisem na aparat socket',mongo.sendSetup())
                     serialPort.writeSerial(Buffer.from(mongo.sendSetup(), constant.HEX_B));
                    }, 1000);
                if(data.wifiSettings.Connect){
                    setTimeout(() => {
                        //console.log('data',data.wifiSettings);
                        wifiWorker.scanWifi()
                        wifiWorker.connectToWifi(data.wifiSettings.Name,data.wifiSettings.Password)
                    }, 1000);
                }
                
                
                
             } else {
                 console.log('nema podataka');
                
             }
        });
    });
}