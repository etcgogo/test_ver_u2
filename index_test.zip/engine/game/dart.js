﻿// player    - Player
// score     - 1-20, 1-20 x2, 1-20 x3, 25, 50, 0, -1, -2, -3, -4, -5
module.exports = class Dart {
    constructor(hitEnum, isDouble, isTriple, isQuatro, quatroAllowed) {
        this.hitEnum = hitEnum;
        this.isDouble = isDouble;
        this.isTriple = isTriple;
        this.isQuatro = isQuatro;
        this.date = new Date().toISOString().slice(0, 10).replace('T', ' ');
        this.time = new Date().toISOString().slice(11, 19).replace('T', ' ');
        this.quatroAllowed = quatroAllowed;
        if (hitEnum === 0 || hitEnum === -1) {
            this.score = 0;
        }
        else if (hitEnum === -2) {
            this.score = 0;
        }
        else {
            if (isDouble === true) {
                this.score = hitEnum * 2;
            }
            else if (isTriple === true) {
                this.score = hitEnum * 3;
            }
            else if (isQuatro && quatroAllowed) {
                this.score = hitEnum * 4;
            }
            else {
                this.score = hitEnum;
            }
        }
        this.player = {};
    }
}