const constant = require('../const/const');
const variables = require('../const/varibales');
const ErrorHandeler = require('../objects/errorHandeler');

function Transmute() {
	this.startProtocolX = false;
	this.bytes = [];
	this.orderBytes = [];
	this.orderBytes4 = [];
	this.transmuting = true;
	this.push = function(data, callback1, callback2) {
		let _this = this;
		if (!_this.transmuting) {
			callback2(data);
		}
		let incomingBytes = new Uint8Array(data);
		for (let i = 0; i < incomingBytes.length; i++) {
			_this.bytes.push(incomingBytes[i]);
		}
		while (_this.bytes.length > 0) {
			if (_this.bytes[0] === parseInt(constant.poclXStartByte, 16)) {
				_this.orderBytes.push(_this.bytes.shift());
				_this.startProtocolX = true;
				continue;
			}
			if (_this.bytes[0] === parseInt(constant.poclXEndByte, 16)) {

				_this.orderBytes.push(_this.bytes.shift());
							let sum = 0;
							for (let i = 1; i <= _this.orderBytes[1]; i++) {
							sum += _this.orderBytes[i];
							}
				//console.log('_this.orderBytes',_this.orderBytes,'sum',sum)
				if (_this.startProtocolX && sum !== parseInt(constant.poclXEndByte, 16)) {
					callback1(Buffer.from(_this.orderBytes));
					_this.orderBytes = [];
					_this.startProtocolX = false;
								}else if(_this.startProtocolX && sum === parseInt(constant.poclXEndByte, 16)
								&& _this.orderBytes[_this.orderBytes.length - 1] === parseInt(constant.poclXEndByte, 16)
								&& _this.orderBytes[_this.orderBytes.length - 2] === parseInt(constant.poclXEndByte, 16)){
									callback1(Buffer.from(_this.orderBytes));
									_this.orderBytes = [];
									_this.startProtocolX = false;
								}
				continue;
			}

			if (_this.bytes[0] === parseInt(constant.firstPassByte, 16)) {
				if (_this.bytes[1] && _this.bytes[1] === parseInt(constant.secondPassByte, 16)) {
					if (_this.bytes[2] && _this.bytes[3] && _this.bytes[2] === 255 - _this.bytes[3] ||
						_this.bytes[2] && _this.bytes[3] && (_this.bytes[2] === 255 - _this.bytes[3] - 1 || _this.bytes[2] === 255 - _this.bytes[3] + 1 || _this.bytes[2] === 255 - _this.bytes[3] + 2 || _this.bytes[2] === 255 - _this.bytes[3] + 3 || _this.bytes[2] === 255 - _this.bytes[3] + 4 || _this.bytes[2] === 255 - _this.bytes[3] + 5)) {
						for (let i = 0; i < 4; i++) {
							_this.orderBytes4.push(_this.bytes.shift());
						}
						callback1(Buffer.from(_this.orderBytes4));
						_this.orderBytes4 = [];
						continue;
					} else if (!_this.bytes[2] || !_this.bytes[3]) {
						break;
					}
				} else if (!_this.bytes[1]) {
					break;
				}
			}

			if (_this.startProtocolX) {
				_this.orderBytes.push(_this.bytes.shift());
				continue;
			}

			_this.bytes.shift();
		}
	}

	this.stopTransmuting = function() {
		this.transmuting = false;
	}

	this.resumeTransmuting = function() {
		this.transmuting = true;
	}
}

function parseHex(hexString) {
	if (!hexString) {
		ErrorHandeler.newError(19, constant.NO_MESS);
		return;
	}

	return hexString.toString(constant.HEX_B).toUpperCase();
}

function parseStatusData(statusBuffer) {    //// Ivan vukoja Statust data
	let bytes = new Uint8Array(statusBuffer);
	let menuState = hexify(bytes[2]);

	// CS LL OR IN CC CS
	//console.log('sta tu dobijem',constant.poclXStartByte,bytes[0].toString(16).toUpperCase(),'dali je ovo drugi',constant.poclXStartByte,bytes[bytes.length - 1].toString(16).toUpperCase())
	if (bytes[0].toString(16).toUpperCase() !== constant.poclXStartByte || bytes[bytes.length - 1].toString(16).toUpperCase() !== constant.poclXEndByte) {
		// data not valid
		console.log('DATA NOT VALID test', bytes);
		return;
	}
	//console.log('manuState?', menuState);

	else if (menuState === constant.GameDataByte) {
			length = bytes[1];
			command = bytes[2];
			game_mode = bytes[3];
			player_value = [bytes[4]+(bytes[5] * 256),bytes[6]+(bytes[7] * 256),bytes[8]+(bytes[9] * 256),
							bytes[10]+(bytes[11] * 256),bytes[12]+(bytes[13] * 256),bytes[14]+(bytes[15] * 256),
							bytes[16]+(bytes[17] * 256),bytes[18]+(bytes[19] * 256)];
			currentRoundScore =  bytes[20]+(bytes[21] * 256);
			dart = bytes[22];
			round = bytes[23];
			player_throw = bytes[24];
			credit = bytes[25]+(bytes[26] * 256);

			game = bytes[27];
			option = bytes[28] + (bytes[29] * 256);
			num_players = bytes[30];
			cricket_numbers_closed = [
				bytes[31], bytes[32], bytes[33],
				bytes[34], bytes[35], bytes[36],
				bytes[37], bytes[38], bytes[39],
				bytes[40], bytes[41], bytes[42],
				bytes[43], bytes[44], bytes[45],
				bytes[46], bytes[47], bytes[48],
				bytes[49], bytes[50], bytes[51],
				bytes[52], bytes[53], bytes[54]
			]; // cricket 24

			player_rank = [
				bytes[55], bytes[56], bytes[57],
				bytes[58], bytes[59], bytes[60],
				bytes[61], bytes[62]
			]; // 8

			playoff_flag = bytes[63];
			sub_game = bytes[64];
			team_num = bytes[65];
			flags_data = bytes[66];
			cricket_numbers = [
				bytes[67], bytes[68], bytes[69],
				bytes[70], bytes[71], bytes[72],
				bytes[73], bytes[74]
			]; // 8
			darts_thrown = bytes[75] + (bytes[76] * 256);
			max_darts_thrown = bytes[77] + (bytes[78] * 256);
			dart_hit = [bytes[79], bytes[80], bytes[81]];
			parts_of_credit_in_dart = bytes[82];
			
			/*
			c_cijena_igre: 0,
			c_max_rounds: 0,
			c_show_msg: 0,
			c_jumpers: 0,
			c_ver_cpu: new Uint8Array(2),
			c_ver_target: new Uint8Array(2),
			c_ver_cctalk: new Uint8Array(2)
			*/
			console.log('ovo je game data:',
			// 'length',length,
			//  'command',command,
			// 	'game_mode',game_mode,
			 	'player_value',player_value,
			// 	'currentRoundScore',currentRoundScore,
			//  'dart',dart,
			//  'round',round,
			//  'player_throw',player_throw,
			//  'player_rank',player_rank,
			//  'playoff_flag',playoff_flag,
			//   'credit',credit,
			// 	 'game',game,
			// 	 'option',option,
			// 	 'sub_game',sub_game,
			// 	 'num_players',num_players,
			 //	 'cricket_numbers_closed',cricket_numbers_closed,
			 //	 'cricket_numbers',cricket_numbers,
			// 	 'team_num',team_num,
			// 	 'flags_data',flags_data,
			 	 'darts_thrown',darts_thrown,
			// 'max_darts_thrown',max_darts_thrown,
			// 'dart_hit',dart_hit,
			// 'parts_of_credit_in_dart',parts_of_credit_in_dart
			);
			//valid = true;
		
		
		if((!variables.Game_data.activeGame.active || variables.Game_data.game.gameStatus.players.lenght === 0 || num_players !== variables.Game_data.game.gameStatus.players.lenght) && darts_thrown === 0){
			//console.log('u ovaj uvijet je usao jer je bio izvan u 0 ili je ovaj prazan');
			variables.Game_data.game.players = [];
			for (i = 0; i < num_players; i++){
				variables.Game_data.game.players.push({

						'id': i+1,
						'name': "Player"+(i+1),
						'type': null,
						'copyOfType': null,
						'owner': {
							'id': i+1,
							'name': "Player"+(i+1),
							'type': null,
							'copyOfType': null
						},
						'avgStatistic': 0,
						'numbersHit': 0,
						'totalScore': currentRoundScore,
						'roundScores': [],
						'score': player_value[i],
						'penaltyScore': 0,
						'darts':[],
						'numbersToHit': [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],
						'noOfDartsRemaining': 0,
						'runAndGunEndTime': 0,
						'teamId':null,
						'isDoubledIn': false,
						'shangaiWin': 0,
						'shangaiNo': 0,
						'ladder': 0,
						'playoff':false,
						'total_score': 0,
		
				});
			}
		}
		
		//console.log('sta se tu desi',variables.Game_data.activeGame.active,variables.Game_data.game.gameStatus.players.lenght,variables.Game_data.game.gameStatus.currentPlayer)
		if(variables.Game_data.activeGame.active && variables.Game_data.game.gameStatus.currentPlayer !== 0){
		variables.Game_data.game.players[variables.Game_data.game.gameStatus.currentPlayer].totalScore = currentRoundScore;
		variables.Game_data.game.players[variables.Game_data.game.gameStatus.currentPlayer].score = player_value[variables.Game_data.game.gameStatus.currentPlayer];
		}
		//let player = [];
		//console.log('dali ude svaki put ovdje---------------------');
		// // for (i = 0; i < num_players; i++){
		// // 	player.push({
		// // 		'id': i+1,
		// // 		'name': "Player"+(i+1),
		// // 		'type': null,
		// // 		'copyOfType': null,
		// // 		'owner': {
		// // 			'id': i+1,
		// // 			'name': "Player"+(i+1),
		// // 			'type': null,
		// // 			'copyOfType': null
		// // 		},
		// // 		'avgStatistic': "",
		// // 		'numbersHit': 0,
		// // 		'totalScore': currentRoundScore,
		// // 		'roundScores': [],
		// // 		'score': player_value[i],
		// // 		'penaltyScore': 0,
		// // 		'darts':[],
		// // 		'numbersToHit': [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],
		// // 		'noOfDartsRemaining': 0,
		// // 		'runAndGunEndTime': 0,
		// // 		'teamId':null,
		// // 		'isDoubledIn': false,
		// // 		'shangaiWin': 0,
		// // 		'shangaiNo': 0,
		// // 		'ladder': 0,
		// // 		'playoff':false,

		// // 	});
		// // }

		return {
			lenght:length,
			command:command,
			game_mode:game_mode,
			player:variables.Game_data.game.players,
			currentRoundScore:currentRoundScore,
			dart:dart,
			round:round,
			player_throw:player_throw,
			credit:credit,
			game:game,
			option:option,
			num_players:num_players,
			cricket_numbers_closed:cricket_numbers_closed,
			cricket_numbers:cricket_numbers,
			player_rank:player_rank,
			playoff_flag:playoff_flag,
			sub_game:sub_game,
			team_num:team_num,
			flags_data:flags_data,
			darts_thrown:darts_thrown,
			max_darts_thrown:max_darts_thrown,
			dart_hit:dart_hit,
			parts_of_credit_in_dart:parts_of_credit_in_dart

		};
    } else if (menuState === constant.GameSettingsByte){
			length = bytes[0];
			command = bytes[1];
			sta_je_ovo = bytes[2];
			/*ee_price_adjust = 
						[bytes[3],bytes[4],bytes[5],bytes[6],bytes[7],
						bytes[8],bytes[9],bytes[10],bytes[11],bytes[12],
						bytes[13],bytes[14],bytes[15],bytes[16],bytes[17],
						bytes[18],bytes[19],bytes[20],bytes[21],bytes[22],
						bytes[23],bytes[24],bytes[25],bytes[26],bytes[27],
						bytes[28],bytes[29],bytes[30],bytes[31],bytes[32]];
			ee_happy_price_adjust = 
						[bytes[33],bytes[34],bytes[35],bytes[36],bytes[37],
						bytes[38],bytes[39],bytes[40],bytes[41],bytes[42],
						bytes[43],bytes[44],bytes[45],bytes[46],bytes[47],
						bytes[48],bytes[49],bytes[50],bytes[51],bytes[52],
						bytes[53],bytes[54],bytes[55],bytes[56],bytes[57],
						bytes[58],bytes[59],bytes[60],bytes[61],bytes[62]];
			ee_round_adjust = 
						[bytes[63],bytes[64],bytes[65],bytes[66],bytes[67],
						bytes[68],bytes[69],bytes[70],bytes[71],bytes[72],
						bytes[73],bytes[74],bytes[75],bytes[76],bytes[77],
						bytes[78],bytes[79],bytes[80],bytes[81],bytes[82],
						bytes[83],bytes[84],bytes[85],bytes[86],bytes[87],
						bytes[88],bytes[89],bytes[90],bytes[91],bytes[92]];
			ee_happy_round_adjust = 
						[bytes[93],bytes[94],bytes[95],bytes[96],bytes[97],
						bytes[98],bytes[99],bytes[100],bytes[101],bytes[102],
						bytes[103],bytes[104],bytes[105],bytes[106],bytes[107],
						bytes[108],bytes[109],bytes[110],bytes[111],bytes[112],
						bytes[113],bytes[114],bytes[115],bytes[116],bytes[117],
						bytes[118],bytes[119],bytes[120],bytes[121],bytes[122]];
			ee_setup_time 				= [bytes[123],bytes[124],bytes[125]];
			ee_happy_setup_time 		= [bytes[126],bytes[127],bytes[128],bytes[129]];
			ee_time_limit 				= bytes[130];
			ee_counter_pulses 			= bytes[131];
			ee_switch_credits 			= bytes[132];
			ee_tcr 						= bytes[133];
			ee_bonus_credit 			= bytes[134];
			ee_bonus_percent 			= bytes[135];
			ee_lottery					= bytes[136];
			ee_option_remember			= bytes[137];
			ee_demo_sound				= bytes[138];
			ee_quatro_mode_on			= bytes[139];
			ee_return_dart				= bytes[140];
			ee_bull_value				= bytes[141];
			ee_play_off					= bytes[142];
			ee_lamp_on					= bytes[143];
			ee_main_lamp				= bytes[144];
			ee_back_light				= bytes[145];
			ee_infra_adjust  			= bytes[146];
			ee_acceptor_time_adjust 	= bytes[147];
			ee_ppd_statistics			= [bytes[148],bytes[149],bytes[150],bytes[151],bytes[152],bytes[153],bytes[154],bytes[155]];
			ee_ppr_statistics			= [bytes[156],bytes[157],bytes[158],bytes[159],bytes[160],bytes[161],bytes[162],bytes[163]];
			ee_location					= bytes[164];
			ee_coin_value				= bytes[165];
			ee_led_light				= bytes[166];
			ee_sett_language			= bytes[167];
			ee_sett_num_acceptors		= bytes[168];
			ee_sett_num_counters		= bytes[169];
			ee_sett_led_mount			= bytes[170];
			ee_sett_happy_day			= bytes[171];
			ee_money_for_credit			= bytes[172];
			ee_sett_target_quattro_on 	= bytes[173];
			ee_model_type 				= bytes[174];
			ee_model_target 			= bytes[175];
			ee_tup_sense 				= bytes[176];

			ee_vrijednost_kanala_cctalka = [
				bytes[177], bytes[178], bytes[179], bytes[180], bytes[181],
				bytes[182], bytes[183], bytes[184], bytes[185], bytes[186],
				bytes[187], bytes[188], bytes[189], bytes[190], bytes[191],
				bytes[192], bytes[193], bytes[194], bytes[195], bytes[196],
				bytes[197], bytes[198], bytes[199], bytes[200], bytes[201],
				bytes[202], bytes[203], bytes[204], bytes[205], bytes[206], 
				bytes[207], bytes[208]
			];
			
			ee_vrijednost_impulsa_kanala = [bytes[209],bytes[210]];
			ee_cijena_jednog_kredita 	= bytes[211];
			ee_coin_channel_inhibit		= bytes[212];
			ee_bill_channel_inhibit		= bytes[213];
			ee_coin_table_extra_credits= [
				bytes[214], bytes[215], bytes[216], bytes[217], bytes[218],
				bytes[219], bytes[220], bytes[221], bytes[222], bytes[223],
				bytes[224], bytes[225], bytes[226], bytes[227], bytes[228],
				bytes[229]
			];
			ee_bill_table_extra_credits= [
				bytes[230], bytes[231], bytes[232], bytes[233], bytes[234],
				bytes[235], bytes[236], bytes[237], bytes[238], bytes[239],
				bytes[240], bytes[241], bytes[242], bytes[243], bytes[244],
				bytes[245]
			];*/
		
			console.log('ovo je GameSettings',
			  	// 'length',length,
			 	// 'command',command,
			 	// 'sta_je_ovo',sta_je_ovo,cd server
			 	// 'ee_price_adjust',ee_price_adjust,
			//  	'ee_happy_price_adjust',ee_happy_price_adjust,
			// 	'ee_round_adjust',ee_round_adjust,
			// 	'ee_happy_round_adjust',ee_happy_round_adjust,
			// 	'ee_setup_time' ,ee_setup_time ,
			// 	'ee_happy_setup_time',ee_happy_setup_time,
			// 	'ee_time_limit',ee_time_limit,
			// 	'ee_counter_pulses',ee_counter_pulses,
			// 	'ee_switch_credits',ee_switch_credits,
			// 	'ee_tcr',ee_tcr,
			// 	'ee_bonus_credit',ee_bonus_credit,
			// 	'ee_bonus_percent',ee_bonus_percent,
			// 	'ee_lottery',ee_lottery,
			// 	'ee_option_remember',ee_option_remember,
			// 	'ee_demo_sound',ee_demo_sound,
			// 	'ee_quatro_mode_on',ee_quatro_mode_on,
			// 	'ee_return_dart',ee_return_dart,
			// 	'ee_bull_value',ee_bull_value,
			// 	'ee_play_off',ee_play_off,
			// 	'ee_lamp_on',ee_lamp_on,
			// 	'ee_main_lamp',ee_main_lamp,
			// 	'ee_back_light',ee_back_light,
			// 	'ee_infra_adjust',ee_infra_adjust,
			// 	'ee_acceptor_time_adjust',ee_acceptor_time_adjust,
			// 	'ee_ppd_statistics',ee_ppd_statistics,
			// 	'ee_ppr_statistics',ee_ppr_statistics,
			// 	'ee_location',ee_location,
			// 	'ee_coin_value',ee_coin_value,
			// 	'ee_led_light',ee_led_light,
			// 'ee_sett_language',ee_sett_language,
			// 	'ee_sett_num_acceptors',ee_sett_num_acceptors,
			// 	'ee_sett_num_counters',ee_sett_num_counters,
			// 	'ee_sett_led_mount',ee_sett_led_mount,
			// 	'ee_sett_happy_day',ee_sett_happy_day,
			// 	'ee_money_for_credit',ee_money_for_credit,
			// 	'ee_sett_target_quattro_on',ee_sett_target_quattro_on
			);
			return {
					length:length,
					command:command,
					sta_je_ovo:sta_je_ovo,
					/*ee_price_adjust:ee_price_adjust,
					ee_happy_price_adjust:ee_happy_price_adjust,
					ee_round_adjust:ee_round_adjust,
					ee_happy_round_adjust:ee_happy_round_adjust,
					ee_setup_time:ee_setup_time,
					ee_happy_setup_time:ee_happy_setup_time,
					ee_time_limit:ee_time_limit,
					ee_counter_pulses:ee_counter_pulses,
					ee_switch_credits:ee_switch_credits,
					ee_tcr:ee_tcr,
					ee_bonus_credit:ee_bonus_credit,
					ee_bonus_percent:ee_bonus_percent,
					ee_lottery:ee_lottery,
					ee_option_remember:ee_option_remember,
					ee_demo_sound:ee_demo_sound,
					ee_quatro_mode_on:ee_quatro_mode_on,
					ee_return_dart:ee_return_dart,
					ee_bull_value:ee_bull_value,
					ee_play_off:ee_play_off,
					ee_lamp_on:ee_lamp_on,
					ee_main_lamp:ee_main_lamp,
					ee_back_light:ee_back_light,
					ee_infra_adjust:ee_infra_adjust,
					ee_acceptor_time_adjust:ee_acceptor_time_adjust,
					ee_ppd_statistics:ee_ppd_statistics,
					ee_ppr_statistics:ee_ppr_statistics,
					ee_location:ee_location,
					ee_coin_value:ee_coin_value,
					ee_led_light:ee_led_light,
					ee_sett_language:ee_sett_language,
					ee_sett_num_acceptors:ee_sett_num_acceptors,
					ee_sett_num_counters:ee_sett_num_counters,
					ee_sett_led_mount:ee_sett_led_mount,
					ee_sett_happy_day:ee_sett_happy_day,
					ee_money_for_credit:ee_money_for_credit,
					ee_sett_target_quattro_on:ee_sett_target_quattro_on,
					ee_model_type:ee_model_type,
					ee_model_target:ee_model_target,
					ee_tup_sense:ee_tup_sense,
					ee_vrijednost_kanala_cctalka:ee_vrijednost_kanala_cctalka, 
    				ee_vrijednost_impulsa_kanala:ee_vrijednost_impulsa_kanala, 
					ee_cijena_jednog_kredita:ee_cijena_jednog_kredita,
					ee_coin_channel_inhibit:ee_coin_channel_inhibit,
					ee_bill_channel_inhibit:ee_bill_channel_inhibit,
					ee_coin_table_extra_credits:ee_coin_table_extra_credits,
					ee_bill_table_extra_credits:ee_bill_table_extra_credits,*/
				};
	}
}


function isInternetUp(callback) {
	callback(true);
	require('dns').lookup('www.google.com', function(err) {
		if (err) {
			ErrorHandeler.newError(10, err);
			callback(false);
		} else {
			callback(true);
		}
	});
}

function hexify(unfullHex) {
    if (!unfullHex && unfullHex !== 0) {
		ErrorHandeler.newError(12, constant.NO_MESS);
        return;
    } else if (unfullHex === 0) {
		return constant.ZEROS2;
	}
	return (constant.ZEROS2 + unfullHex.toString(16).toUpperCase()).slice(-2)
}

function getTup(data) {
	if (!data) {
		ErrorHandeler.newError(17, constant.NO_MESS);
		return;
	}
	let bytes = new Uint8Array(data);
	let byte0 = bytes[0];
	let byte1 = bytes[1];
	let byte2 = bytes[2];
	let byte3 = bytes[3];

	if (byte0 === 90 && byte1 === 165 && byte2 === (255 - byte3) && byte2 === 33) {
		return true;
	} else {
		return false;
	}
}

function mapCodeToHit(data, isSuper100, callback) {
	let hit = {};
	hit.score = 0;
	hit.multiplier = 1;
	hit.hitValid = false;
	hit.irSensor = false;
	hit.dartStuck = false;
	hit.dartUnStuck = false;
	hit.playerButton = false;
	hit.isInner = false;
	hit.isOuter = false;
	hit.message = '';
	let bytes = new Uint8Array(data);
	let byte0 = bytes[0];
	let byte1 = bytes[1];
	let byte2 = bytes[2];
	let byte3 = bytes[3];

	if (!isSuper100) {
		console.log('usao je u hit','byte0',byte0,'byte1',byte1,'byte2',byte2,'byte3',byte3);
		if (byte0 === 90 && byte1 === 165 && byte2 === (255 - byte3)) {
			if (0 < byte2 && byte2 <= 25) {
				hit.score = byte2;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.isInner = true;
			} else if (50 < byte2 && byte2 <= 70) {
				hit.score = byte2 - 50;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.isOuter = true;
			} else if (100 < byte2 && byte2 <= 125) {
				hit.score = byte2 - 100;
				hit.multiplier = 2;
				hit.hitValid = true;
			} else if (200 < byte2 && byte2 <= 220) {
				hit.score = byte2 - 200;
				hit.multiplier = 3;
				hit.hitValid = true;
			} else if (150 < byte2 && byte2 <= 170) {
				hit.score = byte2 - 150;
				hit.multiplier = 4;
				hit.hitValid = true;
			} else if (byte2 === 30) {
				hit.message = 'Player button';
				hit.playerButton = true;
				hit.hitValid = true;
			} else if (byte2 === 32) {
				hit.message = 'IR sensor';
				hit.irSensor = true;
				hit.irSensorActivate = true;
			} else if (byte2 === 235) {
				hit.message = 'IR sensor';
				hit.irSensor = true;
				hit.irSensorActivate = false;
			} else if (byte2 === 33) {
				hit.score = -1;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.message = 'TUP';
			}
		} else if (byte0 === 90 && byte1 === 165 && byte2 === (255 - byte3 + 1)) {
			dartStuck = true;
			hit.message = 'Dart stuck!';
			hit.dartStuck = true;
			if (0 < byte2 && byte2 <= 25) {
				hit.score = byte2;
				hit.multiplier = 1;
				hit.isInner = true;
			} else if (50 < byte2 && byte2 <= 70) {
				hit.score = byte2 - 50;
				hit.multiplier = 1;
				hit.isOuter = true;
			} else if (100 < byte2 && byte2 <= 125) {
				hit.score = byte2 - 100;
				hit.multiplier = 2;
			} else if (200 < byte2 && byte2 <= 220) {
				hit.score = byte2 - 200;
				hit.multiplier = 3;
			} else if (150 < byte2 && byte2 <= 170) {
				hit.score = byte2 - 150;
				hit.multiplier = 4;
			}
		} else if (byte0 === 90 && byte1 === 165 && byte2 === (255 - byte3 - 1)) {
			dartStuck = false;
			hit.message = 'Dart unstuck!';
			hit.dartUnStuck = true;
			if (0 < byte2 && byte2 <= 25) {
				hit.score = byte2;
				hit.multiplier = 1;
				hit.isInner = true;
			} else if (50 < byte2 && byte2 <= 70) {
				hit.score = byte2 - 50;
				hit.multiplier = 1;
				hit.isOuter = true;
			} else if (100 < byte2 && byte2 <= 125) {
				hit.score = byte2 - 100;
				hit.multiplier = 2;
			} else if (200 < byte2 && byte2 <= 220) {
				hit.score = byte2 - 200;
				hit.multiplier = 3;
			} else if (150 < byte2 && byte2 <= 170) {
				hit.score = byte2 - 150;
				hit.multiplier = 4;
			}
		} else {
			hit.message = 'Error in code.';
			ErrorHandeler.newError(18, hit.message);
		}
	} else {
		console.log('Ulazak u super 100 logiku');
		console.log('Bytovi: ', byte0, byte1, byte2, byte3);
		if (byte0 === 90 && byte1 === 165 && byte2 === (255 - byte3 + 2)) {
			if (0 < byte2 && byte2 <= 25) {
				if (byte2 !== 25) {
					hit.score = 0;
				} else {
					hit.score = 1;
				}
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.isInner = true;
			} else if (50 < byte2 && byte2 <= 70) {
				hit.score = 0;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.isOuter = true;
			} else if (100 < byte2 && byte2 <= 125) {
				if (byte2 !== 125) {
					hit.score = 0;
				} else {
					hit.score = 1.5;
				}
				hit.multiplier = 2;
				hit.hitValid = true;
			} else if (200 < byte2 && byte2 <= 220) {
				hit.score = 0;
				hit.multiplier = 3;
				hit.hitValid = true;
			} else if (150 < byte2 && byte2 <= 170) {
				hit.score = 0;
				hit.multiplier = 4;
				hit.hitValid = true;
			} else if (byte2 === 30) {
				hit.message = 'Player button';
				hit.playerButton = true;
				hit.hitValid = true;
			} else if (byte2 === 32) {
				hit.message = 'IR sensor';
				hit.irSensor = true;
				hit.irSensorActivate = true;
			} else if (byte2 === 235) {
				hit.message = 'IR sensor';
				hit.irSensor = true;
				hit.irSensorActivate = false;
			} else if (byte2 === 33) {
				hit.score = -1;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.message = 'TUP';
			}
		} else if (byte0 === 90 && byte1 === 165 && byte2 === (255 - byte3 + 5)) {
			if (0 < byte2 && byte2 <= 25) {
				hit.score = 2;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.isInner = true;
			} else if (50 < byte2 && byte2 <= 70) {
				hit.score = 2;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.isOuter = true;
			} else if (100 < byte2 && byte2 <= 125) {
				hit.score = 2;
				hit.multiplier = 2;
				hit.hitValid = true;
			} else if (200 < byte2 && byte2 <= 220) {
				hit.score = 2;
				hit.multiplier = 3;
				hit.hitValid = true;
			} else if (150 < byte2 && byte2 <= 170) {
				hit.score = 2;
				hit.multiplier = 4;
				hit.hitValid = true;
			}
		} else if (byte0 === 90 && byte1 === 165 && byte2 === (255 - byte3 + 4)) {
			if (0 < byte2 && byte2 <= 25) {
				hit.score = 5;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.isInner = true;
			} else if (50 < byte2 && byte2 <= 70) {
				hit.score = 5;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.isOuter = true;
			} else if (100 < byte2 && byte2 <= 125) {
				hit.score = 5;
				hit.multiplier = 2;
				hit.hitValid = true;
			} else if (200 < byte2 && byte2 <= 220) {
				hit.score = 5;
				hit.multiplier = 3;
				hit.hitValid = true;
			} else if (150 < byte2 && byte2 <= 170) {
				hit.score = 5;
				hit.multiplier = 4;
				hit.hitValid = true;
			}
		} else if (byte0 === 90 && byte1 === 165 && byte2 === (255 - byte3 + 3)) {
			if (0 < byte2 && byte2 <= 25) {
				hit.score = 10;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.isInner = true;
			} else if (50 < byte2 && byte2 <= 70) {
				hit.score = 10;
				hit.multiplier = 1;
				hit.hitValid = true;
				hit.isOuter = true;
			} else if (100 < byte2 && byte2 <= 125) {
				hit.score = 10;
				hit.multiplier = 2;
				hit.hitValid = true;
			} else if (200 < byte2 && byte2 <= 220) {
				hit.score = 10;
				hit.multiplier = 3;
				hit.hitValid = true;
			} else if (150 < byte2 && byte2 <= 170) {
				hit.score = 10;
				hit.multiplier = 4;
				hit.hitValid = true;
			}
		} else if (byte0 === 90 && byte1 === 165 && byte2 === (255 - byte3 + 1)) {
			dartStuck = true;
			hit.message = 'Dart stuck!';
			hit.dartStuck = true;
			if (0 < byte2 && byte2 <= 25) {
				hit.score = byte2;
				hit.multiplier = 1;
				hit.isInner = true;
			} else if (50 < byte2 && byte2 <= 70) {
				hit.score = byte2 - 50;
				hit.multiplier = 1;
				hit.isOuter = true;
			} else if (100 < byte2 && byte2 <= 125) {
				hit.score = byte2 - 100;
				hit.multiplier = 2;
			} else if (200 < byte2 && byte2 <= 220) {
				hit.score = byte2 - 200;
				hit.multiplier = 3;
			} else if (150 < byte2 && byte2 <= 170) {
				hit.score = byte2 - 150;
				hit.multiplier = 4;
			}
		} else if (byte0 === 90 && byte1 === 165 && byte2 === (255 - byte3 - 1)) {
			dartStuck = false;
			hit.message = 'Dart unstuck!';
			hit.dartUnStuck = true;
			if (0 < byte2 && byte2 <= 25) {
				hit.score = byte2;
				hit.multiplier = 1;
				hit.isInner = true;
			} else if (50 < byte2 && byte2 <= 70) {
				hit.score = byte2 - 50;
				hit.multiplier = 1;
				hit.isOuter = true;
			} else if (100 < byte2 && byte2 <= 125) {
				hit.score = byte2 - 100;
				hit.multiplier = 2;
			} else if (200 < byte2 && byte2 <= 220) {
				hit.score = byte2 - 200;
				hit.multiplier = 3;
			} else if (150 < byte2 && byte2 <= 170) {
				hit.score = byte2 - 150;
				hit.multiplier = 4;
			}
		} else {
			hit.message = 'Error in code.';
			ErrorHandeler.newError(18, hit.message);
		}
	}
	callback(hit);
}
function dip_switch_status(data, callback) {
	let dip_switch_data = {};
	let bytes = new Uint8Array(data);

	let DipSwitchState = hexify(bytes[2]);

	if (bytes[0].toString(16).toUpperCase() !== constant.poclXStartByte || bytes[bytes.length - 1].toString(16).toUpperCase() !== constant.poclXEndByte) {
		// data not valid
		console.log('DATA NOT VALID test', bytes);
		return;
	}
	

	console.log('usao je u dip switch status');
	if(DipSwitchState === constant.dip_switch_menu_Byte){
		console.log('usao je u dip switch menu');
		dip_switch_data.lenght = hexify(bytes[1]);
		dip_switch_data.command = hexify(bytes[2]);
		dip_switch_data.pod_menu = hexify(bytes[3]);
		dip_switch_data.pod_menu_value = hexify(bytes[4]);
	}else if(DipSwitchState === constant.dip_switch_menu_settings_Byte){
		console.log('usao je u dip switch menu settings');
		dip_switch_data.lenght = hexify(bytes[1]);
		dip_switch_data.command = hexify(bytes[2]);
		//dip_switch_data.settings_parametar = bytes[3]+(bytes[4] * 256);
		dip_switch_data.value_parametar = bytes[5];
		dip_switch_data.min = bytes[6];
		dip_switch_data.max = bytes[7];
		dip_switch_data.step = bytes[8];
	}else if(DipSwitchState === constant.dip_switch_test_menu_Byte){
		console.log('usao je u dip switch test menu');
	}
		
	callback(dip_switch_data);
}
function coin_status(data, callback) {
	let coin_data = {};
	let bytes = new Uint8Array(data);

	let CoinState = hexify(bytes[2]);

	if (bytes[0].toString(16).toUpperCase() !== constant.poclXStartByte || bytes[bytes.length - 1].toString(16).toUpperCase() !== constant.poclXEndByte) {
		// data not valid
		console.log('DATA NOT VALID test', bytes);
		return;
	}
	coin_data.kanal_1 = bytes[5]+bytes[6];
	coin_data.kanal_2 = bytes[7]+bytes[8];
	coin_data.kanal_3 = bytes[9]+bytes[10];


	callback(coin_data);
}

module.exports = {
	coin_status:coin_status,
    hexify: hexify,
    isInternetUp: isInternetUp,
	parseStatusData: parseStatusData,
    mapCodeToHit: mapCodeToHit,
	dip_switch_status:dip_switch_status,
    Transmute: Transmute,
	parseHex: parseHex,
	getTup: getTup,
}
