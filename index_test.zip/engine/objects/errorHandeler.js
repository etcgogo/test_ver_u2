//const ErrorReport = require('../models/errorReport.model');
const variables = require('../const/varibales');

function ErrorHandeler() {
	this.errorEnumList = [
		{Enum: 0, Message: '[objects/mongo.js] - retriveInitialData'},
		{Enum: 1, Message: '[workers/socketWorker.js] - creating inital default mode failed'},
		{Enum: 2, Message: '[workers/socketWorker.js] - that is not a valid id of this device'},
		{Enum: 3, Message: '[objects/fset.js] - createRGBCircleListOrder numbers is not array'},
		{Enum: 4, Message: '[objects/fset.js] - createRGBCircleOneOrder data is not valid'},
		{Enum: 5, Message: '[objects/fset.js] - createRGBCircleAllOrder rgb is not valid'},
		{Enum: 6, Message: '[objects/fset.js] - createRGBLighterOrder function parameters not valid'},
		{Enum: 7, Message: '[objects/fset.js] - createRGBLighterAllOrder function parameters not valid'},
		{Enum: 8, Message: '[objects/fset.js] - createDemoOrder function parameters not valid'},
		{Enum: 9, Message: '[objects/fset.js] - mechanicalCounterAdd function parameters not valid'},
		{Enum: 10, Message: '[objects/fset.js] - isInternetUp function error'},
		{Enum: 11, Message: '[objects/fset.js] - createInhiData function parameters not valid'},
		{Enum: 12, Message: '[objects/fset.js] - hexiy function parameters not valid'},
		{Enum: 13, Message: '[objects/fset.js] - deletePageIdOrder function parameters not valid'},
		{Enum: 14, Message: '[objects/fset.js] - createRFIDContent function parameters not valid'},
		{Enum: 15, Message: '[objects/fset.js] - parseRFIData function parameters not valid'},
		{Enum: 16, Message: '[objects/fset.js] - createPageIdOrder function parameters not valid'},
		{Enum: 17, Message: '[objects/fset.js] - getTup function parameters not valid'},
		{Enum: 18, Message: '[objects/fset.js] - mapCodeToHit error in hit, code does not exist'},
		{Enum: 19, Message: '[objects/fset.js] - parseHex function parameters not valid'},
		{Enum: 20, Message: '[objects/mongo.js] - getAllShortenModes error in executing'},
		{Enum: 21, Message: '[objects/mongo.js] - getAllShortenModes id was not valid'},
		{Enum: 22, Message: '[objects/mongo.js] - createMode error while finding one with id'},
		{Enum: 23, Message: '[objects/mongo.js] - createMode save error'},
		{Enum: 24, Message: '[objects/mongo.js] - createMode not a valid id'},
		{Enum: 25, Message: '[objects/mongo.js] - activateMode error while finding one with id'},
		{Enum: 26, Message: '[objects/mongo.js] - activateMode save error'},
		{Enum: 27, Message: '[objects/mongo.js] - activateMode not a valid id'},
		{Enum: 28, Message: '[objects/mongo.js] - updateMode error while finding one with id'},
		{Enum: 29, Message: '[objects/mongo.js] - updateMode save error'},
		{Enum: 30, Message: '[objects/mongo.js] - updateMode not a valid id'},
		{Enum: 31, Message: '[objects/mongo.js] - deleteMode error while finding one with id'},
		{Enum: 32, Message: '[objects/mongo.js] - deleteMode save error'},
		{Enum: 33, Message: '[objects/mongo.js] - deleteMode not a valid id'},
		{Enum: 34, Message: '[objects/mongo.js] - getValuteIndex error while finding one with id'},
		{Enum: 35, Message: '[objects/mongo.js] - getValuteIndex could not find right valute'},
		{Enum: 36, Message: '[objects/mongo.js] - getValuteIndex not a valid id'},
		{Enum: 37, Message: '[objects/mongo.js] - updateResumeInitialData error while finding one with id'},
		{Enum: 38, Message: '[objects/mongo.js] - updateResumeInitialData save error'},
		{Enum: 39, Message: '[objects/mongo.js] - updateResumeInitialData not a valid id'},
		{Enum: 40, Message: '[objects/mongo.js] - updateCreditStatus error while finding one with id'},
		{Enum: 41, Message: '[objects/mongo.js] - updateCreditStatus save error'},
		{Enum: 42, Message: '[objects/mongo.js] - updateCreditStatus not a valid id'},
		{Enum: 43, Message: '[objects/mongo.js] - getStatisticsData error while finding one with id'},
		{Enum: 44, Message: '[objects/mongo.js] - getStatisticsData not valid id'},
		{Enum: 45, Message: '[objects/mongo.js] - resetBookkeeping error while finding one with id'},
		{Enum: 46, Message: '[objects/mongo.js] - resetBookkeeping type is not valid'},
		{Enum: 47, Message: '[objects/mongo.js] - resetBookkeeping save error'},
		{Enum: 48, Message: '[objects/mongo.js] - resetBookkeeping not a valid id'},
		{Enum: 49, Message: '[objects/mongo.js] - resetStatistics error while finding one with id'},
		{Enum: 50, Message: '[objects/mongo.js] - resetStatistics type is not valid'},
		{Enum: 51, Message: '[objects/mongo.js] - resetStatistics save error'},
		{Enum: 52, Message: '[objects/mongo.js] - resetStatistics not a valid id'},
		{Enum: 53, Message: '[objects/mongo.js] - updateHitsStatistics error while finding one with id'},
		{Enum: 54, Message: '[objects/mongo.js] - updateHitsStatistics save error'},
		{Enum: 55, Message: '[objects/mongo.js] - updateHitsStatistics not a valid id'},
		{Enum: 56, Message: '[objects/mongo.js] - updateGamesStatistics error while finding one with id'},
		{Enum: 57, Message: '[objects/mongo.js] - updateGamesStatistics save error'},
		{Enum: 58, Message: '[objects/mongo.js] - updateGamesStatistics not a valid id'},
		{Enum: 59, Message: '[objects/mongo.js] - getBookkeepingData error while finding one with id'},
		{Enum: 60, Message: '[objects/mongo.js] - getBookkeepingData not a valid id'},
		{Enum: 61, Message: '[objects/mongo.js] - updateBookeeping error while finding one with id'},
		{Enum: 62, Message: '[objects/mongo.js] - updateBookeeping save error'},
		{Enum: 63, Message: '[objects/mongo.js] - updateBookeeping not a valid id'},
		{Enum: 64, Message: '[objects/mongo.js] - updateBookeepingBonus error while finding one with id'},
		{Enum: 65, Message: '[objects/mongo.js] - updateBookeepingBonus save error'},
		{Enum: 66, Message: '[objects/mongo.js] - updateBookeepingBonus not a valid id'},
		{Enum: 67, Message: '[objects/mongo.js] - updateBookeepingLottery error while finding one with id'},
		{Enum: 68, Message: '[objects/mongo.js] - updateBookeepingLottery save error'},
		{Enum: 69, Message: '[objects/mongo.js] - updateBookeepingLottery not a valid id'},
		{Enum: 70, Message: '[objects/mongo.js] - updateLotteryBuffer error while finding one with id'},
		{Enum: 71, Message: '[objects/mongo.js] - updateLotteryBuffer save error'},
		{Enum: 72, Message: '[objects/mongo.js] - updateLotteryBuffer not a valid id'},
		{Enum: 73, Message: '[objects/mongo.js] - factoryReset error while finding one with id'},
		{Enum: 74, Message: '[objects/mongo.js] - factoryReset save error'},
		{Enum: 75, Message: '[objects/mongo.js] - factoryReset not a valid id'},
		{Enum: 76, Message: '[objects/mongo.js] - fingerprintListAdd error while finding one with id'},
		{Enum: 77, Message: '[objects/mongo.js] - fingerprintListAdd not a valid aprameters'},
		{Enum: 78, Message: '[objects/mongo.js] - fingerprintListAdd save error'},
		{Enum: 79, Message: '[objects/mongo.js] - fingerprintListAdd not a valid id'},
		{Enum: 80, Message: '[objects/mongo.js] - fingerprintListRemove error while finding one with id'},
		{Enum: 81, Message: '[objects/mongo.js] - fingerprintListRemove save error'},
		{Enum: 82, Message: '[objects/mongo.js] - fingerprintListRemove not a valid id'},
		{Enum: 83, Message: '[objects/mongo.js] - checkFingerExist error while finding one with id'},
		{Enum: 84, Message: '[objects/mongo.js] - checkFingerExist not a valid id'},
		{Enum: 85, Message: '[objects/mongo.js] - getFingerEmailByPageId error while finding one with id'},
		{Enum: 86, Message: '[objects/mongo.js] - getFingerEmailByPageId save error'},
		{Enum: 87, Message: '[objects/mongo.js] - getFingerEmailByPageId email of registered finger not found'},
		{Enum: 88, Message: '[objects/mongo.js] - getFingerEmailByPageId not a valid id'},
		{Enum: 89, Message: '[objects/mongo.js] - getFreePageId error while finding one with id'},
		{Enum: 90, Message: '[objects/mongo.js] - getFreePageId there is no free page id'},
		{Enum: 91, Message: '[objects/mongo.js] - getFreePageId  not a valid id'},
		{Enum: 92, Message: '[objects/mongo.js] - createStatisticsDataIfMissing save error'},
		{Enum: 93, Message: '[objects/mongo.js] - createBookkeepingDataIfMissing save error'},
		{Enum: 94, Message: '[objects/mongo.js] - addValuteList error while finding bookeping with id'},
		{Enum: 95, Message: '[objects/mongo.js] - addValuteList error while saving bookeping'},
		{Enum: 96, Message: '[objects/mongo.js] - addValuteList error while fidning initial data with id'},
		{Enum: 97, Message: '[objects/mongo.js] - addValuteList error while saving initial data'},
		{Enum: 98, Message: '[objects/mongo.js] - addValuteList no valid id when searcing initial data'},
		{Enum: 99, Message: '[objects/mongo.js] - addValuteList no valid id when searching bookkeeping'},
		{Enum: 100, Message: '[objects/mongo.js] - createInitialDataIfMissing error while saving'},
		{Enum: 101, Message: '[objects/sql.js] - saveDart getting connection from pool error'},
		{Enum: 102, Message: '[objects/sql.js] - saveDart executing query error'},
		{Enum: 103, Message: '[objects/sql.js] - saveMoney getting connection from pool error'},
		{Enum: 104, Message: '[objects/sql.js] - saveMoney executing query error'},
		{Enum: 105, Message: '[objects/videoPlayer.js] - VideoPlayer.prototype.init error while reading v_graphics_static_list.txt'},
		{Enum: 106, Message: '[objects/videoPlayer.js] - VideoPlayer.prototype.init error v_graphics_static_list.txt not found'},
		{Enum: 107, Message: '[objects/videoPlayer.js] - VideoPlayer.prototype.init error while reading v_graphics_custom_list.txt'},
		{Enum: 108, Message: '[objects/videoPlayer.js] - VideoPlayer.prototype.init error v_graphics_custom_list.txt not found'},
		{Enum: 109, Message: '[objects/videoPlayer.js] - VideoPlayer.prototype.init error while rading v_graphics_ordered_list.txt'},
		{Enum: 110, Message: '[objects/videoPlayer.js] - VideoPlayer.prototype.init error v_graphics_ordered_list.txt not found'},
		{Enum: 111, Message: '[objects/videoPlayer.js] - chooseNextVideo error while executing, list in the error message'},
		{Enum: 112, Message: '[objects/etherentWorker.js] - disableEthernet executing command error'},
		{Enum: 113, Message: '[objects/etherentWorker.js] - enableEthernet executing command error'},
		{Enum: 114, Message: '[objects/etherentWorker.js] - getEthernetData getting interfaces list error'},
		{Enum: 115, Message: '[objects/etherentWorker.js] - setEthernetIp function parameters not valid'},
		{Enum: 116, Message: '[objects/etherentWorker.js] - setEthernetIp execute command error'},
		{Enum: 117, Message: '[objects/etherentWorker.js] - setEthernetNetmask function parameters not valid'},
		{Enum: 118, Message: '[objects/etherentWorker.js] - setEthernetNetmask execute command error'},
		{Enum: 119, Message: '[objects/etherentWorker.js] - setEthernetGateway function parameters not valid'},
		{Enum: 120, Message: '[objects/etherentWorker.js] - setEthernetGateway execute command error'},
		{Enum: 121, Message: '[objects/rpioWorker.js] - updateing cpu file description not valid'},
		{Enum: 122, Message: '[objects/rpioWorker.js] - updateing tablet file description not valid'},
		{Enum: 123, Message: '[objects/rpioWorker.js] - updateing rpi file descritpion not valid'},
		{Enum: 124, Message: '[objects/rpioWorker.js] - error executing cpu file download'},
		{Enum: 125, Message: '[objects/rpioWorker.js] - error rebooting cpu'},
		{Enum: 126, Message: '[objects/rpioWorker.js] - error downloading apk file'},
		{Enum: 127, Message: '[objects/rpioWorker.js] - error updating tablet'},
		{Enum: 128, Message: '[objects/rpioWorker.js] - error downloading rpi update file'},
		{Enum: 129, Message: '[objects/rpioWorker.js] - error executing rpu update'},
		{Enum: 130, Message: '[objects/rpioWorker.js] - update ended with cpu errors'},
		{Enum: 131, Message: '[objects/rpioWorker.js] - update ended with tablet errors'},
		{Enum: 132, Message: '[objects/rpioWorker.js] - update ended with rpi errors'},
		{Enum: 133, Message: '[objects/rpioWorker.js] - checkServerFile error in checking server file'},
		{Enum: 134, Message: '[objects/rpioWorker.js] - execute error executing command'},
		{Enum: 135, Message: '[objects/serialPortWorker.js] - error while reding game mode data'},
		{Enum: 136, Message: '[objects/serialPortWorker.js] - eroor while reading rfid, no id found'},
		{Enum: 137, Message: '[objects/serialPortWorker.js] - there is no such cpu mode'},
		{Enum: 138, Message: '[objects/serialPortWorker.js] - cpu failed to reboot'},
		{Enum: 139, Message: '[objects/serialPortWorker.js] - writeSerial function error writing'},
		{Enum: 140, Message: '[objects/serialPortWorker.js] - readLocalBinaryFile function error while reading'},
		{Enum: 141, Message: '[objects/wifiWorker.js] - scanWifi error'},
		{Enum: 142, Message: '[objects/wifiWorker.js] - connectToWifi error'},
		{Enum: 143, Message: '[objects/wifiWorker.js] - switchWifi turn on error'},
		{Enum: 144, Message: '[objects/wifiWorker.js] - switchWifi turn off error'},
		{Enum: 145, Message: '[objects/wifiWorker.js] - getWifiStatus order execute error'},
		{Enum: 146, Message: '[SERVER] - error occured'},
		{Enum: 147, Message: '[objects/etherentWorker.js] - connectVPN error'},
		{Enum: 147, Message: '[workers/soundWorker.js] - Sound script error'},
	];
}

ErrorHandeler.prototype.newError = function(errorCode, errorMessage) {
	let _this = this;
	let errorReport = {};

	errorReport.message = _this.errorEnumList[errorCode].message || 'Undefined message';
	errorReport.deviceId = variables.deviceId || 'Undefined ID';
	errorReport.deviceVersion = variables.deviceVersion || 'Undefined version';
	errorReport.errorMessage = errorMessage || 'Undefined message';
	errorReport.errorEnum = _this.errorEnumList[errorCode].Enum || 'Undefined error enum';

	if (process.env.VERBOSE === 'true') {
		console.log('[ERROR] - ' + errorReport.deviceId + ' | ' + errorReport.deviceVersion + ' | ' + errorReport.message + ' | ' + errorReport.errorEnum + ' | ' + new Date());
	}

	if (errorReport) {
		//let errorReporter = new ErrorReport;
		let errorReporter = {}; // hotfix...
		errorReporter.deviceId = errorReport.deviceId;
		errorReporter.deviceVersion = errorReport.deviceVersion;
		errorReporter.message = errorReport.message;
		errorReporter.errorMessage = errorReport.errorMessage;
		errorReporter.errorEnum = errorReport.errorEnum;
		/*errorReporter.save(function(err) {
			if (err) {
				console.log('THERE WAS AN ERROR IN ERROR REPORTING: ', err);
			}
		});*/
	}
}

module.exports = new ErrorHandeler;
