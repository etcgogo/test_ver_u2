var time = 10;
var videoActive = false;
var mediaRecorder = null;
var mediaRecorderChunks = [];
var callConnections = [];
var dataConnections = [];
var container = null;
var currentId = null;
var peer = null;
var localId = undefined;

if (navigator.mediaDevices === undefined) {
	navigator.mediaDevices = {};
}

if (navigator.mediaDevices.getUserMedia === undefined) {
	navigator.mediaDevices.getUserMedia = function (constraints) {
		var getUserMedia = navigator.webkitGetUserMedia || navigator.mozGetUserMedia;

		if (!getUserMedia) {
			return Promise.reject(new Error('getUserMedia is not implemented in this browser'));
		}

		return new Promise(function (resolve, reject) {
			getUserMedia.call(navigator, constraints, resolve, reject);
		});
	}
}

// output functions


function initalaziePeer(localPlayerId, callback) {
	console.log('init peer! -logging videoActive?', videoActive);
	if (peer || videoActive) {
		callback();
	} else {
		if (localPlayerId) {
			peer = new Peer(localPlayerId, {
				host: '54.93.228.85',
				port: '9000',
				path: '/video',
				config: {
					'iceServers': [
						{ url: 'stun:stun.l.google.com:19302' },
						{ url: "turn:numb.viagenie.ca", credential: 'password', username: "antonio.krivak@gmail.com" }
					],
				},
			});

			peer.on('open', function (id) {
				localId = localPlayerId;
				console.log('peer.on(open) logging localID', localId);
				callback();
			});
		}
	}
}

function initalaizeSlefVideo(audio, video, record, useCaseNumber) {
	if (videoActive) {
		return;
	}

	let properties = {
		audio: audio,
		video: {
			width: 1280,
			height: 480,
			frameRate: 20,
		},
	}
	if (!useCaseNumber) {
		container = document.getElementById('streampo');
		console.log(container);
	} else if (useCaseNumber === 300) {
		container = document.getElementById('streamp');
		console.log(container);
	} else if (useCaseNumber === 400) {
		container = document.getElementById('streampCricket');
	}

	if (container) {
		container.onloadedmetadata = function (e) {
			container.play();
		};
	}

	navigator.mediaDevices.getUserMedia(properties).then(function (localMediaStream) {
		/* use the stream */
		videoActive = true;

		if (record) {
			mediaRecorderChunks = [];
			mediaRecorder = new MediaRecorder(localMediaStream, {
				bitsPerSecond: 2097152
			});

			mediaRecorder.ondataavailable = function (e) {
				if (mediaRecorderChunks.length >= time) {
					mediaRecorderChunks.shift();
				}

				mediaRecorderChunks.push(e.data);
			}
		}

		container.srcObject = localMediaStream;
	}).catch(function (err) {
		/* handle the error */
		console.log(err);
	});
}

function startRecording() {
	if (mediaRecorder === null) {
		return;
	}
	mediaRecorder.start(200);
}

function pauseRecording() {
	if (mediaRecorder === null) {
		return;
	}
	mediaRecorder.pause();
}

function resumeRecording() {
	if (mediaRecorder === null) {
		return;
	}
	mediaRecorder.resume();
}

function stopRecording() {
	if (mediaRecorder === null) {
		return;
	}
	mediaRecorder.stop();
}

function returnCircularBlob() {
	if (mediaRecorder === null || mediaRecorderChunks.length !== 10) {
		return;
	}

	return mediaRecorderChunks;
}

function initalaizeMediaConnection(audio, video, record, players, currentPlayerId) {
	if (videoActive) {
		console.log('ERROR: video already active');
		return;
	}

	let properties = {
		audio: audio,
		video: {
			width: 1280,
			height: 480,
			frameRate: 15,
		},
	}

	for (let i = 0; i < players.length; i++) {
		if (players[i].copyOfType === 1 || players[i].copyOfType === 3) {
			callConnections.push({
				id: players[i].id,
				stream: null
			});
		}
	}

	if (callConnections.length <= 1) {
		return console.log('NOT ENOUGH PLAYER TO START VIDEO');
	}

	container = document.getElementById('streamp');

	if (container) {
		container.onloadedmetadata = function (e) {
			container.play();
		};
	}

	if (peer && peer.disconnected) {
		peer.reconnect();
	}

	navigator.mediaDevices.getUserMedia(properties).then(function (localMediaStream) {
		/* use the stream */
		videoActive = true;
		let readyToCall = false;

		if (record) {
			mediaRecorder = new MediaRecorder(localMediaStream);
			mediaRecorderChunks = [];
			mediaRecorder.ondataavailable = function (e) {
				if (mediaRecorderChunks.length >= time) {
					mediaRecorderChunks.shift();
				}

				mediaRecorderChunks.push(e.data);
			}
		}

		currentId = currentPlayerId;
		console.log ('peer.on(call) listener');
		peer.on('call', function (call) {
			// Answer the call, providing our mediaStream
			console.log('netko me zove, salji video');
			call.answer(localMediaStream);

			// search for id and save stream for selection
			call.on('stream', function (remoteStream) {
				console.log('dobio sam video nakon slanja svojeg');
				for (let i = 0; i < callConnections.length; i++) {
					if (callConnections[i].id === call.peer && !callConnections[i].stream) {
						callConnections[i].stream = remoteStream;
						callConnections[i].media = call;
						if ((currentPlayerId !== localId && currentPlayerId === call.peer) || (callConnections.length === 2 && call.peer !== localId)) {
							container.srcObject = remoteStream;
						}
					}
				}
			});
		});

		peer.on('dissconnected', function () {
			closeMediaConnection();
		})

		for (let i = 0; i < callConnections.length; i++) {
			if (callConnections[i].id === localId) {
				readyToCall = true;
				continue;
			}
			if (readyToCall && !callConnections[i].stream) {
				console.log('zovem', callConnections[i].id);
				var call = peer.call(callConnections[i].id, localMediaStream);
				call.on('stream', function (remoteStream) {
					callConnections[i].stream = remoteStream;
					callConnections[i].media = call;
					if ((currentPlayerId !== localId && currentPlayerId === call.peer) || (callConnections.length === 2 && call.peer !== localId)) {
						container.srcObject = remoteStream;
					}
				});
			}
		}
	});
}

function showVideoById(id) {
	if (id === currentId) {
		return;
	}

	if (localId === id) {
		container.pause();
		container.removeAttribute('srcObject');
		container.load();
		return;
	}

	for (let i = 0; i < callConnections.length; i++) {
		if (callConnections[i].id === id) {
			currentId = id;
			container.srcObject = callConnections[i].stream;
		}
	}
}

function closeMediaConnection() {
	console.log('closemediaconnection2');
	videoActive = false;
	for (let i = 0; i < callConnections.length; i++) {
		if (callConnections[i].stream) {
			callConnections[i].stream.getVideoTracks().forEach(function (track) {
				track.stop();
			});
		}
		if (callConnections[i].media) {
			callConnections[i].media.close();
		}
	}
	if (peer) 
		peer.disconnect();
	callConnections = [];
}

function closeSelfVideo() {
	if (!container) {
		return;
	}
	let stream = container.srcObject;
	let tracks = stream.getTracks();

	tracks.forEach(function (track) {
		track.stop();
	});

	container.srcObject = null;
	videoActive = false;
}

function initalaizeDataConnection(players) {
	// good thing to pass data pee2peer without server
}