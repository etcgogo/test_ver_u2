const si = require('systeminformation');
//const { spawn } = require('child_process');

var uuid = 0;

si.uuid(function(data) {
  uuid = data.hardware;
  // console.log('System Information:');
  // console.log('- os: ' + data.os);
  //console.log('- 123: ' + uuid);
  console.log('- hardware: ' + data.hardware);
  // console.log('- macs: ' + data.macs);
  
  console.log('- 535345: ' + uuid);
})



si.cpuCurrentSpeed(function(data) {
	// console.log('cpuCurrentSpeed:');
	// console.log('- data: ' + data.avg);
  })
si.cpuTemperature(function(data) {
	// console.log('cpuTemperature:');
	// console.log('- data: ' + data.main);
  })


// const ls = spawn('ls', ['-lh', '/usr']);
  
//   ls.stdout.on('data', (data) => {
//     console.log(`stdout: ${data}`);
//   });
  
//   ls.stderr.on('data', (data) => {
//     console.error(`stderr: ${data}`);
//   });
  
//   ls.on('close', (code) => {
//     console.log(`child process exited with code ${code}`);
//   });



module.exports = {
  uuid:uuid
}