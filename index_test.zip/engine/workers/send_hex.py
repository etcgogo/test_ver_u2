#!/usr/bin/python
#read serial $02CYBER$03
#write serial $02$AA$55$03
#read serial $02SPIDER$03
#send START CMD NONE NUM_OF_BLOCK START_ZL START_ZH
#write serial 62 bloka od 2048B podataka 4096B je bootloader $02$A0$A0$3E$00$00

import time,sys,os
from time import sleep
import serial
buffer_in = " "
new_data_in = 0
first_check = 0
sector_to_read = 0
csum_ = 0
flag_kraj_filea = 0
kz = 0
iz = 0

def send_data_from_file_to_serail_(broj_sektora):
    #buffer_temp = ""
    #csum_ = 0
    #byte_to_send = 0xFF
    #lenghth_file_block = 0
    #code_file_block = 0
    flag_kraj_filea = 0
    f=open("/home/hybrid3/server/engine/workers/update_files/boot_loader1.hex","r")
    print ("otvaram file ", f.name)
    print (" i saljem ",broj_sektora)
    sector_to_read = 0  #30
    f.seek(2048 * 0)
    k = 0
    for k in range (broj_sektora):
        i = 0
        buffer_temp = ""
        csum_ = 0
        byte_to_send = 0xFF
        lenghth_file_block = 0
        code_file_block = 0
        while (i < 2048):
            ocitano = f.read(1)
            if ocitano == ':':  #pocetak bloka
                ocitano = f.read(1)
                lenghth_file_block = convert_ascii_hex_to_num(ocitano) * 16
                ocitano = f.read(1)
                lenghth_file_block += convert_ascii_hex_to_num(ocitano)
                #print (lenghth_file_block)
                ocitano = f.read(1)
                ocitano = f.read(1)
                ocitano = f.read(1)
                ocitano = f.read(1) # 4 memorijske lokacije
                
                ocitano = f.read(1)
                code_file_block = convert_ascii_hex_to_num(ocitano) * 16
                ocitano = f.read(1)
                code_file_block += convert_ascii_hex_to_num(ocitano)
                #print (code_file_block)
                if code_file_block == 0:
                    j = 0
                    for j in range(lenghth_file_block):
                        ocitano = f.read(1)
                        buffer_temp += ocitano
                        byte_to_send = convert_ascii_hex_to_num(ocitano) * 16
                        ocitano = f.read(1)
                        buffer_temp += ocitano
                        byte_to_send += convert_ascii_hex_to_num(ocitano)
                        if k >= sector_to_read:
                            ser.write(b'%c'%(byte_to_send))  #ord
                            delay_us_()
                        csum_ += (byte_to_send)
                        i += 1
                    
                    buffer_temp += chr(0x0D)
                    buffer_temp += chr(0x0A)
                elif code_file_block == 2:    #extended segment data
                    j = 0
                    for j in range(lenghth_file_block):
                        ocitano = f.read(1)
                        ocitano = f.read(1)
                elif code_file_block == 1:     #EOF index
                    flag_kraj_filea = 1
                    print("kraj filea")
                    for iz in range(i , 2048):
                        if (iz % 16) == 0:
                            buffer_temp += chr(0x0D)
                            buffer_temp += chr(0x0A)
                        buffer_temp += "0"
                        buffer_temp += "0"
                        ser.write(b'%c'%(0x00))  #ord
                        delay_us_()
                        i += 1
                    break
                    #return 0   #EOF
                else:
                    j = 0
                    for j in range(lenghth_file_block):
                        ocitano = f.read(1)
                        ocitano = f.read(1)
                    
            #print(i)
            
            
        
        
        #print ("podaci poslani, csum sektora ",k," iznosi ",csum_)
        #ovdje cekaj response za dalje
        if k >= sector_to_read:
            #if k == 8:  #namjerno pogrijesi csum
                #csum_ += 1
                #print ("csum uvecan za 1")
            send_data_csum_to_serial_(csum_)
            print (buffer_temp)
            send_data_csum_to_serial_(csum_)
            print ("wait for response, csum sektora ",k," iznosi ",csum_)
            x_ = 1
            if flag_kraj_filea == 1:
                print ("kraj filea, ubaci slijedece sa 0x00")
            while (x_):
                print (".")
                status_ = wait_for_next_entery_flag()
                if (status_ == 1):
                    x_ = 0
                elif (status_ == 2):
                        x_ = 0
                        break
                elif (status_ == 3): #error csuma
                        x_ = 0
                        print ("csum error ")
                        return
                        
        if flag_kraj_filea == 1:
            break
    print("zavrsi ostatak sektora sa 0x00...")
    k += 1  #odi na slijedeci sektor zato sto ne uvecava odmah nego na ulasku u petlju gore
    kz = k
    for kz in range (k, broj_sektora):     #zavrsi ostatak sektora sa 0x00
        i = 0
        buffer_temp = ""
        csum_ = 0
        for i in range (2048):
            buffer_temp += "0"
            buffer_temp += "0"
            ser.write(b'%c'%(0x00))  #ord
            delay_us_()
            if (i % 16) == 0:
                buffer_temp += chr(0x0D)
                buffer_temp += chr(0x0A)
        if kz >= sector_to_read:
            send_data_csum_to_serial_(csum_)
            print (buffer_temp)
            print ("wait for response, csum sektora ",kz," iznosi ",csum_)
            x_ = 1
            pokusaj = 0
            while (x_):
                print (".+")
                #pokusaj += 1
                #if pokusaj > 5: #dodaj po jedan byte dok ne uspije
                    
                 #  for hk in range (0,512): 
                  #      ser.write(b'%c'%(0x00))  #ord
                   #     delay_us_() 
                status_ = wait_for_next_entery_flag()
                if (status_ == 1):
                    x_ = 0
                elif (status_ == 2): #kraj broja upisanih stranica
                        x_ = 0
                        print ("kraj broja upisanih stranica", kz, sector_to_read, broj_sektora) 
                        break
                elif (status_ == 3): #error csuma
                        x_ = 0
                        print ("csum error ", kz, sector_to_read, broj_sektora)
                        return
                        

                    
    #for i in range(128):
    #    print(ocitano)
    print("done..")
    f.close()
    #ser.write(b'%c'%csum)
    
def wait_for_next_entery_flag():
    buffer_in_temp = ser.readline()
    print(buffer_in_temp)
    #ser.write(buffer_in)
    broj = string_len_()
    if buffer_in_temp == b'\x06':    #next sector
        return 1
    elif buffer_in_temp == b'\x06\x02':   #kraj broja upisanih stranica
        return 2
    elif buffer_in_temp == b'D\x06':    #high memory page
        return 1
    elif buffer_in_temp == b'\x15\x06':    #error csum on 2048B sector
        print("*******************CSUM ********************")
        return 1
        #return 3
    else:
        return 0
    
def send_data_csum_to_serial_(pom1):
    pom = pom1 
    cs0 = 0
    cs1 = 0
    cs2 = 0
    
    if pom > 255:
        cs0 = int(pom % 256)   #LSB
        pom = int(pom / 256)
        #ser.write(b'%c'%var_p)   #LSB
        if pom > 255:
            cs1 = int(pom % 256)
            pom = int(pom / 256)    #MSB
            cs2 = pom
    print (pom1)
    print (b'%c'%cs0)
    print (b'%c'%cs1)
    print (b'%c'%cs2)
    ser.write(b'%c'%cs0)
    delay_us_()
    ser.write(b'%c'%cs1)
    delay_us_()
    ser.write(b'%c'%cs2)    #MSB
    delay_us_()
    
def read_data_from_serial_to_file_(broj_sektora):
    #buffer_temp = ""
    #csum_ = 0
    #byte_to_send = 0xFF
    #lenghth_file_block = 0
    #code_file_block = 0
    flag_kraj_filea = 0
    #f=open("/home/goran/Desktop/Pikado_spider_new_128A_v4_led.hex","r")
    print ("citam podatke")
    print (" i saljem broj sektora ",broj_sektora)
    sector_to_read = 0  #30
    #f.seek(2048 * 0)
    k = 0
    for k in range (broj_sektora):
        buffer_in = ser.readline()
        sleep(0.5)
        
        
def start_code_transfer_(broj_sektora):
    #upisi od kojeg sektora ide
    delay_us_()
    ser.write(b'%c'%0x02)
    delay_us_()
    ser.write(b'%c'%0xA0)  #CMD
    delay_us_()
    ser.write(b'%c'%0xA0)
    delay_us_()
    ser.write(b'%c'%broj_sektora)  #3E NUM OF BLOCKS
    delay_us_()
    ser.write(b'%c'%0x00)  #ZL = 0
    delay_us_()
    ser.write(b'%c'%0x00)  #ZH = 0  F000
    delay_us_()
    ser.write(b'%c'%0x03)  
    delay_us_()
    
    send_data_from_file_to_serail_(broj_sektora)
        
    first_check = 0  
         
def start_read_prog_(broj_sektora):
    delay_us_()
    ser.write(b'%c'%0x02)
    delay_us_()
    ser.write(b'%c'%0xA2)  #CMD
    delay_us_()
    ser.write(b'%c'%0xA2)
    delay_us_()
    ser.write(b'%c'%broj_sektora)  #3E NUM OF BLOCKS
    delay_us_()
    ser.write(b'%c'%0x00)  #ZL = 0
    delay_us_()
    ser.write(b'%c'%0x00)  #ZH = 0  F000
    delay_us_()
    ser.write(b'%c'%0x03)  
    delay_us_()
    
    read_data_from_serial_to_file_(broj_sektora)
        
    first_check = 0  

def string_len_():
    len_buff = 0
    for i in buffer_in:
        len_buff +=1
    return len_buff

def delay_us_():
    #sleep(0.00025)
    sleep(0.00025)
    j = 0
    for i in range(256):
        j = j + 2

def send_start_transfer_():
    delay_us_()
    ser.write(b'%c'%0x02)
    delay_us_()
    ser.write(b'%c'%0xAA)
    delay_us_()
    ser.write(b'%c'%0x55)
    delay_us_()
    ser.write(b'%c'%0x03)
    delay_us_()
    
def wait_for_serial_():
    buffer_in = ser.inWaiting()
    new_data_in = 0
    #new_data_in = string_len_(buffer_in) 

def convert_ascii_hex_to_num(char_):
    x = 0
    if char_ >= '0':
        if char_ <= '9':
            x = int(char_)
    if char_ >= 'A':
        if char_ <= 'F':
           x = (ord(char_) - ord('A')) + 10
    return x

ser=serial.Serial("/dev/ttyS0", baudrate=57600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE, bytesize=serial.EIGHTBITS, timeout=0.2)
    
pom = 5
print ('Start prog %d'%pom)
pom = convert_ascii_hex_to_num('F')
print (pom)
print (b'%c'%pom)
first_check = 2  #0 radi boot, 2 ne radi boot

while 1:
    
    if first_check == 2:
        while 1:
            odabir = '1'
    #        odabir = input ("menu:\n 1: write prog\n 2: read prog\n")
    #        if odabir == '1' or odabir == '2':
            first_check = 0
                #posalji reset komndu
            print (b'sending reset')
            ser.write(b'\xAB\x05\xA9\xA9\xA9\xA9\xA9\x52\xBA')  #ord
            break
                
    try:
        buffer_in = ser.read_until(b'\x03')  # čita binarno, ne očekuje \n #ser.readline()
        if not buffer_in:
            continue  # timeout, nema ništa, ponovi petlju
        print(buffer_in)

        broj = string_len_()
    #ser.write(buffer_in)
   
        if first_check == 0: 
            if buffer_in == b'\x02CYBER\x03':
                print (b'device online')
                send_start_transfer_();
                first_check = 1
        if first_check == 1:
            if odabir == '1':
                if buffer_in == b'\x02SPIDER\x03':
                    print (b'device connected')
                    start_code_transfer_(0x3E);   #60 = 0x3C 0x3E 0x22
                    #start_code_transfer_(1);
                    first_check = 2
            if odabir == '2':
                if buffer_in == b'\x02SPIDER\x03':
                    print (b'device connected')
                    start_read_prog_(0x02);   #60 = 0x3C 0x3E 0x22
                    #start_code_transfer_(1);
                    first_check = 2
        if broj > 0:
            print (b'%d'%broj)
            
    except serial.SerialException as e:
        print("Serial error:", e)
        time.sleep(0.5)  # daš malo vremena prije ponovnog pokušaja
        continue
    #wait_for_serial_()
    #print (string_len_())
    #print (buffer_in)
    #if buffer_in  print (buffer_in)
    #buffer_in = ""
    #sleep(0.5)


