//socketWorker i serialPortWorker link
/*const EventEmitter = require("events");

class SharedState extends EventEmitter {
  constructor() {
    super();
    this._var_restart = 0;
  }

  set var_restart(value) {
    this._var_restart = value;
    this.emit("var_restart", value); // emit signal kad se promijeni
  }

  get var_restart() {
    return this._var_restart;
  }
}

module.exports = new SharedState();*/
const EventEmitter = require("events");

class SharedState extends EventEmitter {
  constructor() {
    super();
    this._var_restart = 0;
    this._var_start_update = 0;
  }

  set var_restart(value) {
    this._var_restart = value;
    this.emit("var_restart", value);
  }

  get var_restart() {
    return this._var_restart;
  }

  set var_start_update(value) {
    this._var_start_update = value;
    this.emit("var_start_update", value);
  }

  get var_start_update() {
    return this._var_start_update;
  }
}

module.exports = new SharedState();
