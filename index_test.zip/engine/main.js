const MAX_PLAYERS = 10;

const OPTION_DOUBLE_IN = 0x01;
const OPTION_DOUBLE_OUT = 0x02;
const OPTION_MASTER_OUT = 0x4000;
const OPTION_TEAM = 0x8000;
const OPTION_EQUAL = 0x20;
const OPTION_QUATTRO = 0x0200;

const GAME_CRICKET = 6;
const GAME_MARATHON = 18;
const SUB_GAME_MARATHON_MINI = 70;


const JUMPER_TURNIR = 0x20;

const MSG_NONE = 0;
const MSG_THROW = 1;
const MSG_N_THROW = 2;
const MSG_BUST = 3;
const MSG_EAT = 4;
const MSG_TUP = 5;
const MSG_MATCH_POINT = 6;
const MSG_180 = 10; //180
const MSG_150 = 11; //bingo
const MSG_WHITE_HORSE = 12;
const MSG_LOW_TON = 13;
const MSG_HIGH_TON = 14;
const MSG_TEAM_FREEZE = 15;
const MSG_LOTTERY_DATA = 16;
const MSG_SHOW_WINNER_STAT = 20;
const MSG_PICK_NUM = 21;

const MSG_ERROR_TARGET_STUCKED = 51;	//target one segment is stucked, c_max_strelica holds data
const MSG_ERROR_KEY_STUCKED = 52;	//one key is pressed, c_max_strelica holds data
const MSG_ERROR_TUP_ALWAYS_ON = 53;	//tup is always on 
const MSG_ERROR_TARGET_CPU_CSUM	= 54;	//wrong target cpu csum
const MSG_ERROR_TARGET_CPU_DATA	= 55;	//wrong target cpu data
const MSG_ERROR_CCTALK_CSUM = 56;	//wrong cctalk cpu csum
const MSG_ERROR_CLOCK_TIME = 57;    //I2C clock time

const C_GAME_MODE_SELECT_GAME = 0;
const C_GAME_MODE_PLAY = 1;
const C_GAME_MODE_PLAYOFF = 3;
const C_GAME_MODE_LOTTERY = 4;
const C_GAME_MODE_SWITCH_PLAYER = 5;
const C_GAME_MODE_DEMO = 6;
const C_GAME_MODE_PLAYER_ID = 7;

const C_GAME_MODE_NULL = 9;
const C_GAME_MODE_SETTINGS = 10;
const C_GAME_MODE_TEST = 11;
const C_GAME_MODE_DEFAULT = 12;
const C_GAME_MODE_BOOK_MAIN = 13;
const C_GAME_MODE_BOOK_SEC = 14;
const C_GAME_MODE_HIDDEN_MENU = 15;

const C_GAME_MODE_BUST = 16;
const C_GAME_MODE_JEDI = 17;

const C_GAME_MODE_ONLINE_THROW = 18;
const C_GAME_MODE_ONLINE_WAIT = 19;
const C_GAME_MODE_FREEZE = 20;

const GAME_SOLO_301 = 17;
const GAME_SPLIT_SCORE = 19;


class StatisticsDataX01 {
    constructor() {
        this.reset(); // Postavlja sve na 0 prilikom kreiranja
    }

    // Metoda za resetovanje svih vrednosti na 0
    reset() {
        this.s_score = 0; //ukupni score, samo bust ne računa 1 strelicu
        this.s_rank = 0;
        this.s_darts = 0; //stvarno baceno strelica 
        this.s_score_real = 0;
        this.s_darts_calc = 0; //baceno strelica, tipka next i bust uzme 3 strelice
        this.s_rounds = 0;
        this.s_ppd = 0;
        this.s_ppd_real = 0;
        this.s_ppr = 0;
        this.s_dart_out = 0;
        this.s_round_out = 0;
        this.s_3_in_a_bed = 0;
        this.s_hat_trick = 0;
        this.s_super_hat_trick = 0;
        this.s_low_tons = 0;
        this.s_high_tons = 0;
        this.s_ton_80 = 0;
        this.s_max_ton = 0;
        this.s_bulls = 0;
        this.s_double_bulls = 0;
    }
}

class StatisticsDataCricket {
    constructor() {
        this.reset(); // Postavlja sve na 0 prilikom kreiranja
    }

    // Metoda za resetovanje svih vrednosti na 0
    reset() {
        this.s_score = 0; //ukupni score, samo bust ne računa 1 strelicu
        this.s_rank = 0;
        this.s_darts = 0; //stvarno baceno strelica 
        this.s_score_real = 0;
        this.s_darts_calc = 0; //baceno strelica, tipka next i bust uzme 3 strelice
        this.s_rounds = 0;
        this.s_mpr = 0;
        this.s_mpr_real = 0;
        this.s_dart_out = 0;
        this.s_round_out = 0;
        this.s_9_dart_out = 0;
        this.s_white_horse = 0; //3 dif 
        this.s_9_mark = 0; //3 dif
        this.s_8_mark = 0; //3 dif
        this.s_7_mark = 0; //3 dif
        this.s_6_mark = 0; //3 dif
        this.s_5_mark = 0; //3 dif
        this.s_4_mark = 0; //3 dif

        this.s_cricket_hat = 0; //3 dart bull, add to mark 3 - 6
    }
}

let app = angular.module('DartApp', ['pascalprecht.translate']);


// ovaj je za strimanje
app.controller('DartCtrl', function($scope, $timeout, $interval, $translate) {

    let host = window.location.hostname;

    const urlParams = new URLSearchParams(window.location.search);
    const display = urlParams.get("display");  // will be "1" if ?display=1
    console.log("Display param:", display);

    if (host === "localhost" || host === "127.0.0.1") {
        host = "localhost"; // always connect locally
        $scope.stream = false;   // local → keep sheet visible
    } else {
        host = prompt("Enter server IP address:", host) || host;
        $scope.stream = true;    // outside network → hide sheet
    }

    let socket = io.connect(`http://${host}:3000`);


    // ovo je orginal
    //app.controller('DartCtrl', function($scope, $timeout, $interval,$translate) {
    //   let socket = io.connect('http://localhost:3000');

    let currentGameData = {};
    //let runAndGunTimer;
    let currentPlayerIndex = -1;
    let timerlotterystarted = false;
    let timerlotterystarted_1 = false;

    let game_price = 0;
    let cpu_settings_data = {};
    let timerlotterystarted_2 = false;

    let last_system_errors = 0;
    let last_data_error_ = 0;
    $scope.error_active_inactive = 0; 
    /*  SCOPE  */
    $scope.Lottery = false;

    $scope.players = [];
    $scope.networkStatus = '';
    $scope.runAndGunTimerStatus = 0;
    $scope.menuState = 0; // 500
    $scope.graphicsType = 0;
    $scope.videoShown = true; // false
    $scope.logedPlayer = false;
    $scope.connected = false;
    $scope.showPopout = false;
    $scope.rules = {};
    //$scope.creditStatus = 'CREDITS: ';
    $scope.deviceId = getCookie('deviceId');
    $scope.showExtraPopout = false;
    $scope.extraPopoutText = '';
    $scope.lotteryWinners = false;
    $scope.showLottery = false;
    $scope.playoff = false;
    $scope.playoffStarted = false;
    $scope.endMessage = '';
    $scope.isRunAndGun = false;
    $scope.isSplitScore = false;
    $scope.isMiniM = false;
    $scope.isM = false;
    $scope.shangaiNumber = {};
    $scope.videoLocal = false;
    $scope.imgPath = "lineShot.jpg"
    $scope.imgPathCount = 0;
    $scope.pull = false;
    $scope.fullyClosedNumbers = [];
    $scope.pigGame = false;
    $scope.currentRound = 1;
    $scope.usbConnected = false;
    $scope.gameName = '';
    $scope.gameOption = '       ';
    $scope.gameQuattro = 'Quattro : OFF';
    $scope.gameRounds = '';
    $scope.gamePrice = '';
    $scope.showTeam = false;
    $scope.teamOption = '';
    $scope.nextPlayer = null;
    $scope.timerStarted = false;

    $scope.players_value = new Array(8);
    $scope.current_score = 0;
    $scope.num_players = 0;
    $scope.current_player_score = 0;
    $scope.current_dart = 0;
    $scope.current_credits = 0;
    $scope.current_player_throw = 0;
    $scope.current_player_winner = 1;
    $scope.current_line_player_throw = 0;
    $scope.dart = [];
    $scope.text_free = '';
    $scope.player_throw = '';
    $scope.player_throw_color = '';

    $scope.select_game_color_background = [];
    $scope.select_option_mode_x01_color_background = [];
    $scope.select_option_mode_cricket_color_background = [];
    $scope.select_num_of_set_color_background = [];
    $scope.select_num_of_leg_color_background = [];
    $scope.select_num_of_players_color_background = [];
    $scope.select_id_players_color_background = [];
    $scope.select_num_of_teams_color_background = [];
    $scope.select_quattro_color_background = '#ffffff';
    $scope.select_pick_it_num_color_background = [];
    $scope.flag_block_button_next = 0;
    $scope.select_medley_color_background = [];

    $scope.model_dart_offline = 0; //only display dart
    $scope.special_game_text = '';
    $scope.settings_name = '';
    $scope.settings_name_icon_path = '';
    $scope.test_menu_target_path = '';
    $scope.test_menu_target_pie_path = '';
    $scope.test_menu_tup_infra_path = '';
    $scope.test_menu_tup_infra_on_1_path = '';
    $scope.test_menu_tup_infra_on_2_path = '';
    $scope.test_menu_margins_left = 0;
    $scope.test_menu_margins_left_on_1 = 0;
    $scope.test_menu_margins_left_on_2 = 0;


    $scope.player_ppd_total_score = [];
    let player_ppd_total_score_prev = 0;
    let player_c_score_prev = new Array(3);

    $scope.player_ppd_total_darts = [];
    $scope.current_player_ppd = 0;
    $scope.player_ppd_or_mpd = 1; // 0 ppd, 1 mpd
    let new_dart_event = 0;
    let prev_dart = -1;
    $scope.num_c_dart_prev = [];
    $scope.ponudi_izlaz = '';
    let strelica_u_ovoj_rundi = 0;
    $scope.current_player_total_darts = 0;
    $scope.current_player_total_score = 0;
    $scope.current_player_score_prev = 0;
    $scope.old_setup_menu_prev = "";
    $scope.lista_statistike_prikazi_flag = 0;
    $scope.game_with_stat_data = 0;
    let reset_current_statistics = 0;
    $scope.statisticsDataX01Array = Array.from({ length: 8 }, () => new StatisticsDataX01());
    $scope.statisticsDataX01Array_prev = Array.from({ length: 8 }, () => new StatisticsDataX01());
    $scope.statisticsDataCricketArray = Array.from({ length: 8 }, () => new StatisticsDataCricket());
    $scope.statisticsDataCricketArray_prev = Array.from({ length: 8 }, () => new StatisticsDataCricket());
    let game_data_c_baceno_strelica_prev = 0;
    let num_of_players_prev = 0;
    let data_c_option_prev = 0;
    let data_c_sub_game_prev = 0;
    let data_c_game_prev = 0;
    let game_names_prev = "";
    let intervalId_2s;
    let intervalId_10s;
    $scope.background_player_score = [];
    $scope.prikaz_loterry_num = "";
    let restore_data_setup_clock_select = 0;
    $scope.ver_dart_cpu = "x";
    $scope.ver_dart_target = "y";
    $scope.ver_dart_cctalk = "z";
    $scope.cpu_serial_num = '--------';
    $scope.system_errors = "READY";
    $scope.dijelova_kredita = 0;


    $scope.changeLanguage = function(key) {
        $translate.use(key);
    };
  
                                          //display0 $scope.menuState = 190;
    $scope.display_running = display;     //display1  $scope.menuState = 100;
    $scope.quit_menu = 0;
    $scope.quit_menu = 0;
    $scope.insufficient_credit = 0;
    $scope.insufficient_missing_credit = 0;
    let GL_Cpu_game_data, GL_Cpu_settings_data;

    /*  SOCKET EVENTS  */
    socket.on('connect', function() {
        /*$scope.extraPopoutText = "Setting up connection of system devices, please wait."
        $scope.showExtraPopout = true;
        $scope.$apply();*/
        socket.emit('MONITOR>RPI:requireInitData', 8998, /*$scope.usbConnected,*/ function(result) {
            $scope.showExtraPopout = result;
            //$scope.usbConnected = true;
            $scope.$apply();
        });
    });


    socket.on('RPI>MONITOR:initData', function(data) {
        console.log('RPI>MONITOR:initData start ', data);
        for (var i = 0; i < 26; i++) {
            $scope.select_game_color_background.push('#000000');
        }
        $scope.select_game_color_background[25] = '#777777'; //spremi u sivo
        for (var i = 0; i < 14; i++) {
            $scope.select_option_mode_x01_color_background.push('#000000');
        }
        for (var i = 0; i < 7; i++) {
            $scope.select_option_mode_cricket_color_background.push('#000000');
        }
        for (var i = 0; i < 20; i++) {
            $scope.select_num_of_set_color_background.push('#000000');
            $scope.select_num_of_leg_color_background.push('#000000');
        }

        for (var i = 0; i < 8; i++) {
            $scope.player_ppd_total_score.push(0); //koristi ih 8
            $scope.player_ppd_total_darts.push(0);

            $scope.num_c_dart_prev.push(-1);
            $scope.select_num_of_players_color_background.push('#FFFFFF');
            $scope.select_id_players_color_background.push('#FFFFFF');

            $scope.background_player_score.push('#000');
        }
        player_ppd_total_score_prev = 0;
        player_c_score_prev[0] = 0;
        player_c_score_prev[1] = 0;
        player_c_score_prev[2] = 0;
        prev_dart = -1;
        for (var i = 0; i < 3; i++) {
            $scope.select_num_of_teams_color_background.push('#FFFFFF');
        }
        for (var i = 0; i < 21; i++) {
            $scope.select_pick_it_num_color_background.push('#000000');
        }
        for (var i = 0; i < 5; i++) {
            $scope.select_medley_color_background.push('#000000');
        }
        $scope.select_medley_color_background
            //default data
        $scope.select_num_of_set_color_background[0] = '#ff0000';
        $scope.select_num_of_leg_color_background[1] = '#ff0000';
        $scope.selectedNumOfSetIndex = 0; //prikazuje 1, 
        $scope.selectedNumOfLegIndex = 1; //prikazuje 2, 
        $scope.select_num_of_players_color_background[0] = '#ff0000';
        $scope.select_id_players_color_background[0] = '#ff0000';
        $scope.select_quattro_color_background = '#ffffff';
        
        if(display == 1){
            console.log('ovo je display1')
            $scope.menuState = 100;
        }else{
            console.log('ovo je display0')
            $scope.menuState = 190;
        }
        

        if (data.Cpu_data.game_mode == 1 && data.Cpu_data.game >= 0 && data.Cpu_data.game <= 5) {
            console.log('ovo je x01')
            $scope.menuState = 300;
        } else if (data.Cpu_data.game_mode == 1 && data.Cpu_data.game == 6) {
            console.log('ovo je Cricket')
            $scope.menuState = 400;

        } else if (data.Cpu_data.game_mode == 0) {
            //console.log('ovo je select game')
            if(display == 1){
                //console.log('ovo je display1')
                $scope.menuState = 100;
            }else{
                //console.log('ovo je display0')
                $scope.menuState = 190;
            }

        }
        for (var i = 0; i < 128; i++) {
            data.Cpu_other_data.c_podaci[i] = 0;
        }
        let hit = 0;
        game_data_c_baceno_strelica_prev = 0;

        igra_podaci_iz_aparata_offline(data.Cpu_game_data, data.Cpu_settings_data, data.Cpu_other_data, hit, data.Cpu_settings_turnir_data);

        //$scope.changeLanguage(data.Setup_data.ee_sett_language);
        $scope.$apply(); //to je vec u igra_podaci
    });

    //Goran 
    socket.on('RPI>MONITOR:settings_data', function(Cpu_setting_data) { ///ivan vukoja odabir igre
        console.log('refresh settings podataka', Cpu_setting_data);
        cpu_settings_data = Cpu_setting_data;
        $scope.$apply();
    });

    socket.on('RPI>MONITOR:gameSelect', function(Cpu_data, Display_data, Setup_data) { ///ivan vukoja odabir igre
        console.log('usao u moinitor select', 'Cpu_data', Cpu_data, 'Display_data', Display_data, 'Setup_data', Setup_data);
        $scope.menuState = 0;
        $scope.$apply();
    });

    socket.on('Monitor:dip_switch', function(data) {
        console.log('sad je dip switch', data)
        $scope.menuState = 800;
        $scope.$apply();
    });

    //prijem podataka od 
    socket.on('MONITOR:bootloader_update_status', function(boot_line_current, boot_total_lines, boot_status) { //Goran
        console.log('MONITOR:bootloader_update_status', boot_line_current, 'boot_total_lines', boot_total_lines, 'boot_status', boot_status);
        $scope.boot_line_current = boot_line_current;
        $scope.boot_total_lines = boot_total_lines;
        $scope.boot_status = boot_status;
        $scope.$apply();
    });
    /*
    100 selsect game
    300 game x01
    400 game cricket

    600 game winner score board

    800 settings
    //c_game_mode  vrijednosti i znacenje
    #define C_GAME_MODE_SELECT_GAME		0
    #define C_GAME_MODE_PLAY			1
    #define C_GAME_MODE_GAME_END		2
    #define C_GAME_MODE_PLAYOFF			3
    #define C_GAME_MODE_LOTTERY			4
    #define C_GAME_MODE_SWITCH_PLAYER		5
    #define C_GAME_MODE_DEMO			6
    #define C_GAME_MODE_PLAYER_ID		7

    #define C_GAME_MODE_NULL			9

    #define C_GAME_MODE_SETTINGS		10
    #define C_GAME_MODE_TEST			11
    #define C_GAME_MODE_DEFAULT			12
    #define C_GAME_MODE_BOOK_MAIN		13
    #define C_GAME_MODE_BOOK_SEC		14
    #define C_GAME_MODE_HIDDEN_MENU		15

    #define C_GAME_MODE_BUST			16
    #define C_GAME_MODE_JEDI			17
	
    */

    //GUMBI NA FRONTU

    // Added script to handle button clicks and change color
    //odabir igre povratak pritisnute tipke
    $scope.selectedGameIndex = null;
    $scope.selectGame = function(index) {

        console.log('Button game clicked:', index);
        var prev_selected_game_item = index; //za pocetno bi bio 0 , onda ne bi imalo smisla za prvo paljenje
        var tipka_rng, tipka_parcheesi;
        tipka_rng = '#000000';
        tipka_parcheesi = '#000000';
        if ($scope.select_game_color_background[10] == '#ff0000') tipka_rng = '#ff0000';
        if ($scope.select_game_color_background[11] == '#ff0000') tipka_parcheesi = '#ff0000';

        for (var i = 0; i < 26; i++) { //provjeri koji je odabran
            if ($scope.select_game_color_background[i] == '#ff0000') {
                prev_selected_game_item = i;
                break;
            }
        }
        for (var i = 0; i < 26; i++) { //ostale vrati u crno
            $scope.select_game_color_background[i] = '#000000';
        }
        $scope.select_game_color_background[25] = '#777777'; //stavi u sivo

        //nije idealno napisano,a li ima select deselect i block bez igre
        $scope.select_game_color_background[index] = '#ff0000';
        if (index == 10 && tipka_rng == '#ff0000') {
            $scope.select_game_color_background[index] = '#000000';
            index = prev_selected_game_item;
            $scope.select_game_color_background[index] = '#ff0000';
        }
        if (index == 11 && tipka_parcheesi == '#ff0000') {
            $scope.select_game_color_background[index] = '#000000';
            index = prev_selected_game_item;
            $scope.select_game_color_background[index] = '#ff0000';
        }


        if (index == 10 || index == 11 || prev_selected_game_item == 10 || prev_selected_game_item == 11) {
            if (index < 6 || prev_selected_game_item < 6) {
                $scope.select_game_color_background[prev_selected_game_item] = '#ff0000';
                if (index > prev_selected_game_item) {
                    let temp_sw;
                    temp_sw = index;
                    index = prev_selected_game_item;
                    prev_selected_game_item = temp_sw;
                }
            }

        }
        $scope.selectedGameIndex = index; //koja je igra odabrana
        //obrisi opcije ostale
        select_game_default_option_data();
        select_game_name_local(index, prev_selected_game_item);
        /*
        		$scope.select_game_color_background = [];
        	$scope.select_option_mode_x01_color_background = [];
        	$scope.select_option_mode_cricket_color_background = [];
        	$scope.select_num_of_set_color_background = [];
        	$scope.select_num_of_leg_color_background = [];
        	$scope.select_num_of_players_color_background = [];
        	$scope.select_id_players_color_background = [];
        	$scope.select_num_of_teams_color_background = [];
        	*/
    };

    //tipke option_mode_x01
    $scope.selectedOptionModeX01Index = null;
    $scope.selectdOptionModeX01 = function(index) {
        $scope.selectedOptionModeX01Index = index; //koja je igra odabrana
        console.log('Button option x01 clicked:', index);
        if ($scope.select_option_mode_x01_color_background[index] == '#000000') $scope.select_option_mode_x01_color_background[index] = '#ff0000';
        else $scope.select_option_mode_x01_color_background[index] = '#000000';

        if (index == 0) $scope.select_option_mode_x01_color_background[2] = '#000000'; //postavi u crno
        else if (index == 1) $scope.select_option_mode_x01_color_background[3] = '#000000'; //postavi u crno
        else if (index == 2) $scope.select_option_mode_x01_color_background[0] = '#000000'; //postavi u crno
        else if (index == 3) $scope.select_option_mode_x01_color_background[1] = '#000000'; //postavi u crno
        else if (index == 10) {
            $scope.select_option_mode_x01_color_background[12] = '#000000'; //postavi u crno
            $scope.select_quattro_color_background = '#ffffff';
        } else if (index == 12) {
            $scope.select_option_mode_x01_color_background[10] = '#000000'; //postavi u crno
            $scope.select_quattro_color_background = '#ffffff';
        } else if (index == 11) $scope.select_option_mode_x01_color_background[13] = '#000000'; //postavi u crno
        else if (index == 13) $scope.select_option_mode_x01_color_background[11] = '#000000'; //postavi u crno
        if (index >= 5 && index <= 9) {
            for (var i = 5; i < 10; i++) {
                if (i != index) $scope.select_option_mode_x01_color_background[i] = '#000000'; //postavi u crno
            }
        }
        //$scope.select_option_mode_x01_color_background
        //socket.emit('MONITOR>RPI:prijam_podataka_odabir_opcije', index);
    };

    //tipke option_mode_cricket
    $scope.selectedOptionModeCricketIndex = null;
    $scope.selectOptionModeCricket = function(index) {
        $scope.selectedOptionModeCricketIndex = index; //koja je igra odabrana
        console.log('Button option cricket clicked:', index);
        if ($scope.select_option_mode_cricket_color_background[index] == '#000000') $scope.select_option_mode_cricket_color_background[index] = '#ff0000';
        else $scope.select_option_mode_cricket_color_background[index] = '#000000';


        if (index == 3) {
            $scope.select_option_mode_cricket_color_background[5] = '#000000'; //postavi u crno	
            $scope.select_quattro_color_background = '#ffffff';
        } else if (index == 5) {
            $scope.select_option_mode_cricket_color_background[3] = '#000000'; //postavi u crno
            $scope.select_quattro_color_background = '#ffffff';
        }
        if (index >= 0 && index <= 2) {
            for (var i = 0; i < 3; i++) {
                if (i != index) $scope.select_option_mode_cricket_color_background[i] = '#000000'; //postavi u crno
            }
        }
    };
    //tipke select set
    $scope.selectedNumOfSetIndex = null;
    $scope.selectNumOfSet = function(index) {
        $scope.selectedNumOfSetIndex = index + 1;
        console.log('Button num of set clicked:', index);
        for (var i = 0; i < 20; i++) { //ostale vrati u crno
            $scope.select_num_of_set_color_background[i] = '#000000';
        }
        $scope.select_num_of_set_color_background[index] = '#ff0000';
    };

    //tipke select leg
    $scope.selectedNumOfLegIndex = null;
    $scope.selectNumOfLeg = function(index) {
        $scope.selectedNumOfLegIndex = (index + 1) * 2 - 1;
        console.log('Button num of leg clicked:', index);
        for (var i = 0; i < 20; i++) { //ostale vrati u crno
            $scope.select_num_of_leg_color_background[i] = '#000000';
        }
        $scope.select_num_of_leg_color_background[index] = '#ff0000';
    };
    //odabir medley igre
    $scope.selectedMedleyIndex = null;
    $scope.selectMedley = function(index) {
        $scope.selectedMedleyIndex = index; //koja je igra odabrana
        console.log('Button medley clicked:', index);
        if ($scope.select_medley_color_background[index] == '#000000') $scope.select_medley_color_background[index] = '#ff0000';
        else $scope.select_medley_color_background[index] = '#000000';
        $scope.menuState = 110; //medlay game pick it
        $scope.medley_num_select = 'MEDLEY PICK GAME ' + (index + 1);
    }

    //pritisak na gumb quattro
    $scope.button_quattro = function(index) {

        if ($scope.select_quattro_color_background == '#ffffff') {
            $scope.select_quattro_color_background = '#ff0000'; //quattro on
            $scope.select_option_mode_x01_color_background[10] = '#000000'; //x01 obrisi podatke handicap
            $scope.select_option_mode_x01_color_background[12] = '#000000'; //x01 obrisi podatke handicap
            $scope.select_option_mode_cricket_color_background[3] = '#000000'; //cricket obrisi podatke handicap
            $scope.select_option_mode_cricket_color_background[5] = '#000000'; //cricket obrisi podatke handicap
        } else $scope.select_quattro_color_background = '#ffffff';
        console.log('Button quattro clicked:', $scope.select_quattro_color_background);
    };

    //tipke cricket pick number
    $scope.selectedPickItNumIndex = null;
    $scope.selectPickItNum = function(index) {
        $scope.selectedPickItNumIndex = index;
        console.log('Button pick it number clicked:', index);
        let broj_odabranih = 0;
        for (let i = 0; i < 21; i++) {
            if ($scope.select_pick_it_num_color_background[i] == '#ff0000') broj_odabranih++;
        }
        if (broj_odabranih == 7) $scope.flag_block_button_next = 0; //ima ih dovoljno 
        else $scope.flag_block_button_next = 1;

        if ($scope.select_pick_it_num_color_background[index] == '#ff0000') $scope.select_pick_it_num_color_background[index] = '#000000';
        else {
            if (broj_odabranih < 7) {
                if ($scope.select_pick_it_num_color_background[index] == '#000000') $scope.select_pick_it_num_color_background[index] = '#ff0000';
            }
        }
        console.log('Button pick it number clicked broj_odabranih:', broj_odabranih);
    };

    //pritisak na gumb selectNumOfPlayers
    $scope.selectedNumOfPlayers = 1;
    $scope.selectNumOfPlayers = function(index) {
        $scope.selectedNumOfPlayers = index;
        console.log('Button num of players clicked:', index);
        for (var i = 0; i < 8; i++) {
            $scope.select_num_of_players_color_background[i] = '#FFFFFF';
        }
        $scope.select_num_of_players_color_background[index] = '#ff0000';

        for (var i = 0; i < 8; i++) {
            $scope.select_id_players_color_background[i] = '#FFFFFF';
            $scope.row2up_num_of_players[i] = " "; //obrisi sve team oznake
        }
        $scope.positions_row2_num_of_players = []; //inicijaliziraj ponvno
        for (var i = 0; i <= index; i++) {
            $scope.positions_row2_num_of_players.push(i * 10.4);
        }
        $scope.selectedTeam_2pl = null; //obrisi teamove sve
        for (var i = 0; i < 3; i++) {
            $scope.select_num_of_teams_color_background[i] = '#FFFFFF';
        }
        //socket.emit('MONITOR>RPI:potrebni_zadnji_podaci_za_settings', index);
    };
    //pritisak na gumb selectIdPlayer
    $scope.selectedIdPlayer = null;
    $scope.selectIdPlayer = function(index) {
        $scope.selectedIdPlayer = index;
        console.log('Button id player clicked:', index);
        for (var i = 0; i < 8; i++) {
            $scope.select_id_players_color_background[i] = '#FFFFFF';
        }
        $scope.select_id_players_color_background[index] = '#ff0000';
    };
    //pritisak na gumb button_team_2pl
    $scope.selectedTeam_2pl = null;
    $scope.selectTeam_2pl = function(index) {
        $scope.selectedTeam_2pl = index;
        var index_temp, team_pl_temp = 1; //da ne dijeli sa 0 slucajno
        console.log('Button Team_2pl clicked:', index);
        //$scope.menuState = 107;			//stranica teams select		
        for (var i = 0; i < 3; i++) {
            $scope.select_num_of_teams_color_background[i] = '#FFFFFF';
        }
        $scope.select_num_of_teams_color_background[index] = '#ff0000';
        if (index == 0) //team od 2 igraca
        {
            index_temp = 3;
            team_pl_temp = 2;
        } else if (index == 1) //team od 3 igraca
        {
            index_temp = 5;
            team_pl_temp = 3;
        } else if (index == 2) //team od 4 igraca
        {
            index_temp = 7;
            team_pl_temp = 4;
        }
        console.log('j:', ((index_temp + 1) / team_pl_temp));
        console.log('i:', team_pl_temp);
        for (var j = 0; j < (team_pl_temp); j++) { //broj igraca u teamu
            for (var i = 0; i < ((index_temp + 1) / team_pl_temp); i++) //broj timova
            {
                $scope.row2up_num_of_players[(j * ((index_temp + 1) / team_pl_temp)) + i] = "Team " + (i + 1);
                console.log('var:', (j * team_pl_temp) + i);
            }
        }
        $scope.selectedNumOfPlayers = index_temp;
        console.log('Change num of players clicked:', index_temp);
        for (var i = 0; i < 8; i++) {
            $scope.select_num_of_players_color_background[i] = '#FFFFFF';
        }
        $scope.select_num_of_players_color_background[index_temp] = '#ff0000';

        for (var i = 0; i < 8; i++) {
            $scope.select_id_players_color_background[i] = '#FFFFFF';
        }
        $scope.positions_row2_num_of_players = []; //inicijaliziraj ponvno
        for (var i = 0; i <= index_temp; i++) {
            $scope.positions_row2_num_of_players.push(i * 10.4);
        }
    };
    //pritisak na gumb home
    $scope.button_home = function(index) {
        $scope.menuState = 100;
        console.log('Button home clicked:');
    };
    //pritisak na gumb local play
    $scope.button_local = function(index) {
        select_game_mode(); //load data
        select_option_mode_x01(); //load data
        select_option_mode_cricket(); //load data
        select_num_of_sets(); //load data
        select_num_of_players(); //load data
        select_game_default_option_data(); //default player num, default 1
        $scope.menuState = 101;

        console.log('Button local play clicked:');
    };
    //pritisak na gumb online
    $scope.button_online = function(index) {
        $scope.menuState = 102;
        console.log('Button online play clicked:');

    };
    //pritisak na gumb mypage
    $scope.button_mypage = function(index) {
        $scope.menuState = 103;
        console.log('Button mypage clicked:');
    };
    //pritisak na gumb tournaments
    $scope.button_tournaments = function(index) {
        $scope.menuState = 103;
        console.log('Button tournaments clicked:');
    };
    //pritisak na gumb number_of_sets_legs
    $scope.button_number_of_sets_legs = function(index) {
        $scope.menuState = 104;
        console.log('Button number_of_sets_legs clicked:');
    };
    //pritisak na gumb medley
    $scope.button_medley = function(index) {
        $scope.menuState = 105;
        console.log('Button medley clicked:');
    };
    //pritisak na gumb bluetooth
    $scope.button_bluetooth = function(index) {
        $scope.menuState = 120;
        console.log('Button bluetooth clicked:');
    };
    //pritisak na gumb info
    $scope.button_info = function(index) {
        let temp = 0;
        $scope.menuState = 130;
        console.log('Button info clicked:');
        socket.emit('MONITOR>RPI:potreban_bootloader_update', temp);
    };
    //pritisak na gumb language
    $scope.button_language = function(index) {
        $scope.menuState = 140;
        console.log('Button language clicked:');
    };
    //pritisak na gumb settings
    $scope.button_settings = function(index) {

        select_settings_name(index);
        $scope.menuState = index;
        console.log('Button settings clicked:', index);
    };

    //pritisak na gumb next ili start, poslozi koji je izbornik
    $scope.button_next = function(index) {
        let temp = $scope.menuState;
        let insufficientTimer;
        if (temp == 101) {
            //provjeri da li je odabrana igra, ak one vrati na 101
            let ima_igre = 0;
            for (let i = 0; i < 26; i++) {
                if (i != 10 && i != 11) {
                    if ($scope.select_game_color_background[i] == '#ff0000') ima_igre = 1;
                }
            }
            if (ima_igre) {
                if ($scope.selectedGameIndex >= 0 && $scope.selectedGameIndex <= 5) temp = 102;
                else if ($scope.selectedGameIndex == 7) temp = 108; //pick numbers
                else if ($scope.selectedGameIndex >= 6 && $scope.selectedGameIndex <= 9) temp = 103;
                else if ($scope.selectedGameIndex == 25) temp = 104; //select sets/legs
                else temp = 106;
            }
            select_num_of_sets(); //load data update for medley games
        } else if (temp == 102) temp = 106;
        else if (temp == 103) temp = 106;
        else if (temp == 104) {
            if ($scope.selectedGameIndex == 25) {
                select_num_of_medley_games() //load number of games
                temp = 109; //medley select games
            } else temp = 106;
        } else if (temp == 105) temp = 106;
        else if (temp == 108) {
            let broj_odabranih = 0;
            for (let i = 0; i < 21; i++) {
                if ($scope.select_pick_it_num_color_background[i] == '#ff0000') broj_odabranih++;
            }
            if (broj_odabranih == 7) temp = 103; //pick numbers finished
        } else if (temp == 109) temp = 106; //select players
        else if (temp > 109 && temp < 119) temp = 109;
        else {
            if (temp == 106 || temp == 107) {
                //izracunaj cijenu igre ??? 
                let cijena_odabrane_igre = 5;

                let number_game, num_sub_game, some_game_option, broj_igraca;
                ({
                    number_game,
                    num_sub_game,
                    some_game_option,
                    broj_igraca
                } = odabrani_parametri_igre());
                //console.log('number_game:', number_game, 'num_sub_game:', num_sub_game, 'some_game_option:', some_game_option, 'broj_igraca:', broj_igraca);
                cijena_odabrane_igre = dupla_cijena_igre(number_game, num_sub_game, some_game_option);
                cijena_odabrane_igre = cijena_odabrane_igre * broj_igraca / 2;
                if (cijena_odabrane_igre <= $scope.current_credits)
                {
                    //ako ima dovoljno ok ponisti, inace ubaci credit
                    $scope.insufficient_credit = 0;     //0
                    $scope.insufficient_missing_credit = 0;

                    temp = 300; 
                    //slanje podataka od odabira na monitoru prema RPi
                    socket.emit('MONITOR>RPI:prijam_podataka_odabir_igre', $scope.select_game_color_background,
                        $scope.select_option_mode_x01_color_background,
                        $scope.select_quattro_color_background,
                        $scope.select_option_mode_cricket_color_background,
                        $scope.select_num_of_set_color_background,
                        $scope.select_num_of_leg_color_background,
                        $scope.select_num_of_players_color_background,
                        $scope.select_id_players_color_background,
                        $scope.select_num_of_teams_color_background,
                        $scope.select_pick_it_num_color_background,
                        index);
                }
                else
                {
                    socket.emit('MONITOR>RPI:prijam_podataka_quit_menu', 2); //beep
                    $scope.insufficient_credit = 1;
                    $scope.insufficient_missing_credit = cijena_odabrane_igre - $scope.current_credits;
                    if (insufficientTimer) {
                        $timeout.cancel(insufficientTimer);
                    }
                
                    insufficientTimer = $timeout(function () {
                        $scope.insufficient_credit = 0;
                        $scope.insufficient_missing_credit = 0;
                    }, 1000);
                }
            }
        }
        /*if (temp == 300)
        {
        	serialPort.protocolx_write("", constant.CMD_RETURN_GAME_SETTINGS);
        	serialPort.protocolx_write("", constant.CMD_RETURN_GAME_DATA);
        }*/
        //select_local_game_name($scope.selectedGameIndex);   //napravi naziv igre
        //potrebni su novi podaci kako bi se izracunala cijena igre
       /* if (temp == 106) {
            socket.emit('MONITOR>RPI:potrebni_zadnji_podaci_za_settings', temp);
            console.log('MONITOR>RPI:potrebni_zadnji_podaci_za_settings:', temp);
            //izracunaj cijenu igre ??? 

        }*/
        $scope.menuState = temp;
        console.log('Button next clicked:', temp);
    };

    //pritisak na gumb back, poslozi koji je izbornik
    $scope.button_back = function(index) {
        let temp = $scope.menuState;
        if (temp == 101) temp = 100;
        else if (temp == 102) temp = 101;
        else if (temp == 103) temp = 101;
        else if (temp == 104) //back from select sets legs
        {
            if ($scope.selectedGameIndex == 25) temp = 101; //medley select games 		
            else if ($scope.selectedGameIndex < 6) temp = 102; //x01 select games
            else if ($scope.selectedGameIndex > 5 && $scope.selectedGameIndex < 10) temp = 103; //cricket select games	
            else temp = 101;
        } else if (temp == 105) temp = 102;
        else if (temp == 106) {
            if ($scope.selectedGameIndex >= 0 && $scope.selectedGameIndex <= 5) temp = 102;
            else if ($scope.selectedGameIndex >= 6 && $scope.selectedGameIndex <= 9) temp = 103;
            else if ($scope.selectedGameIndex == 25) temp = 109; //medley select games 
            else temp = 101;
        } else if (temp == 107) temp = 106;
        else if (temp == 108) temp = 101;
        else if (temp == 109) temp = 104;
        else if (temp > 109 && temp < 119) temp = 109;
        else if (temp > 119 && temp < 150) temp = 100;
        else if (temp == 300 || temp == 400) {
            temp = 100;
            select_game_default_option_data();
        } else if (temp == 800) temp = 100;
        else if (temp == 801) temp = 800; //settings
        else if (temp == 901) temp = 800; //settings
        else if (temp >= 802 && temp <= 804) temp = 801; // setup
        else if (temp >= 810 && temp <= 815) temp = 802; //game settings
        else if (temp >= 830 && temp <= 835) temp = 803; //dart settings
        else if (temp >= 850 && temp <= 861) temp = 804; //monney credits
        else if (temp >= 910 && temp <= 924) temp = 901; //test menu
        else if (temp == 981) temp = 800; //settings

        select_settings_name(temp);
        $scope.menuState = temp;
        console.log('Button back clicked:', temp);
    };
    //pritisak na gumb button_last_stat, poslozi koji je izbornik
    $scope.button_last_stat = function(index) {
        let temp = $scope.menuState;
        temp = 601;
        select_settings_name(temp);
        $scope.menuState = temp;
        console.log('Button last stat clicked:', temp);
    };
    //pritisak na gumb button_quit_menu, poslozi koji je izbornik
    $scope.button_quit_menu = function(index) {
        let temp = $scope.menuState;
        
        if ( $scope.quit_menu == 1)  $scope.quit_menu = 0;
        else $scope.quit_menu = 1;

        select_settings_name(temp);
        $scope.menuState = temp;
        console.log('Button quit menu clicked:', temp);
    };
    //pritisak na gumb button_quit_game, poslozi koji je izbornik
    $scope.button_quit_game = function(index) {
        let temp = $scope.menuState;
        $scope.quit_menu = 0;
        //slanje podataka od odabira na monitoru prema RPi
        //socket.emit('MONITOR>RPI:prijam_podataka_odabir_igre', $scope.select_game_color_background,
        socket.emit('MONITOR>RPI:prijam_podataka_quit_menu', 0);
        select_settings_name(temp);
        $scope.menuState = temp;
        console.log('Button quit game clicked:', temp);
    };
    //pritisak na gumb button_return_dart, poslozi koji je izbornik
    $scope.button_return_dart = function(index) {
        let temp = $scope.menuState;
        $scope.quit_menu = 0;
        //slanje podataka od odabira na monitoru prema RPi
        //socket.emit('MONITOR>RPI:prijam_podataka_odabir_igre', $scope.select_game_color_background,
        if (index)
            socket.emit('MONITOR>RPI:prijam_podataka_quit_menu', 1);
            
        select_settings_name(temp);
        $scope.menuState = temp;
        console.log('Button return dart clicked:', temp);
    };

    //prijem podataka od igre sa ploce preko RPi na monitor
    socket.on('Monitor:Igra', function(game_data, Cpu_data, Cpu_other, hit, Cpu_turnir_data) { //Goran
        //console.log('prikaz igre ,game_data ivan',game_data,'Cpu_data',Cpu_data,Cpu_other,hit);
        console.log('prikaz igre ,game_data main2',Cpu_turnir_data);
        $scope.quit_menu = 0;   //prekinu pritisak na quit menu na donjem ekranu
        igra_podaci_iz_aparata_offline(game_data, Cpu_data, Cpu_other, hit, Cpu_turnir_data);
       
    });

    function odabrani_parametri_igre()
    {
        /*socket.emit('MONITOR>RPI:prijam_podataka_odabir_igre', $scope.select_game_color_background,
        $scope.select_option_mode_x01_color_background,
        $scope.select_quattro_color_background,
        $scope.select_option_mode_cricket_color_background,
        $scope.select_num_of_set_color_background,
        $scope.select_num_of_leg_color_background,
        $scope.select_num_of_players_color_background,
        $scope.select_id_players_color_background,
        $scope.select_num_of_teams_color_background,
        $scope.select_pick_it_num_color_background,
        index);*/
        let number_game = 0;
        let num_sub_game = 0;
        let some_game_option = 0;
        let broj_igraca = 0;
        let game, option_x01, option_quattro, option_cricket, num_of_set, num_of_leg, num_of_players, id_players, num_of_teams, pick_it_num;
            
        //prevedi podatke iz polja RGB u broj
        for (var i = 0; i < 26; i++) {
            if ($scope.select_game_color_background[i] != ('#000000')) 
            {
                game = i;
                break;
            }
        }
        //provjeri za opcije RnG i Parchessi koje su u game
        let game_rng_par = 0;
        //pick_it_num = pick_it_num_ar;
        if ($scope.select_quattro_color_background != ('#ffffff')) option_quattro = 1;
        else option_quattro = 0;

        if ($scope.select_game_color_background[10] != ('#000000')) game_rng_par = 10;
        if ($scope.select_game_color_background[11] != ('#000000')) game_rng_par = 11;
        option_x01 = 0;
        option_cricket = 0;
        let option_end_equal = 0;
        if (game < 6)
        {
            for (var i = 0; i < 14; i++) {
                if ($scope.select_option_mode_x01_color_background[i] != ('#000000')) 
                {
                    if (i == 0) option_x01 |= OPTION_DOUBLE_IN;  //DBL IN
                    else if (i == 1)  option_x01 |= OPTION_DOUBLE_OUT; //DBL OUT
                    else if (i == 2)  option_x01 |= OPTION_DOUBLE_IN; //MASTER IN
                    else if (i == 3)  option_x01 |= OPTION_MASTER_OUT; //MASTER OUT
                    else if (i == 11)
                    {
                        option_x01 |= OPTION_EQUAL; //EQUAL
                        option_end_equal = 1;
                    }
                    else if (i == 13)  
                    {
                        option_x01 |= OPTION_EQUAL; //END
                        option_end_equal = 2;
                    }
                }
            }
        }
        else if (game < 10)
        {
           
           
            for (var i = 0; i < 7; i++) {
                if ($scope.select_option_mode_cricket_color_background[i] != ('#000000')) 
                {
                    if (i == 0) option_cricket = 30; //CUT THROAT
                    else if (i == 1)  option_cricket = 10; //MASTER
                    else if (i == 2)  option_cricket = 20; //KILLER
                }
            }
        }
        for (var i = 0; i < 20; i++) {
            
        }

        for (var i = 0; i < 8; i++) {
            if ($scope.select_num_of_players_color_background[i] != ('#FFFFFF'))
            {
                num_of_players = i + 1;
                break;
            } 
        }
        for (var i = 0; i < 3; i++) {
            
        }
        if (game >= 6 && game <= 9)
            {
                number_game = 6; //ovo je cricket
                num_sub_game = game + 20 - 1; //ovo je cricket opcija   
                num_sub_game += option_cricket; //ovo je sub game  
                
            } 
            else if (game == 12 ) number_game = 10; //ovo je Sahangai
            else if (game == 13 ) number_game = 14; //ovo je super 100
            else if (game == 14 ) number_game = 9; //ovo je Super score
            else if (game == 15 ) number_game = 19; //ovo je Split score
            else if (game == 16 ) number_game = 7; //ovo je Hi score
            else if (game == 17 ) number_game = 8; //ovo je Low score
            else if (game == 18 ) number_game = 17; //ovo je Solo 301
            else if (game == 19 ) number_game = 16; //ovo je Solo Hi score
            else if (game == 20 ) number_game = 15; //ovo je Pub game
            else if (game == 21 ) number_game = 13; //ovo je Scram
            else if (game == 22 ) number_game = 18; //ovo je Marathon
            else if (game == 23 ) number_game = 12; //ovo je roulete
            else if (game == 24 ) number_game = 11; //ovo je Baseball
            
            else 
                number_game = game; //ovo je igra
            if (game < 6)
            {
                if (option_end_equal != 0 && game_rng_par != 0)  //onda je parchessi equal end
                {
                    if (game_rng_par == 11) //Parcheesi
                    num_sub_game = game_rng_par + option_end_equal;
                }
                else if (option_end_equal != 0)
                    num_sub_game = option_end_equal; //ovo je equal end
                else if (game_rng_par != 0)
                    num_sub_game = game_rng_par; //ovo je run & gun i parcheesi
            }
            //igra bez reload-a
            if (option_quattro) option_x01 |= OPTION_QUATTRO;   //dodaj i quattro na kraju
            some_game_option = option_x01;      //ovo je opcija
            

           
        broj_igraca = num_of_players;

        return {
            number_game,
            num_sub_game,
            some_game_option,
            broj_igraca
        };
    }
    
    //GL_Cpu_game_data = game_data;
    //GL_Cpu_settings_data = Cpu_data;
    function dupla_cijena_igre(number_game, num_sub_game, some_game_option)
    {
        let game_price_, broj_polovina_, cijelih_cijena_, cijena_pod_opcija, pom;
        broj_polovina_ = 0;
        game_price_ = 0;
        cijena_pod_opcija = 0;
        
        cijelih_cijena_ = GL_Cpu_settings_data.ee_price_adjust[number_game];
        if (num_sub_game == SUB_GAME_MARATHON_MINI && number_game == GAME_MARATHON) cijelih_cijena_ = cijelih_cijena_ >> 1;
        //ovaj $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_score_realuvjet ako je cijena igre samo pola onda ne uzima ostale opcije na naplatu nego samo pola kredita
        //if (cijelih_cijena_ == 255) return 1;		//znaci pola *2 = 1  
        if (cijelih_cijena_ == 255) broj_polovina_++;
        else game_price_ += cijelih_cijena_;
        cijelih_cijena_ = 0;
        if (number_game < GAME_CRICKET)  //samo x01 igre
        {
            //opcije mogu imati vrijednost od +-20
            if ((some_game_option & OPTION_DOUBLE_IN) && (some_game_option & OPTION_DOUBLE_OUT)) cijelih_cijena_ = GL_Cpu_settings_data.ee_price_adjust[22];
            else if ((some_game_option & OPTION_DOUBLE_IN) && (some_game_option & OPTION_MASTER_OUT)) pom = 0;	
            else if (some_game_option & OPTION_DOUBLE_IN)  cijelih_cijena_ = GL_Cpu_settings_data.ee_price_adjust[20];
            else if (some_game_option & OPTION_DOUBLE_OUT) cijelih_cijena_ = GL_Cpu_settings_data.ee_price_adjust[21];
            else if (some_game_option & OPTION_MASTER_OUT) cijelih_cijena_ = GL_Cpu_settings_data.ee_price_adjust[23];	
        }
        else if (number_game == GAME_CRICKET)  //samo cricket igre	
        {		//samo su sub game pod posebnom naplatom
            if (num_sub_game % 10 == 6)		 cijelih_cijena_ = GL_Cpu_settings_data.ee_price_adjust[26];	//pick it
            else if (num_sub_game % 10 == 7) cijelih_cijena_ = GL_Cpu_settings_data.ee_price_adjust[27];   //random
            else if (num_sub_game % 10 == 8) cijelih_cijena_ = GL_Cpu_settings_data.ee_price_adjust[28];   //crazy
            
            //ovo su opcije 
            if (Math.floor(num_sub_game / 10) == 3) cijena_pod_opcija = 0;  //master cricket
            else if (Math.floor(num_sub_game / 10) == 4) cijena_pod_opcija = GL_Cpu_settings_data.ee_price_adjust[29];		//killer cricket
            else if (Math.floor(num_sub_game / 10) == 5) cijena_pod_opcija = GL_Cpu_settings_data.ee_price_adjust[24];		//cut throat
        }
        if (cijena_pod_opcija > 20)
        {
            cijena_pod_opcija = 41 - cijena_pod_opcija;	//da dobijem modul broja
            game_price_ -= cijena_pod_opcija;		
        }
        else
            game_price_ += cijena_pod_opcija;	
            
        if (cijelih_cijena_ > 20)
        {
            cijelih_cijena_ = 41 - cijelih_cijena_;	//da dobijem modul broja
            game_price_ -= cijelih_cijena_;		
        }			
        else
            game_price_ += cijelih_cijena_;	
        if (game_price_ > 128) game_price_ = 0;	//znaci da ne moze biti negativna
        game_price_ = (game_price_ * 2) + broj_polovina_; 
        
        return game_price_;
    }	

    function igra_podaci_iz_aparata_offline(game_data, Cpu_data, Cpu_other, hit, Cpu_turnir_data) {
        GL_Cpu_game_data = game_data;
        GL_Cpu_settings_data = Cpu_data;
        console.log('prikaz igre ,game_data main3', game_data, 'Cpu_data', Cpu_data, Cpu_other, hit, Cpu_turnir_data);
        $scope.num_players = game_data.c_num_players;
        $scope.current_score = game_data.c_score;

        $scope.ver_dart_cpu = String('CPv') + game_data.c_ver_cpu[0] + String('.') + game_data.c_ver_cpu[1];
        $scope.ver_dart_target = String('Tv') + game_data.c_ver_target[0] + String('.') + game_data.c_ver_target[1];
        $scope.ver_dart_cctalk = String('CCv') + game_data.c_ver_cctalk[0] + String('.') + game_data.c_ver_cctalk[1];
        $scope.cpu_serial_num = String('12345678');
        //namjerno *5 ostavljeno da se zna onda vrijednost u c
        if (Cpu_data.ee_cijena_jednog_kredita)
        {
            $scope.dijelova_kredita = game_data.c_dijelova_kredita_u_aparatu * 5 / (Cpu_data.ee_cijena_jednog_kredita * 5) * 5;
        }
        //if ($scope.dijelova_kredita > 5) $scope.dijelova_kredita = 5;
        
        if (game_data.c_round < 10) $scope.currentRound = String('0') + game_data.c_round;
        else $scope.currentRound = game_data.c_round;

        if ((game_data.c_jumpers & JUMPER_TURNIR) == 0) {
            $scope.currentRound += String(' / ');
            if (game_data.c_max_rounds < 10) $scope.currentRound += String('0') + game_data.c_max_rounds;
            else $scope.currentRound += game_data.c_max_rounds;
        }

        $scope.gamePrice = game_data.c_cijena_igre / 2;
        if (game_data.c_max_rounds == 255)
            $scope.gameRounds = '';
        else
            $scope.gameRounds = '/' + game_data.c_max_rounds;
        $scope.current_dart = game_data.c_dart;
        $scope.current_credits = game_data.c_credit;
        $scope.current_player_throw = game_data.c_player_throw;
        $scope.current_line_player_throw = game_data.c_player_throw;
        $scope.bull_value = 'Bull 25/50';
        if (Cpu_data.ee_bull_value == 1) $scope.bull_value = 'Bull 25/25';
        if (Cpu_data.ee_bull_value == 2) $scope.bull_value = 'Bull 25/50';
        if (Cpu_data.ee_bull_value == 3) $scope.bull_value = 'Bull 50/50';
        if (Cpu_data.ee_bull_value == 4) $scope.bull_value = 'Bull 50/100';
        if (game_data.c_game == 6) $scope.bull_value = 'PLAYER ' + String($scope.current_line_player_throw);

        //poruka ispod broja
        $scope.player_throw = '';
        $scope.text_free = '';

        if (game_data.c_show_msg == MSG_THROW) $scope.player_throw = 'Throw';
        else if (game_data.c_show_msg == MSG_BUST) $scope.player_throw = 'BUST';
        else if (game_data.c_show_msg == MSG_TEAM_FREEZE) $scope.player_throw = 'Frozen';
        else if (game_data.c_show_msg == MSG_EAT) $scope.player_throw = 'Throw';
        else if (game_data.c_show_msg == MSG_ERROR_TARGET_STUCKED) $scope.player_throw = 'Stuck';

        if (game_data.c_show_msg == MSG_NONE) $scope.text_free = '';
        else if (game_data.c_show_msg == MSG_N_THROW) $scope.text_free = 'Remove Darts';

        else if (game_data.c_show_msg == MSG_EAT) $scope.text_free = 'EAT';
        else if (game_data.c_show_msg == MSG_TUP) $scope.text_free = 'MISSED';
        else if (game_data.c_show_msg == MSG_180) $scope.text_free = '180';
        else if (game_data.c_show_msg == MSG_150) $scope.text_free = 'BINGO';

        system_errors_data(game_data.c_show_msg, game_data.c_max_strelica);

        if (game_data.c_game_mode == C_GAME_MODE_PLAY) //play game mode
        {
            if (reset_current_statistics) {
                reset_current_statistics = 0;
                $scope.statisticsDataX01Array.forEach(obj => obj.reset()); //statistika za 8 igraca = 0; 
                $scope.statisticsDataCricketArray.forEach(obj => obj.reset()); //statistika za 8 igraca = 0; 
            }
            ponudi_izlaz(game_data, Cpu_data);
            run_statistics_data(game_data, Cpu_data);
        }
        if (game_data.c_game_mode == C_GAME_MODE_SWITCH_PLAYER) //change player game mode
        {
            $scope.current_player_score_prev = 0;
            strelica_u_ovoj_rundi = 0;
            console.log('C_GAME_MODE_SWITCH_PLAYER');
        }
        if (game_data.c_game_mode == C_GAME_MODE_SWITCH_PLAYER) //play game mode
        {
            //prikaz_statistike(game_data,Cpu_data);
        }
        if (game_data.c_game_mode == C_GAME_MODE_SELECT_GAME) //select game mode
        {
            //select_game_mode();   //odaberi neku igru
            select_game_name_local_buttons(game_data, Cpu_data, hit);
            if(display == 1){
                console.log('ovo je display1')
                if ($scope.menuState > 109)
                    $scope.menuState = 100;
            }else{
                console.log('ovo je display0')
                $scope.menuState = 190;
            }
            if (game_data.c_show_msg == MSG_SHOW_WINNER_STAT) {
                console.log('********* prikaz_statistike2 *********');
                prikaz_statistike(game_data, Cpu_data);
                //$scope.startTimer_10s();
            } else {
                $scope.stopTimer_10s();
                for (let i = 0; i < 8; i++) //postavi statistiku u 0
                {
                    $scope.player_ppd_total_score[i] = 0; //koristi ih 8
                    $scope.player_ppd_total_darts[i] = 0;
                    reset_current_statistics = 1;
                    $scope.num_c_dart_prev[i] = -1;
                }
                player_ppd_total_score_prev = 0; //player_ppd_or_mpd
            }
        }
        if (game_data.c_game_mode == C_GAME_MODE_LOTTERY) //end game mode
        {
            if ($scope.menuState != 601) {
                // Pokreni timer
                prikaz_statistike(game_data, Cpu_data);
                $scope.startTimer_2s();
                $scope.menuState = 600;
            }
            if (game_data.c_show_msg == MSG_LOTTERY_DATA) //end game mode
            {
                $scope.prikaz_loterry_num = 'Lottery : ' + String(game_data.c_score);
                for (let i = 0; i < game_data.c_num_players; i++) {
                    if (game_data.c_score == game_data.c_player_value[i]) {
                        $scope.prikaz_loterry_num = 'Lottery : ' + String(game_data.c_score) + ' WINNER';
                    }
                }
            }
            //izmjeni za team
            $scope.player_winner_show = '';
            for (var i = 0; i < 8; i++) {
                if (game_data.c_player_rank[i] == 1) {
                    if (game_data.c_team_num) $scope.player_winner_show = 'TEAM ' + (i + 1); //ako je team igra
                    else $scope.player_winner_show = 'PLAYER ' + (i + 1);
                    $scope.current_player_ppd = (0).toFixed(2); //postavi u nulu
                    if ($scope.player_ppd_total_darts[i] > 0) //provjeri da ne dijelis sa 0 bacenih strelica
                    {
                        //$scope.current_player_ppd = ($scope.player_ppd_total_score[lokacija_podatka_igraca] / $scope.player_ppd_total_darts[lokacija_podatka_igraca]);
                        $scope.current_player_ppd = ($scope.player_ppd_total_score[i] / $scope.player_ppd_total_darts[i]).toFixed(2);

                    }
                    if (((game_data.c_option & OPTION_QUATTRO) == 0 && (game_data.c_sub_game == 0) && game_data.c_game < 6) || game_data.c_game == GAME_SOLO_301) $scope.current_player_ppd = 'PPD ' + String($scope.current_player_ppd);
                    else if (game_data.c_game == 6) $scope.current_player_ppd = 'MPR ' + String($scope.current_player_ppd);
                    else $scope.current_player_ppd = 'SCORE ' + String(game_data.c_player_value[i]);
                }
            }
        } else {
            $scope.prikaz_loterry_num = "";
        }

        if (game_data.c_game_mode == C_GAME_MODE_SETTINGS) //settings mode
        {
            $scope.menuState = 951;
            $scope.settings_name = "SETUP";
            $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/setup.png';
            old_display_jumper_data($scope.menuState, Cpu_other, Cpu_data, game_data, Cpu_turnir_data);
        } else if (game_data.c_game_mode == C_GAME_MODE_TEST) //test mode
        {
            $scope.menuState = 952;
            $scope.settings_name = "TEST MODE";
            $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_menu.png';
            old_display_jumper_data($scope.menuState, Cpu_other, Cpu_data, game_data, Cpu_turnir_data);
        } else if (game_data.c_game_mode == C_GAME_MODE_BOOK_MAIN) //bookkeeping main mode
        {
            $scope.menuState = 953;
            $scope.settings_name = "MAIN BOOKKEEPING";
            $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/main_bookkeeping.png';
            old_display_jumper_data($scope.menuState, Cpu_other, Cpu_data, game_data, Cpu_turnir_data);
        } else if (game_data.c_game_mode == C_GAME_MODE_BOOK_SEC) //bookkeeping sec mode
        {
            $scope.menuState = 954;
            $scope.settings_name = "SECONDARY BOOKKEEPING";
            $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/sec_bookkeeping.png';
            old_display_jumper_data($scope.menuState, Cpu_other, Cpu_data, game_data, Cpu_turnir_data);
        } else if (game_data.c_game_mode == C_GAME_MODE_DEFAULT) //init default factory mode
        {
            $scope.menuState = 955;
            $scope.settings_name = "FACTORY RESET";
            $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/factory_reset.png';
            old_display_jumper_data($scope.menuState, Cpu_other, Cpu_data, game_data, Cpu_turnir_data);
        }
        else if (game_data.c_game_mode == C_GAME_MODE_HIDDEN_MENU) //init default factory mode
        {
            $scope.menuState = 956;
            $scope.settings_name = "FACTORY SETUP";
            $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/factory_reset.png';
            old_display_jumper_data($scope.menuState, Cpu_other, Cpu_data, game_data, Cpu_turnir_data);
        }
        if (game_data.c_game_mode == 5) {
            $scope.player_throw = 'Don\'t Throw';
        }
        for (let i = 0; i < 3; i++) {
            if (game_data.c_hits[i] > 100 && game_data.c_hits[i] <= 150) //ovo je x2
            {
                $scope.dart[i] = '2 x ' + (game_data.c_hits[i] - 100);
            } else if (game_data.c_hits[i] > 150 && game_data.c_hits[i] < 200) //ovo je x4
            {
                if (game_data.c_option & OPTION_QUATTRO)
                    $scope.dart[i] = '4 x ' + (game_data.c_hits[i] - 150);
                else
                    $scope.dart[i] = (game_data.c_hits[i] - 150);
            } else if (game_data.c_hits[i] > 200 && game_data.c_hits[i] <= 250) //ovo je x3
            {
                $scope.dart[i] = '3 x ' + (game_data.c_hits[i] - 200);
            } else if (game_data.c_hits[i] == 255) //ovo je prazna ne bacena, 0 je bacena
            {
                $scope.dart[i] = '';
            } else
                $scope.dart[i] = game_data.c_hits[i];
        }

        for (let i = 0; i < game_data.c_num_players; i++) {
            $scope.players_value[i] = game_data.c_player_value[i];
        }
        $scope.current_player_score = game_data.c_player_value[game_data.c_player_throw - 1];
        $scope.special_game_text = ''; //obrisi podatke
        //if (game_data.c_game_mode == 0 game_data.c_flags_data == 2)  //znaci prikaz pobjednika
        //if (game_data.c_game_mode == 0 game_data.c_flags_data == 1)	//znaci select game
        if (game_data.c_game_mode == 2 && game_data.c_show_msg == MSG_TEAM_FREEZE) $scope.special_game_text = 'Frozen';
        if (game_data.c_game_mode == 1 && game_data.c_show_msg == MSG_PICK_NUM) $scope.special_game_text = 'PICK NUMBERS';
        
        if ((game_data.c_game_mode == 1 || game_data.c_game_mode == 3) && game_data.c_game != 6) { //play or playoff x01

            $scope.menuState = 300;
            $scope.player_ppd_or_mpd = 0;

            if (game_data.c_game > 6) {
                if (game_data.c_game == 11) //Baseball       11
                {
                    $scope.special_game_text = "ANY " + String(game_data.c_round);
                } else if (game_data.c_game == 12) //Roulette       12  trerba komanda sa CPUa
                {
                    if (game_data.c_option == OPTION_DOUBLE_IN) //Roulette
                    {
                        $scope.special_game_text = "DOUBLE " + String(game_data.c_cricket_broj[0]);
                    } else
                    //const unsigned char brojevi_split_score[] PROGMEM = {15, 16, 2, 17, 18, 3, 19, 20, 25};
                        $scope.special_game_text = "ANY " + String(game_data.c_cricket_broj[0]);
                    if (game_data.c_cricket_broj[0] == 0) $scope.special_game_text = "";
                } else if (game_data.c_game == 13) //GAME_SCRAM       13
                {
                    if (game_data.c_cricket_broj[game_data.c_player_throw - 1] == 1) $scope.special_game_text = "SCORE";
                    else $scope.special_game_text = "STOP";
                } else if (game_data.c_game == 15) //GAME_PUB       15
                {
                    if (game_data.c_cricket_broj[game_data.c_player_throw - 1] > 10) $scope.special_game_text = "10";
                    else $scope.special_game_text = game_data.c_cricket_broj[game_data.c_player_throw - 1];
                    //pokreni timer
                } else if (game_data.c_game == 18) //GAME_MARATHON       18
                {
                    $scope.special_game_text = "2 x " + String(game_data.c_cricket_broj[game_data.c_player_throw - 1]);
                } else if (game_data.c_game == 19) //GAME_SPLIT_SCORE       19
                {

                    //const unsigned char brojevi_split_score2[] PROGMEM = {13, 14, 2, 15, 16, 3, 17, 18, 4, 19, 20, 25};
                    //ovdje dodaj za quattro drugi brpjevi, for quattro dif numbers
                    if ((game_data.c_option & OPTION_QUATTRO))
                    {
                        if (game_data.c_round == 1) $scope.special_game_text = "ANY 13";
                        else if (game_data.c_round == 2) $scope.special_game_text = "ANY 14";
                        else if (game_data.c_round == 3) $scope.special_game_text = "ANY 2x";
                        else if (game_data.c_round == 4) $scope.special_game_text = "ANY 15";
                        else if (game_data.c_round == 5) $scope.special_game_text = "ANY 16";
                        else if (game_data.c_round == 6) $scope.special_game_text = "ANY 3x";
                        else if (game_data.c_round == 7) $scope.special_game_text = "ANY 17";
                        else if (game_data.c_round == 8) $scope.special_game_text = "ANY 18";
                        else if (game_data.c_round == 9) $scope.special_game_text = "ANY 4x";
                        else if (game_data.c_round == 10) $scope.special_game_text = "ANY 19";
                        else if (game_data.c_round == 11) $scope.special_game_text = "ANY 20";
                        else if (game_data.c_round == 12) $scope.special_game_text = "ANY 25";
                    }
                    else
                    {
                        //const unsigned char brojevi_split_score[] PROGMEM = {15, 16, 2, 17, 18, 3, 19, 20, 25};
                        if (game_data.c_round == 1) $scope.special_game_text = "ANY 15";
                        else if (game_data.c_round == 2) $scope.special_game_text = "ANY 16";
                        else if (game_data.c_round == 3) $scope.special_game_text = "ANY 2x";
                        else if (game_data.c_round == 4) $scope.special_game_text = "ANY 17";
                        else if (game_data.c_round == 5) $scope.special_game_text = "ANY 18";
                        else if (game_data.c_round == 6) $scope.special_game_text = "ANY 3x";
                        else if (game_data.c_round == 7) $scope.special_game_text = "ANY 19";
                        else if (game_data.c_round == 8) $scope.special_game_text = "ANY 20";
                        else if (game_data.c_round == 9) $scope.special_game_text = "ANY 25";
                    }

                }

            }
            if ((game_data.c_game < 7) && (game_data.c_sub_game == 10)) $scope.special_game_text = game_data.c_cricket_broj[game_data.c_player_throw - 1];
            if (game_data.c_show_msg == MSG_TEAM_FREEZE) $scope.special_game_text = 'Frozen';
            if (game_data.c_show_msg == MSG_EAT) $scope.special_game_text = 'EAT';

            //dodaj ostale igre u prikaz, zuti ekran na raw1_5
        }
        if ((game_data.c_game_mode == 1 || game_data.c_game_mode == 3) && game_data.c_game == 6) { //cricket
            let flag_got_bull = 0;
            $scope.menuState = 400;
            $scope.player_ppd_or_mpd = 1;
            $scope.cricket_fixed_num = []; //$scope.cricket_fixed_num = ['20', '19', '18', '17', '16'];
            $scope.cricket_fixed_num_opacity = []; //$scope.cricket_fixed_num = ['20', '19', '18', '17', '16'];
            for (var k = 7; k > 0; k--) { //idi od veceg prema manjem
                if (game_data.c_cricket_broj[k - 1] != 25) {
                    $scope.cricket_fixed_num.push(game_data.c_cricket_broj[k - 1]); //brojevi na cricketu
                    $scope.cricket_fixed_num_opacity.push(1); //brojevi na cricketu
                }
            }
            if (game_data.c_cricket_broj[6] == 25) {
                $scope.cricket_fixed_num.push(game_data.c_cricket_broj[6]); //brojevi na cricketu, zadnji
                $scope.cricket_fixed_num_opacity.push(1); //brojevi na cricketu
                flag_got_bull = 1;
            }

            //$scope.positions_cricket = [14, 20, 26, 32, 38, 44, 50]; 
            //$scope.positions_cricket = [0, 6, 12, 18, 24, 30, 36];   //ovo su redovi
            $scope.positions_cricket = [0, 6.3, 12.6, 18.9, 25.2, 31.5, 37.8]; //ovo su redovi
            //$scope.positions_cricket = [5, 11, 17, 23, 29, 35, 41];   //ovo su redovi
            $scope.players_cricket_value = new Array(24);
            $scope.positions_cricket_scores = [];
            //let positions_cricket_scores_table = [43.6, 52.6, 39.6, 56.6, 35.6, 60.6, 31.6, 64.6];
            //let positions_cricket_scores_table = [43.6, 52.6, 39.4, 56.8, 35.2, 61.0, 31.0, 65.2];
            let positions_cricket_scores_table = [43.6, 52.4, 39.4, 56.6, 35.2, 60.8, 31.0, 65.0]; //pomak stupaca cricketa
            //var temp_array_positions_cricket_scores = [32, 36, 40, 44, 53, 57, 61, 65]; //kolone
            if ($scope.num_players > 8) $scope.num_players = 8;
            for (var i = 0; i < $scope.num_players; i++) {
                $scope.positions_cricket_scores.push(0);
            }
            for (var i = 0; i < $scope.num_players; i++) {
                $scope.positions_cricket_scores[i] = positions_cricket_scores_table[i];
            }
            /*if ($scope.num_players > 8) $scope.num_players = 8;
            var pomak_kolone = 8 - $scope.num_players;
			pomak_kolone = pomak_kolone / 2;
			pomak_kolone = Math.floor(pomak_kolone); // Zaokružuje prema dolje
			var temp_shift = 0;
            for (var i = (0 + pomak_kolone); i < ($scope.num_players + pomak_kolone); i++) {
				if (i > 3) temp_shift = 5;
				$scope.positions_cricket_scores.push(31.6 + (i * 4) + temp_shift);
			}
			*/
            for (var i = 0; i < 24; i++) {
                //$scope.players_cricket_value[i] = game_data.c_player_cricket[i];
                $scope.players_cricket_value[i] = reverseBits8bit(game_data.c_player_cricket[i], flag_got_bull);
            }

            // Function to check if bit at position is set
            $scope.isBitSet = function(value, bit) {
                return (value & (1 << bit)) !== 0;
            };
            //ispitaj da li su svi pogodili isti cricket broj
            for (var k = 0; k < 7; k++) {
                let ima_sve = 1;
                for (var j = 0; j < $scope.num_players; j++) {
                    if (($scope.players_cricket_value[j * 3 + 0] & (1 << k)) == 0) ima_sve = 0;
                    if (($scope.players_cricket_value[j * 3 + 1] & (1 << k)) == 0) ima_sve = 0;
                    if (($scope.players_cricket_value[j * 3 + 2] & (1 << k)) == 0) ima_sve = 0;
                }
                if (ima_sve == 1) {
                    //$scope.cricket_fixed_num[k] = '-';
                    $scope.cricket_fixed_num_opacity[k] = 0.2; //brojevi na cricketu
                }
            }
        }
        if (game_data.c_game_mode == 3 || game_data.c_playoff_flag > 0) {
            $scope.special_game_text = '';
            $scope.ponudi_izlaz = '';
            $scope.special_game_text = 'PLAYOFF ';
        }
        if (game_data.c_game_mode == 3 && game_data.c_playoff_flag > 0)
            $scope.special_game_text += String(game_data.c_playoff_flag) + '. PLACE';

        select_game_name(game_data, Cpu_data, hit);

        //players
        $scope.positions_player_top = [];
        $scope.positions_player_left = [];
        $scope.positions_player_okvir_top = [];
        $scope.positions_player_okvir_left = [];
        $scope.positions_player_okvir_hight = [];
        $scope.players_index_value = [];
        $scope.positions_player_okvir_bck_color = [];
        $scope.player_team_mate = -1;
        $scope.players_teams_sums = [];
        //$scope.positions_color = ['#ff0000', '#009245', '#0000ff', '#f7931e', '#ed1e79', '#29abe2', '#754c24', '#000000']; // Niz boja
        $scope.positions_color = ['#c07f2f', '#c07f2f', '#c07f2f', '#c07f2f', '#c07f2f', '#c07f2f', '#c07f2f', '#c07f2f']; // Niz boja

        // Izračunaj pozicije igraca
        // Maksimalan broj igrača
        if ($scope.num_players > 8) $scope.num_players = 8;
        //za team izracun okvira
        let team_num = game_data.c_team_num % 10;
        let team_num_players = Math.floor(game_data.c_team_num / 10);
        let pom_hight = 0;
        if (team_num_players == 2) {
            if ($scope.num_players < 5) //za veci prikaz koristi
                pom_hight = 25.6;
            else
                pom_hight = 20.6;
        } else if (team_num_players == 3) pom_hight = 31.6;
        else if (team_num_players == 4) pom_hight = 42.6;
        for (var i = 0; i < team_num; i++) {
            $scope.positions_player_okvir_left.push(i);
            $scope.positions_player_okvir_top.push(i);
            $scope.positions_player_okvir_hight.push(pom_hight);
            $scope.positions_player_okvir_bck_color.push('transparent');
            $scope.players_teams_sums.push(i);
        }
        if (team_num_players) //ako je team igra
        {
            if (team_num_players == 2) //pronadi suigraca
            {
                $scope.players_teams_sums[0] = $scope.players_value[0] + $scope.players_value[2];
                $scope.players_teams_sums[1] = $scope.players_value[1] + $scope.players_value[3];

                if (game_data.c_player_throw == 1) $scope.player_team_mate = 3;
                if (game_data.c_player_throw == 2) $scope.player_team_mate = 4;
                if (game_data.c_player_throw == 3) $scope.player_team_mate = 1;
                if (game_data.c_player_throw == 4) $scope.player_team_mate = 2;
                if (game_data.c_team_num == 23) //iznimka, prikazi 6 na poziciji 7
                {
                    if (game_data.c_player_throw == 5) $scope.player_team_mate = 6;
                    if (game_data.c_player_throw == 6) $scope.player_team_mate = 5;
                    $scope.players_teams_sums[2] = $scope.players_value[4] + $scope.players_value[5];
                    if (game_data.c_player_throw == 6) $scope.current_line_player_throw = game_data.c_player_throw + 1;
                } else {
                    if (game_data.c_player_throw == 5) $scope.player_team_mate = 7;
                    if (game_data.c_player_throw == 6) $scope.player_team_mate = 8;
                    if (game_data.c_player_throw == 7) $scope.player_team_mate = 6;
                    if (game_data.c_player_throw == 8) $scope.player_team_mate = 8;
                    $scope.players_teams_sums[2] = $scope.players_value[4] + $scope.players_value[6];
                    $scope.players_teams_sums[3] = $scope.players_value[5] + $scope.players_value[7];
                }
                /*, 'highlight_team_mate': $index === (player_team_mate - 1)*/
            } else if (team_num_players == 3) {
                $scope.players_teams_sums[0] = $scope.players_value[0] + $scope.players_value[2] + $scope.players_value[4];
                $scope.players_teams_sums[1] = $scope.players_value[1] + $scope.players_value[3] + $scope.players_value[5];
            } else if (team_num_players == 4) {
                $scope.players_teams_sums[0] = $scope.players_value[0] + $scope.players_value[2] + $scope.players_value[4] + $scope.players_value[6];
                $scope.players_teams_sums[1] = $scope.players_value[1] + $scope.players_value[3] + $scope.players_value[5] + $scope.players_value[7];
            }
            if (game_data.c_player_throw % 2) //provjeri da li je par ili nepar
            {
                if (team_num_players == 2 && game_data.c_player_throw > 3)
                    $scope.positions_player_okvir_bck_color[2] = '#B3B3B3';
                else
                    $scope.positions_player_okvir_bck_color[0] = '#B3B3B3';
            } else //ako je paran
            {
                if (team_num_players == 2 && game_data.c_player_throw > 4) {
                    if (game_data.c_team_num == 23) //iznimka, prikazi 6 na poziciji 7
                        $scope.positions_player_okvir_bck_color[2] = '#B3B3B3';
                    else
                        $scope.positions_player_okvir_bck_color[3] = '#B3B3B3';
                } else
                    $scope.positions_player_okvir_bck_color[1] = '#B3B3B3';
            }
        }
        for (var i = 0; i < team_num; i++) {
            let pom = 0;
            if ($scope.num_players > 4) {
                if (i > 1) pom = 1.6;
                if (i % 2 === 1) {
                    $scope.positions_player_okvir_left[i] = 11.7;
                    $scope.positions_player_okvir_top[i] = pom + Math.floor(i / 2) * 20.6 + 0.01;
                } else {
                    $scope.positions_player_okvir_left[i] = 0.0;
                    $scope.positions_player_okvir_top[i] = pom + Math.floor(i / 2) * 20.6;
                }
            } else {
                if (i > 1) pom = 1.6;
                if (i % 2 === 1) {
                    $scope.positions_player_okvir_left[i] = 9.0;
                    $scope.positions_player_okvir_top[i] = 4.4 + 0.01;
                } else {
                    $scope.positions_player_okvir_left[i] = -4.9;
                    $scope.positions_player_okvir_top[i] = 4.4;
                }
            }

        }
        //postavljanje igraca
        for (var i = 0; i < $scope.num_players; i++) {
            if (game_data.c_team_num == 23 && i == 5) i = 6; //iznimka, prikazi 6 na poziciji 7
            $scope.players_index_value.push(i + 1);
            /*if (i % 2 === 1) {
            	$scope.positions_player_left.push(15.15); // 
            	$scope.positions_player_top.push(1.4 + Math.floor(i / 2) * 11.2 + 0.01); 
            } else { 
            	$scope.positions_player_left.push(3.5); 
            	$scope.positions_player_top.push(1.4 + Math.floor(i / 2) * 11.2); 
            }*/
            if ($scope.num_players > 4) {
                if (i % 2 === 1) {
                    $scope.positions_player_left.push(15.15); // 
                    $scope.positions_player_top.push(1.4 + Math.floor(i / 2) * 11.2 + 0.01);
                } else {
                    $scope.positions_player_left.push(3.5);
                    $scope.positions_player_top.push(1.4 + Math.floor(i / 2) * 11.2);
                }
            } else if ($scope.num_players > 2) {
                if (i % 2 === 1) {
                    $scope.positions_player_left.push(12.85); // 
                    $scope.positions_player_top.push(5.4 + Math.floor(i / 2) * 15.5 + 0.01);
                } else {
                    $scope.positions_player_left.push(-1.0);
                    $scope.positions_player_top.push(5.4 + Math.floor(i / 2) * 15.5);
                }
            } else if ($scope.num_players > 0) {
                $scope.positions_player_left.push(5.5);
                $scope.positions_player_top.push(5.4 + i * 15.5);
            }
        }

        if ($scope.player_throw == 'Throw') $scope.player_throw_color = '#FFFF00'; //yellow
        else if ($scope.player_throw == 'BUST') $scope.player_throw_color = '#00FFFF'; //tirkizno
        else if ($scope.player_throw == 'Remove Darts') $scope.player_throw_color = '#FFAA00'; //narand
        else if ($scope.player_throw == 'Don\'t Throw') $scope.player_throw_color = '#FF0000'; //crvena

        for (i = 0; i < 8; i++) $scope.background_player_score[i] = '#000';
        if (game_data.c_game_mode == 3 || game_data.c_playoff_flag > 0) {
            for (let i = 0; i < game_data.c_num_players; i++) {
                if (game_data.c_playoff_flag == game_data.c_player_rank[i]) $scope.players_value[i] = Cpu_data.ee_ppr_statistics[i];
                else $scope.background_player_score[i] = '#999';
            }
        }

        /*
			 <div class="column5_okviri">
                <p ng-repeat="pos in [0, 1, 2, 3]" ng-style="{'top': pos + 'vh', 'left': positions_player_left[$index] + 'vw'};" ng-class="{'highlight_throw': $index === (current_player_throw - 1)}">
                    <span class="player-value-text">{{players_value[$index]}}</span>
                </p>
            </div>
			<div id="player_score_name">
                <p ng-repeat="pos in positions_player_top" ng-style="{'top': pos + 'vh', 'left': positions_player_left[$index] + 'vw'};" ng-class="{'highlight_throw': $index === (current_player_throw - 1)};">
                    
                    <span class="player-value-text">{{players_value[$index]}}</span>
                </p>
            </div>
			*/
        /*
        	if ($scope.num_players > 8) $scope.num_players = 8;
        	for (var i = 0, j = 0; i < $scope.num_players; i++) {
        		$scope.positions_player_left.push(j * 15.2);
        		if ($scope.num_players % 2  === 0)  //parni
        		{
        			$scope.positions_player_top.push(4.5 + i * 12);
        			$scope.positions_player_left.push(15.2);
        		}
        		else   //neparni
        		{
        			j++;
        			$scope.positions_player_top.push(4.5 + i * 12);
        			$scope.positions_player_left.push(0);
        				//$scope.positions_player_top.push(4.5 + Math.floor(i/2) * 12 + i/100);   //uzmi cijeli broj od i/2
        			}
        		}
        	}
        */

        $scope.$apply();
    }
    //don't throw remove darts blink

    setInterval(() => {
        if ($scope.player_throw == 'Don\'t Throw') $scope.player_throw = 'Remove Darts';
        else if ($scope.player_throw == 'Remove Darts') $scope.player_throw = 'Don\'t Throw';
        if ($scope.player_throw == 'Throw') $scope.player_throw_color = '#FFFF00'; //yellow
        else if ($scope.player_throw == 'BUST') $scope.player_throw_color = '#00FFFF'; //tirkizno
        else if ($scope.player_throw == 'Remove Darts') $scope.player_throw_color = '#FF8800'; //narand
        else if ($scope.player_throw == 'Don\'t Throw') $scope.player_throw_color = '#FF0000'; //crvena

        $scope.$apply(); // Osigurava ažuriranje u AngularJS
    }, 1500);

    $scope.startTimer_2s = function() {
        intervalId_2s = setInterval(() => {

            if ($scope.menuState == 600) {
                $scope.menuState = 601; //prikaz_statistike(game_data,Cpu_data);   //ovo automatski prebaci u 601 ako ima
                $scope.stopTimer_2s();
            }
            $scope.$apply(); // Osigurava ažuriranje u AngularJS
        }, 4000);
    };

    $scope.stopTimer_2s = function() {
        if (intervalId_2s) {
            clearInterval(intervalId_2s);
        }
    };

    $scope.startTimer_10s = function() {
        intervalId_10s = setInterval(() => {

            $scope.menuState = 190; //prikaz_statistike(game_data,Cpu_data);   //ovo automatski prebaci u 601 ako ima
            $scope.stopTimer_10s();

            $scope.$apply(); // Osigurava ažuriranje u AngularJS
        }, 10000);
    };

    $scope.stopTimer_10s = function() {
        if (intervalId_10s) {
            clearInterval(intervalId_10s);
        }
    };
    // Pokreni timer
    //$scope.startTimer_2s();

    // Zaustavi timer nakon 3 sekundi
    /*setTimeout(() => {
    	$scope.stopTimer_2s();
    }, 3000);*/

    //cricket zamjena pozicija bitova
    // Funkcija koja preokreće bitove u 8-bitnom broju
    function reverseBits8bit(num, flag_got_bull) {
        let reversedNum = 0;
        for (let i = 0; i < 8; i++) {
            if (num & (1 << i)) reversedNum = reversedNum | (1 << (7 - i)); //uzmi bit  
            else reversedNum = reversedNum & (255 - (1 << (7 - i))); //uzmi bit i postavi ga u 0
        }
        reversedNum = reversedNum >> 1; //pomakni za 1 mjestu u desno
        /*console.log('num:', num,'reversedNum: ',reversedNum);
        console.log('flag_got_bull_vrijednost:',flag_got_bull);*/
        if (flag_got_bull == 1) {
            let bull_bit = reversedNum & 0x01;
            reversedNum = reversedNum >> 1; //pomakni za 1 mjestu u desno
            if (bull_bit) reversedNum = reversedNum | 0x40;
            else reversedNum = reversedNum & 0xBF;
        }
        return reversedNum;
    }
    /**LOCAL GAME SELECTION   odabir igre preko tipki */

    function select_game_name_local_buttons(game_data, Cpu_data, hit) {

        let broj_opcija = 0;
        $scope.selection_game = "";
        $scope.selection_option = "";
        $scope.selection_option_quattro = "";
        $scope.selection_players = game_data.c_num_players;
        $scope.selection_teams = "";
        let temp = '';

        if (game_data.c_game == 0) temp = '180';
        else if (game_data.c_game == 1) temp = '301';
        else if (game_data.c_game == 2) temp = '501';
        else if (game_data.c_game == 3) temp = '701';
        else if (game_data.c_game == 4) temp = '901';
        else if (game_data.c_game == 5) temp = '1001';
        else if (game_data.c_game == 6) temp = 'Cricket';
        else if (game_data.c_game == 7) temp = 'Hi Score';
        else if (game_data.c_game == 8) temp = 'Low Score';
        else if (game_data.c_game == 9) temp = 'Super Score';
        else if (game_data.c_game == 10) temp = 'Shangai';
        else if (game_data.c_game == 11) temp = 'Baseball';
        else if (game_data.c_game == 12) temp = 'Roulette';
        else if (game_data.c_game == 13) temp = 'Scram';
        else if (game_data.c_game == 14) temp = 'Super 100';
        else if (game_data.c_game == 15) temp = 'Pub';
        else if (game_data.c_game == 16) temp = 'Solo Hi Score';
        else if (game_data.c_game == 17) temp = 'Solo 301';
        else if (game_data.c_game == 18) temp = 'Marathon';
        else if (game_data.c_game == 19) temp = 'Split Score';
        else temp = 'Other';
        $scope.selection_game = temp;

        for (var k = 0; k < 16; k++) {
            temp = '';
            var j;
            j = 1 << k;
            if ((game_data.c_option & j) != 0) {
                if (game_data.c_game < 6) {
                    if (j == OPTION_DOUBLE_IN) temp = 'Double In';
                    else if (j == OPTION_DOUBLE_OUT) temp = 'Double Out';
                    //else if (j == 0x20) temp = 'Equal';
                    else if (j == OPTION_MASTER_OUT) temp = 'Master Out';
                }
                //else if (j == 0x1000) temp = 'Parcheesi';
                if (j == OPTION_QUATTRO) $scope.selection_option_quattro = 'Quattro';
                if (game_data.c_game == 12) //Roulette
                {
                    if (j == OPTION_DOUBLE_IN) temp = 'Double In';
                }
            }
            if (temp != '') {
                broj_opcija++;
                if ($scope.selection_option != '') $scope.selection_option += ' / ';
                $scope.selection_option += String(temp);
            }
        }
        temp = '';
        if (game_data.c_sub_game == 1) temp = 'Equal';
        else if (game_data.c_sub_game == 2) temp = 'End';
        else if (game_data.c_sub_game == 10) temp = 'Run & Gun';
        else if (game_data.c_sub_game == 11) temp = 'Parcheesi';
        else if (game_data.c_sub_game == 12) temp = 'Parcheesi Equ';
        else if (game_data.c_sub_game == 13) temp = 'Parcheesi End';
        //else if (game_data.c_sub_game == 25) temp = 'Normal';
        else if (game_data.c_sub_game == 26) temp = 'Pick It';
        else if (game_data.c_sub_game == 27) temp = 'Random';
        else if (game_data.c_sub_game == 28) temp = 'Crazy';
        else if (game_data.c_sub_game == 35) temp = 'Master';
        else if (game_data.c_sub_game == 36) temp = 'Pick It Master';
        else if (game_data.c_sub_game == 37) temp = 'Random Master';
        else if (game_data.c_sub_game == 38) temp = 'Crazy Master';
        else if (game_data.c_sub_game == 45) temp = 'Killer';
        else if (game_data.c_sub_game == 46) temp = 'Pick It Killer';
        else if (game_data.c_sub_game == 47) temp = 'Random Killer';
        else if (game_data.c_sub_game == 48) temp = 'Crazy Killer';
        else if (game_data.c_sub_game == 55) temp = 'Cut Throat';
        else if (game_data.c_sub_game == 56) temp = 'Pick It Cut';
        else if (game_data.c_sub_game == 57) temp = 'Random Cut';
        else if (game_data.c_sub_game == 58) temp = 'Crazy Cut';
        else if (game_data.c_sub_game == 70) temp = 'Marathon mini';

        if (temp != '') //ako ima podataka
        {
            if ($scope.selection_option != '') $scope.selection_option += ' / ';
            $scope.selection_option += String(temp);
            broj_opcija++;
        }
        if ($scope.selection_option_quattro == 'Quattro') {
            if (broj_opcija < 3) //prelazi u novi red
            {
                if ($scope.selection_option != '') $scope.selection_option += ' / ';
                $scope.selection_option += $scope.selection_option_quattro; //pridruzi mu quattro	
                $scope.selection_option_quattro = ''; //  quattro obrisi
            }
        }

        temp = '';
        if (game_data.c_team_num >= 20 && game_data.c_team_num < 30) temp = '2 Players';
        else if (game_data.c_team_num >= 30 && game_data.c_team_num < 40) temp = '3 Players';
        else if (game_data.c_team_num >= 40 && game_data.c_team_num < 50) temp = '4 Players';
        $scope.selection_teams = String(temp);

    }
    /*
    $scope.select_game_color_background = [];
    	$scope.select_option_mode_x01_color_background = [];
    	$scope.select_option_mode_cricket_color_background = [];
    	$scope.select_num_of_set_color_background = [];
    	$scope.select_num_of_leg_color_background = [];
    	$scope.select_num_of_players_color_background = [];
    	$scope.select_id_players_color_background = [];
    	$scope.select_num_of_teams_color_background = [];
    */ //
    function select_game_name_local(index, pom_index) {
        $scope.game_names2 = [];
        $scope.positions_game_name2 = []; //[0, 12, 24, 36, 48, 60];  //pozicije naziva igre
        let naziv_igre_monitor = ["180", "301", "501", "701", "901", "1001", "Cricket", "Pick It Cricket", "Random Cricket", "Crazy Cricket",
            "Run & Gun", "Parcheesi", "Shangai", "Super 100", "Super Score", "Split Score", "Hi Score", "Low Score", "Solo 301", "Solo Hi score", "Pub Game", "Scram", "Marathon", "Roulette", "Baseball", "Medley"
        ];

        $scope.game_names2[0] = naziv_igre_monitor[index];
        $scope.positions_game_name2[0] = 31; //udaljenost na sredini
        if (pom_index == 10 || pom_index == 11) {
            if (index < 6) {
                $scope.game_names2[1] = naziv_igre_monitor[pom_index];
                $scope.positions_game_name2[0] = 25; //udaljenost na sredini
                $scope.positions_game_name2[1] = 37; //udaljenost na sredini
            }
        }
        console.log('naziv_igre_monitor[index]:', naziv_igre_monitor[index]);
        console.log('naziv_igre_monitor[pom_index]:', naziv_igre_monitor[pom_index]);
    }

    function select_game_name(game_data, Cpu_data, hit) {
        //opisi igru tekstom kao na tipkama
        $scope.game_names = [];
        $scope.positions_game_name = []; //[0, 12, 24, 36, 48, 60];  //pozicije naziva igre
        let game_name_position_index = 0;
        let temp = '';
        /*naziv igre u igri*/
        if (game_data.c_game == 0) temp = '180';
        else if (game_data.c_game == 1) temp = '301';
        else if (game_data.c_game == 2) temp = '501';
        else if (game_data.c_game == 3) temp = '701';
        else if (game_data.c_game == 4) temp = '901';
        else if (game_data.c_game == 5) temp = '1001';
        else if (game_data.c_game == 6) temp = 'CRICKET';
        else if (game_data.c_game == 7) temp = 'HI SCORE';
        else if (game_data.c_game == 8) temp = 'LOW SCORE';
        else if (game_data.c_game == 9) temp = 'SUPER SCORE';
        else if (game_data.c_game == 10) temp = 'SHANGHAI';
        else if (game_data.c_game == 11) temp = 'BASEBALL';
        else if (game_data.c_game == 12) temp = 'ROULETTE';
        else if (game_data.c_game == 13) temp = 'SCRAM';
        else if (game_data.c_game == 14) temp = 'SUPER 100';
        else if (game_data.c_game == 15) temp = 'PUB';
        else if (game_data.c_game == 16) temp = 'SOLO HI SCORE';
        else if (game_data.c_game == 17) temp = 'SOLO 301';
        else if (game_data.c_game == 18) temp = 'MARATHON';
        else if (game_data.c_game == 19) temp = 'SPLIT SCORE';
        else temp = 'OTHER';

        $scope.game_names.push(temp);
        $scope.positions_game_name.push(game_name_position_index * 12);
        game_name_position_index++;

        for (var k = 0; k < 16; k++) {
            temp = '';
            var j;
            j = 1 << k;
            if ((game_data.c_option & j) != 0) {
                if (game_data.c_game < 6) {
                    if (j == OPTION_DOUBLE_IN) temp = 'DOUBLE IN';
                    else if (j == OPTION_DOUBLE_OUT) temp = 'DOUBLE OUT';
                    //else if (j == 0x20) temp = 'EQUAL';
                    else if (j == OPTION_MASTER_OUT) temp = 'MASTER OUT';
                }
                //else if (j == 0x1000) temp = 'Parcheesi';
                if (j == OPTION_TEAM) temp = 'TEAM';
                else if (j == OPTION_QUATTRO) temp = 'QUATTRO';
            }
            if (temp != '') {
                $scope.game_names.push(temp);
                $scope.positions_game_name.push(game_name_position_index * 12);
                game_name_position_index++;
            }
        }

        temp = '';
        if ((game_data.c_sub_game % 10) == 6) temp = 'PICK IT';
        else if ((game_data.c_sub_game % 10) == 7) temp = 'RANDOM';
        else if ((game_data.c_sub_game % 10) == 8) temp = 'CRAZY';

        if (temp != '') {
            $scope.game_names.push(temp);
            $scope.positions_game_name.push(game_name_position_index * 12);
            game_name_position_index++;
        }

        temp = '';
        if (game_data.c_sub_game == 1) temp = 'EQUAL';
        else if (game_data.c_sub_game == 2) temp = 'END';
        else if (game_data.c_sub_game == 10) temp = 'RUN & GUN';
        else if (game_data.c_sub_game == 11) temp = 'PARCHEESI';
        else if (game_data.c_sub_game == 12) temp = 'PARCHE EQU';
        else if (game_data.c_sub_game == 13) temp = 'PARCHE END';
        //else if (game_data.c_sub_game == 25) temp = 'NORMAL';
        /*else if (game_data.c_sub_game == 26) temp = 'PICK IT';
        else if (game_data.c_sub_game == 27) temp = 'RANDOM';
        else if (game_data.c_sub_game == 28) temp = 'CRAZY';*/
        else if (game_data.c_sub_game == 35) temp = 'MASTER';
        /*else if (game_data.c_sub_game == 36) temp = 'PICK IT MASTER';
        else if (game_data.c_sub_game == 37) temp = 'RANDOM MASTER';
        else if (game_data.c_sub_game == 38) temp = 'CRAZY MASTER';
        else if (game_data.c_sub_game == 45) temp = 'KILLER';
        else if (game_data.c_sub_game == 46) temp = 'PICK IT KILLER';
        else if (game_data.c_sub_game == 47) temp = 'RANDOM KILLER';
        else if (game_data.c_sub_game == 48) temp = 'CRAZY KILLER';
        else if (game_data.c_sub_game == 55) temp = 'CUT THROAT';
        else if (game_data.c_sub_game == 56) temp = 'PICK IT CUT';
        else if (game_data.c_sub_game == 57) temp = 'RANDOM CUT';
        else if (game_data.c_sub_game == 58) temp = 'CRAZY CUT';*/
        else if (game_data.c_sub_game == 36) temp = 'MASTER';
        else if (game_data.c_sub_game == 37) temp = 'MASTER';
        else if (game_data.c_sub_game == 38) temp = 'MASTER';
        else if (game_data.c_sub_game == 45) temp = 'KILLER';
        else if (game_data.c_sub_game == 46) temp = 'KILLER';
        else if (game_data.c_sub_game == 47) temp = 'KILLER';
        else if (game_data.c_sub_game == 48) temp = 'KILLER';
        else if (game_data.c_sub_game == 55) temp = 'CUT THROAT';
        else if (game_data.c_sub_game == 56) temp = 'CUT THROAT';
        else if (game_data.c_sub_game == 57) temp = 'CUT THROAT';
        else if (game_data.c_sub_game == 58) temp = 'CUT THROAT';
        else if (game_data.c_sub_game == 70) temp = 'MARATHON MINI';


        if (temp != '') {
            $scope.game_names.push(temp);
            $scope.positions_game_name.push(game_name_position_index * 12);
            game_name_position_index++;
        }

        //preformuliraj pozicije

        let temp1 = [1, 31, 25, 19, 13, 7, 1];
        for (var k = 0; k < game_name_position_index; k++) {
            $scope.positions_game_name[k] = temp1[game_name_position_index] + 0.6 + (k * 12); //0.6 dodatno centriranje
        }
    }

    function select_game_default_option_data() {
        for (var i = 0; i < 14; i++) {
            $scope.select_option_mode_x01_color_background[i] = ('#000000');
        }
        for (var i = 0; i < 7; i++) {
            $scope.select_option_mode_cricket_color_background[i] = ('#000000');
        }
        for (var i = 0; i < 20; i++) {
            $scope.select_num_of_set_color_background[i] = ('#000000');
            $scope.select_num_of_leg_color_background[i] = ('#000000');
        }

        for (var i = 0; i < 8; i++) {
            $scope.select_num_of_players_color_background[i] = ('#FFFFFF');
            $scope.select_id_players_color_background[i] = ('#FFFFFF');
        }
        for (var i = 0; i < 3; i++) {
            $scope.select_num_of_teams_color_background[i] = ('#FFFFFF');
        }
        for (var i = 0; i < 21; i++) {
            $scope.select_pick_it_num_color_background[i] = ('#000000');
        }
        for (var i = 0; i < 5; i++) {
            $scope.select_medley_color_background[i] = ('#000000');
        }
        //default data
        $scope.select_num_of_set_color_background[$scope.selectedNumOfSetIndex] = '#ff0000'; //pamti stanje
        $scope.select_num_of_leg_color_background[$scope.selectedNumOfLegIndex] = '#ff0000'; //pamti stanje
        //$scope.selectedNumOfSetIndex = 0;   //prikazuje 1, 
        //$scope.selectedNumOfLegIndex = 1;   //prikazuje 2, 
        $scope.select_num_of_players_color_background[0] = '#ff0000';
        $scope.select_id_players_color_background[0] = '#ff0000';
        $scope.select_quattro_color_background = '#ffffff'; //quattro off
        $scope.positions_row2_num_of_players = []; //inicijaliziraj ponvno
        for (var i = 0; i < 1; i++) {
            $scope.positions_row2_num_of_players.push(i * 10.4);
        }
    }

    function select_game_mode() {
        $scope.menuState = 101;
        $scope.positions_row1_game_name = [13, 22, 31, 40, 49, 58];
        $scope.row1_game_name = ["180", "301", "501", "701", "901", "1001"];
        $scope.row1_game_name_text_h = [7.5, 7.5, 7.5, 7.5, 7.5, 7.5];

        $scope.positions_row2_game_name = [22, 31, 40, 49];
        //$scope.row2_game_name = ["Cricket", "", "", ""];
        $scope.row2_game_name = ["Cricket", "Pick It Cricket", "Random Cricket", "Crazy Cricket"];
        $scope.row2_game_name_text_h = [7.5, 3.5, 3.5, 3.5];

        $scope.positions_row3_game_name = [4, 13, 22, 31, 40, 49, 58, 67];
        //$scope.row3_game_name = ["&", "Parcheesi", "Shangai", "", "", "", "", ""];
        $scope.row3_game_name = ["Run & Gun", "Parcheesi", "Shangai", "Super 100", "Super  Score", "Split  Score", "Hi Score", "Low  Score"];
        $scope.row3_game_name_text_h = [3.5, 7.5, 7.5, 7.5, 3.5, 3.5, 7.5, 3.5];

        $scope.positions_row4_game_name = [8.5, 17.5, 26.5, 35.5, 44.5, 53.5, 62.5];
        //$scope.row4_game_name = ["", "", "", "Scram", "Marathon", "Roulette", "Baseball"];
        $scope.row4_game_name = ["Solo 301", "Solo Hi score", "Pub  Game", "Scram", "Marathon", "Roulette", "Baseball"];
        $scope.row4_game_name_text_h = [7.5, 3.5, 3.5, 7.5, 7.5, 7.5, 7.5];

        // Primjer varijabli sa HTML sadržajem
        //ERBOSE[undefined]::[SOCKET] - show newe game = tablet requested to show new game with all the data he sent //{Thu Jun 27 2024 17:05:13 GMT+0200 (Central European Summer Time)}
        // Function to check if bit at position is set
        /*$scope.isBitSet = function(value, bit) {
            return (value & (1 << bit)) !== 0;
        };*/
    }

    function select_option_mode_x01() {
        $scope.menuState = 102;
        $scope.positions_row1_option_mode_x01 = [0, 16.5, 33, 49.5, 66];
        $scope.row1_option_mode_x01 = ["DOUBLE IN", "DOUBLE OUT", "MASTER IN", "MASTER OUT", "BULL 25/50"];
        $scope.row1_option_mode_x01_text_h = [7, 7, 7, 7, 7];

        $scope.positions_row2_option_mode_x01 = [0, 16.5, 33, 49.5, 66];
        //$scope.row2_game_name = ["Cricket", "", "", ""];
        $scope.row2_option_mode_x01 = ["ROUND FREE", "ROUND 10", "ROUND 15", "ROUND 20", "ROUND 25"];
        $scope.row2_option_mode_x01_text_h = [7, 7, 7, 7, 7];

        $scope.positions_row3_option_mode_x01 = [0, 66];
        //$scope.row3_game_name = ["&", "Parcheesi", "Shangai", "", "", "", "", ""];
        $scope.row3_option_mode_x01 = ["AUTO HANDICAP", "EQUAL"];
        $scope.row3_option_mode_x01_text_h = [11, 11];

        $scope.positions_row4_option_mode_x01 = [0, 66];
        //$scope.row4_game_name = ["", "", "", "Scram", "Marathon", "Roulette", "Baseball"];
        $scope.row4_option_mode_x01 = ["MANUAL HANDICAP", "END"];
        $scope.row4_option_mode_x01_text_h = [11, 11];

    }

    function select_option_mode_cricket() {
        $scope.menuState = 103;
        $scope.positions_row1_option_mode_cricket = [0, 33, 66];
        $scope.row1_option_mode_cricket = ["CUT THROAT", "MASTER", "KILLER"];
        $scope.row1_option_mode_cricket_text_h = [7, 7, 7];


        $scope.positions_row3_option_mode_cricket = [0, 66];
        //$scope.row3_game_name = ["&", "Parcheesi", "Shangai", "", "", "", "", ""];
        $scope.row3_option_mode_cricket = ["AUTO HANDICAP", "EQUAL"];
        $scope.row3_option_mode_cricket_text_h = [11, 11];

        $scope.positions_row4_option_mode_cricket = [0, 66];
        //$scope.row4_game_name = ["", "", "", "Scram", "Marathon", "Roulette", "Baseball"];
        $scope.row4_option_mode_cricket = ["MANUAL HANDICAP", "END"];
        $scope.row4_option_mode_cricket_text_h = [11, 11];

    }

    function select_num_of_sets() {
        $scope.menuState = 104;
        $scope.positions_row1_num_of_sets = [6.5, 12, 17.5, 23, 28.5];
        $scope.row1_num_of_sets = ["1", "2", "3", "4", "5"];
        $scope.row1_num_of_sets_text_h = [4, 4, 4, 4, 4];

        $scope.positions_row2_num_of_sets = [6.5, 12, 17.5, 23, 28.5];
        //$scope.row2_game_name = ["Cricket", "", "", ""];
        $scope.row2_num_of_sets = ["6", "7", "8", "9", "10"];
        $scope.row2_num_of_sets_text_h = [4, 4, 4, 4, 4];

        $scope.positions_row3_num_of_sets = [6.5, 12, 17.5, 23, 28.5];
        //$scope.row3_game_name = ["&", "Parcheesi", "Shangai", "", "", "", "", ""];
        $scope.row3_num_of_sets = ["11", "12", "13", "14", "15"];
        $scope.row3_num_of_sets_text_h = [4, 4, 4, 4, 4];

        if ($scope.selectedGameIndex == 25) {
            $scope.positions_row1_num_of_legs = [12, 17.5, 23];
            $scope.row1_num_of_legs = ["1", "3", "5"];
            $scope.row1_num_of_legs_text_h = [7, 7, 7];

            $scope.positions_row2_num_of_legs = [];
            //$scope.row2_game_name = ["Cricket", "", "", ""];
            $scope.row2_num_of_legs = [];
            $scope.row2_num_of_legs_text_h = [];
        } else {
            $scope.positions_row1_num_of_legs = [6.5, 12, 17.5, 23, 28.5];
            $scope.row1_num_of_legs = ["1", "3", "5", "7", "9"];
            $scope.row1_num_of_legs_text_h = [4, 4, 4, 4, 4];

            $scope.positions_row2_num_of_legs = [6.5, 12, 17.5, 23, 28.5];
            //$scope.row2_game_name = ["Cricket", "", "", ""];
            $scope.row2_num_of_legs = ["11", "13", "15", "17", "19"];
            $scope.row2_num_of_legs_text_h = [4, 4, 4, 4, 4];
        }
    }

    function select_num_of_medley_games() {
        if ($scope.selectedNumOfLegIndex == 1) //samo jedna igra
        {
            $scope.positions_row1_medley_name = [35.5];
            //$scope.row4_game_name = ["", "", "", "Scram", "Marathon", "Roulette", "Baseball"];
            $scope.row1_medley_name = ["Solo Hi score"];
            $scope.row1_medley_name_text_h = [7];
        } else if ($scope.selectedNumOfLegIndex == 3) {
            $scope.positions_row1_medley_name = [17.5, 35.5, 53.5];
            //$scope.row4_game_name = ["", "", "", "Scram", "Marathon", "Roulette", "Baseball"];
            $scope.row1_medley_name = ["Pub Game", "Scram", "Marathon"];
            $scope.row1_medley_name_text_h = [7, 15, 15];
        } else if ($scope.selectedNumOfLegIndex == 5) {
            $scope.positions_row1_medley_name = [17.5, 26.5, 35.5, 44.5, 53.5];
            //$scope.row4_game_name = ["", "", "", "Scram", "Marathon", "Roulette", "Baseball"];
            $scope.row1_medley_name = ["Solo Hi score", "Pub Game", "Scram", "Marathon", "Roulette"];
            $scope.row1_medley_name_text_h = [7, 7, 15, 15, 15];
        }

    }

    function select_num_of_players() {
        $scope.menuState = 104;

        $scope.positions_row1_num_of_players = [];
        $scope.row1_num_of_players = [];
        $scope.row1_num_of_players_text_h = [];

        $scope.positions_row2_num_of_players = [];
        $scope.row2_num_of_players = [];
        $scope.row2_num_of_players_text_h = [];
        $scope.row2up_num_of_players = [];
        $scope.row2up_num_of_players_text_h = [];

        for (var i = 0; i < 8; i++) {

            $scope.positions_row1_num_of_players.push(i * 9);
            $scope.row1_num_of_players.push("# " + (i + 1));
            $scope.row1_num_of_players_text_h.push(14);

            $scope.positions_row2_num_of_players.push(i * 10.4);
            $scope.row2_num_of_players.push("Player " + (i + 1));
            $scope.row2_num_of_players_text_h.push(32);
            $scope.row2up_num_of_players.push(" ");
            $scope.row2up_num_of_players_text_h.push(-5);

        }

        $scope.positions_row3_num_of_players = [6.5, 12, 17.5, 23, 28.5];
        //$scope.row3_game_name = ["&", "Parcheesi", "Shangai", "", "", "", "", ""];
        $scope.row3_num_of_players = ["11", "12", "13", "14", "15"];
        $scope.row3_num_of_players_text_h = [7, 7, 7, 7, 7];
    }

    

    function prikaz_statistike(game_data, Cpu_data) {
        //***************STATISTIKA prikaz
        //lijeva strana
        $scope.statistics_list_1 = [];
        $scope.statistics_data_list_1 = [];
        $scope.statistics_list_1_background = [];
        $scope.statistics_data_list_1_data_background = [];
        $scope.statistics_list_1_left = [3.8, 26, 31, 49, 54, 72];
        $scope.statistics_list_top = 40;
        //desna strana
        $scope.statistics_positions_scores = [];
        $scope.statistics_positions_color = ['#c07f2f', '#c07f2f', '#c07f2f', '#c07f2f', '#c07f2f', '#c07f2f', '#c07f2f', '#c07f2f']; // Niz boja
        $scope.statistics_players_index_value = []; //nazivi stupaca
        $scope.statistics_players_rows_pos = []; //pozicije redaka
        $scope.statistics_players_rows_width_pos = []; //duljine redaka
        $scope.statistics_rows_index_name = []; //nazivi redaka
        $scope.statistics_row_count = 0;
        select_game_name(game_data, Cpu_data, 0);
        if (game_data.c_num_players > 0) {
            num_of_players_prev = game_data.c_num_players;
            data_c_option_prev = game_data.c_option;
            data_c_sub_game_prev = game_data.c_sub_game;
            data_c_game_prev = game_data.c_game;
            game_names_prev = $scope.game_names[0];
        }
        let num_of_players = game_data.c_num_players;
        let data_c_option = game_data.c_option;
        let data_c_sub_game = game_data.c_sub_game;
        let data_c_game = game_data.c_game;
        let game_names = $scope.game_names[0];
        if (num_of_players == 0) {
            num_of_players = num_of_players_prev;
            data_c_option = data_c_option_prev;
            data_c_sub_game = data_c_sub_game_prev;
            data_c_game = data_c_game_prev;
            game_names = game_names_prev;
        }

        //quattro iskljucen, parch i run & gun isto iskljuceni, samo x01
        if ((data_c_option & OPTION_QUATTRO) == 0 && (data_c_sub_game == 0) && data_c_game < 6) {
            $scope.menuState = 601;
            let statistics_rows_index_names = [
                'Score', 'Darts', 'Rounds', 'PPD', 'PPR',
                'Dart Out', 'Round Out', '3 in a bed', 'Hat Trick', 'Super Hat Trick',
                'Low Tons (100+)', 'High Tons (140+)', 'Ton 80', 'Max in a round', 'Bulls', 'Double Bulls'
            ];
            const S_STATISTICS_DATA_NUM_X01 = 16;
            for (let i = 0; i < num_of_players; i++) //trazim poziciju
            {
                for (let j = 0; j < num_of_players; j++) {
                    if (game_data.c_player_rank[j] == (i + 1)) {
                        if (game_data.c_team_num == 0) $scope.statistics_list_1.push(game_data.c_player_rank[j] + '. Player ' + String(j + 1));
                        else {
                            if (i < (game_data.c_team_num % 10)) $scope.statistics_list_1.push(game_data.c_player_rank[j] + '. Team ' + String(j + 1));
                        }
                    }
                }
                $scope.statistics_data_list_1.push("");
                $scope.statistics_list_1_background.push("");
                $scope.statistics_data_list_1_data_background.push("");
            }
            /*for (let i = 0; i < num_of_players; i++)
            {
            	if (game_data.c_team_num == 0) $scope.statistics_list_1.push(game_data.c_player_rank[i] + '. Player ' + String(i + 1));
            	else 
            	{
            		if (i < (game_data.c_team_num % 10)) $scope.statistics_list_1.push(game_data.c_player_rank[i] + '. Team ' + String(i + 1));
            	}
            	//$scope.statistics_list_1.push(String(i + 1) + ' Player ' + String(i + 1));
            	$scope.statistics_data_list_1.push("");
            	$scope.statistics_list_1_background.push("");
            	$scope.statistics_data_list_1_data_background.push("");
            }*/
            //izmjeni za team
            $scope.player_winner_show = '';
            for (var i = 0; i < num_of_players; i++) {
                if (game_data.c_player_rank[i] == 1) {
                    if (game_data.c_team_num) {
                        $scope.current_player_winner = i + 1;
                        $scope.statistics_list_1_background[0] = '#ff0000'; //ako je team igra
                    } else {
                        $scope.current_player_winner = i + 1;
                        $scope.statistics_list_1_background[0] = '#ff0000';
                    }
                }
            }
            $scope.statistics_row_count = S_STATISTICS_DATA_NUM_X01;
            for (var i = 0; i < S_STATISTICS_DATA_NUM_X01; i++) //prvih 16
            {
                $scope.statistics_players_rows_pos.push(i * 3.8);
                $scope.statistics_rows_index_name.push(statistics_rows_index_names[i]);
            }
            for (var i = 0; i < num_of_players; i++) //prvih 16
            {
                for (var j = 0; j < S_STATISTICS_DATA_NUM_X01; j++) //prvih 16
                {
                    $scope.statistics_rows_index_name.push(i * S_STATISTICS_DATA_NUM_X01 + j); //podaci statistike
                }
            }
            for (var i = 0; i < (num_of_players + 1); i++) //prvi stupac je naziv
            {
                if (i == 0) $scope.statistics_players_rows_width_pos.push(18.1); // width prvog elementa
                else $scope.statistics_players_rows_width_pos.push(4.5); //width ostalih elemenata
                if (i == 0) $scope.statistics_players_index_value.push('PLAYER');
                else $scope.statistics_players_index_value.push(i);
                if (i == 0) $scope.statistics_positions_scores.push(37.4); // pozicija left prvog elementa
                else $scope.statistics_positions_scores.push(52 + (i * 5.1)); //pozicija left ostalih elemenata
            }
            //napuni podatke statistike
            for (let i = 0; i < num_of_players; i++) {
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 0] = $scope.statisticsDataX01Array[i].s_score; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 1] = $scope.statisticsDataX01Array[i].s_darts; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 2] = $scope.statisticsDataX01Array[i].s_rounds; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 3] = $scope.statisticsDataX01Array[i].s_ppd; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 4] = $scope.statisticsDataX01Array[i].s_ppr; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 5] = $scope.statisticsDataX01Array[i].s_dart_out; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 6] = $scope.statisticsDataX01Array[i].s_round_out; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 7] = $scope.statisticsDataX01Array[i].s_3_in_a_bed; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 8] = $scope.statisticsDataX01Array[i].s_hat_trick; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 9] = $scope.statisticsDataX01Array[i].s_super_hat_trick; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 10] = $scope.statisticsDataX01Array[i].s_low_tons; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 11] = $scope.statisticsDataX01Array[i].s_high_tons; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 12] = $scope.statisticsDataX01Array[i].s_ton_80; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 13] = $scope.statisticsDataX01Array[i].s_max_ton; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 14] = $scope.statisticsDataX01Array[i].s_bulls; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_X01 + 15] = $scope.statisticsDataX01Array[i].s_double_bulls; //podaci statistike
            }

            $scope.statiscs_game_name = game_names;
        } else if (data_c_game == 6) {
            /*this.s_score = 0;   //ukupni score, samo bust ne računa 1 strelicu
			this.s_rank = 0;
			this.s_darts = 0;	//stvarno baceno strelica 
			this.s_score_real = 0;
			this.s_darts_calc = 0;	//baceno strelica, tipka next i bust uzme 3 strelice
			this.s_rounds = 0;
			this.s_mpr = 0;
			this.s_mpr_real = 0;
			this.s_dart_out = 0;
			this.s_round_out = 0;
			this.s_9_dart_out = 0;
			this.s_white_horse = 0;		//3 dif 
			this.s_9_mark = 0;		//3 dif
			this.s_8_mark = 0;		//3 dif
			this.s_7_mark = 0;		//3 dif
			this.s_6_mark = 0;		//3 dif
			this.s_5_mark = 0;		//3 dif
			this.s_4_mark = 0;		//3 dif
	
			this.s_cricket_hat = 0;	//3 dart bull, add to mark 3 - 6*/
            $scope.menuState = 601;
            let statistics_rows_index_names = [
                'Score', 'Darts', 'Rounds', 'MPR', 'Dart Out',
                'Round Out', '9 Dart Out', 'White Horse', '9 Mark', '8 Mark',
                '7 Mark', '6 Mark', '5 Mark', '4 Mark', 'Cricket Hat'
            ];
            const S_STATISTICS_DATA_NUM_CRICKET = 15;
            for (let i = 0; i < num_of_players; i++) //trazim poziciju
            {
                for (let j = 0; j < num_of_players; j++) {
                    if (game_data.c_player_rank[j] == (i + 1)) {
                        if (game_data.c_team_num == 0) $scope.statistics_list_1.push(game_data.c_player_rank[j] + '. Player ' + String(j + 1));
                        else {
                            if (i < (game_data.c_team_num % 10)) $scope.statistics_list_1.push(game_data.c_player_rank[j] + '. Team ' + String(j + 1));
                        }
                    }
                }
                $scope.statistics_data_list_1.push("");
                $scope.statistics_list_1_background.push("");
                $scope.statistics_data_list_1_data_background.push("");
            }
            /*for (let i = 0; i < num_of_players; i++)
            {
            	if (game_data.c_team_num == 0) $scope.statistics_list_1.push(game_data.c_player_rank[i] + '. Player ' + String(i + 1));
            	else 
            	{
            		if (i < (game_data.c_team_num % 10)) $scope.statistics_list_1.push(game_data.c_player_rank[i] + '. Team ' + String(i + 1));
            	}
            	//$scope.statistics_list_1.push(String(i + 1) + ' Player ' + String(i + 1));
            	$scope.statistics_data_list_1.push("");
            	$scope.statistics_list_1_background.push("");
            	$scope.statistics_data_list_1_data_background.push("");
            }*/
            //izmjeni za team
            $scope.player_winner_show = '';
            for (var i = 0; i < num_of_players; i++) {
                if (game_data.c_player_rank[i] == 1) {
                    if (game_data.c_team_num) {
                        $scope.current_player_winner = i + 1;
                        $scope.statistics_list_1_background[0] = '#ff0000'; //ako je team igra
                    } else {
                        $scope.current_player_winner = i + 1;
                        $scope.statistics_list_1_background[0] = '#ff0000';
                    }
                }
            }
            $scope.statistics_row_count = S_STATISTICS_DATA_NUM_CRICKET;
            for (var i = 0; i < S_STATISTICS_DATA_NUM_CRICKET; i++) //prvih 16
            {
                $scope.statistics_players_rows_pos.push(i * 3.8);
                $scope.statistics_rows_index_name.push(statistics_rows_index_names[i]);
            }
            for (var i = 0; i < num_of_players; i++) //prvih 16
            {
                for (var j = 0; j < S_STATISTICS_DATA_NUM_CRICKET; j++) //prvih 16
                {
                    $scope.statistics_rows_index_name.push(i * S_STATISTICS_DATA_NUM_CRICKET + j); //podaci statistike
                }
            }
            for (var i = 0; i < (num_of_players + 1); i++) //prvi stupac je naziv
            {
                if (i == 0) $scope.statistics_players_rows_width_pos.push(18.1); // width prvog elementa
                else $scope.statistics_players_rows_width_pos.push(4.5); //width ostalih elemenata
                if (i == 0) $scope.statistics_players_index_value.push('PLAYER');
                else $scope.statistics_players_index_value.push(i);
                if (i == 0) $scope.statistics_positions_scores.push(37.4); // pozicija left prvog elementa
                else $scope.statistics_positions_scores.push(52 + (i * 5.1)); //pozicija left ostalih elemenata
            }
            //napuni podatke statistike
            /*this.s_score = 0;   //ukupni score, samo bust ne računa 1 strelicu
			this.s_rank = 0;
			this.s_darts = 0;	//stvarno baceno strelica 
			this.s_score_real = 0;
			this.s_darts_calc = 0;	//baceno strelica, tipka next i bust uzme 3 strelice
			this.s_rounds = 0;
			this.s_mpr = 0;
			this.s_mpr_real = 0;
			this.s_dart_out = 0;
			this.s_round_out = 0;
			this.s_9_dart_out = 0;
			this.s_white_horse = 0;		//3 dif 
			this.s_9_mark = 0;		//3 dif
			this.s_8_mark = 0;		//3 dif
			this.s_7_mark = 0;		//3 dif
			this.s_6_mark = 0;		//3 dif
			this.s_5_mark = 0;		//3 dif
			this.s_4_mark = 0;		//3 dif
	
			this.s_cricket_hat = 0;	//3 dart bull, add to mark 3 - 6*/
            for (let i = 0; i < num_of_players; i++) {
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 0] = $scope.statisticsDataCricketArray[i].s_score; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 1] = $scope.statisticsDataCricketArray[i].s_darts; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 2] = $scope.statisticsDataCricketArray[i].s_rounds; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 3] = $scope.statisticsDataCricketArray[i].s_mpr; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 5] = $scope.statisticsDataCricketArray[i].s_dart_out; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 6] = $scope.statisticsDataCricketArray[i].s_round_out; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 7] = $scope.statisticsDataCricketArray[i].s_9_dart_out; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 8] = $scope.statisticsDataCricketArray[i].s_white_horse; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 9] = $scope.statisticsDataCricketArray[i].s_9_mark; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 10] = $scope.statisticsDataCricketArray[i].s_8_mark; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 11] = $scope.statisticsDataCricketArray[i].s_7_mark; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 12] = $scope.statisticsDataCricketArray[i].s_6_mark; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 13] = $scope.statisticsDataCricketArray[i].s_5_mark; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 14] = $scope.statisticsDataCricketArray[i].s_4_mark; //podaci statistike
                $scope.statistics_rows_index_name[(i + 1) * S_STATISTICS_DATA_NUM_CRICKET + 15] = $scope.statisticsDataCricketArray[i].s_cricket_hat; //podaci statistike
            }

            $scope.statiscs_game_name = game_names;
        } else {
            $scope.menuState = 601;
            let statistics_rows_index_names = [
                'Score', 'Rounds'
            ];
            for (let i = 0; i < num_of_players; i++) //trazim poziciju
            {
                for (let j = 0; j < num_of_players; j++) {
                    if (game_data.c_player_rank[j] == (i + 1)) {
                        if (game_data.c_team_num == 0) $scope.statistics_list_1.push(game_data.c_player_rank[j] + '. Player ' + String(j + 1));
                        else {
                            if (i < (game_data.c_team_num % 10)) $scope.statistics_list_1.push(game_data.c_player_rank[j] + '. Team ' + String(j + 1));
                        }
                    }
                }
                $scope.statistics_data_list_1.push("");
                $scope.statistics_list_1_background.push("");
                $scope.statistics_data_list_1_data_background.push("");
            }
            /*for (let i = 0; i < num_of_players; i++)
            {
            	if (game_data.c_team_num == 0) $scope.statistics_list_1.push(game_data.c_player_rank[i] + '. Player ' + String(i + 1));
            	else 
            	{
            		if (i < (game_data.c_team_num % 10)) $scope.statistics_list_1.push(game_data.c_player_rank[i] + '. Team ' + String(i + 1));
            	}
            	//$scope.statistics_list_1.push(String(i + 1) + ' Player ' + String(i + 1));
            	$scope.statistics_data_list_1.push("");
            	$scope.statistics_list_1_background.push("");
            	$scope.statistics_data_list_1_data_background.push("");
            }*/

            //izmjeni za team
            $scope.player_winner_show = '';
            for (var i = 0; i < num_of_players; i++) {
                if (game_data.c_player_rank[i] == 1) {
                    if (game_data.c_team_num) {
                        $scope.current_player_winner = i + 1;
                        $scope.statistics_list_1_background[0] = '#ff0000'; //ako je team igra
                    } else {
                        $scope.current_player_winner = i + 1;
                        $scope.statistics_list_1_background[0] = '#ff0000';
                    }
                }
            }
            $scope.statistics_row_count = 2;
            for (var i = 0; i < 2; i++) //prvih 2
            {
                $scope.statistics_players_rows_pos.push(i * 3.8);
                $scope.statistics_rows_index_name.push(statistics_rows_index_names[i]);
            }

            for (var i = 0; i < num_of_players; i++) //prvih 2
            {
                for (var j = 0; j < 2; j++) //prvih 2
                {
                    $scope.statistics_rows_index_name.push(i * 2 + j); //podaci statistike
                }

            }
            for (var i = 0; i < (num_of_players + 1); i++) //prvi stupac je naziv
            {
                if (i == 0) $scope.statistics_players_rows_width_pos.push(18.1); // width prvog elementa
                else $scope.statistics_players_rows_width_pos.push(4.5); //width ostalih elemenata
                if (i == 0) $scope.statistics_players_index_value.push('PLAYER');
                else $scope.statistics_players_index_value.push(i);
                if (i == 0) $scope.statistics_positions_scores.push(37.4); // pozicija left prvog elementa
                else $scope.statistics_positions_scores.push(52 + (i * 5.1)); //pozicija left ostalih elemenata
            }
            //napuni podatke statistike
            for (let i = 0; i < num_of_players; i++) {
               
                $scope.statistics_rows_index_name[(i + 1) * 2 + 0] = game_data.c_player_value[i]; //podaci igre
                $scope.statistics_rows_index_name[(i + 1) * 2 + 1] = game_data.c_round; //podaci igre
            }
            $scope.statiscs_game_name = game_names;
        }
        console.log('current_player_winner', $scope.current_player_winner);

    }

    function run_statistics_data(game_data, Cpu_data) {

        $scope.game_with_stat_data = 0;
        if ((game_data.c_option & OPTION_QUATTRO) == 0 && (game_data.c_sub_game == 0) && game_data.c_game < 6) {
            let return_dart = 0;
            let flag_bust = 0;
            // Pokreni timer
            //$scope.startTimer_2s();
            console.log('******** print statistika *********');
            if (game_data.c_baceno_strelica > 0) {
                if (game_data.c_baceno_strelica == 1) game_data_c_baceno_strelica_prev = 0;
                if (game_data.c_baceno_strelica < game_data_c_baceno_strelica_prev) {
                    $scope.statisticsDataX01Array = $scope.statisticsDataX01Array_prev.map(obj => Object.assign(new StatisticsDataX01(), obj));
                    console.log('******** reload backup n-1 statistics data *********');
                    return_dart = 1;
                }
                game_data_c_baceno_strelica_prev = game_data.c_baceno_strelica;
            } else {
                game_data_c_baceno_strelica_prev = 0;
            }
            if (return_dart == 0) {
                let lokacija_podatka_igraca = game_data.c_player_throw - 1;
                let new_dart_ready = 0;
                let last_dart_backup = 0;
                let igrac_postigao_kraj = 0;
                $scope.current_player_ppd = (0).toFixed(2);
                if ($scope.player_ppd_total_darts[lokacija_podatka_igraca] > 0) //da ne dijeli sa 0
                    $scope.current_player_ppd = ($scope.player_ppd_total_score[lokacija_podatka_igraca] / $scope.player_ppd_total_darts[lokacija_podatka_igraca]).toFixed(2);
                let start_score = [180, 301, 501, 701, 901, 1001];
                if (game_data.c_game < 6) {
                    $scope.game_with_stat_data = 1;
                } else if (game_data.c_game == 6) {
                    if (((game_data.c_sub_game > 20) && (game_data.c_sub_game < 30)) || ((game_data.c_sub_game > 50) && (game_data.c_sub_game < 60))) //normal i cut throat ima stat
                    {
                        $scope.game_with_stat_data = 1;
                    } else
                        $scope.game_with_stat_data = 0;
                } else
                    $scope.game_with_stat_data = 0;
                if ((prev_dart != game_data.c_dart) && (game_data.c_dart > 0)) {
                    prev_dart = game_data.c_dart;
                    new_dart_ready = 1;
                }
                if ((game_data.c_dart == 0) && (game_data.c_hits[2] != 255)) //zadnja strelica inace je tipka next
                {
                    prev_dart = game_data.c_dart;
                    new_dart_ready = 1;
                }
                if ((game_data.c_dart == 0) && (game_data.c_player_value[lokacija_podatka_igraca] == 0)) //kraj igre
                {
                    prev_dart = game_data.c_dart;
                    new_dart_ready = 1;
                }
                if (game_data.c_show_msg == 3) //BUST
                {
                    flag_bust = 1;
                    $scope.player_ppd_total_darts[lokacija_podatka_igraca] += 1; //dodaj strelicu
                    if ($scope.player_ppd_total_darts[lokacija_podatka_igraca] > 0) //da ne dijeli sa 0
                        $scope.current_player_ppd = ($scope.player_ppd_total_score[lokacija_podatka_igraca] / $scope.player_ppd_total_darts[lokacija_podatka_igraca]).toFixed(2);
                }
                if (game_data.c_show_msg == 15) //FREEZE
                {
                    flag_bust = 1;
                    igrac_postigao_kraj = 1;
                }
                if ((game_data.c_game < 6)) //samo x01 igre
                { //selekcija strelica koje je bacena
                    if (game_data.c_show_msg != 3) //ako nije bust
                    {
                        if (new_dart_ready) {
                            if (game_data.c_player_value[lokacija_podatka_igraca] == 0) igrac_postigao_kraj = 1;
                            $scope.statisticsDataX01Array_prev = $scope.statisticsDataX01Array.map(obj => Object.assign(new StatisticsDataX01(), obj));
                            last_dart_backup = 1;
                            let koja_je_strelica_zadnja = -1;
                            if (game_data.c_hits[0] != 255) koja_je_strelica_zadnja = 0;
                            if (game_data.c_hits[1] != 255) koja_je_strelica_zadnja = 1;
                            if (game_data.c_hits[2] != 255) koja_je_strelica_zadnja = 2;
                            if (koja_je_strelica_zadnja == -1) {
                                player_c_score_prev[0] = 0;
                                player_c_score_prev[1] = 0;
                                player_c_score_prev[2] = 0;
                            } else if (koja_je_strelica_zadnja == 0) {
                                player_c_score_prev[0] = game_data.c_score;
                                $scope.player_ppd_total_darts[lokacija_podatka_igraca] += 1; //dodaj strelicu
                            } else if (koja_je_strelica_zadnja == 1) {
                                player_c_score_prev[1] = game_data.c_score - player_c_score_prev[0];
                                $scope.player_ppd_total_darts[lokacija_podatka_igraca] += 1; //dodaj strelicu
                            } else if (koja_je_strelica_zadnja == 2) {
                                player_c_score_prev[2] = game_data.c_score - player_c_score_prev[0] - player_c_score_prev[1];
                                $scope.player_ppd_total_darts[lokacija_podatka_igraca] += 1; //dodaj strelicu
                            }

                            if (game_data.c_show_msg == 3) //BUST
                            {

                            } else {
                                if (koja_je_strelica_zadnja == 0) {
                                    $scope.player_ppd_total_score[lokacija_podatka_igraca] += player_c_score_prev[0]; //dodaj score 1 strelice
                                } else if (koja_je_strelica_zadnja == 1) {
                                    $scope.player_ppd_total_score[lokacija_podatka_igraca] += player_c_score_prev[1]; //dodaj score 2 strelice
                                } else if (koja_je_strelica_zadnja == 2) {
                                    $scope.player_ppd_total_score[lokacija_podatka_igraca] += player_c_score_prev[2]; //dodaj score 3 strelice
                                }
                            }
                            if ($scope.player_ppd_total_darts[lokacija_podatka_igraca] > 0) //da ne dijeli sa 0
                                $scope.current_player_ppd = ($scope.player_ppd_total_score[lokacija_podatka_igraca] / $scope.player_ppd_total_darts[lokacija_podatka_igraca]).toFixed(2);

                            console.log('game_data.c_dart: ', game_data.c_dart, 'player_c_score_prev: ', player_c_score_prev);
                        }
                    }
                    if (game_data.c_dart == 0 || igrac_postigao_kraj) //spremi za prebacivanje, ima 0 strelica
                    { //odredi sta ide manje za BUST
                        if (last_dart_backup == 0) {
                            $scope.statisticsDataX01Array_prev = $scope.statisticsDataX01Array.map(obj => Object.assign(new StatisticsDataX01(), obj));
                            last_dart_backup = 1;
                        }
                        $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_score = $scope.player_ppd_total_score[lokacija_podatka_igraca];
                        $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_darts = $scope.player_ppd_total_darts[lokacija_podatka_igraca];
                        $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_score_real = start_score[game_data.c_game] - game_data.c_player_value[lokacija_podatka_igraca];
                        $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_score = $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_score_real;
                        if (game_data.c_dart == 0) $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_darts_calc += 3;
                        else $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_darts_calc += (3 - game_data.c_dart);
                        if ($scope.statisticsDataX01Array[lokacija_podatka_igraca].s_darts > 0) {
                            $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_ppd =
                                parseFloat(($scope.statisticsDataX01Array[lokacija_podatka_igraca].s_score /
                                    $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_darts).toFixed(2));
                        }

                        if ($scope.statisticsDataX01Array[lokacija_podatka_igraca].s_darts_calc > 0) {
                            $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_ppd_real =
                                parseFloat(($scope.statisticsDataX01Array[lokacija_podatka_igraca].s_score_real /
                                    $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_darts_calc).toFixed(2));
                        }

                        if (game_data.c_round > 0) {
                            $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_ppr =
                                parseFloat(($scope.statisticsDataX01Array[lokacija_podatka_igraca].s_score_real /
                                    game_data.c_round).toFixed(2));
                        }
                        if (game_data.c_player_value[lokacija_podatka_igraca] == 0) $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_dart_out = $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_darts_calc;
                        if (game_data.c_player_value[lokacija_podatka_igraca] == 0) $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_round_out = game_data.c_round;
                        $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_rounds = game_data.c_round;
                        if (game_data.c_show_msg != 3 && !flag_bust) //BUST
                        {
                            let flag_hat_trick = 0;
                            if ((game_data.c_hits[0] == 125)) {
                                if ((game_data.c_hits[1] == 125)) {
                                    if ((game_data.c_hits[2] == 125)) {
                                        flag_hat_trick = 1;
                                        $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_super_hat_trick += 1;
                                        $scope.ponudi_izlaz = 'SUPER HAT TRICK';
                                    }
                                }
                            }
                            if (flag_hat_trick == 0) {
                                if ((game_data.c_hits[0] == 25) || (game_data.c_hits[0] == 125)) {
                                    if ((game_data.c_hits[1] == 25) || (game_data.c_hits[1] == 125)) {
                                        if ((game_data.c_hits[2] == 25) || (game_data.c_hits[2] == 125)) {
                                            flag_hat_trick = 1;
                                            $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_hat_trick += 1;
                                            $scope.ponudi_izlaz = 'HAT TRICK';
                                        }
                                    }
                                }
                            }
                            //if (flag_hat_trick == 0)
                            //{
                            if (game_data.c_score > $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_max_ton) {
                                $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_max_ton = game_data.c_score;
                            }

                            if (game_data.c_score == 180) {
                                $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_ton_80 += 1;
                                $scope.ponudi_izlaz = 'TON 180';
                            } else if (game_data.c_score > 149) {
                                $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_high_tons += 1;
                                $scope.ponudi_izlaz = 'HIGH TON';
                            } else if (game_data.c_score > 99) {
                                $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_low_tons += 1;
                                $scope.ponudi_izlaz = 'LOW TON';
                            }

                            //}
                            if (game_data.c_hits[0] != 255) {
                                if (game_data.c_hits[0] == game_data.c_hits[1]) {
                                    if (game_data.c_hits[1] == game_data.c_hits[2]) {
                                        $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_3_in_a_bed += 1;
                                    }
                                }
                            }
                            for (let i = 0; i < 3; i++) //provjeri sve tri strelice
                            {
                                if (game_data.c_hits[i] == 25) //broj pogodaka u bull 25 
                                {
                                    $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_bulls += 1;
                                } else if (game_data.c_hits[i] == 125) //ili bull 50 
                                {
                                    $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_bulls += 1;
                                    $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_double_bulls += 1;
                                }
                            }


                            /*this.s_score = 0;   //ukupni score, samo bust ne računa 1 strelicu
                            this.s_darts = 0;	//stvarno baceno strelica 
                            this.s_score_real = 0;
                            this.s_darts_calc = 0;	//baceno strelica, tipka next i bust uzme 3 strelice
                            this.s_rounds = 0;
                            this.s_ppd = 0;
                            this.s_ppd_real = 0;
                            this.s_ppr = 0;
                            this.s_dart_out = 0;
                            this.s_round_out = 0;

                            this.s_3_in_a_bed = 0;

                            this.s_hat_trick = 0;
                            this.s_super_hat_trick = 0;

                            this.s_low_tons = 0;
                            this.s_high_tons = 0;
                            this.s_ton_80 = 0;
                            this.s_max_ton = 0;
							
                            this.s_bulls = 0;
                            this.s_double_bulls = 0;*/

                            //u slucaju kraja stavi tocan broj strelica
                        }
                        console.log($scope.statisticsDataX01Array); // Prikazuje promenjene vrednosti
                    }

                }

                console.log('run_statistics_data', '$scope.player_ppd_total_darts', $scope.player_ppd_total_darts, '$scope.player_ppd_total_score', $scope.player_ppd_total_score);
                /*if (game_data.c_dart != $scope.num_c_dart_prev[0] && game_data.c_dart < 3)
                {
                	$scope.num_c_dart_prev[0] = game_data.c_dart;
                	new_dart_event = 1;
                	console.log('$scope.num_c_dart_prev[0] , game_data.c_dart, game_data.c_player_throw', $scope.num_c_dart_prev[0], game_data.c_dart, game_data.c_player_throw);
                }
                if (new_dart_event)
                {
                	new_dart_event = 0;
                	if (game_data.c_game < 6)  //samo x01 igre
                	{
                		let i = 2 - game_data.c_dart;
                		let value_hit = 0;
                		if (game_data.c_hits[i] > 100 && game_data.c_hits[i] <= 150)  //ovo je x2 value_hit
                			value_hit = 2*(game_data.c_hits[i] - 100);
                		else if (game_data.c_hits[i] > 150 && game_data.c_hits[i] < 200)  //ovo je x4
                			value_hit = 4*(game_data.c_hits[i] - 150);
                		else if (game_data.c_hits[i] > 200 && game_data.c_hits[i] <= 250)  //ovo je x3
                			value_hit = 3*(game_data.c_hits[i] - 200);
                		else if (game_data.c_hits[i] == 255)  //ovo je prazna ne bacena, 0 je bacena
                			value_hit = 0;
                		else
                			value_hit = game_data.c_hits[i];
                		$scope.player_ppd_total_darts[lokacija_podatka_igraca] += 1;   //povecaj za 1 strelicu
                		$scope.player_ppd_total_score[lokacija_podatka_igraca] += value_hit; 	//dodaj za vrijednost strerlice
                		console.log('player_ppd_total_darts , player_ppd_total_score, value_hit, i, game_data.c_hits', $scope.player_ppd_total_darts[lokacija_podatka_igraca], $scope.player_ppd_total_score[lokacija_podatka_igraca], value_hit, i, game_data.c_hits);
				
                	}
                }
                if ($scope.player_ppd_total_darts[lokacija_podatka_igraca] > 0)
                {
                	//$scope.current_player_ppd = ($scope.player_ppd_total_score[lokacija_podatka_igraca] / $scope.player_ppd_total_darts[lokacija_podatka_igraca]);
                	$scope.current_player_ppd = ($scope.player_ppd_total_score[lokacija_podatka_igraca] / $scope.player_ppd_total_darts[lokacija_podatka_igraca]).toFixed(2);

                }*/
            }
        } else if (game_data.c_game == 6) {
            let return_dart = 0;
            // Pokreni timer
            //$scope.startTimer_2s();
            console.log('******** print statistika cricket*********');
            if (game_data.c_baceno_strelica > 0) {
                if (game_data.c_baceno_strelica == 1) game_data_c_baceno_strelica_prev = 0;
                if (game_data.c_baceno_strelica < game_data_c_baceno_strelica_prev) {
                    $scope.statisticsDataCricketArray = $scope.statisticsDataCricketArray_prev.map(obj => Object.assign(new StatisticsDataCricket(), obj));
                    console.log('******** reload backup n-1 statistics data cricket*********');
                    return_dart = 1;
                }
                game_data_c_baceno_strelica_prev = game_data.c_baceno_strelica;
            } else {
                game_data_c_baceno_strelica_prev = 0;
            }
            if (return_dart == 0) {
                let lokacija_podatka_igraca = game_data.c_player_throw - 1;
                let new_dart_ready = 0;
                let last_dart_backup = 0;
                let igrac_postigao_kraj = 0;
                $scope.current_player_ppd = (0).toFixed(2);
                /*if ($scope.player_ppd_total_darts[lokacija_podatka_igraca] > 0)		//da ne dijeli sa 0
                	$scope.current_player_ppd = ($scope.player_ppd_total_score[lokacija_podatka_igraca] / $scope.player_ppd_total_darts[lokacija_podatka_igraca]).toFixed(2);
                let start_score = [180, 301, 501, 701, 901, 1001];
                if (game_data.c_game < 6)
                {
                	$scope.game_with_stat_data = 1;
                }*/
                if (game_data.c_game == 6) {
                    if (((game_data.c_sub_game > 20) && (game_data.c_sub_game < 30)) || ((game_data.c_sub_game > 50) && (game_data.c_sub_game < 60))) //normal i cut throat ima stat
                    {
                        $scope.game_with_stat_data = 1;
                    } else
                        $scope.game_with_stat_data = 0;
                } else
                    $scope.game_with_stat_data = 0;
                /*if ((prev_dart != game_data.c_dart) && (game_data.c_dart > 0)) 
                {
                	prev_dart = game_data.c_dart;
                	new_dart_ready = 1;
                }
                if ((game_data.c_dart == 0) && (game_data.c_hits[2] != 255))   //zadnja strelica inace je tipka next
                {
                	prev_dart = game_data.c_dart;
                	new_dart_ready = 1;
                }
				
				
                if ((game_data.c_game == 6))  //samo cricket igre
                {	//selekcija strelica koje je bacena
                	if (game_data.c_show_msg != 3)  //ako nije bust
                	{
                		if (new_dart_ready)
                		{
                			if (game_data.c_player_value[lokacija_podatka_igraca] == 0) igrac_postigao_kraj = 1;
                			$scope.statisticsDataCricketArray_prev = $scope.statisticsDataCricketArray.map(obj => Object.assign(new StatisticsDataCricket(), obj));
                			last_dart_backup = 1;
                			let koja_je_strelica_zadnja = -1;
                			if (game_data.c_hits[0] != 255) koja_je_strelica_zadnja = 0;
                			if (game_data.c_hits[1] != 255) koja_je_strelica_zadnja = 1;
                			if (game_data.c_hits[2] != 255) koja_je_strelica_zadnja = 2;
                			if (koja_je_strelica_zadnja == -1)
                			{
                				player_c_score_prev[0] = 0;
                				player_c_score_prev[1] = 0;
                				player_c_score_prev[2] = 0;
                			} 
                			else if (koja_je_strelica_zadnja == 0)
                			{
                				player_c_score_prev[0] = game_data.c_score;
                				$scope.player_ppd_total_darts[lokacija_podatka_igraca] += 1;		//dodaj strelicu
                			}
                			else if (koja_je_strelica_zadnja == 1)
                			{
                				player_c_score_prev[1] = game_data.c_score - player_c_score_prev[0];
                				$scope.player_ppd_total_darts[lokacija_podatka_igraca] += 1;		//dodaj strelicu
                			}
                			else if (koja_je_strelica_zadnja == 2)
                			{
                				player_c_score_prev[2] = game_data.c_score - player_c_score_prev[0] - player_c_score_prev[1];
                				$scope.player_ppd_total_darts[lokacija_podatka_igraca] += 1;		//dodaj strelicu
                			}

                			
                				if (koja_je_strelica_zadnja == 0)
                				{
                					$scope.player_ppd_total_score[lokacija_podatka_igraca] += player_c_score_prev[0];   //dodaj score 1 strelice
                				}
                				else if (koja_je_strelica_zadnja == 1)
                				{
                					$scope.player_ppd_total_score[lokacija_podatka_igraca] += player_c_score_prev[1];   //dodaj score 2 strelice
                				}
                				else if (koja_je_strelica_zadnja == 2)
                				{
                					$scope.player_ppd_total_score[lokacija_podatka_igraca] += player_c_score_prev[2];   //dodaj score 3 strelice
                				}
                			
                			if ($scope.player_ppd_total_darts[lokacija_podatka_igraca] > 0)		//da ne dijeli sa 0
                				$scope.current_player_ppd = ($scope.player_ppd_total_score[lokacija_podatka_igraca] / $scope.player_ppd_total_darts[lokacija_podatka_igraca]).toFixed(2);
                		
                			console.log('game_data.c_dart: ', game_data.c_dart, 'player_c_score_prev: ', player_c_score_prev);		
                		}
                	}
                	if (game_data.c_dart == 0 || igrac_postigao_kraj)  //spremi za prebacivanje, ima 0 strelica
                	{		//odredi sta ide manje za BUST
                		if (last_dart_backup == 0) 
                		{
                			$scope.statisticsDataCricketArray_prev = $scope.statisticsDataCricketArray.map(obj => Object.assign(new StatisticsDataCricket(), obj));
                			last_dart_backup = 1;
                		}
                		$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_score = $scope.player_ppd_total_score[lokacija_podatka_igraca];
                		$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_darts = $scope.player_ppd_total_darts[lokacija_podatka_igraca];
                		$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_score_real = start_score[game_data.c_game] - game_data.c_player_value[lokacija_podatka_igraca];
                		$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_score = $scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_score_real;
                		if (game_data.c_dart == 0) $scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_darts_calc += 3;
                		else $scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_darts_calc += (3 - game_data.c_dart);
                		if ($scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_darts > 0) {
                			$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_ppd = 
                				parseFloat(($scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_score / 
                							$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_darts).toFixed(2));
                		}
                		
                		if ($scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_darts_calc > 0) {
                			$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_ppd_real = 
                				parseFloat(($scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_score_real / 
                							$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_darts_calc).toFixed(2));
                		}
                		
                		if (game_data.c_round > 0) {
                			$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_ppr = 
                				parseFloat(($scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_score_real / 
                							game_data.c_round).toFixed(2));
                		}
                		if (game_data.c_player_value[lokacija_podatka_igraca] == 0)$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_dart_out = $scope.statisticsDataX01Array[lokacija_podatka_igraca].s_darts_calc;	
                		if (game_data.c_player_value[lokacija_podatka_igraca] == 0) $scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_round_out = game_data.c_round;
                		$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_rounds = game_data.c_round;
                		if (game_data.c_show_msg != 3)  //BUST
                		{
                			let flag_hat_trick = 0;
                			if ((game_data.c_hits[0] == 125))
                			{
                				if ((game_data.c_hits[1] == 125))
                				{
                					if ((game_data.c_hits[2] == 125))
                					{
                						flag_hat_trick = 1;
                						$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_super_hat_trick += 1;
                						$scope.ponudi_izlaz = 'SUPER HAT TRICK';
                					}
                				}
                			}
                			if (flag_hat_trick == 0)
                			{
                				if ((game_data.c_hits[0] == 25) || (game_data.c_hits[0] == 125))
                				{
                					if ((game_data.c_hits[1] == 25) || (game_data.c_hits[1] == 125))
                					{
                						if ((game_data.c_hits[2] == 25) || (game_data.c_hits[2] == 125))
                						{
                							flag_hat_trick = 1;
                							$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_hat_trick += 1;
                							$scope.ponudi_izlaz = 'HAT TRICK';
                						}
                					}
                				}
                			}
                			//if (flag_hat_trick == 0)
                			//{
                				if (game_data.c_score > $scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_max_ton )
                				{
                					$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_max_ton = game_data.c_score;
                				}
                					
                				if (game_data.c_score == 180)
                				{
                					$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_ton_80 += 1;
                					$scope.ponudi_izlaz = 'TON 180';
                				}
                				else if (game_data.c_score > 149)
                				{
                					$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_high_tons += 1;
                					$scope.ponudi_izlaz = 'HIGH TON';
                				}
                				else if (game_data.c_score > 99)
                				{
                					$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_low_tons += 1;
                					$scope.ponudi_izlaz = 'LOW TON';
                				}
                				
                			//}
                			if (game_data.c_hits[0] != 255)
                			{
                				if (game_data.c_hits[0] == game_data.c_hits[1])
                				{
                					if (game_data.c_hits[1] == game_data.c_hits[2])
                					{
                						$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_3_in_a_bed += 1;
                					}
                				}
                			}
                			for (let i = 0; i < 3; i++)		//provjeri sve tri strelice
                			{
                				if (game_data.c_hits[i] == 25) //broj pogodaka u bull 25 
                				{
                					$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_bulls += 1;
                				}
                				else if (game_data.c_hits[i] == 125)  //ili bull 50 
                				{
                					$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_bulls += 1;
                					$scope.statisticsDataCricketArray[lokacija_podatka_igraca].s_double_bulls += 1;
                				}
                			}
                				//u slucaju kraja stavi tocan broj strelica
                		}
                		console.log($scope.statisticsDataCricketArray); // Prikazuje promenjene vrednosti
                	} 
                	
                }
				
                console.log('run_statistics_data','$scope.player_ppd_total_darts',$scope.player_ppd_total_darts,'$scope.player_ppd_total_score',$scope.player_ppd_total_score);
                */
                /*			
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 0] = $scope.statisticsDataCricketArray[i].s_score;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 1] = $scope.statisticsDataCricketArray[i].s_darts;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 2] = $scope.statisticsDataCricketArray[i].s_rounds;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 3] = $scope.statisticsDataCricketArray[i].s_mpr;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 5] = $scope.statisticsDataCricketArray[i].s_dart_out;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 6] = $scope.statisticsDataCricketArray[i].s_round_out;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 7] = $scope.statisticsDataCricketArray[i].s_9_dart_out;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 8] = $scope.statisticsDataCricketArray[i].s_white_horse;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 9] = $scope.statisticsDataCricketArray[i].s_9_mark;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 10] = $scope.statisticsDataCricketArray[i].s_8_mark;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 11] = $scope.statisticsDataCricketArray[i].s_7_mark;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 12] = $scope.statisticsDataCricketArray[i].s_6_mark;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 13] = $scope.statisticsDataCricketArray[i].s_5_mark;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 14] = $scope.statisticsDataCricketArray[i].s_4_mark;   //podaci statistike
			$scope.statistics_rows_index_name[(i+ 1) * S_STATISTICS_DATA_NUM_CRICKET + 15] = $scope.statisticsDataCricketArray[i].s_cricket_hat;   //podaci statistike
			*/
            }
        }
    }

    function system_errors_data(error_num_, data_error_)
    {
        let buttons_names_ = [  "TEAM", "MASTER", "CRICKET", "PURCHASE", "180 / 301", 
                                "QUATTRO", "SCRAM", "HI SCORE", "SOLO 301", "SUPER 100",
                                "EQUAL", "TEST", "ROULETTE", "PLAYERS", "DOUBLE OUT", 
                                "DOUBLE IN"];
        let buttons_name_mask_ = [  0x8000, 0x4000, 0x2000, 0x1000, 0x0800,
                                    0x0400, 0x0200, 0x0100, 0x0080, 0x0040,
                                    0x0020, 0x0010, 0x0008, 0x0004, 0x0002, 0x0001];
        let string_data_error_ = ''; 
        if (error_num_ < 50 && last_system_errors > 50) 
        {
            data_error_ = last_data_error_;
        }
        if (error_num_> 50) $scope.error_active_inactive = 1;
        else $scope.error_active_inactive = 0;
        if (error_num_ > 50 || last_system_errors > 50)
        {
            if (error_num_ == MSG_ERROR_TARGET_STUCKED || last_system_errors == MSG_ERROR_TARGET_STUCKED)
            {
                if (data_error_ > 200) string_data_error_ = '3x ' + String(data_error_ - 200);
                else if (data_error_ > 150) string_data_error_ = '4x ' + String(data_error_ - 150);
                else if (data_error_ > 100) string_data_error_ = '2x ' + String(data_error_ - 100);
                else string_data_error_ = String(data_error_);

                $scope.system_errors = "MSG_ERROR_TARGET_STUCKED " + String(string_data_error_);
                last_data_error_ = data_error_;
            }
            if (error_num_ == MSG_ERROR_KEY_STUCKED || last_system_errors == MSG_ERROR_KEY_STUCKED)
            {
                let pressed_buttons = buttons_name_mask_
                    .map((mask, i) => (data_error_ & mask) ? buttons_names_[i] : null)
                    .filter(Boolean);

                if (pressed_buttons.length > 0)
                    string_data_error_ = pressed_buttons.join(", ");

                $scope.system_errors = "MSG_ERROR_KEY_STUCKED: " + string_data_error_ + " (id: " + data_error_ + ")";  
                if (data_error_ > 0)
                    last_data_error_ = data_error_;
            }
            if (error_num_ == MSG_ERROR_TUP_ALWAYS_ON)
            {
                $scope.system_errors = "MSG_ERROR_TUP_ALWAYS_ON";  
            }
            if (error_num_ == MSG_ERROR_TARGET_CPU_CSUM)
            {
                $scope.system_errors = "MSG_ERROR_TARGET_CPU_CSUM";  
            }
            if (error_num_ == MSG_ERROR_TARGET_CPU_DATA)
            {
                $scope.system_errors = "MSG_ERROR_TARGET_CPU_DATA";  
            }
            if (error_num_ == MSG_ERROR_CCTALK_CSUM)
            {
                $scope.system_errors = "MSG_ERROR_CCTALK_CSUM";  
            }
            if (error_num_ == MSG_ERROR_CLOCK_TIME)
            {
                $scope.system_errors = "MSG_ERROR_CLOCK_TIME";  
            }
            if (error_num_ > 50)    //da ostavi error
                last_system_errors = error_num_;
        }
        else
        {
            $scope.system_errors = "READY";
        }
    }

    function ponudi_izlaz(game_data, Cpu_data) {
        let lokacija_podatka_igraca = game_data.c_player_throw - 1;
        let tempi = 0;
        let flag_ima_uvjet_od_teama = 1;
        let team_num = game_data.c_team_num % 10;
        let team_num_players = Math.floor(game_data.c_team_num / 10);
        let temp_sums = [0, 0, 0, 0];
        $scope.ponudi_izlaz = '';


        if ((game_data.c_jumpers & JUMPER_TURNIR) == 0) {
            if (game_data.c_game < 6) //ako je igra x01
            {
                /*if (team_num_players)  //ako je team igra
                {
                	if (team_num_players == 2)  //pronadi suigraca
                	{
                		$scope.players_teams_sums[0] = $scope.players_value[0] + $scope.players_value[2];
                		$scope.players_teams_sums[1] = $scope.players_value[1] + $scope.players_value[3];
                		
                		if (game_data.c_player_throw == 1)	$scope.player_team_mate = 3;
                		if (game_data.c_player_throw == 2)	$scope.player_team_mate = 4;
                		if (game_data.c_player_throw == 3)	$scope.player_team_mate = 1;
                		if (game_data.c_player_throw == 4)	$scope.player_team_mate = 2;
                		if (game_data.c_team_num == 23) 	//iznimka, prikazi 6 na poziciji 7
                		{
                			if (game_data.c_player_throw == 5)	$scope.player_team_mate = 6;
                			if (game_data.c_player_throw == 6)	$scope.player_team_mate = 5;
                			$scope.players_teams_sums[2] = $scope.players_value[4] + $scope.players_value[5];
                		}
                		else
                		{
                			if (game_data.c_player_throw == 5)	$scope.player_team_mate = 7;
                			if (game_data.c_player_throw == 6)	$scope.player_team_mate = 8;
                			if (game_data.c_player_throw == 7)	$scope.player_team_mate = 6;
                			if (game_data.c_player_throw == 8)	$scope.player_team_mate = 8;
                			$scope.players_teams_sums[2] = $scope.players_value[4] + $scope.players_value[6];
                			$scope.players_teams_sums[3] = $scope.players_value[5] + $scope.players_value[7];
                		}
                			
                	}
                	else if (team_num_players == 3)
                	{	
                		$scope.players_teams_sums[0] = $scope.players_value[0] + $scope.players_value[2] + $scope.players_value[4];
                		$scope.players_teams_sums[1] = $scope.players_value[1] + $scope.players_value[3] + $scope.players_value[5];
                	}
                	else if (team_num_players == 4) 
                	{
                		$scope.players_teams_sums[0] = $scope.players_value[0] + $scope.players_value[2] + $scope.players_value[4] + $scope.players_value[6];
                		$scope.players_teams_sums[1] = $scope.players_value[1] + $scope.players_value[3] + $scope.players_value[5] + $scope.players_value[7];
                	}
                	if (game_data.c_player_throw % 2) //provjeri da li je par ili nepar
                	{
                		if (team_num_players == 2 && game_data.c_player_throw > 3)
                			$scope.positions_player_okvir_bck_color[2] = '#B3B3B3';
                		else 
                			$scope.positions_player_okvir_bck_color[0] = '#B3B3B3';
                	}
                	else  //ako je paran
                	{
                		if (team_num_players == 2 && game_data.c_player_throw > 4)
                		{
                			if (game_data.c_team_num == 23)	//iznimka, prikazi 6 na poziciji 7
                				$scope.positions_player_okvir_bck_color[2] = '#B3B3B3';
                			else
                				$scope.positions_player_okvir_bck_color[3] = '#B3B3B3';
                		}
                		else 
                			$scope.positions_player_okvir_bck_color[1] = '#B3B3B3';
                	}
                }*/
                if (game_data.c_team_num) {
                    flag_ima_uvjet_od_teama = 0; //nema uvjet za izlaz
                    //za team izracun okvira
                    if (team_num_players == 2) {

                    }
                    if (team_num_players == 3 || team_num_players == 4) {
                        if (team_num_players == 3) {
                            temp_sums[0] = game_data.c_player_value[0] + game_data.c_player_value[2] + game_data.c_player_value[4];
                            temp_sums[1] = game_data.c_player_value[1] + game_data.c_player_value[3] + game_data.c_player_value[5];
                        }
                        if (team_num_players == 4) {
                            temp_sums[0] = game_data.c_player_value[0] + game_data.c_player_value[2] + game_data.c_player_value[4] + game_data.c_player_value[6];
                            temp_sums[1] = game_data.c_player_value[1] + game_data.c_player_value[3] + game_data.c_player_value[5] + game_data.c_player_value[7];
                        }
                        if ((lokacija_podatka_igraca % 2) == 0) {
                            if ((temp_sums[0] - game_data.c_player_value[lokacija_podatka_igraca]) <= temp_sums[1]) flag_ima_uvjet_od_teama = 1; //ima uvjet za izlaz
                        } else {
                            if ((temp_sums[1] - game_data.c_player_value[lokacija_podatka_igraca]) <= temp_sums[0]) flag_ima_uvjet_od_teama = 1; //ima uvjet za izlaz
                        }
                    }
                }
                if (flag_ima_uvjet_od_teama) {
                    let prethodni_string = 0;
                    if ((game_data.c_option & OPTION_DOUBLE_OUT) == 0 && (game_data.c_option & OPTION_MASTER_OUT) == 0) {
                        if ((game_data.c_option & OPTION_QUATTRO)) {
                            if (game_data.c_player_value[lokacija_podatka_igraca] % 4 == 0) //broj dijeljiv sa 4
                            {
                                tempi = Math.floor(game_data.c_player_value[lokacija_podatka_igraca] / 4);
                                if (tempi <= 20) {
                                    $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' Q' + tempi;
                                    prethodni_string = 1;
                                }
                            }
                        }
                        if (game_data.c_player_value[lokacija_podatka_igraca] % 3 == 0) //broj dijeljiv sa 3
                        {
                            tempi = Math.floor(game_data.c_player_value[lokacija_podatka_igraca] / 3);
                            if (tempi <= 20) {
                                if (prethodni_string) $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' /';
                                $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' T' + tempi;
                                prethodni_string = 1;
                            }
                        }
                        if (game_data.c_player_value[lokacija_podatka_igraca] % 2 == 0) //broj dijeljiv sa 2
                        {
                            tempi = Math.floor(game_data.c_player_value[lokacija_podatka_igraca] / 2);
                            if (tempi <= 20) {
                                if (prethodni_string) $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' /';
                                $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' D' + tempi;
                                prethodni_string = 1;
                            }

                        }
                        tempi = game_data.c_player_value[lokacija_podatka_igraca];
                        if (tempi <= 20) {
                            if (prethodni_string) $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' /';
                            $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' ' + tempi;
                        }
                    } else if (game_data.c_option & OPTION_DOUBLE_OUT) {
                        if (game_data.c_player_value[lokacija_podatka_igraca] % 2 == 0) //broj dijeljiv sa 2
                        {
                            tempi = Math.floor(game_data.c_player_value[lokacija_podatka_igraca] / 2);
                            if (tempi <= 20) {
                                $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' D' + tempi;
                                prethodni_string = 1;
                            }
                        }
                    } else if (game_data.c_option & OPTION_MASTER_OUT) {
                        if (game_data.c_player_value[lokacija_podatka_igraca] % 3 == 0) //broj dijeljiv sa 3
                        {
                            tempi = Math.floor(game_data.c_player_value[lokacija_podatka_igraca] / 3);
                            if (tempi <= 20) {
                                if (prethodni_string) $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' /';
                                $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' T' + tempi;
                                prethodni_string = 1;
                            }
                        }
                        if (game_data.c_player_value[lokacija_podatka_igraca] % 2 == 0) //broj dijeljiv sa 2
                        {
                            tempi = Math.floor(game_data.c_player_value[lokacija_podatka_igraca] / 2);
                            if (tempi <= 20) {
                                if (prethodni_string) $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' /';
                                $scope.ponudi_izlaz = $scope.ponudi_izlaz + ' D' + tempi;
                                prethodni_string = 1;
                            }
                        }
                    }
                }
            }
        }

    }

    function select_settings_menu() {
        $scope.menuState = 800;
        $scope.positions_row1_select_settings = [0, 20, 40, 60];
        $scope.row1_select_settings = ["TEST MENI", "STATISTICS", "DEMO SOUND", "MAIN BOOK"];
        $scope.row1_select_settings_text_h = [7, 7, 7, 7, 7];

        $scope.positions_row2_select_settings = [0, 20, 40, 60];
        //$scope.row2_game_name = ["Cricket", "", "", ""];
        $scope.row2_select_settings = ["TURNIR MODE", "INITIALISATION", "PARAMETERS SETUP", "SECOUNDARY BOOK"];
        $scope.row2_select_settings_text_h = [7, 7, 7, 7, 7];


    }

    function select_settings_test_menu() {
        $scope.menuState = 901;
        $scope.positions_row1_test_menu = [0, 16.5, 33, 49.5, 66];
        $scope.row1_test_menu = ["TEST TARGET", "TEST LIGHT", "TEST BUTTON", "TEST INFRA", "TEST TUP"];
        $scope.row1_test_menu_text_h = [7, 7, 7, 7, 7];

        $scope.positions_row2_test_menu = [0, 16.5, 33, 49.5, 66];
        //$scope.row2_game_name = ["Cricket", "", "", ""];
        $scope.row2_test_menu = ["TEST CREDIT", "TEST MONITOR", "TEST CALIBRATION", "TEST RFID", "TEST NETWORK"];
        $scope.row2_test_menu_text_h = [7, 7, 7, 7, 7];

        $scope.positions_row3_test_menu = [0, 16.5];

        $scope.row3_test_menu = ["TEST SOUND", "TEST CAMERA"];
        $scope.row3_test_menu_text_h = [11, 11];



    }

    function old_display_jumper_data(menu_current_state, data_input, Cpu_data, game_data, Cpu_turnir_data) {
        console.log('data_input:', data_input.c_podaci[1]);
        let menu_setup_name = [
            "PRICE ADJUST", "HAPPY PRICE", "ROUND ADJUST", "HAPPY ROUND", "SETUP CLOCK",
            "SETUP HAPPY HR", "BONUS CREDIT", "BONUS PERCENT", "TIME LIMIT", "COUNTER PULSES",
            "SWITCH CREDITS", "TIME CREDITS", "PUBLICITY", "LOTTERY", "OPTIONS REMEMBER",
            "DEMO SOUND", "QUATTRO MODE", "TARGET QUATTRO", "RETURN DART", "BULL VALUE",
            "PLAYOFF", "LAMP ON", "MAINLAMP", "BACK LIGHT", "RPI BOARD",
            "INFRA ADJUST", "STATISTICS", "COIN CCTALK", "BILL CCTALK", "COIN PULSE",
            "BILL PULSE", "PRICE 1CREDIT", "TUP ADJUST", "ACCEPTOR TIME"
        ];
        let menu_setup_name_toogle = [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        let menu_setup_name_tipke_nav = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
        let menu_test_name = ['TARGET', 'LIGHT', 'BUTTON', 'INFRA', 'TUP', 'CREDIT'];
        let menu_test_light_led = [1, 18, 4, 13, 6, 10, 15, 2, 17, 3, 19, 7, 16, 8, 11, 14, 9, 12, 5, 20, 21, 22, 23, 24, 25];
        let menu_test_nazivi_tipke_old = ["DBL IN", "DBL OUT", "PLAYER", "ROULETTE", "TEST", "EQUAL", "SUPER", "SOLO 301", "HI SCORE", "SCRAM", "QUATTRO", "301", "PARCHEES", "CRICKET", "MASTER", "TEAM"];
        let menu_bookkeeping_list_3 = [ //ovo je za listu bookkeeping
            "KEY CREDITS ", "COIN CREDITS ", "BILL CREDITS ", "_____________________", "TOTAL CREDITS "
        ];
        let menu_setup_name_list_1_2 = [ //ovo je za listu setup
            "PRICE ADJUST", "HAPPY PRICE", "ROUND ADJUST", "HAPPY ROUND", "SETUP CLOCK",
            "SETUP HAPPY HR", "BONUS CREDIT", "BONUS PERCENT", "TIME LIMIT", "COUNTER PULSES",
            "SWITCH CREDITS", "TIME CREDITS", "PUBLICITY", "LOTTERY", "OPTIONS REMEMBER",
            "DEMO SOUND", "QUATTRO MODE"
        ];
        let menu_setup_name_list_2_2 = [ //ovo je za listu setup
            "TARGET QUATTRO", "RETURN DART", "BULL VALUE", "PLAYOFF", "LAMP ON",
            "MAINLAMP", "BACK LIGHT", "RPI BOARD", "INFRA ADJUST", "STATISTICS",
            "COIN CCTALK", "BILL CCTALK", "COIN PULSE", "BILL PULSE", "PRICE 1CREDIT",
            "TUP ADJUST", "ACCEPTOR TIME"
        ];
        let game_name_and_options_1_2 = [ //ovo je za listu cijena i rundi
            "180         ", "301         ", "501         ", "701         ", "901         ", // 0-4
            "1001        ", "CRICKET     ", "HI SCORE    ", "LO SCORE    ", "SSCORE      ", // 5-9
            "SHANGAI     ", "BASEBALL    ", "ROULETTE    ", "SCRAM       ", "SUPER 100   ", // 10-14
        ];
        let game_name_and_options_2_2 = [ //ovo je za listu cijena i rundi        
            "PUB         ", "SOLO HISCORE", "SOLO  301   ", "MARATHON    ", "SPLIT SCORE ", // 15-19
            "DOUBLEIN    ", "DOUBLEOUT   ", "DBLIN-OUT   ", "MASTEROUT   ", "CUT THROAT  ", // 20-24
            "SHORTY      ", "PICK IT     ", "RANDOM      ", "CRAZY       ", "KILLER      " // 25-29
        ];
        $scope.settings_name_button_path = [
            'graphics/i_graphics/settings_buttons/player_button_fade.png',
            'graphics/i_graphics/settings_buttons/double_out_button.png',
            'graphics/i_graphics/settings_buttons/hi_score_button.png',
            'graphics/i_graphics/settings_buttons/scram_button.png',
        ];
        $scope.old_setup_menu = "";
        $scope.old_setup_menu_data0 = "";
        $scope.old_setup_menu_data1 = "";
        $scope.old_setup_menu_data2 = "";
        $scope.old_setup_menu_data3 = "";
        $scope.old_setup_menu_toogle = 0;
        $scope.old_setup_menu_tipke_nav = 0;
        $scope.navigations_buttons_data = [1, 2, 3, 4]; //up left ok right down
        $scope.navigations_buttons_pos_top = [26, 26, 54.4, 54.4]; //vh
        $scope.navigations_buttons_pos_left = [58, 81.5, 58, 81.5]; //vw
        $scope.navigations_buttons_data_name = ['\u25B2', '\u25C4', 'OK', '\u25BA', '\u25BC'];
        $scope.navigations_buttons_pos_top_name = [34, 34, 59.4, 56.0]; //vh
        $scope.navigations_buttons_pos_left_name = [68.5, 74.5, 68.5, 77]; //vw
        $scope.navigations_buttons_pos_data_name = ['NEXT', 'ENTER', '+', '_'];
        $scope.navigations_buttons_pos_data_name_size = ['3', '3', '8', '8'];
        $scope.old_menu_settings_list_1 = [];
        $scope.old_menu_settings_list_2 = [];
        $scope.old_menu_settings_list_3 = [];
        $scope.old_menu_settings_list_1_data = [];
        $scope.old_menu_settings_list_2_data = [];
        $scope.old_menu_settings_list_3_data = [];
        $scope.old_menu_settings_list_left = [8, 26, 31, 49, 54, 72];
        $scope.old_menu_settings_list_top = 18;
        $scope.old_menu_settings_list_top_3 = 40;
        $scope.old_menu_settings_list_1_background = []; /*"#be7f2e";*/
        $scope.old_menu_settings_list_2_background = [];
        $scope.old_menu_settings_list_1_data_background = [];
        $scope.old_menu_settings_list_2_data_background = [];

        let menu_settings_buttons_on = [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1];
        let menu_settings_buttons_num = [0, 0, 0, 0, 3, 4, 1, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1, 2, 1, 2, 0, 0, 1, 1, 1, 1, 1]; //koliko gumbi

        $scope.old_menu_settings_buttons_on = 0;
        $scope.old_menu_settings_buttons_background = ['#000000', '#000000', '#000000', '#000000']; //[1,0]; /*"#be7f2e";*/
        $scope.old_setup_menu_data0 = data_input.c_podaci[0];
        $scope.old_menu_settings_buttons_data_limits = "";
        $scope.old_menu_settings_buttons_data_napomena = ["", "", "", ""];


        let pozicije_polja_eeproma_settings = [0, 0, 0, 0, 5, 6, 211, 212, 207, 208, 209, 210, 0, 213, 214, 215, 216, 250, 217, 218, 219, 220, 221, 222, 243, 223, 225, 7, 7, 64, 65, 66, 253, 224];
        /*let menu_setup_name = [
            "PRICE ADJUST", "HAPPY PRICE", "ROUND ADJUST", "HAPPY ROUND", "SETUP CLOCK",
            "SETUP HAPPY HR", "BONUS CREDIT", "BONUS PERCENT", "TIME LIMIT", "COUNTER PULSES",
            "SWITCH CREDITS", "TIME CREDITS", "PUBLICITY", "LOTTERY", "OPTIONS REMEMBER",
            "DEMO SOUND", "QUATTRO MODE", "TARGET QUATTRO", "RETURN DART", "BULL VALUE",
            "PLAYOFF", "LAMP ON", "MAINLAMP", "BACK LIGHT", "LED LIGHT",
            "INFRA ADJUST", "STATISTICS", "COIN CCTALK", "BILL CCTALK", "COIN PULSE",
            "BILL PULSE", "PRICE 1CREDIT"
        ];*/

        let pozicije_polja_eeproma_settings_limits = [
            "", "", "", "", "(hh:mm:ss)",
            "", "(2-50)", "(0-30)", "(0-60)", "CREDIT (0-10)",
            "CREDIT (1-50)", "(0-30)", "(TEXT)", "(5-30)", "",
            "", "", "", "(0-10)", "(1-4)",
            "", "", "(4-16)", "(0-10)", "",
            "(0-5)", "", "(0-1000)", "(0-1000)", "(1-100)",
            "(1-100)", "(0-1000)", "(10-250)", "(0-3)"
        ];
        let pozicije_polja_eeproma_settings_napomena1 = [
            "", "", "", "", "",
            "start stop", "", "", "", "",
            "", "", "", "0 - lottery off", "",
            "", "", "", "", "1 - bull 25 / 25",
            "", "", "", "", "",
            "0 - infra sensor off", "", "", "", "",
            "", "price for 1 credit", "90 default", "0 - 100ms"
        ];
        let pozicije_polja_eeproma_settings_napomena2 = [
            "", "", "", "", "",
            "hh:mm hh:mm", "", "", "", "",
            "", "", "", "", "",
            "", "", "", "", "2 - bull 25 / 50",
            "", "", "", "", "",
            "1 - fast switching", "", "", "", "",
            "", "", "", "1 - 200ms"
        ];
        let pozicije_polja_eeproma_settings_napomena3 = [
            "", "", "", "", "",
            "", "", "", "", "",
            "", "", "", "", "",
            "", "", "", "", "3 - bull 50 / 50",
            "", "", "", "", "",
            "", "", "", "", "",
            "", "", "", "2 - 50ms"
        ];
        let pozicije_polja_eeproma_settings_napomena4 = [
            "", "", "", "", "",
            "", "", "", "", "",
            "", "", "", "", "",
            "", "", "", "", "4 - bull 50 / 100",
            "", "", "", "", "",
            "5 - slow switching", "", "", "", "",
            "", "", "", "3 - 150ms"
        ];

        let money_region_names = [
            "0",
            "EU005", "EU010", "EU020", "EU050", "EU100", "EU200", 
            "AU005", "AU010", "AU020", "AU050", "AU100", "AU200",
            "CA005", "CA010", "CA025", "CA050", "CA100", "CA200",
            "CZ001", "CZ002", "CZ005", "CZ010", "CZ020", "CZ050",
            "DK100", "DK200", "DK500", "DK1000", "DK2000",
            "HU005", "HU010", "HU020", "HU050", "HU100", "HU200",
            "JP001", "JP005", "JP010", "JP050", "JP100", "JP500",
            "NO100", "NO500", "NO1000", "NO2000",
            "SE100", "SE200", "SE500", "SE1000",
            "CH005", "CH010", "CH020", "CH050", "CH100", "CH200", "CH500",
            "GB001", "GB002", "GB005", "GB010", "GB020", "GB050", "GB100", "GB200",
            "US001", "US005", "US010", "US025", "US050", "US100",
            "BA005", "BA010", "BA020", "BA050", "BA100", "BA200", "BA500",
            "PL001", "PL002", "PL005", "PL010", "PL020", "PL050", "PL100", "PL200", "PL500",
            "TK050", "TK100", "TK200"
        ];

        let money_region_names_bill = [
            "0",
            "EU0005", "EU0010", "EU0020", "EU0050", "EU0100", "EU0200", "EU0500"
        ];

        let menu_hidden_setup_name_list_1_2 = [ //ovo je za listu hidden setup
            "LANGUAGE", "ACCEPTOR", "COUNTERS", "SERIAL NUMBER", "RPI MOUNT",
            "TYPE VER", "TARGET TYPE"
        ];

        let menu_hidden_setup_language_list = [ "HRV", "ITA", "CHE", "DEU", "CZE", "SVK", "POL", "RUS", "SVN", "AUT", "CAK", "FRA", "ENG", "ESP", "PRT" ];
        let menu_hidden_setup_model_types_list = [ "V H7", "OBL3", "L-19", "B-63" ];
        let menu_hidden_setup_model_target_list = [ "16-P", "20-P", "24-P", "TEST" ];
       
        if (menu_current_state == 951) //setup menu
        {
            if ((data_input.c_podaci[0] == 172) && (data_input.c_podaci[2] == 0) && data_input.c_podaci[1]) //pocetni izbornik
            {

                $scope.old_menu_settings_list_top = 16.7; //18.7;
                for (let i = 0; i < 17; i++) {
                    $scope.old_menu_settings_list_1.push(menu_setup_name_list_1_2[i]);
                    $scope.old_menu_settings_list_2.push(menu_setup_name_list_2_2[i]);
                    $scope.old_menu_settings_list_1_data.push("");
                    $scope.old_menu_settings_list_2_data.push("");
                    $scope.old_menu_settings_list_1_background.push("");
                    $scope.old_menu_settings_list_2_background.push("");
                    $scope.old_menu_settings_list_1_data_background.push("");
                    $scope.old_menu_settings_list_2_data_background.push("");
                }

                $scope.old_menu_settings_list_1_data[6] = Cpu_data.ee_bonus_credit;
                $scope.old_menu_settings_list_1_data[7] = Cpu_data.ee_bonus_percent;
                $scope.old_menu_settings_list_1_data[8] = Cpu_data.ee_time_limit;
                $scope.old_menu_settings_list_1_data[9] = Cpu_data.ee_counter_pulses;
                $scope.old_menu_settings_list_1_data[10] = Cpu_data.ee_switch_credits;
                $scope.old_menu_settings_list_1_data[11] = Cpu_data.ee_tcr;
                $scope.old_menu_settings_list_1_data[12] = Cpu_data.ee_publicity;
                $scope.old_menu_settings_list_1_data[13] = Cpu_data.ee_lottery;
                $scope.old_menu_settings_list_1_data[14] = Cpu_data.ee_option_remember;
                $scope.old_menu_settings_list_1_data[15] = Cpu_data.ee_demo_sound;
                $scope.old_menu_settings_list_1_data[16] = Cpu_data.ee_quatro_mode_on;

                $scope.old_menu_settings_list_2_data[0] = Cpu_data.ee_sett_target_quattro_on;
                $scope.old_menu_settings_list_2_data[1] = Cpu_data.ee_return_dart;
                $scope.old_menu_settings_list_2_data[2] = Cpu_data.ee_bull_value;
                $scope.old_menu_settings_list_2_data[3] = Cpu_data.ee_play_off;
                $scope.old_menu_settings_list_2_data[4] = Cpu_data.ee_lamp_on;
                $scope.old_menu_settings_list_2_data[5] = Cpu_data.ee_main_lamp;
                $scope.old_menu_settings_list_2_data[6] = Cpu_data.ee_back_light;
                $scope.old_menu_settings_list_2_data[7] = Cpu_data.ee_sett_rpi_mount;

                $scope.old_menu_settings_list_2_data[8] = Cpu_data.ee_infra_adjust;
                $scope.old_menu_settings_list_2_data[9] = Cpu_data.ee_ppd_statistics[0];
                $scope.old_menu_settings_list_2_data[14] = Cpu_data.ee_cijena_jednog_kredita * 5;
                $scope.old_menu_settings_list_2_data[15] = Cpu_data.ee_tup_sense;
                $scope.old_menu_settings_list_2_data[16] = Cpu_data.ee_acceptor_time_adjust;
                //podaci koji imaju samo off ili on
                if ($scope.old_menu_settings_list_1_data[14] == 0) $scope.old_menu_settings_list_1_data[14] = 'OFF'; //Cpu_data.ee_option_remember
                else $scope.old_menu_settings_list_1_data[14] = 'ON';
                if ($scope.old_menu_settings_list_1_data[15] == 0) $scope.old_menu_settings_list_1_data[15] = 'OFF'; //Cpu_data.ee_demo_sound
                else $scope.old_menu_settings_list_1_data[15] = 'ON';
                if ($scope.old_menu_settings_list_1_data[16] == 0) $scope.old_menu_settings_list_1_data[16] = 'OFF'; //Cpu_data.ee_quatro_mode_on
                else $scope.old_menu_settings_list_1_data[16] = 'ON';

                if ($scope.old_menu_settings_list_2_data[0] == 0) $scope.old_menu_settings_list_2_data[0] = 'OFF'; //Cpu_data.ee_sett_target_quattro_on
                else $scope.old_menu_settings_list_2_data[0] = 'ON';

                if ($scope.old_menu_settings_list_2_data[3] == 0) $scope.old_menu_settings_list_2_data[3] = 'OFF'; //Cpu_data.ee_play_off
                else $scope.old_menu_settings_list_2_data[3] = 'ON';
                if ($scope.old_menu_settings_list_2_data[4] == 0) $scope.old_menu_settings_list_2_data[4] = 'OFF'; //Cpu_data.ee_lamp_on
                else $scope.old_menu_settings_list_2_data[4] = 'ON';

                if ($scope.old_menu_settings_list_2_data[7] == 0) $scope.old_menu_settings_list_2_data[7] = 'OFF'; //Cpu_data.ee_lamp_on
                else $scope.old_menu_settings_list_2_data[7] = 'ON';

                if ($scope.old_menu_settings_list_2_data[9] == 0) $scope.old_menu_settings_list_2_data[9] = 'OFF'; //Cpu_data.ee_ppd_statistics[0];
                else $scope.old_menu_settings_list_2_data[9] = 'ON';
                //oznaka na postavljeni niz
                if (data_input.c_podaci[1] < 18) {
                    $scope.old_menu_settings_list_1_background[(data_input.c_podaci[1] - 1)] = "rgba(190, 127, 46, 0.5)";
                    if (data_input.c_podaci[1] > 6 && data_input.c_podaci[1] != 13)
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[1] - 1)] = "rgba(190, 127, 46, 0.5)";

                } else {
                    $scope.old_menu_settings_list_2_background[(data_input.c_podaci[1] - 1 - 17)] = "rgba(190, 127, 46, 0.5)";
                    if (data_input.c_podaci[1] < 28 || data_input.c_podaci[1] > 31)
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[1] - 1 - 17)] = "rgba(190, 127, 46, 0.5)";
                }
            } else if ((data_input.c_podaci[1] == 1) || ((data_input.c_podaci[1] == 2) && (data_input.c_podaci[2] >= 80) && (data_input.c_podaci[2] < 110))) //price adjust
            {
                $scope.settings_name_button_path[0] = 'graphics/i_graphics/settings_buttons/player_button.png';
                $scope.old_menu_settings_list_top = 18.7;
                for (let i = 0; i < 15; i++) {
                    $scope.old_menu_settings_list_1.push(game_name_and_options_1_2[i]);
                    $scope.old_menu_settings_list_2.push(game_name_and_options_2_2[i]);
                    $scope.old_menu_settings_list_1_data.push(Cpu_data.ee_price_adjust[i]);
                    $scope.old_menu_settings_list_2_data.push(Cpu_data.ee_price_adjust[i + 15]);
                    $scope.old_menu_settings_list_1_background.push("");
                    $scope.old_menu_settings_list_2_background.push("");
                    $scope.old_menu_settings_list_1_data_background.push("");
                    $scope.old_menu_settings_list_2_data_background.push("");
                    if ($scope.old_menu_settings_list_1_data[i] == 255) $scope.old_menu_settings_list_1_data[i] = '1/2';
                    if ($scope.old_menu_settings_list_2_data[i] == 255) $scope.old_menu_settings_list_2_data[i] = '1/2';
                    if ($scope.old_menu_settings_list_1_data[i] > 20) $scope.old_menu_settings_list_1_data[i] -= 41;
                    if ($scope.old_menu_settings_list_2_data[i] > 20) $scope.old_menu_settings_list_2_data[i] -= 41;
                }
                //oznaka na postavljeni niz 
                /*
                 data_input.c_podaci[1]  1 izbornik
                                            2 promjena
                data_input.c_podaci[2]  1   1 - 30 odabir
                                        2   80-110 promjena                     
                                            */
                if ((data_input.c_podaci[0] == 172) && data_input.c_podaci[1] == 1) //izbornik 
                {
                    if (data_input.c_podaci[2] < 16) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 31) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 1 - 15)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 1 - 15)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
                if ((data_input.c_podaci[0] == 170) && data_input.c_podaci[1] == 2) //promjena u izborniku
                {
                    if (data_input.c_podaci[2] < 95) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 80)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 80)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 110) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 95)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 95)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
            } else if (((data_input.c_podaci[1] == 2) && (data_input.c_podaci[2] < 31)) || ((data_input.c_podaci[2] >= 110) && (data_input.c_podaci[2] < 140))) //happy price adjust
            {
                $scope.settings_name_button_path[0] = 'graphics/i_graphics/settings_buttons/player_button.png';
                $scope.old_menu_settings_list_top = 18.7;
                for (let i = 0; i < 15; i++) {
                    $scope.old_menu_settings_list_1.push(game_name_and_options_1_2[i]);
                    $scope.old_menu_settings_list_2.push(game_name_and_options_2_2[i]);
                    $scope.old_menu_settings_list_1_data.push(Cpu_data.ee_happy_price_adjust[i]);
                    $scope.old_menu_settings_list_2_data.push(Cpu_data.ee_happy_price_adjust[i + 15]);
                    $scope.old_menu_settings_list_1_background.push("");
                    $scope.old_menu_settings_list_2_background.push("");
                    $scope.old_menu_settings_list_1_data_background.push("");
                    $scope.old_menu_settings_list_2_data_background.push("");
                    if ($scope.old_menu_settings_list_1_data[i] == 255) $scope.old_menu_settings_list_1_data[i] = '1/2';
                    if ($scope.old_menu_settings_list_2_data[i] == 255) $scope.old_menu_settings_list_2_data[i] = '1/2';
                    if ($scope.old_menu_settings_list_1_data[i] > 20) $scope.old_menu_settings_list_1_data[i] -= 41;
                    if ($scope.old_menu_settings_list_2_data[i] > 20) $scope.old_menu_settings_list_2_data[i] -= 41;
                }
                //oznaka na postavljeni niz 

                if ((data_input.c_podaci[0] == 172) && data_input.c_podaci[1] == 2) //izbornik
                {
                    if (data_input.c_podaci[2] < 16) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 31) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 1 - 15)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 1 - 15)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
                if ((data_input.c_podaci[0] == 170) && data_input.c_podaci[1] == 2) //promjena u izborniku
                {
                    if (data_input.c_podaci[2] < 125) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 110)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 110)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 140) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 125)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 125)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
            } else if ((data_input.c_podaci[1] == 3) || ((data_input.c_podaci[2] >= 140) && (data_input.c_podaci[2] < 170))) //round adjust
            {
                $scope.settings_name_button_path[0] = 'graphics/i_graphics/settings_buttons/player_button.png';
                $scope.old_menu_settings_list_top = 18.7;
                for (let i = 0; i < 15; i++) {
                    $scope.old_menu_settings_list_1.push(game_name_and_options_1_2[i]);
                    $scope.old_menu_settings_list_2.push(game_name_and_options_2_2[i]);
                    /*if ((game_data.c_jumpers & JUMPER_TURNIR))
                    {
                        $scope.settings_name = "TOURNAMENT ROUND";
                       // $scope.old_menu_settings_list_1_data.push(Cpu_turnir_data.ee_round_turnir_adjust[i]);
                        //$scope.old_menu_settings_list_2_data.push(Cpu_turnir_data.ee_round_turnir_adjust[i + 15]);
                    }
                    else
                    {*/
                       /* if (game_data.c_jumpers & JUMPER_TURNIR)
                        {
                            $scope.old_menu_settings_list_1_data.push(Cpu_turnir_data.ee_round_turnir_adjust[i]);
                            $scope.old_menu_settings_list_2_data.push(Cpu_turnir_data.ee_round_turnir_adjust[i + 15]);
                        }
                        else
                        {
                            $scope.old_menu_settings_list_1_data.push(Cpu_data.ee_round_adjust[i]);
                            $scope.old_menu_settings_list_2_data.push(Cpu_data.ee_round_adjust[i + 15]);
                        }*/
                        $scope.old_menu_settings_list_1_data.push(Cpu_data.ee_round_adjust[i]);
                        $scope.old_menu_settings_list_2_data.push(Cpu_data.ee_round_adjust[i + 15]);
                    //}
                    $scope.old_menu_settings_list_1_background.push("");
                    $scope.old_menu_settings_list_2_background.push("");
                    $scope.old_menu_settings_list_1_data_background.push("");
                    $scope.old_menu_settings_list_2_data_background.push("");
                }
                //oznaka na postavljeni niz 

                if ((data_input.c_podaci[0] == 172) && data_input.c_podaci[1] == 3) //izbornik
                {
                    if (data_input.c_podaci[2] < 16) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 31) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 1 - 15)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 1 - 15)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
                if ((data_input.c_podaci[0] == 170) && data_input.c_podaci[1] == 2) //promjena u izborniku
                {
                    if (data_input.c_podaci[2] < 155) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 140)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 140)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 170) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 155)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 155)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
            } else if ((data_input.c_podaci[1] == 12) && ((data_input.c_podaci[2] >= 80) && (data_input.c_podaci[2] < 110))) //tournament round adjust
            {
                $scope.settings_name_button_path[0] = 'graphics/i_graphics/settings_buttons/player_button.png';
                $scope.old_menu_settings_list_top = 18.7;
                for (let i = 0; i < 15; i++) {
                    $scope.old_menu_settings_list_1.push(game_name_and_options_1_2[i]);
                    $scope.old_menu_settings_list_2.push(game_name_and_options_2_2[i]);
                    
                        /*if (game_data.c_jumpers & JUMPER_TURNIR)
                        {
                            $scope.old_menu_settings_list_1_data.push(Cpu_turnir_data.ee_round_turnir_adjust[i]);
                            $scope.old_menu_settings_list_2_data.push(Cpu_turnir_data.ee_round_turnir_adjust[i + 15]);
                        }
                        else
                        {
                            $scope.old_menu_settings_list_1_data.push(Cpu_data.ee_round_adjust[i]);
                            $scope.old_menu_settings_list_2_data.push(Cpu_data.ee_round_adjust[i + 15]);
                        }
                        */
                        $scope.old_menu_settings_list_1_data.push(Cpu_data.ee_round_adjust[i]);
                        $scope.old_menu_settings_list_2_data.push(Cpu_data.ee_round_adjust[i + 15]);
                    //}
                    $scope.old_menu_settings_list_1_background.push("");
                    $scope.old_menu_settings_list_2_background.push("");
                    $scope.old_menu_settings_list_1_data_background.push("");
                    $scope.old_menu_settings_list_2_data_background.push("");
                }
                //oznaka na postavljeni niz 

                if ((data_input.c_podaci[0] == 172) && data_input.c_podaci[1] == 3) //izbornik
                {
                    if (data_input.c_podaci[2] < 16) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 31) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 1 - 15)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 1 - 15)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
                if ((data_input.c_podaci[0] == 170) && data_input.c_podaci[1] == 12) //promjena u izborniku
                {
                    if (data_input.c_podaci[2] < 95) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 80)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 80)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 110) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 95)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 95)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
            } else if ((data_input.c_podaci[1] == 4) || ((data_input.c_podaci[2] >= 170) && (data_input.c_podaci[2] < 200))) //happy round adjust
            {
                $scope.settings_name_button_path[0] = 'graphics/i_graphics/settings_buttons/player_button.png';
                $scope.old_menu_settings_list_top = 18.7;
                for (let i = 0; i < 15; i++) {
                    $scope.old_menu_settings_list_1.push(game_name_and_options_1_2[i]);
                    $scope.old_menu_settings_list_2.push(game_name_and_options_2_2[i]);
                    $scope.old_menu_settings_list_1_data.push(Cpu_data.ee_happy_round_adjust[i]);
                    $scope.old_menu_settings_list_2_data.push(Cpu_data.ee_happy_round_adjust[i + 15]);
                    $scope.old_menu_settings_list_1_background.push("");
                    $scope.old_menu_settings_list_2_background.push("");
                    $scope.old_menu_settings_list_1_data_background.push("");
                    $scope.old_menu_settings_list_2_data_background.push("");
                }
                //oznaka na postavljeni niz 

                if ((data_input.c_podaci[0] == 172) && data_input.c_podaci[1] == 4) //izbornik
                {
                    if (data_input.c_podaci[2] < 16) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 31) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 1 - 15)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 1 - 15)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
                if ((data_input.c_podaci[0] == 170) && data_input.c_podaci[1] == 2) //promjena u izborniku
                {
                    if (data_input.c_podaci[2] < 185) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 170)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 170)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 200) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 185)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 185)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
            } else if ((data_input.c_podaci[1] == 28) || ((data_input.c_podaci[1] == 7) && (data_input.c_podaci[2] >= 32) && (data_input.c_podaci[2] < 48))) //coin cctalk
            {
                $scope.settings_name_button_path[0] = 'graphics/i_graphics/settings_buttons/player_button.png';
                $scope.old_menu_settings_list_top = 34;
                let temp_inhibit = "";
                let real_channel_value = "";
                for (let i = 0; i < 8; i++) {
                    //real_channel_value = Cpu_data.ee_vrijednost_kanala_cctalka[i] * 5;
                    real_channel_value = money_region_names[Cpu_data.ee_vrijednost_kanala_cctalka[i]];
                    temp_inhibit = "✓";
                    if ((Cpu_data.ee_coin_channel_inhibit & (1 << i)) == 0) temp_inhibit = "✘";
                    $scope.old_menu_settings_list_1.push(String(temp_inhibit) + ' Coin ch ' + (i + 1) + ' (' + String(real_channel_value) + ')');
                    //real_channel_value = Cpu_data.ee_vrijednost_kanala_cctalka[i + 8] * 5;
                    real_channel_value = money_region_names[Cpu_data.ee_vrijednost_kanala_cctalka[i + 8]];
                    temp_inhibit = "✓";
                    if ((Cpu_data.ee_coin_channel_inhibit & (1 << (i + 8))) == 0) temp_inhibit = "✘";
                    $scope.old_menu_settings_list_2.push(String(temp_inhibit) + ' Coin ch ' + (i + 9) + ' (' + String(real_channel_value) + ')');
                    $scope.old_menu_settings_list_1_data.push(Cpu_data.ee_coin_bill_table_extra_credits[i] * 5);
                    $scope.old_menu_settings_list_2_data.push(Cpu_data.ee_coin_bill_table_extra_credits[i + 8] * 5);
                    $scope.old_menu_settings_list_1_background.push("");
                    $scope.old_menu_settings_list_2_background.push("");
                    $scope.old_menu_settings_list_1_data_background.push("");
                    $scope.old_menu_settings_list_2_data_background.push("");
                }
                //oznaka na postavljeni niz 

                if ((data_input.c_podaci[0] == 172) && data_input.c_podaci[1] == 28) //izbornik
                {
                    if (data_input.c_podaci[2] < 9) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 17) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 1 - 8)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 1 - 8)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
                if ((data_input.c_podaci[0] == 170) && data_input.c_podaci[1] == 7) //promjena u izborniku
                {
                    if (data_input.c_podaci[2] < 40) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 32)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 32)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 48) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 40)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 40)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
            } else if ((data_input.c_podaci[1] == 29) || ((data_input.c_podaci[1] == 7) && (data_input.c_podaci[2] >= 48) && (data_input.c_podaci[2] < 63))) //coin cctalk
            {
                $scope.settings_name_button_path[0] = 'graphics/i_graphics/settings_buttons/player_button.png';
                $scope.old_menu_settings_list_top = 34;
                let temp_inhibit = "";
                let real_channel_value = "";
                for (let i = 0; i < 8; i++) {
                    //real_channel_value = Cpu_data.ee_vrijednost_kanala_cctalka[i + 16];
                    real_channel_value = money_region_names_bill[Cpu_data.ee_vrijednost_kanala_cctalka[i + 16]];
                    temp_inhibit = "✓";
                    if ((Cpu_data.ee_bill_channel_inhibit & (1 << i)) == 0) temp_inhibit = "✘";
                    $scope.old_menu_settings_list_1.push(String(temp_inhibit) + ' Bill ch ' + (i + 1) + ' (' + String(real_channel_value) + ')');
                    //real_channel_value = Cpu_data.ee_vrijednost_kanala_cctalka[i + 24];
                    real_channel_value = money_region_names_bill[Cpu_data.ee_vrijednost_kanala_cctalka[i + 24]];
                    temp_inhibit = "✓";
                    if ((Cpu_data.ee_bill_channel_inhibit & (1 << (i + 8))) == 0) temp_inhibit = "✘";
                    $scope.old_menu_settings_list_2.push(String(temp_inhibit) + ' Bill ch ' + (i + 9) + ' (' + String(real_channel_value) + ')');
                    $scope.old_menu_settings_list_1_data.push(Cpu_data.ee_coin_bill_table_extra_credits[i + 16]);
                    $scope.old_menu_settings_list_2_data.push(Cpu_data.ee_coin_bill_table_extra_credits[i + 24]);
                    $scope.old_menu_settings_list_1_background.push("");
                    $scope.old_menu_settings_list_2_background.push("");
                    $scope.old_menu_settings_list_1_data_background.push("");
                    $scope.old_menu_settings_list_2_data_background.push("");
                }
                //oznaka na postavljeni niz 

                if ((data_input.c_podaci[0] == 172) && data_input.c_podaci[1] == 29) //izbornik
                {
                    if (data_input.c_podaci[2] < 9) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 1)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 17) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 1 - 8)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 1 - 8)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
                if ((data_input.c_podaci[0] == 170) && data_input.c_podaci[1] == 7) //promjena u izborniku
                {
                    if (data_input.c_podaci[2] < 56) {
                        $scope.old_menu_settings_list_1_background[(data_input.c_podaci[2] - 48)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[2] - 48)] = "rgba(190, 127, 46, 0.5)";
                    } else if (data_input.c_podaci[2] < 64) {
                        $scope.old_menu_settings_list_2_background[(data_input.c_podaci[2] - 56)] = "rgba(190, 127, 46, 0.5)";
                        $scope.old_menu_settings_list_2_data_background[(data_input.c_podaci[2] - 56)] = "rgba(190, 127, 46, 0.5)";
                    }
                }
            } else
            /* let old_menu_settings_buttons_num = [0,0,0,0,3, 6,2,2,1,1, 1,1,0,1,2, 2,6,4,2,2, 1,1,1,1,2, 0,2,2,2,1, 1,1];   //koliko gumbi
        let menu_settings_buttons_on =         [0,0,0,0,1, 1,1,1,1,1, 1,1,0,1,1, 1,1,1,1,1, 1,1,1,1,1, 0,1,1,1,1, 1,1];
        let menu_settings_buttons_on =      [0,0,0,0,1, 1,1,1,1,1, 1,1,0,1,1, 1,1,1,1,1, 1,1,1,1,1, 0,1,1,1,1, 1,1];
        let menu_settings_buttons_num = [0,0,0,0,3, 6,2,2,1,1, 1,1,0,1,2, 2,6,4,2,2, 1,1,1,1,2, 0,2,2,2,1, 1,1];   //koliko gumbi
        
        $scope.old_menu_settings_buttons_pos_top = [];   //vh
        $scope.old_menu_settings_buttons_pos_left = [];     //vw
        $scope.old_menu_settings_buttons_background = []; /*"#be7f2e";*/
            {
                $scope.old_menu_settings_buttons_on = 1;
                //$scope.menu_settings_buttons_on = menu_settings_buttons_on[data_input.c_podaci[1] - 1];
                let odgovara_poziciji = 0;
                if ((data_input.c_podaci[1] != 5) && (data_input.c_podaci[1] != 6) && (data_input.c_podaci[1] != 28) && (data_input.c_podaci[1] != 29)) {
                    for (let i = 0; i < 34; i++) {
                        if (data_input.c_podaci[2] == pozicije_polja_eeproma_settings[i]) {
                            odgovara_poziciji = i;
                            //console.log('odgovara_poziciji:', odgovara_poziciji);
                            break;
                        }
                    }
                } else //upali gumb
                {
                    if (data_input.c_podaci[1] == 5) odgovara_poziciji = 4;
                    if (data_input.c_podaci[1] == 6) odgovara_poziciji = 5;
                    if (data_input.c_podaci[1] == 28) odgovara_poziciji = 27;
                    if (data_input.c_podaci[1] == 29) odgovara_poziciji = 28;
                    $scope.settings_name_button_path[0] = 'graphics/i_graphics/settings_buttons/player_button.png';
                }
                //override za clock data promjena
                if ((data_input.c_podaci[0] == 170) && (data_input.c_podaci[1] == 2)) {
                    if ((data_input.c_podaci[2] > 199) && (data_input.c_podaci[2] < 203)) {
                        odgovara_poziciji = 4; //setup clock in menu
                    }
                    if ((data_input.c_podaci[2] > 202) && (data_input.c_podaci[2] < 207)) {
                        odgovara_poziciji = 5; //setup hh clock in menu
                    }
                }

                //
                $scope.old_menu_settings_buttons_data_limits = pozicije_polja_eeproma_settings_limits[odgovara_poziciji];
                $scope.old_menu_settings_buttons_data_napomena[0] = pozicije_polja_eeproma_settings_napomena1[odgovara_poziciji];
                $scope.old_menu_settings_buttons_data_napomena[1] = pozicije_polja_eeproma_settings_napomena2[odgovara_poziciji];
                $scope.old_menu_settings_buttons_data_napomena[2] = pozicije_polja_eeproma_settings_napomena3[odgovara_poziciji];
                $scope.old_menu_settings_buttons_data_napomena[3] = pozicije_polja_eeproma_settings_napomena4[odgovara_poziciji];

                $scope.old_menu_settings_buttons_num = [];
                $scope.old_menu_settings_buttons_pos_top = [];
                $scope.old_menu_settings_buttons_pos_left = [];
                $scope.old_menu_settings_buttons_pos_width = []; //15.3vw;  10.3
                $scope.old_menu_settings_buttons_data = [];
                $scope.old_menu_settings_buttons_limit_pos_left = 25.5; //left: 25.5vw;

                for (let i = 0; i < menu_settings_buttons_num[odgovara_poziciji]; i++) {
                    $scope.old_menu_settings_buttons_num.push(i);
                    $scope.old_menu_settings_buttons_pos_top.push(42); //vh
                    $scope.old_menu_settings_buttons_pos_left.push(7.4 + 18.8 * i); //vw
                    $scope.old_menu_settings_buttons_data.push(data_input.c_podaci[3]);
                    if (data_input.c_podaci[2] == 66) $scope.old_menu_settings_buttons_data[0] *= 5;
                    $scope.old_menu_settings_buttons_pos_width.push(15.3);
                    if (odgovara_poziciji == 4) //setup clock
                    {
                        $scope.old_menu_settings_buttons_limit_pos_left = 42.0;
                        $scope.old_menu_settings_buttons_pos_left[i] = (4.0 + 13.0 * i); //vw
                        $scope.old_menu_settings_buttons_pos_width[i] = 10.3;
                        $scope.settings_name_button_path[0] = 'graphics/i_graphics/settings_buttons/player_button.png';
                    }
                    if (odgovara_poziciji == 5) //setup hh clock
                    {
                        $scope.old_menu_settings_buttons_limit_pos_left = 42.0;
                        $scope.old_menu_settings_buttons_pos_left[i] = (4.0 + 13.3 * i); //vw
                        $scope.old_menu_settings_buttons_pos_width[i] = 10.3;
                        $scope.settings_name_button_path[0] = 'graphics/i_graphics/settings_buttons/player_button.png';
                    }
                }
                if ((data_input.c_podaci[1] == 5)) //setup clock
                {
                    $scope.old_menu_settings_buttons_data[0] = Cpu_data.ee_setup_time[0];
                    $scope.old_menu_settings_buttons_data[1] = Cpu_data.ee_setup_time[1];
                    $scope.old_menu_settings_buttons_data[2] = Cpu_data.ee_setup_time[2];
                    $scope.old_menu_settings_buttons_background[data_input.c_podaci[3]] = '#c07f2f';
                    restore_data_setup_clock_select = data_input.c_podaci[3];
                } else if ((data_input.c_podaci[1] == 6)) //setup hh clock
                {
                    $scope.old_menu_settings_buttons_data[0] = Cpu_data.ee_happy_setup_time[0];
                    $scope.old_menu_settings_buttons_data[1] = Cpu_data.ee_happy_setup_time[1];
                    $scope.old_menu_settings_buttons_data[2] = Cpu_data.ee_happy_setup_time[2];
                    $scope.old_menu_settings_buttons_data[3] = Cpu_data.ee_happy_setup_time[3];
                    $scope.old_menu_settings_buttons_background[data_input.c_podaci[3]] = '#c07f2f';
                }
                if ((data_input.c_podaci[0] == 170) && (data_input.c_podaci[1] == 2)) //setup clock in menu
                {
                    if ((data_input.c_podaci[2] > 199) && (data_input.c_podaci[2] < 203)) {
                        $scope.old_menu_settings_buttons_data[0] = Cpu_data.ee_setup_time[0];
                        $scope.old_menu_settings_buttons_data[1] = Cpu_data.ee_setup_time[1];
                        $scope.old_menu_settings_buttons_data[2] = Cpu_data.ee_setup_time[2];
                        if (data_input.c_podaci[2] == 200) {
                            $scope.old_menu_settings_buttons_data[0] = data_input.c_podaci[3];
                            $scope.old_menu_settings_buttons_background[0] = '#c07f2f';
                            restore_data_setup_clock_select = 0;
                        }
                        if (data_input.c_podaci[2] == 201) {
                            $scope.old_menu_settings_buttons_data[1] = data_input.c_podaci[3];
                            $scope.old_menu_settings_buttons_background[1] = '#c07f2f';
                            restore_data_setup_clock_select = 1;
                        }
                        if (data_input.c_podaci[2] == 202) {
                            $scope.old_menu_settings_buttons_data[2] = data_input.c_podaci[3];
                            $scope.old_menu_settings_buttons_background[restore_data_setup_clock_select] = '#c07f2f';
                        }

                    }
                    if ((data_input.c_podaci[2] > 202) && (data_input.c_podaci[2] < 207)) {
                        $scope.old_menu_settings_buttons_data[0] = Cpu_data.ee_happy_setup_time[0];
                        $scope.old_menu_settings_buttons_data[1] = Cpu_data.ee_happy_setup_time[1];
                        $scope.old_menu_settings_buttons_data[2] = Cpu_data.ee_happy_setup_time[2];
                        $scope.old_menu_settings_buttons_data[3] = Cpu_data.ee_happy_setup_time[3];
                        if (data_input.c_podaci[2] == 203) $scope.old_menu_settings_buttons_data[0] = data_input.c_podaci[3];
                        if (data_input.c_podaci[2] == 204) $scope.old_menu_settings_buttons_data[1] = data_input.c_podaci[3];
                        if (data_input.c_podaci[2] == 205) $scope.old_menu_settings_buttons_data[2] = data_input.c_podaci[3];
                        if (data_input.c_podaci[2] == 206) $scope.old_menu_settings_buttons_data[3] = data_input.c_podaci[3];
                        $scope.old_menu_settings_buttons_background[data_input.c_podaci[2] - 203] = '#c07f2f';
                    }
                }
                if (menu_settings_buttons_num[odgovara_poziciji] == 2) //uz jos neke uvjete
                {
                    $scope.old_menu_settings_buttons_data[0] = 'ON';
                    $scope.old_menu_settings_buttons_data[1] = 'OFF';
                    if (data_input.c_podaci[3] == 0) {
                        $scope.old_menu_settings_buttons_background[0] = '#000000';
                        $scope.old_menu_settings_buttons_background[1] = '#c07f2f';
                    } else {
                        $scope.old_menu_settings_buttons_background[0] = '#c07f2f';
                        $scope.old_menu_settings_buttons_background[1] = '#000000';
                    }
                }
                //$scope.old_menu_settings_buttons_num = old_menu_settings_buttons_num[data_input.c_podaci[1] - 1];

                console.log('old_menu_settings_buttons_num:', menu_settings_buttons_num[odgovara_poziciji], odgovara_poziciji);
            }
            /*if ((data_input.c_podaci[1] > 0) && (data_input.c_podaci[1] < 5))
            {
                $scope.old_menu_settings_list_top = 21;
                for (let i = 0; i < 15; i++)
                {
                    $scope.old_menu_settings_list_1.push(game_name_and_options_1_2[i]);
                    $scope.old_menu_settings_list_2.push(game_name_and_options_2_2[i]);
                    $scope.old_menu_settings_list_1_data.push(i);
                    $scope.old_menu_settings_list_2_data.push(i);
                }
            }*/
            if ((data_input.c_podaci[1] > 0) && (data_input.c_podaci[1] < 35) && (data_input.c_podaci[2] == 0)) {

                $scope.old_setup_menu = menu_setup_name[data_input.c_podaci[1] - 1];
                //promjeni ROUND ADJUST U TOURNAMENT ROUND ADJUST
                /*if ((game_data.c_jumpers & JUMPER_TURNIR) && ((data_input.c_podaci[1] - 1) == 2))
                {
                    $scope.old_setup_menu = "TOURNAMENT ROUND ADJUST";
                }*/
                $scope.old_setup_menu_prev = $scope.old_setup_menu;
                $scope.old_setup_menu_data1 = data_input.c_podaci[1];
                /*if (game_data.c_jumpers & JUMPER_TURNIR && (data_input.c_podaci[1] == 3))
                {
                    $scope.old_setup_menu_data2 = Cpu_turnir_data.ee_round_turnir_adjust;
                }
                else */   
                    $scope.old_setup_menu_data2 = eeprom_cpu_values((data_input.c_podaci[1] - 1), 0, Cpu_data);
            } else {
                $scope.old_setup_menu = $scope.old_setup_menu_prev;
                $scope.old_setup_menu_data1 = data_input.c_podaci[1];
                $scope.old_setup_menu_data2 = data_input.c_podaci[2];
                $scope.old_setup_menu_data3 = data_input.c_podaci[3];
            }
            //if (menu_setup_name_toogle[data_input.c_podaci[1] - 1]) $scope.old_setup_menu_toogle = 1;
            if (menu_setup_name_tipke_nav[data_input.c_podaci[1] - 1]) $scope.old_setup_menu_tipke_nav = 1;
            $scope.settings_name = $scope.old_setup_menu;
            /*if ((game_data.c_jumpers & JUMPER_TURNIR) && ((data_input.c_podaci[1]) == 3 || (data_input.c_podaci[1]) == 12))
            {
                $scope.settings_name = "TOURNAMENT ROUND";
            }*/
            /*$scope.old_setup_menu_data1 = data_input.c_podaci[2];
            $scope.old_setup_menu_data2 = data_input.c_podaci[3];*/
        } else if (menu_current_state == 952) //test menu
        {
            if ((data_input.c_podaci[1] > 0) && (data_input.c_podaci[1] < 7)) {
                $scope.old_setup_menu_data1 = "";
                $scope.old_setup_menu_data2 = "";
                $scope.old_setup_menu = menu_test_name[data_input.c_podaci[1] - 1];
                $scope.old_test_menu_mode = data_input.c_podaci[1];
                if ((data_input.c_podaci[1] == 1) && (data_input.c_podaci[2] == 0)) select_test_menu_target_hit(0, 0);
                if ((data_input.c_podaci[1] == 2) && (data_input.c_podaci[2] == 0)) select_test_menu_light_test(0, 0);
                if ((data_input.c_podaci[1] == 3) && (data_input.c_podaci[2] == 0)) select_test_menu_button_test(0, 0);
                if ((data_input.c_podaci[1] == 4) && (data_input.c_podaci[2] == 0)) select_test_menu_tup_infra(4, 0);
                if ((data_input.c_podaci[1] == 5) && (data_input.c_podaci[2] == 0)) select_test_menu_tup_infra(5, 0);
                
                if (data_input.c_podaci[2] > 0) //running testing mode
                {
                    $scope.old_test_menu_data_napomena = "TEST RUNNING...";
                    if (data_input.c_podaci[1] == 1) //target test
                    {

                        $scope.old_setup_menu_data1 = data_input.c_podaci[3];
                        if (($scope.old_setup_menu_data1 < 26)) {
                            select_test_menu_target_hit((data_input.c_podaci[3]), 1);
                        } else if (($scope.old_setup_menu_data1 > 100) && ($scope.old_setup_menu_data1 < 150)) {
                            select_test_menu_target_hit((data_input.c_podaci[3] - 100), 2);
                            $scope.old_setup_menu_data1 = "2 x " + (data_input.c_podaci[3] - 100);
                        } else if (($scope.old_setup_menu_data1 > 150) && ($scope.old_setup_menu_data1 < 200)) {
                            select_test_menu_target_hit((data_input.c_podaci[3] - 150), 4);
                            $scope.old_setup_menu_data1 = "4 x " + (data_input.c_podaci[3] - 150);
                        } else if (($scope.old_setup_menu_data1 > 200) && ($scope.old_setup_menu_data1 < 250)) {
                            select_test_menu_target_hit((data_input.c_podaci[3] - 200), 3);
                            $scope.old_setup_menu_data1 = "3 x " + (data_input.c_podaci[3] - 200);
                        }
                        if ($scope.old_setup_menu_data1 == 0) {
                            select_test_menu_target_hit(0, 0);
                            $scope.old_setup_menu_data1 = "TEST";
                        }
                    }
                    if (data_input.c_podaci[1] == 2) //light test
                    {
                        $scope.old_setup_menu_data1 = data_input.c_podaci[2]
                        if (data_input.c_podaci[2] == 1) {
                            $scope.old_setup_menu_data1 = "ALL ON";
                            $scope.old_test_menu_data_napomena = "TEST RUNNING... ALL ON";
                            select_test_menu_light_test(0, 1);
                        } else if (data_input.c_podaci[2] == 2) {
                            $scope.old_test_menu_data_napomena = "TEST RUNNING... 8 DISP";
                            select_test_menu_light_test(0, 0);
                        } else if (data_input.c_podaci[2] == 3) {
                            $scope.old_test_menu_data_napomena = "TEST RUNNING... ----";
                            $scope.old_setup_menu_data1 = "-";
                        } else if (data_input.c_podaci[2] == 4) {
                            $scope.old_test_menu_data_napomena = "TEST RUNNING... BUTTONS";
                            $scope.old_setup_menu_data1 = "BUTTON";
                        } else if (data_input.c_podaci[2] == 5) {
                            $scope.old_test_menu_data_napomena = "TEST RUNNING... DOTS";
                            $scope.old_setup_menu_data1 = "DOTS";
                        } else if (data_input.c_podaci[2] == 6) {
                            select_test_menu_light_test(menu_test_light_led[data_input.c_podaci[3]], 0);
                            $scope.old_test_menu_data_napomena = "TEST RUNNING... LED";
                            $scope.old_setup_menu_data1 = "LED";
                            $scope.old_setup_menu_data2 = menu_test_light_led[data_input.c_podaci[3]];

                        }
                    }
                    if (data_input.c_podaci[1] == 3) //button test
                    {
                        $scope.old_setup_menu_data1 = menu_test_nazivi_tipke_old[data_input.c_podaci[3] - 1];
                        $scope.old_setup_menu_data2 = "";

                        $scope.select_settings_buttons_paths = [];
                        $scope.select_settings_buttons_top = [];
                        $scope.select_settings_buttons_left = [];
                        $scope.select_settings_buttons_width = [];
                        $scope.select_settings_buttons_hight = [];
                        $scope.select_settings_buttons_data = [];

                        $scope.select_settings_buttons_name_top = 16.5;
                        $scope.select_settings_buttons_font_size = 1.2;
                        let pritisnut_button_broj = data_input.c_podaci[3]; //1-16
                        let pritisnut_button_broj_enumeracija = [0, 6, 7, 15, 14, 0, 4, 9, 10, 8, 12, 11, 1, 2, 13, 5, 3];
                        for (var i = 0; i < 15; i++) {
                            $scope.select_settings_buttons_data.push(i);
                            if ((pritisnut_button_broj_enumeracija[pritisnut_button_broj] == (i + 1)))
                                $scope.select_settings_buttons_paths.push('graphics/i_graphics/test_menu_buttons/test_button_' + String(i + 1) + '_on.png');
                            else
                                $scope.select_settings_buttons_paths.push('graphics/i_graphics/test_menu_buttons/test_button_' + String(i + 1) + '.png');
                        }

                        for (var i = 0; i < 15; i++) {
                            if (i < 7) { $scope.select_settings_buttons_left.push(4 + i * 13.4); } else if (i < 14) { $scope.select_settings_buttons_left.push(4 + (i - 7) * 13.4); } else { $scope.select_settings_buttons_left.push(3 + (3) * 13.4); }

                            if (i < 7) { $scope.select_settings_buttons_top.push(4); } else if (i < 14) { $scope.select_settings_buttons_top.push(28); } else { $scope.select_settings_buttons_top.push(50); }


                            $scope.select_settings_buttons_width.push(11.8);
                            $scope.select_settings_buttons_hight.push(20.0);

                        }
                        $scope.select_settings_buttons_width[14] = 13.9;
                        $scope.select_settings_buttons_hight[14] = 24.2;
                    }
                    if (data_input.c_podaci[1] == 4) //infra test
                    {
                        if (data_input.c_podaci[3]) select_test_menu_tup_infra(4, 1);
                        else select_test_menu_tup_infra(4, 0);
                    }
                    if (data_input.c_podaci[1] == 5) //tup test
                    {
                        if (data_input.c_podaci[3]) select_test_menu_tup_infra(5, 1);
                        else select_test_menu_tup_infra(5, 0);
                    }
                    if (data_input.c_podaci[1] == 6) //credit test
                    {
                        $scope.old_setup_menu_data1 = "TEST";
                        if (data_input.c_podaci[3]) select_test_menu_tup_infra(6, 1);
                        else select_test_menu_tup_infra(6, 0);
                    }
                } else {
                    $scope.old_test_menu_data_napomena = "PRESS BUTTON DOUBLEOUT FOR TEST";
                }
                $scope.settings_name = $scope.old_setup_menu;
            }
            $scope.old_setup_menu_data0 = data_input.c_podaci[0];
            $scope.old_setup_menu_data1 = data_input.c_podaci[1];
            $scope.old_setup_menu_data2 = data_input.c_podaci[2];
            $scope.old_setup_menu_data3 = data_input.c_podaci[3];
        } else if ((menu_current_state == 953) || (menu_current_state == 954)) //bookkeeping mode
        {
            let temp = new Uint32Array(5); // Inicijalizacija niza sa 4 elementa
            let temp_chanell = new Uint32Array(32); // Inicijalizacija niza sa 32 elementa, 16 coin 16 bill

            temp[0] = (data_input.c_podaci[1] << 24) | (data_input.c_podaci[2] << 16) | (data_input.c_podaci[3] << 8) | (data_input.c_podaci[4]);
            temp[1] = (data_input.c_podaci[5] << 24) | (data_input.c_podaci[6] << 16) | (data_input.c_podaci[7] << 8) | (data_input.c_podaci[8]);
            temp[2] = (data_input.c_podaci[9] << 24) | (data_input.c_podaci[10] << 16) | (data_input.c_podaci[11] << 8) | (data_input.c_podaci[12]);
            temp[3] = temp[0] + temp[1] + temp[2];
            temp[4] = temp[3];
            for (let i = 0; i < 32; i++) {
                temp_chanell[i] = (data_input.c_podaci[13 + (i * 4)] << 24) | (data_input.c_podaci[14 + (i * 4)] << 16) |
                    (data_input.c_podaci[15 + (i * 4)] << 8) | (data_input.c_podaci[16 + (i * 4)]);
            }

            $scope.old_setup_menu_data0 = "KEY CREDITS " + String(temp[0]);
            $scope.old_setup_menu_data1 = "COIN CREDITS " + String(temp[1]);
            $scope.old_setup_menu_data2 = "BILL CREDITS " + String(temp[2]);
            $scope.old_setup_menu_data3 = "TOTAL CREDITS " + String(temp[3]);
            let temp_inhibit = "";
            $scope.old_menu_settings_list_top = 16.2; //16.2;		//18.7
            for (let i = 0; i < 16; i++) {
                temp_inhibit = "✓";
                if ((Cpu_data.ee_coin_channel_inhibit & (1 << i)) == 0) temp_inhibit = "✘";
                //$scope.old_menu_settings_list_1.push(String(temp_inhibit) + " Coin ch " + String(i+1) + " , (" + String(Cpu_data.ee_vrijednost_kanala_cctalka[i] * 5) + ")");
                $scope.old_menu_settings_list_1.push(String(temp_inhibit) + " Coin ch " + String(i + 1) + " , (" + String(money_region_names[Cpu_data.ee_vrijednost_kanala_cctalka[i]]) + ")");
                //$scope.old_menu_settings_list_1_data.push('0');
                $scope.old_menu_settings_list_1_data.push(temp_chanell[i]);
                temp_inhibit = "✓";
                if ((Cpu_data.ee_bill_channel_inhibit & (1 << i)) == 0) temp_inhibit = "✘";
                //$scope.old_menu_settings_list_2.push(String(temp_inhibit) + " Bill ch " + String(i+1) + " , (" + String(Cpu_data.ee_vrijednost_kanala_cctalka[i + 16]) + ")");
                $scope.old_menu_settings_list_2.push(String(temp_inhibit) + " Bill ch " + String(i + 1) + " , (" + String(money_region_names_bill[Cpu_data.ee_vrijednost_kanala_cctalka[i + 16]]) + ")");
                //$scope.old_menu_settings_list_2_data.push('0');
                $scope.old_menu_settings_list_2_data.push(temp_chanell[i + 16]);
            }
            //jos jedan red TOTAL

            /*
			let total_current_coins_values_c = 0;
			for (let i = 0; i < 16; i++)
			{
				//total_current_coins_values_c += Cpu_data.ee_vrijednost_kanala_cctalka[i] * 5 * temp_chanell[i];
				total_current_coins_values_c += Cpu_data.ee_vrijednost_kanala_cctalka[i] * 5 * temp_chanell[i];
			}
			total_current_coins_values_c = total_current_coins_values_c / 100.;
			$scope.old_menu_settings_list_1.push('TOTAL: (EUR) ' + String(total_current_coins_values_c.toFixed(2)));
			//$scope.old_menu_settings_list_1_data.push(total_current_coins_values_c.toFixed(2));
	
			total_current_coins_values_c = 0;
			for (let i = 0; i < 16; i++)
			{
				//total_current_coins_values_c += Cpu_data.ee_vrijednost_kanala_cctalka[i + 16] * temp_chanell[i + 16];
				total_current_coins_values_c += Cpu_data.ee_vrijednost_kanala_cctalka[i + 16] * temp_chanell[i + 16];
			}
			$scope.old_menu_settings_list_2.push('TOTAL: (EUR) ' + String(total_current_coins_values_c.toFixed(2)));
			//$scope.old_menu_settings_list_2_data.push(total_current_coins_values_c);
				*/
            /*let channelIndexes = Cpu_data.ee_vrijednost_kanala_cctalka;  // [brojevi 0–89]
            let coinCounts = temp_chanell;                                // [količine po kanalu]
				
            let countrySums = calculateCoinSumsPerCountry(channelIndexes, coinCounts, money_region_names);
            let formatted = Object.entries(countrySums)
            	.map(([country, sum]) => {
            		let euroValue = (sum / 100).toFixed(2); // pretvaranje iz centi u eure
            		return `${country}: ${euroValue}`;
            	})
            	.join(' | ');

            $scope.old_menu_settings_list_1.push('TOTAL: (EUR) ' + formatted);*/
            ///******* */
            $scope.old_menu_settings_list_top_3 = 18.7 + 20;
            for (let i = 0; i < 5; i++) {
                $scope.old_menu_settings_list_3.push(menu_bookkeeping_list_3[i]);
                $scope.old_menu_settings_list_3_data.push(temp[i]);

            }
            $scope.old_menu_settings_list_3_data[3] = '______';
        } else if (menu_current_state == 955) //factory reset
        {
            $scope.old_setup_menu = "HOLD ROULETTE BUTTON";

            $scope.old_menu_settings_list_top_3 = 18.7 + 20;
            if ((data_input.c_podaci[0] == 175) && (data_input.c_podaci[1] == 1)) {
                $scope.old_menu_settings_list_3.push("release ROULETTE button");
                $scope.old_menu_settings_list_3_data.push('');
            } else if ((data_input.c_podaci[0] == 175) && (data_input.c_podaci[1] == 4)) {
                $scope.old_menu_settings_list_3.push("factory reset done");
                $scope.old_menu_settings_list_3_data.push('');
            }


            $scope.old_setup_menu_data0 = data_input.c_podaci[0];
            $scope.old_setup_menu_data1 = data_input.c_podaci[1];
            $scope.old_setup_menu_data2 = data_input.c_podaci[2];
            $scope.old_setup_menu_data3 = data_input.c_podaci[3];
            data_input.c_podaci[1] = -255; //ocisti podatke
        } 
        else if (menu_current_state == 956) //hidden setup
        { 
            //let menu_hidden_setup_language_list = { "HRV", "ITA", "CHE", "DEU", "CZE", "SVK", "POL", "RUS", "SVN", "AUT", "CAK", "FRA", "ENG", "ESP", "PRT" };
        //let menu_hidden_setup_model_types_list = { "V H7", "OBL3", "L-19", "B-63" };
            $scope.old_setup_menu_data0 = data_input.c_podaci[0];
            $scope.old_setup_menu_data1 = data_input.c_podaci[1];
            $scope.old_setup_menu_data2 = data_input.c_podaci[2];
            $scope.old_setup_menu_data3 = data_input.c_podaci[3];

            
            $scope.old_menu_settings_list_top = 36.2; //16.7; //18.7  40.2;
            for (let i = 0; i < 7; i++) {
                $scope.old_menu_settings_list_1.push(menu_hidden_setup_name_list_1_2[i]);
                
                $scope.old_menu_settings_list_1_data.push("");
                $scope.old_menu_settings_list_1_background.push("");
                $scope.old_menu_settings_list_1_data_background.push("");
                
            }
            $scope.old_menu_settings_list_1_data[0] = menu_hidden_setup_language_list[Cpu_data.ee_sett_language];
            $scope.old_menu_settings_list_1_data[1] = Cpu_data.ee_sett_num_acceptors;
            $scope.old_menu_settings_list_1_data[2] = Cpu_data.ee_sett_num_counters;
            $scope.old_menu_settings_list_1_data[3] = "12345678";
            $scope.old_menu_settings_list_1_data[4] = Cpu_data.ee_sett_led_mount;
            $scope.old_menu_settings_list_1_data[5] = menu_hidden_setup_model_types_list[Cpu_data.ee_model_type];
            $scope.old_menu_settings_list_1_data[6] = menu_hidden_setup_model_target_list[Cpu_data.ee_model_target];


            if ($scope.old_menu_settings_list_1_data[4] == 0) $scope.old_menu_settings_list_1_data[4] = 'OFF'; //Cpu_data.ee_sett_led_mount
                else $scope.old_menu_settings_list_1_data[4] = 'ON';

                //oznaka na postavljeni niz
                if (data_input.c_podaci[1] < 8) {
                    $scope.old_menu_settings_list_1_background[(data_input.c_podaci[1] - 1)] = "rgba(190, 127, 46, 0.5)";
                    $scope.old_menu_settings_list_1_data_background[(data_input.c_podaci[1] - 1)] = "rgba(190, 127, 46, 0.5)";
                }
        }
    }

    function select_test_menu_tup_infra(number, multy) //slika infra i tup
    {
        if (number == 4) //infra
        {
            $scope.test_menu_tup_infra_path = 'graphics/i_graphics/test_menu_tup_infra/test_menu_infra_off.png';
            $scope.test_menu_margins_left = 34.4;
            if (multy == 0) {
                $scope.old_test_mode_tup_infra_on = 0;
            } else if (multy == 1) {
                $scope.test_menu_tup_infra_on_1_path = 'graphics/i_graphics/test_menu_tup_infra/test_menu_infra_on_1.png';
                $scope.test_menu_tup_infra_on_2_path = 'graphics/i_graphics/test_menu_tup_infra/test_menu_infra_on_2.png';
                $scope.test_menu_margins_left_on_1 = 20;
                $scope.test_menu_margins_left_on_2 = 70;
                $scope.old_test_mode_tup_infra_on = 1;
            }
        } else if (number == 5) //tup
        {
            $scope.test_menu_tup_infra_path = 'graphics/i_graphics/test_menu_tup_infra/test_menu_tup_off.png';
            $scope.test_menu_margins_left = 38.4;
            if (multy == 0) {
                $scope.old_test_mode_tup_infra_on = 0;
            } else if (multy == 1) {
                $scope.test_menu_tup_infra_on_1_path = 'graphics/i_graphics/test_menu_tup_infra/test_menu_tup_on_1.png';
                $scope.test_menu_tup_infra_on_2_path = 'graphics/i_graphics/test_menu_tup_infra/test_menu_tup_on_2.png';
                $scope.test_menu_margins_left_on_1 = 20;
                $scope.test_menu_margins_left_on_2 = 70;
                $scope.old_test_mode_tup_infra_on = 1;
            }
        } else if (number == 6) //credit
        {
            $scope.test_menu_margins_left = 38.4;
            if (multy == 0) {
                $scope.old_test_mode_tup_infra_on = 0;
            } else if (multy == 1) {
                $scope.test_menu_tup_infra_on_1_path = 'graphics/i_graphics/test_menu_tup_infra/test_menu_tup_on_1.png';
                $scope.test_menu_tup_infra_on_2_path = 'graphics/i_graphics/test_menu_tup_infra/test_menu_tup_on_2.png';
                $scope.test_menu_margins_left_on_1 = 20;
                $scope.test_menu_margins_left_on_2 = 70;
                $scope.old_test_mode_tup_infra_on = 1;
            }
        }
    }

    function select_test_menu_light_test(number, multy) //light test
    {

        if (multy == 1) {
            $scope.test_menu_target_path = 'graphics/i_graphics/test_menu_light/test_menu_light_target_on.png';
        } else {
            $scope.test_menu_target_path = 'graphics/i_graphics/test_menu_light/test_menu_light_target_off.png';

            if (number > 0 && number < 25) $scope.test_menu_target_path = 'graphics/i_graphics/test_menu_light/test_menu_light_target_' + String(number) + '.png';
        }
    }

    function select_test_menu_button_test(number, multy) //light test
    {
        $scope.test_menu_target_path = '';
    }

    function select_test_menu_target_hit(number, multy) //slika mete
    {
        let pom = '';
        if (multy == 1) pom = '_1x';
        else if (multy == 2) pom = '_2x';
        else if (multy == 3) pom = '_3x';
        else if (multy == 4) pom = '_4x';
        let pie_num = 1;
        if (number == 25) pie_num = 25;

        $scope.test_menu_target_path = 'graphics/i_graphics/test_menu_target/test_menu_target_off.png';
        $scope.test_menu_target_pie_path = 'graphics/i_graphics/test_menu_target/test_menu_target_pie_off.png';

        if (number > 0) $scope.test_menu_target_path = 'graphics/i_graphics/test_menu_target/test_menu_target_' + String(number) + pom + '.png';
        if (number > 0) $scope.test_menu_target_pie_path = 'graphics/i_graphics/test_menu_target/test_menu_target_pie_' + String(pie_num) + pom + '.png';
        $scope.test_menu_target_hit_multi = 'x' + multy;
        $scope.test_menu_target_hit_num = number;

    }

    function eeprom_cpu_values(menu_num, menu_value, Cpu_data, ) {

        if (menu_value == 0) {
            // Map menu_num to corresponding Cpu_data variables logically
            if (menu_num == 0) return Cpu_data.ee_price_adjust; // "PRICE ADJUST"
            else if (menu_num == 1) return Cpu_data.ee_happy_price_adjust; // "HAPPY PRICE"
            else if (menu_num == 2) return Cpu_data.ee_round_adjust; // "ROUND ADJUST"
            else if (menu_num == 3) return Cpu_data.ee_happy_round_adjust; // "HAPPY ROUND"
            else if (menu_num == 4) return Cpu_data.ee_setup_time; // "SETUP CLOCK"

            else if (menu_num == 5) return Cpu_data.ee_happy_setup_time; // "SETUP HAPPY HR"
            else if (menu_num == 6) return Cpu_data.ee_bonus_credit; // "BONUS CREDIT"
            else if (menu_num == 7) return Cpu_data.ee_bonus_percent; // "BONUS PERCENT"
            else if (menu_num == 8) return Cpu_data.ee_time_limit; // "TIME LIMIT"
            else if (menu_num == 9) return Cpu_data.ee_counter_pulses; // "COUNTER PULSES"

            else if (menu_num == 10) return Cpu_data.ee_switch_credits; // "SWITCH CREDITS"
            else if (menu_num == 11) return Cpu_data.ee_tcr; // "TIME CREDITS"
            else if (menu_num == 12) return Cpu_data.ee_publicity; // "PUBLICITY"
            else if (menu_num == 13) return Cpu_data.ee_lottery; // "LOTTERY"
            else if (menu_num == 14) return Cpu_data.ee_option_remember; // "OPTIONS REMEMBER"

            else if (menu_num == 15) return Cpu_data.ee_demo_sound; // "DEMO SOUND"
            else if (menu_num == 16) return Cpu_data.ee_quatro_mode_on; // "QUATTRO MODE"
            else if (menu_num == 17) return Cpu_data.ee_sett_target_quattro_on; // "TARGET QUATTRO"
            else if (menu_num == 18) return Cpu_data.ee_return_dart; // "RETURN DART"
            else if (menu_num == 19) return Cpu_data.ee_bull_value; // "BULL VALUE"

            else if (menu_num == 20) return Cpu_data.ee_play_off; // "PLAYOFF"
            else if (menu_num == 21) return Cpu_data.ee_lamp_on; // "LAMP ON"
            else if (menu_num == 22) return Cpu_data.ee_main_lamp; // "MAINLAMP"
            else if (menu_num == 23) return Cpu_data.ee_back_light; // "BACK LIGHT"
            else if (menu_num == 24) return Cpu_data.ee_sett_rpi_mount; // "LED LIGHT"  RPI MOUNT

            else if (menu_num == 25) return Cpu_data.ee_infra_adjust; // "INFRA ADJUST"
            else if (menu_num == 26) return Cpu_data.ee_ppd_statistics; // "STATISTICS"
            else if (menu_num == 27) return Cpu_data.ee_coin_value; // "COIN CCTALK"
            else if (menu_num == 28) return Cpu_data.ee_acceptor_time_adjust; // "BILL CCTALK"
            else if (menu_num == 29) return Cpu_data.ee_vrijednost_impulsa_kanala[0]; // "COIN PULSE"

            else if (menu_num == 30) return Cpu_data.ee_vrijednost_impulsa_kanala[1]; // "BILL PULSE"
            else if (menu_num == 31) return Cpu_data.ee_cijena_jednog_kredita; // "PRICE 1CREDIT"
            else if (menu_num == 32) return Cpu_data.ee_tup_sense; // "TUP ADJUST"
            else if (menu_num == 33) return Cpu_data.ee_acceptor_time_adjust; // "ACCEPTOR TIME"

        } else if (menu_value == 1) {
            return "other";
        }
        return "";
    }

    function select_settings_name(menu_current_state) {
        if (menu_current_state == 800) $scope.settings_name = 'SETTINGS';

        if (menu_current_state == 801) $scope.settings_name = 'SETUP';
        if (menu_current_state == 901) $scope.settings_name = 'TEST MENU';
        if (menu_current_state == 981) $scope.settings_name = 'BOOKKEEPING';

        if (menu_current_state == 802) $scope.settings_name = 'GAME SETTINGS';
        if (menu_current_state == 803) $scope.settings_name = 'DART SETTINGS';
        if (menu_current_state == 804) $scope.settings_name = 'MONEY CREDITS';
        if (menu_current_state == 805) $scope.settings_name = 'FACTORY RESET';

        if (menu_current_state == 810) $scope.settings_name = 'ROUND SETTINGS';
        if (menu_current_state == 811) $scope.settings_name = 'QUATTRO MODE';
        if (menu_current_state == 812) $scope.settings_name = 'RETURN DART';
        if (menu_current_state == 813) $scope.settings_name = 'OPTION REMEMBER';
        if (menu_current_state == 814) $scope.settings_name = 'TOURNAMENT MODE';
        if (menu_current_state == 815) $scope.settings_name = 'ORDER MODE';

        if (menu_current_state == 830) $scope.settings_name = 'LED';
        if (menu_current_state == 831) $scope.settings_name = 'DEMO MODE';
        if (menu_current_state == 832) $scope.settings_name = 'NETWORK';
        if (menu_current_state == 833) $scope.settings_name = 'INFRARED';
        if (menu_current_state == 834) $scope.settings_name = 'RFID';
        if (menu_current_state == 835) $scope.settings_name = 'FINGER PRINT';

        if (menu_current_state == 850) $scope.settings_name = 'COIN ACCEPTOR';
        if (menu_current_state == 851) $scope.settings_name = 'BILL ACCEPTOR';
        if (menu_current_state == 852) $scope.settings_name = 'GAME PRICE';
        if (menu_current_state == 853) $scope.settings_name = 'HAPPY PRICE';
        if (menu_current_state == 854) $scope.settings_name = 'HAPPY HOUR';
        if (menu_current_state == 855) $scope.settings_name = 'KEY CREDITS';

        if (menu_current_state == 856) $scope.settings_name = 'BONUS CREDITS';
        if (menu_current_state == 857) $scope.settings_name = 'LOTTERY';
        if (menu_current_state == 858) $scope.settings_name = 'TIME CREDITS';
        if (menu_current_state == 859) $scope.settings_name = 'FREE PLAY';
        if (menu_current_state == 860) $scope.settings_name = 'CREDIT MODE';
        if (menu_current_state == 861) $scope.settings_name = 'CURRENCY';

        if (menu_current_state == 910) $scope.settings_name = 'TEST TARGET';
        if (menu_current_state == 911) $scope.settings_name = 'TEST LIGHT';
        if (menu_current_state == 912) $scope.settings_name = 'TEST BUTTON';
        if (menu_current_state == 913) $scope.settings_name = 'TEST INFRA';
        if (menu_current_state == 914) $scope.settings_name = 'TEST TUP';

        if (menu_current_state == 915) $scope.settings_name = 'TEST CREDIT';
        if (menu_current_state == 916) $scope.settings_name = 'TEST MONITOR';
        if (menu_current_state == 917) $scope.settings_name = 'TEST CALIBRATION';
        if (menu_current_state == 918) $scope.settings_name = 'TEST RFID';
        if (menu_current_state == 919) $scope.settings_name = 'TEST NETWORK';

        if (menu_current_state == 920) $scope.settings_name = 'TEST SOUND';
        if (menu_current_state == 921) $scope.settings_name = 'TEST CAMERA';
        if (menu_current_state == 922) $scope.settings_name = '';
        if (menu_current_state == 923) $scope.settings_name = '';
        if (menu_current_state == 924) $scope.settings_name = '';

        select_settings_name_icon_path(menu_current_state);
        select_settings_buttons_dim(menu_current_state);
    }

    function select_settings_name_icon_path(menu_current_state) {
        if (menu_current_state == 800) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/settings.png';
        if (menu_current_state == 801) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/setup.png';
        if (menu_current_state == 901) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_menu.png';
        if (menu_current_state == 981) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/bookkeeping.png';

        if (menu_current_state == 802) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/game_settings.png';
        if (menu_current_state == 803) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/dart_settings.png';
        if (menu_current_state == 804) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/money_credits.png';
        if (menu_current_state == 805) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/factory_reset.png';

        if (menu_current_state == 810) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/round_settings.png';
        if (menu_current_state == 811) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/quattro_mode.png';
        if (menu_current_state == 812) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/return_dart.png';
        if (menu_current_state == 813) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/option_remember.png';
        if (menu_current_state == 814) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/tournament_mode.png';
        if (menu_current_state == 815) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/order_mode.png';

        if (menu_current_state == 830) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/led.png';
        if (menu_current_state == 831) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/demo_mode.png';
        if (menu_current_state == 832) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/network.png';
        if (menu_current_state == 833) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/infrared.png';
        if (menu_current_state == 834) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/rfid.png';
        if (menu_current_state == 835) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/fingerprint.png';

        if (menu_current_state == 850) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/coin_acceptor.png';
        if (menu_current_state == 851) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/bill_acceptor.png';
        if (menu_current_state == 852) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/game_price.png';
        if (menu_current_state == 853) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/happy_price.png';
        if (menu_current_state == 854) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/happy_hour.png';
        if (menu_current_state == 855) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/key_credits.png';

        if (menu_current_state == 856) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/bonus_credits.png';
        if (menu_current_state == 857) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/lottery.png';
        if (menu_current_state == 858) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/time_credits.png';
        if (menu_current_state == 859) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/free_play.png';
        if (menu_current_state == 860) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/credit_mode.png';
        if (menu_current_state == 861) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/currency.png';

        if (menu_current_state == 910) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_target.png';
        if (menu_current_state == 911) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_light.png';
        if (menu_current_state == 912) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_button.png';
        if (menu_current_state == 913) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_infra.png';
        if (menu_current_state == 914) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_tup.png';

        if (menu_current_state == 915) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_credit.png';
        if (menu_current_state == 916) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_monitor.png';
        if (menu_current_state == 917) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_calibration.png';
        if (menu_current_state == 918) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_rfid.png';
        if (menu_current_state == 919) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_network.png';

        if (menu_current_state == 920) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_sound.png';
        if (menu_current_state == 921) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/test_camera.png';
        if (menu_current_state == 922) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/.png';
        if (menu_current_state == 923) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/.png';
        if (menu_current_state == 924) $scope.settings_name_icon_path = 'graphics/i_graphics/settings_icons/.png';

    }

    function select_settings_buttons_dim(menu_current_state) {
        $scope.select_settings_buttons_paths = [];
        $scope.select_settings_buttons_data = [];
        $scope.select_settings_buttons_top = [];
        $scope.select_settings_buttons_left = [];
        $scope.select_settings_buttons_width = [];
        $scope.select_settings_buttons_hight = [];

        $scope.select_settings_buttons_id = [];

        $scope.select_settings_buttons_name_top = 0;
        $scope.select_settings_buttons_font_size = 1.8;
        if (menu_current_state == 800) /*SETTINGS */ {
            $scope.select_settings_buttons_name_top = 30;
            $scope.select_settings_buttons_font_size = 2.4;
            $scope.select_settings_buttons_data = ["SETUP", "TEST MENU", "BOOKKEEPING"];
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/setup.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/bookkeeping.png');
            $scope.select_settings_buttons_id.push(801);
            $scope.select_settings_buttons_id.push(901);
            $scope.select_settings_buttons_id.push(981);
            for (var i = 0; i < 3; i++) {
                $scope.select_settings_buttons_left.push(16.3 + i * 26);
                $scope.select_settings_buttons_top.push(19);
                $scope.select_settings_buttons_width.push(15.5);
                $scope.select_settings_buttons_hight.push(27.5);
            }
        } else if (menu_current_state == 801) /*SETUP */ {
            $scope.select_settings_buttons_name_top = 26;
            $scope.select_settings_buttons_font_size = 1.8;
            $scope.select_settings_buttons_data = ["GAME SETTINGS", "DART SETTINGS", "MONEY CREDITS", "FACTORY RESET"];
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/game_settings.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/dart_settings.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/money_credits.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/factory_reset.png');
            for (var i = 0; i < 4; i++) {
                $scope.select_settings_buttons_left.push(11 + i * 21.6);
                $scope.select_settings_buttons_top.push(19);
                $scope.select_settings_buttons_id.push(802 + i);
                $scope.select_settings_buttons_width.push(13.5);
                $scope.select_settings_buttons_hight.push(24);
            }
        } else if (menu_current_state == 802) /*GAME SETTINGS */ {
            $scope.select_settings_buttons_name_top = 26;
            $scope.select_settings_buttons_font_size = 1.6;
            $scope.select_settings_buttons_data = ["ROUND SETTINGS", "QUATTRO MODE", "RETURN DART", "OPTION REMEMBER", "TOURNAMENT MODE", "ORDER MODE"];
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/round_settings.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/quattro_mode.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/return_dart.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/option_remember.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/tournament_mode.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/order_mode.png');
            for (var i = 0; i < 6; i++) {
                if (i < 4) { $scope.select_settings_buttons_left.push(11 + i * 21.6); } else { $scope.select_settings_buttons_left.push(11 + (i - 3) * 21.6); }
                if (i < 4) { $scope.select_settings_buttons_top.push(3); } else { $scope.select_settings_buttons_top.push(41); }
                $scope.select_settings_buttons_id.push(810 + i);
                $scope.select_settings_buttons_width.push(13.5);
                $scope.select_settings_buttons_hight.push(24);
            }
        } else if (menu_current_state == 803) /*DART SETTINGS */ {
            $scope.select_settings_buttons_name_top = 26;
            $scope.select_settings_buttons_font_size = 1.6;
            $scope.select_settings_buttons_data = ["LED", "DEMO MODE", "NETWORK", "INFRARED", "RFID", "FINGERPRINT"];
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/led.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/demo_mode.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/network.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/infrared.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/rfid.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/fingerprint.png');
            for (var i = 0; i < 6; i++) {
                if (i < 4) { $scope.select_settings_buttons_left.push(11 + i * 21.6); } else { $scope.select_settings_buttons_left.push(11 + (i - 3) * 21.6); }
                if (i < 4) { $scope.select_settings_buttons_top.push(3); } else { $scope.select_settings_buttons_top.push(41); }
                $scope.select_settings_buttons_id.push(830 + i);
                $scope.select_settings_buttons_width.push(13.5);
                $scope.select_settings_buttons_hight.push(24);
            }
        } else if (menu_current_state == 804) /*MONEY CREDITS */ {
            $scope.select_settings_buttons_name_top = 16.5;
            $scope.select_settings_buttons_font_size = 1.2;
            $scope.select_settings_buttons_data = ["COIN ACCEPTOR", "BILL ACCEPTOR", "GAME PRICE", "HAPPY PRICE", "HAPPY HOUR", "KEY CREDITS", "BONUS CREDITS", "LOTTERY", "TIME CREDITS", "FREEE PLAY", "CREDIT MODE", "CURRENCY"];

            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/coin_acceptor.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/bill_acceptor.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/game_price.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/happy_price.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/happy_hour.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/key_credits.png');

            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/bonus_credits.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/lottery.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/time_credits.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/free_play.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/credit_mode.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/currency.png');
            for (var i = 0; i < 12; i++) {
                if (i < 6) { $scope.select_settings_buttons_left.push(12 + i * 13.4); } else { $scope.select_settings_buttons_left.push(12 + (i - 6) * 13.3); }
                if (i < 6) { $scope.select_settings_buttons_top.push(12); } else { $scope.select_settings_buttons_top.push(44); }
                $scope.select_settings_buttons_id.push(850 + i);
                $scope.select_settings_buttons_width.push(8.8);
                $scope.select_settings_buttons_hight.push(15.6);
            }

        } else if (menu_current_state == 805) /*FACTORY RESET */ {
            $scope.select_settings_buttons_name_top = 26;
            $scope.select_settings_buttons_font_size = 1.8;
            $scope.select_settings_buttons_data = ["YES", "NO"];
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/setup.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_menu.png');
            for (var i = 0; i < 2; i++) {
                $scope.select_settings_buttons_left.push(20 + (i + 1) * 20);
                $scope.select_settings_buttons_top.push(30);
                $scope.select_settings_buttons_id.push(890 + i);
                $scope.select_settings_buttons_width.push(13.5);
                $scope.select_settings_buttons_hight.push(24);
            }
        } else if (menu_current_state == 901) /*TEST MENU */ {
            $scope.select_settings_buttons_name_top = 15;
            $scope.select_settings_buttons_font_size = 1.8;
            $scope.select_settings_buttons_data = [
                "TEST TARGET", "TEST LIGHT", "TEST BUTTON", "TEST INFRA", "TEST TUP",
                "TEST CREDIT", "TEST MONITOR", "TEST CALIBRATION", "TEST RFID", "TEST NETWORK",
                "TEST SOUND", "TEST CAMERA"
            ];

            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_target.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_light.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_button.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_infra.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_tup.png');

            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_credit.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_monitor.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_calibration.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_rfid.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_network.png');

            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_sound.png');
            $scope.select_settings_buttons_paths.push('graphics/i_graphics/settings_buttons/test_camera.png');

            for (var i = 0; i < 12; i++) {
                if (i < 5) { $scope.select_settings_buttons_left.push(15 + i * 15); } else if (i < 10) { $scope.select_settings_buttons_left.push(15 + (i - 5) * 15); } else { $scope.select_settings_buttons_left.push(15 + (i - 10) * 15); }
                if (i < 5) { $scope.select_settings_buttons_top.push(10); } else if (i < 10) { $scope.select_settings_buttons_top.push(30); } else { $scope.select_settings_buttons_top.push(50); }
                $scope.select_settings_buttons_id.push(910 + i);
                $scope.select_settings_buttons_width.push(13.5);
                $scope.select_settings_buttons_hight.push(24);
            }
        } else if (menu_current_state == 981) /*BOOKKEEPING */ {

        }

    }
    /*
    	function calculateCoinSumsPerCountry(channelIndexes, coinCounts, moneyRegionNames) {
    		const countryTotals = {};  // npr. { CZ: 40, EU: 200, ... }
    	
    		for (let i = 0; i < channelIndexes.length; i++) {
    			const enumIndex = channelIndexes[i];       // npr. 20 → "CZ010"
    			const count = coinCounts[i];               // broj kovanica u tom kanalu
    	
    			if (enumIndex <= 0 || enumIndex >= moneyRegionNames.length) continue;
    	
    			const coinCode = moneyRegionNames[enumIndex];  // npr. "CZ010"
    			if (typeof coinCode !== "string" || coinCode.length < 5) continue;
    	
    			const country = coinCode.substring(0, 2);       // "CZ"
    			const valueStr = coinCode.substring(2);         // "010"
    			const value = parseInt(valueStr, 10);           // 10
    	
    			if (isNaN(value)) continue;
    	
    			const subtotal = value * count;
    	
    			if (!countryTotals[country]) {
    				countryTotals[country] = 0;
    			}
    			countryTotals[country] += subtotal;
    		}
    	
    		return countryTotals;
    	}
    	*/

    socket.on('RPI>MONITOR:testCamera', function(id, data) {
        if (id !== $scope.deviceId) {
            return;
        }

        $scope.menuState = 1000;
        $scope.$apply();
        initalaizeSlefVideo(false, true, false, 0);
    });

    socket.on('RPI>MONITOR:exitTestCamera', function(id, data) {
        if (id !== $scope.deviceId) {
            return;
        }

        closeSelfVideo();
        $scope.menuState = 0;
        $scope.$apply();
    });

    socket.on('RPI>MONITOR:sendNetworkStatus', function(id, status) {
        if (id !== $scope.deviceId) {
            return;
        }
        $scope.networkStatus = status ? 'ONLINE' : 'OFFLINE';
        $scope.connected = status;
        $scope.$apply();
    });

    socket.on('RPI>MONITOR:enterLineDetection', function(id) {
        console.log('GOT ENTER LINE DETECTION MENU SOCKET');
        if (id !== $scope.deviceId) {
            return;
        }
        $scope.menuState = 1100;
        $scope.$apply();
    })

    socket.on('RPI>MONITOR:sendLineDetect', function(id) {
        console.log('GOT LINE DETECTION SOCKET, CHANGING PATH')
        if (id !== $scope.deviceId) {
            return;
        }
        $scope.imgPath = 'lineShottest.jpg'
        $scope.$apply();
    });


    function getCookie(cname) {
        let name = cname + '=';
        let ca = document.cookie.split(';');
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return '';
    }



    function reinitializeVideo(players, currentPlayerId) {
        closeMediaConnection();
        setTimeout(function() {
            initalaziePeer(localId, function() {
                initalaizeMediaConnection(false, true, false, players, currentPlayerId);
            });
        }, 1000);
    }
});