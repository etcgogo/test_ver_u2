const Player = require('../game/player');
const OtherRules = require('../game/otherGamerules');
const x01Rules = require('../game/x01Rules');
const CricketRules = require('../game/cricketRules');
const x01Game = require('../game/x01Game');
const CricketGame = require('../game/cricketGame');
const MenuService = require('../objects/MenuService');
const Dart = require('../game/dart');

function createGame(game, rules, teamedPlayers, teams) {
	const playerArray = teamedPlayers.map(_player => new Player(
		_player.id, 
		_player.name, 
		_player.type || 0, 
		_player.teamIndex,
		_player.copyOfType || _player.type || 0,
		_player.owner
	));
	return game.create(rules, playerArray, teams);
}

module.exports = {
	game: null,
	newGame: function(rules, teamedPlayers, teams) {
		console.log(rules instanceof OtherRules && (rules.gameType === 1));
		console.log(rules instanceof x01Rules);
		console.log(rules instanceof OtherRules  && (rules.gameType === 2));
		console.log('TEAMS', teams);
		if (rules instanceof x01Rules || (rules instanceof OtherRules  && (rules.gameType === 1))) {
			this.game = new x01Game();
		} else if (rules instanceof CricketRules || (rules instanceof OtherRules  && (rules.gameType === 2))) {
			console.log('NEW CRICKET GAME!')
			this.game = new CricketGame();
		} else if (MenuService.isX01 || (MenuService.isOther && rules.gameType === 1)) {
			console.log('new game x01');
			this.game = new x01Game();
		} else if (MenuService.isCricket || (MenuService.isOther && rules.gameType === 2)) {
			console.log('new game cricket');
			this.game = new CricketGame();
			this.game.rules.numbersToClose = MenuService.resumeRules.numbersToClose;
			this.game.awaitApproach = MenuService.resumeApproach;
		}
		createGame(this.game, rules, teamedPlayers, teams);
		return true;
	},
	dartThrown: function(score, multiplier) {
		var isDouble = multiplier === 2;
		var isTriple = multiplier === 3 && score !== 25;
		var isQuatro = multiplier === 4 && score !== 25;
		var dart = new Dart(score, isDouble, isTriple, isQuatro, this.game.rules.quatro);
		return this.game.addDart(dart);
	},
	nextPlayer: function() {
		if (this.game.rules.runAndGun) {
			this.game.handleRunAndGunNexting();
		}
			this.game.irApproach();
			this.game.irLeave();
	},
	approach: function() {
		this.game.irApproach();
	},
	leave: function() {
		this.game.irLeave();
	},
	undo: function() {
		this.game.undoLastDart();
	},
	redo: function() {
		this.game.redoLastDart();
	},
	getLeaderBoard: function() {
		this.game.getLeaderBoard();
	},
	subscribeToTimeGame: function(callback) {
		this.game.subscribeToTimeGame(callback);
	}
};
