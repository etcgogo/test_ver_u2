#!/usr/bin/env python3
import sys, time, serial, argparse, os

def normalize_hex_lines(text: str):
    out = []
    for ln in text.splitlines():
        ln = ln.strip()
        if not ln:
            continue
        if ln[0] != ':':
            idx = ln.find(':')
            if idx < 0:
                continue
            ln = ln[idx:]
        out.append(ln + '\n')
    return out

def wait_for_keyword(ser, keyword: bytes, timeout: float):
    """Čeka 'keyword' u RX streamu najviše timeout sekundi; vrati True ako nađe."""
    deadline = time.time() + timeout
    buf = b""
    kwlen = len(keyword)
    while time.time() < deadline:
        try:
            chunk = ser.read(64)
        except serial.SerialException as e:
            print("Serial read error:", e)
            return False
        if chunk:
            buf += chunk
            sys.stdout.write(chunk.decode('ascii', errors='ignore'))
            sys.stdout.flush()
            if keyword in buf[-(kwlen+128):]:
                return True
    return False

def main():
    ap = argparse.ArgumentParser(description="Šalje Intel HEX ATmega128A bootloaderu (USART0).")
    ap.add_argument("port")
    ap.add_argument("hexfile")
    ap.add_argument("--baud", type=int, default=19200)
    ap.add_argument("--wait", type=float, default=6.0, help="Koliko sekundi čekati 'SENDHEX' (default 6)")
    ap.add_argument("--dtr-reset", action="store_true", help="DTR puls za auto-reset")
    ap.add_argument("--line-delay", type=float, default=0.0, help="Pauza nakon SVAKOG retka (s)")
    args = ap.parse_args()

    if not os.path.isfile(args.hexfile):
        print("HEX datoteka ne postoji:", args.hexfile)
        sys.exit(1)

    with open(args.hexfile, "r", encoding="utf-8", errors="ignore") as f:
        lines = normalize_hex_lines(f.read())
    if not lines:
        print("Prazan ili nevažeći HEX.")
        sys.exit(1)

    total = len(lines)

    ser = serial.Serial(args.port, args.baud, timeout=0.2)
    try:
        if args.dtr_reset:
            ser.dtr = False; time.sleep(0.05)
            ser.dtr = True;  time.sleep(0.05)
            ser.dtr = False

        ser.reset_input_buffer()
        ser.reset_output_buffer()

        # ⚡ pošalji ':' odmah da bootloader ostane unutra
        ser.write(b':')
        ser.flush()
        time.sleep(0.05)

        print("wait 'SENDHEX'...", flush=True)
        if not wait_for_keyword(ser, b"SENDHEX", args.wait):
            print("Upozorenje: nema 'SENDHEX' (nastavljam svejedno).")

        sent = 0
        for ln in lines:
            ser.write(ln.encode('ascii'))
            ser.flush()
            sent += 1

            # ispis progres statusa
            percent = (sent * 100) // total
            print(f"\rSlanje: {sent}/{total} redaka ({percent}%)", end='', flush=True)

            try:
                resp = ser.read(32)
            except serial.SerialException as e:
                print("\nSerial read error:", e)
                break

            if resp:
                sys.stdout.write(resp.decode('ascii', errors='ignore'))
                sys.stdout.flush()

            if args.line_delay > 0:
                time.sleep(args.line_delay)

        # Pričekaj završni ACK ('K')
        time.sleep(0.2)
        try:
            tail = ser.read(128)
        except serial.SerialException as e:
            print("\nSerial read error:", e)
            tail = b""

        print()  # novi red nakon progres linije

        if tail:
            txt = tail.decode('ascii', errors='ignore')
            print(txt, end='')
            if 'K' in txt:
                print("\nOK: bootloader potvrdio EOF (K).")
        else:
            print("Upozorenje: nema završne poruke.")

        print(f"Poslano {sent} HEX redaka od {total}.")
    finally:
        ser.close()

if __name__ == "__main__":
    main()
