var Omx = require('node-omxplayer');
var player = '';
let videoplay = false;
videodemotimout = 5000;
let video_timer='';

 
function action(credit){
    //console.log('ima li kredita',credit);
    if(videoplay && credit !== 0){
        //console.log('sad gasim video jel imam kredita',player.running);
        stop();
    }
    if(videoplay && credit === 0){
       // console.log('sad gasim stop resume',player.running);
        videoplay = false;
        stop_resume();
    }
    else if(!videoplay && credit === 0){
        videoplay = true;
        //console.log('sad playam video',player.running);
        clearTimeout(video_timer);
        video_timer = setTimeout(() => {
            play();
        }, videodemotimout);
    }
}

function play(){
    //console.log('dali video radi',player.running);
    if(!player.running){
        player = Omx('./Video/demo.mp4','',true,'');
    }
       
}
function stop_resume(){
    try {
        player.quit();
        clearTimeout(video_timer);
        video_timer = setTimeout(() => {
            play();
        }, videodemotimout);
    }
    catch(err) { 
        //console.log('player je vec ugasen');
    }
}
function stop(){
    try {
        player.quit();
        clearTimeout(video_timer);
    }
    catch(err) { 
        //console.log('player je vec ugasen');
    }
}



module.exports = {
    action:action
}