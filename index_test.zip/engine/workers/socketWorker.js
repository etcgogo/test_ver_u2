const mongo = require('../objects/mongo');
const constant = require('../const/const');
const variables = require('../const/varibales');
const ErrorHandeler = require('../objects/errorHandeler');
//const wifiWorker = require('./wifiWorker'); ivan vukoja wifi worker
const socketEnum = require('../const/socketEnums');
const fset = require('../objects/fset');
var bookkeeping = require('../../current_data/bookkeeping.json');
var Setup_data = require('../../current_data/Setup_data.json');
var gameResume = require('../../current_data/gameResume.json');
const { Cpu_data } = require('../const/varibales');

const serialPort = require('./serialPortWorker');
const shared = require('./sharedState');


module.exports = function (pio, jsonfile, log) {
    fset.isInternetUp(function (result) {
        //console.log('is internet up',result);
        variables.Display_data.isDeviceOnline = result;
    });

    setInterval(function () {
        fset.isInternetUp(function (result) {
            if (result !== variables.Display_data.isDeviceOnline) {
                pio.emit(socketEnum.SEND_NETWORK_STATUS, variables.deviceId, variables.Display_data.isDeviceOnline);
                variables.Display_data.isDeviceOnline = result;
            }
        });
    }, 5000);
    //preko tableta odabir
    pio.on('connection', function (socket) {
        socket.on(socketEnum.REQUEST_INIT_DATA_MONITOR, function (id) { ///Ivan vukoja init-data
            log('socket', 'monitor request init data = monitor needs some data to show at device boot');
            //let data = mongo.getHit(); //ovo nije dobro odradeno
            let object = {};
            //console.log('variables.Display_data', variables.Display_data);
            console.log('OVAJ ID JE POSLAO PORUKU!!!', id);
            
            /*for (let i = 0; i < variables.Cpu_other_data.c_podaci.length; i++) {
                variables.Cpu_other_data.c_podaci[i] = 0; // Postavlja sve elemente na 255
            }*/
            //console.log('ovo je poruka!!!', variables.Cpu_data);
            object.Cpu_game_data = variables.Cpu_game_data;     //postavke igre offline
            object.Cpu_settings_data = variables.Cpu_settings_data;     //postavke igre online
            object.Cpu_data = variables.Cpu_data;
            object.Display_data = variables.Display_data;
            object.Setup_data = Setup_data;
            object.Cpu_other_data = variables.Cpu_other_data;
            object.Cpu_settings_turnir_data = variables.Cpu_settings_turnir_data;
            //object.credits = variables.Cpu_data.credit;
            //object.buffer = 0;
            //object.gamePrice = setupMode.ee_price_adjust[variables.game];
            //object.isOnline = variables.isDeviceOnline;
            //object.gameName = variables.gameName;
            //object.gameOptions = variables.GameOptionName;
            //object.gameMode = variables.gameMode;
            //object.gameResume = data;  povwezano sa mongo get hit
            socket.emit(socketEnum.SEND_INIT_DATA_MONITOR, object);
            
        });
        /*
        $scope.select_game_color_background = [];
	$scope.select_option_mode_x01_color_background = [];
	$scope.select_option_mode_cricket_color_background = [];
	$scope.select_num_of_set_color_background = [];
	$scope.select_num_of_leg_color_background = [];
	$scope.select_num_of_players_color_background = [];
	$scope.select_id_players_color_background = [];
	$scope.select_num_of_teams_color_background = [];
    */ //Goran
        socket.on(socketEnum.ZAHTJEV_SETTINGS_PARAMETARA, function(temp) {
            log('socket', 'ZAHTJEV_SETTINGS_PARAMETARA');
            serialPort.protocolx_write("", constant.CMD_RETURN_GAME_SETTINGS);
            serialPort.protocolx_write("", constant.CMD_RETURN_GAME_SETTINGS);
        });

        //console.log('python------------------------')	
	/*const py = spawn('python3', ['./engine/workers/RFID.py']);
	py.stdout.on('data', function (data) {
		const out = JSON.parse(data);
		//console.log('Ime igraca ' + out.name);
		if(variables.Cpu_data.num_players !== 8){
			//console.log('rfid jel prazan',variables.Cpu_data.rfid)
			if(!variables.Cpu_data.rfid.includes(out.name)){
				//console.log('jel ude rfid ovdje')
				variables.Cpu_data.rfid.push({name:out.name,position:variables.Cpu_data.num_players})
				writeSerial(Buffer.from(mongo.sendGameData(constant.setgamedata), constant.HEX_B));
			}
		}
	});
    */
        socket.on(socketEnum.ZAHTJEV_BOOTLOADER_UPDATE, function (temp) {
            console.log('socket', 'ZAHTJEV_BOOTLOADER_UPDATE');
            console.log('sending command');
            console.log("⚡ Restart flag active, sendind reset command for bootloading...");
            shared.var_restart = 1;
            let podaci_za_slanje = new Uint8Array([0xA9, 0xA9, 0xA9, 0xA9]);
            serialPort.protocolx_write(podaci_za_slanje, 0xA9);  //ovo je reset CPU $AB$05$A9$A9$A9$A9$A9$4D$BA
            /*write_serial.protocolx_write("", constant.CMD_RETURN_GAME_SETTINGS);
            serialPort.writeSerial(fset.createSensitivityOrder(1, sens));
            let data_final = new Uint8Array([0xAB, 0x05, 0xA9, 0xA9, 0xA9, 0xA9, 0xA9, 0x4D, 0xBA]);
            serialPort.writeSerial(data_final);*/
            
        });
        socket.on(socketEnum.PRIJAM_PODATAKA_QUIT_MENU, function (temp) {
            console.log('socket', 'PRIJAM_PODATAKA_QUIT_MENU value' , temp);
            console.log('sending command');
            
            if (temp == 0) serialPort.protocolx_write("", 0x83);  //ovo je button_quit_game $AB$01$83$84$BA
            if (temp == 1) serialPort.protocolx_write("", 0x84);  //ovo je button_return_dart $AB$01$84$85$BA
            if (temp == 2) serialPort.protocolx_write("", 0x85);  //ovo je insufficient credit beep $AB$01$85$86$BA
            
            /*write_serial.protocolx_write("", constant.CMD_RETURN_GAME_SETTINGS);
            serialPort.writeSerial(fset.createSensitivityOrder(1, sens));
            let data_final = new Uint8Array([0xAB, 0x05, 0xA9, 0xA9, 0xA9, 0xA9, 0xA9, 0x4D, 0xBA]);
            serialPort.writeSerial(data_final);*/
            
        });

            //const { exec, spawn } = require('child_process');
            /*
            // 1) ZAUSTAVI systemd servis
            exec('sudo systemctl stop myapp.service', (err, stdout, stderr) => {
                if (err) {
                    console.error('Greska pri zaustavljanju servisa:', err);
                    return;
                }
                if (stdout) console.log(stdout.trim());
                if (stderr) console.error(stderr.trim());
                console.log('stop myapp service');
                
                // 2) POKRENI PYTHON skriptu
                setTimeout(() => {
                    const args = [
                        './engine/workers/boot_loader.py',
                        '/dev/ttyS0',
                        './engine/workers/update_files/boot_loader1.hex',
                        '--baud', '57600'
                      ];
                    const args = ['./engine/workers/send_hex.py'];
                    const p = spawn('python3', args, { stdio: 'inherit' });
                    console.log('python started');
                    p.on('error', (e) => console.error('Ne mogu pokrenuti Python:', e));
                    p.on('close', (code) => {
                        console.log('Uploader završio s kodom', code);
                        // 3) START
                        // exec('sudo systemctl start myapp.service', () => {});
                        exec('sudo systemctl start myapp.service', (err2, stdout2, stderr2) => {
                            if (err2) {
                                console.error('Greska pri pokretanju servisa:', err2);
                                return;
                            }
                            if (stdout2) console.log(stdout2.trim());
                            if (stderr2) console.error(stderr2.trim());
                            console.log('myapp.service pokrenut.');
                        });
                    });
                 }, 1000); // 1 sekunda pauze
            });
        });*/
            

        socket.on(socketEnum.PRIJAM_PODATAKA_ODABIR_IGRE, function (game_ar, 
            option_x01_ar,
            option_quattro_ar,
            option_cricket_ar,
            num_of_set_ar,
            num_of_leg_ar,
            num_of_players_ar,
            id_players_ar,
            num_of_teams_ar,
            pick_it_num_ar,
            game_id) { ///goran monitor data
            let game, option_x01, option_quattro, option_cricket, num_of_set, num_of_leg, num_of_players, id_players, num_of_teams, pick_it_num;
            log('socket', 'PRIJAM_PODATAKA_ODABIR_IGRE');
            //prevedi podatke iz polja RGB u broj
            for (var i = 0; i < 26; i++) {
                if (game_ar[i] != ('#000000')) 
                {
                    game = i;
                    break;
                }
            }
            //provjeri za opcije RnG i Parchessi koje su u game
            let game_rng_par = 0;
            pick_it_num = pick_it_num_ar;
            if (option_quattro_ar != ('#ffffff')) option_quattro = 1;
            else option_quattro = 0;

            if (game_ar[10] != ('#000000')) game_rng_par = 10;
            if (game_ar[11] != ('#000000')) game_rng_par = 11;
            option_x01 = 0;
            option_cricket = 0;
            let option_end_equal = 0;
            if (game < 6)
            {
                for (var i = 0; i < 14; i++) {
                    if (option_x01_ar[i] != ('#000000')) 
                    {
                        if (i == 0) option_x01 |= constant.OPTION_DOUBLE_IN;  //DBL IN
                        else if (i == 1)  option_x01 |= constant.OPTION_DOUBLE_OUT; //DBL OUT
                        else if (i == 2)  option_x01 |= constant.OPTION_DOUBLE_IN; //MASTER IN
                        else if (i == 3)  option_x01 |= constant.OPTION_MASTEROUT; //MASTER OUT
                        else if (i == 11)
                        {
                            option_x01 |= constant.OPTION_EQUAL; //EQUAL
                            option_end_equal = 1;
                        }
                        else if (i == 13)  
                        {
                            option_x01 |= constant.OPTION_EQUAL; //END
                            option_end_equal = 2;
                        }
                    }
                }
            }
            else if (game < 10)
            {
                //upisi default brojeve za cricket
                for (var i = 0; i < 6; i++) {
                    variables.Cpu_game_data.c_cricket_broj[i] = 15 + i;
                }
                variables.Cpu_game_data.c_cricket_broj[6] = 25;
                
                if (game > 6)
                {
                    let uniqueNumbers = new Set(); // Use a Set to ensure uniqueness

                    // Generate 7 unique random numbers between 1 and 21
                    while (uniqueNumbers.size < 7) {
                        let randomNum = Math.floor(Math.random() * 21) + 1; // Random number between 1 and 21
                        uniqueNumbers.add(randomNum); // Add to the Set (duplicates are automatically handled)
                    }
                    // Convert the Set to an array and sort the numbers in ascending order
                    let sortedNumbers = Array.from(uniqueNumbers).sort((a, b) => a - b);
                    if (game == 7)
                    {
                        let broj_odabranih = 0;
                        for (let i = 0; i < 21; i++)
                        {
                            if (pick_it_num[i] == '#ff0000') 
                            {
                                sortedNumbers[broj_odabranih] = i + 1;  //prekucaj generirane odabranim
                                broj_odabranih++;
                                if (broj_odabranih > 6) break;
                            }
                        }
                    }
                    for (var i = 0; i < 7; i++) {
                        if (sortedNumbers[i] == 21) sortedNumbers[i] = 25;
                        variables.Cpu_game_data.c_cricket_broj[i] = sortedNumbers[i]; 
                    }
                }
                for (var i = 0; i < 7; i++) {
                    if (option_cricket_ar[i] != ('#000000')) 
                    {
                        if (i == 0) option_cricket = 30; //CUT THROAT
                        else if (i == 1)  option_cricket = 10; //MASTER
                        else if (i == 2)  option_cricket = 20; //KILLER
                    }
                }
            }
            for (var i = 0; i < 20; i++) {
                
            }
    
            for (var i = 0; i < 8; i++) {
                if (num_of_players_ar[i] != ('#FFFFFF'))
                {
                    num_of_players = i + 1;
                    break;
                } 
            }
            for (var i = 0; i < 3; i++) {
                
            }
    
            //let data = mongo.getHit(); //ovo nije dobro odradeno
            //console.log('variables.Display_data', variables.Display_data);
            console.log('PRIJAM_PODATAKA_ODABIR_IGRE', game_id);
           /* console.log('game', game_ar);
            console.log('option_x01', option_x01_ar);
            console.log('option_cricket', option_cricket_ar);
            console.log('num_of_players', num_of_players_ar);
            console.log('num_of_teams', num_of_teams_ar);*/
            //console.log('ovo je poruka!!!', variables.Cpu_data);
            
            console.log('variables.Cpu_game_data.c_credit', variables.Cpu_game_data.c_credit);
            variables.Cpu_game_data.c_sub_game = 0;  //ponisti sub_igru od prije 
            if (game >= 6 && game <= 9)
            {
                variables.Cpu_game_data.c_game = 6; //ovo je cricket
                variables.Cpu_game_data.c_sub_game = game + 20 - 1; //ovo je cricket opcija   
                variables.Cpu_game_data.c_sub_game += option_cricket; //ovo je sub game  
                for (var i = 0; i < 24; i++) 
                    variables.Cpu_game_data.c_player_cricket[i] = 0;
            } 
            else if (game == 12 ) variables.Cpu_game_data.c_game = 10; //ovo je Sahangai
            else if (game == 13 ) variables.Cpu_game_data.c_game = 14; //ovo je super 100
            else if (game == 14 ) variables.Cpu_game_data.c_game = 9; //ovo je Super score
            else if (game == 15 ) variables.Cpu_game_data.c_game = 19; //ovo je Split score
            else if (game == 16 ) variables.Cpu_game_data.c_game = 7; //ovo je Hi score
            else if (game == 17 ) variables.Cpu_game_data.c_game = 8; //ovo je Low score
            else if (game == 18 ) variables.Cpu_game_data.c_game = 17; //ovo je Solo 301
            else if (game == 19 ) variables.Cpu_game_data.c_game = 16; //ovo je Solo Hi score
            else if (game == 20 ) variables.Cpu_game_data.c_game = 15; //ovo je Pub game
            else if (game == 21 ) variables.Cpu_game_data.c_game = 13; //ovo je Scram
            else if (game == 22 ) variables.Cpu_game_data.c_game = 18; //ovo je Marathon
            else if (game == 23 ) variables.Cpu_game_data.c_game = 12; //ovo je roulete
            else if (game == 24 ) variables.Cpu_game_data.c_game = 11; //ovo je Baseball
            
            else 
                variables.Cpu_game_data.c_game = game; //ovo je igra
            if (game < 6)
            {
                if (option_end_equal != 0 && game_rng_par != 0)  //onda je parchessi equal end
                {
                    if (game_rng_par == 11) //Parcheesi
                        variables.Cpu_game_data.c_sub_game = game_rng_par + option_end_equal;
                }
                else if (option_end_equal != 0)
                    variables.Cpu_game_data.c_sub_game = option_end_equal; //ovo je equal end
                else if (game_rng_par != 0)
                    variables.Cpu_game_data.c_sub_game = game_rng_par; //ovo je run & gun i parcheesi
            }
            //igra bez reload-a
            if (option_quattro) option_x01 |= constant.OPTION_QUATTRO;   //dodaj i quattro na kraju
            variables.Cpu_game_data.c_option = option_x01;      //ovo je opcija
            variables.Cpu_game_data.c_game_mode = 1;      //game mode play
            variables.Cpu_game_data.c_round = 1;
            variables.Cpu_game_data.c_score = 0;
            variables.Cpu_game_data.c_dart = 3;
            variables.Cpu_game_data.c_show_msg = 1; //MSG_THROW;
            for (var i = 0; i < 3; i++) variables.Cpu_game_data.c_hits[i] = 255;  //postavi ih u 255 da nisu bacene
            variables.Cpu_game_data.c_player_throw = 1;
            variables.Cpu_game_data.c_playoff_flag = 0;
            //game_settings.c_equal_end_flag = 0;  //broj runde kraja i poredak igraca
            variables.Cpu_game_data.c_cricket_broj[7] = 0;    
            variables.Cpu_game_data.c_baceno_strelica = 0;
            variables.Cpu_game_data.c_game_mode = 1;    
            variables.Cpu_game_data.c_num_players = num_of_players;    //num of players
            variables.Cpu_game_data.c_team_num = 0;
            //dodaj uvjete za ostale opcije
            /*
             */
            
            for (var i = 0; i < 8; i++) 
                variables.Cpu_game_data.c_player_rank[i] = i + 1;     //poredak igraca
            let start_score_const = [180, 301, 501, 701, 901, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 0, 0, 301, 0, 0, 0, 0, 0, 0];
            if (game_rng_par >= 11 && game_rng_par <= 13) game = 11;
            for (var i = 0; i < num_of_players; i++) 
                variables.Cpu_game_data.c_player_value[i] = start_score_const[game];   //pocetni score
        
            //console.log(variables.Cpu_game_data);
            //let exampleData = new Uint8Array([0x01, 0x02, 0x03]); // ili neki drugi niz podataka

            //Ovo je helper funkcija koja koristi Promise da bi omogućila pauzu (await) na određeni broj milisekundi
/*function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}*/
            //pocisti krug
            let podaci_za_slanje = new Uint8Array(82);
            serialPort.copyClassObjectToData(podaci_za_slanje, variables.Cpu_game_data, 0, 2);
            
            
            setTimeout(() => {
                serialPort.protocolx_write(podaci_za_slanje, 0xA7);
            }, 30);
           
            //await sleep(30);    // Pauza od 30ms
            //posalji na krug

        // write_serial.protocolx_write("variables.Cpu_game_data", 0xA7); //variables.CMD_SAVE_GAME_DATA
            setTimeout(() => {
                serialPort.socket_send_data();
            }, 30);  
        //socket.emit('TABLET>RPI:showNewGame',variables.Cpu_game_data,variables.Cpu_settings_data,hitStatus);
        //pio.emit('Monitor:Igra',game_data,Cpu_data,hit);
            
        });

        /*socket.on(socketEnum.PRIJAM_PODATAKA_ODABIR_OPCIJE, function (game_op) { ///goran monitor data
            log('socket', 'PRIJAM_PODATAKA_ODABIR_OPCIJE');
            //let data = mongo.getHit(); //ovo nije dobro odradeno
            //console.log('variables.Display_data', variables.Display_data);
            console.log('PRIJAM_PODATAKA_ODABIR_OPCIJE', game_op);
            //console.log('ovo je poruka!!!', variables.Cpu_data);
            
            console.log('variables.Cpu_game_data.c_credit', variables.Cpu_game_data.c_credit);
            if (game_op == 0 ) variables.Cpu_game_data.c_option = 10; //ovo je double in
            else if (game_op == 1 ) variables.Cpu_game_data.c_game = 14; //ovo je double out
            else if (game_op == 2 ) variables.Cpu_game_data.c_game = 9; //ovo je master in
            else if (game_op == 3 ) variables.Cpu_game_data.c_game = 19; //ovo je master out
            else if (game_op == 4 ) variables.Cpu_game_data.c_game = 7; //ovo je bull 25/50
            else if (game_op == 5 ) variables.Cpu_game_data.c_game = 8; //ovo je round free
            else if (game_op == 6 ) variables.Cpu_game_data.c_game = 17; //ovo je round 10
            else if (game_op == 7 ) variables.Cpu_game_data.c_game = 17; //ovo je round 15
            else if (game_op == 8 ) variables.Cpu_game_data.c_game = 17; //ovo je round 20
            else if (game_op == 9 ) variables.Cpu_game_data.c_game = 17; //ovo je round 25
            else if (game_op == 10 ) variables.Cpu_game_data.c_game = 17; //ovo je auto handicap
            else if (game_op == 11 ) variables.Cpu_game_data.c_game = 17; //ovo je TEAM
            else if (game_op == 12 ) variables.Cpu_game_data.c_game = 17; //ovo je manuL handicap
            else if (game_op == 13 ) variables.Cpu_game_data.c_game = 17; //ovo je eaual end

            
            
            console.log(variables.Cpu_game_data);
            //let exampleData = new Uint8Array([0x01, 0x02, 0x03]); // ili neki drugi niz podataka
            let podaci_za_slanje = new Uint8Array(82);
            write_serial.copyClassObjectToData(podaci_za_slanje, variables.Cpu_game_data, 0, 2);
            write_serial.protocolx_write(podaci_za_slanje, 0xA7);
           // write_serial.protocolx_write("variables.Cpu_game_data", 0xA7); //variables.CMD_SAVE_GAME_DATA

            
        });*/
        socket.on(socketEnum.GAME_SELECT, function (Cpu_data,Display_data,Setup_data, Cpu_turnir_data) {
            log('socket', 'Game select');
            pio.emit(socketEnum.GAME_SELECT_MONITOR,Cpu_data,Display_data,Setup_data, Cpu_turnir_data);
        });
        //socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		
        socket.on(socketEnum.SHOW_NEW_GAME, function (game_data, Cpu_data, Cpu_other_data, hit, Cpu_turnir_data) {
            log('socket', 'show newe game = tablet requested to show new game with all the data he sent');
            pio.emit('Monitor:Igra',game_data, Cpu_data, Cpu_other_data, hit, Cpu_turnir_data);
        });
        //socket.emit(socketEnum.SHOW_BOOT_LOADER,1,hexLines.length,1);
        socket.on(socketEnum.SHOW_BOOT_LOADER, function (fw_current_line, fw_max_lines, fw_mode) {
            log('socket', 'MONITOR:bootloader_update_status');
            pio.emit('MONITOR:bootloader_update_status',fw_current_line, fw_max_lines, fw_mode);
        });

        socket.on(socketEnum.DIP_SWITCH, function (data) {
            log('socket', 'dip switch = tablet requested to show dip switch with all the data he sent');
            pio.emit('Monitor:dip_switch',data);
        });

        socket.on(socketEnum.SHOW_DART_HIT, function (data) {
            log('socket', 'show dart hit = tablet sent hit info');
            if (data.game.playoffGame) {
                if (!variables.isPlayoff && !variables.playoffStarted) {
                    variables.playoffStarted = true;
                } else if (!variables.isPlayoff && variables.playoffStarted) {
                    variables.isPlayoff = true;
                }
            }

            data.playoffStarted = variables.playoffStarted;
            data.isPlayoff = variables.isPlayoff;

            pio.emit(socketEnum.SHOW_DART_HIT_MONITOR, data);
        });

        socket.on(socketEnum.SHOW_SCOREBOARD, function (data,Cpu_data) {
            log('socket', 'show scoreboard = tablet sent scoreboard info');
            //variables.isPlayoff = false;
            //variables.playoffStarted = false;
            pio.emit(socketEnum.SHOW_SCOREBOARD_MONITOR,data,Cpu_data);
        });

        socket.on(socketEnum.NEXTING_PLAYER, function (data) {
            log('socket', 'nexting player = tablet sent player nexting event to device');
            pio.emit(socketEnum.NEXTING_PLAYER_MONITOR, data);
        });

        

        socket.on(socketEnum.SHOW_DART_STUCK, function (id, data) {
            log('socket', 'show dart stuck = tablet sent dart stuck info');
            pio.emit(socketEnum.SHOW_DART_STUCK_MONITOR, id, data.text, data.dartStuck, data.dartUnStuck,data.score);
        });

        socket.on(socketEnum.SHOW_UNDO, function (data) {
            log('socket', 'show undo = tablet sent undo info');

            if (variables.currentCpuMode === 4) {
                serialPort.writeSerial(new Buffer(constant.gameModeEnter, constant.HEX_B));
            }

            let dart1;
            let dart2;
            let dart3;
            if (data.game.gameStatus.currentDart === 2) {
                dart1 = data.game.darts[data.game.darts.length - 1];
            } else if (data.game.gameStatus.currentDart === 3) {
                dart1 = data.game.darts[data.game.darts.length - 2];
                dart2 = data.game.darts[data.game.darts.length - 1];
            } else if (data.game.gameStatus.currentDart === 1) {
                dart1 = data.game.darts[data.game.darts.length - 3];
                dart2 = data.game.darts[data.game.darts.length - 2];
                dart3 = data.game.darts[data.game.darts.length - 1];
            }
            pio.emit(socketEnum.SHOW_UNDO_MONITOR, data);
            //mongo.updateGameSave(data);
        });

        socket.on(socketEnum.SHOW_END_GAME, function (id, lotteryWinners, winnerMessage) {
            log('socket', 'show end game = tablet sent end game info');

            variables.isPlayoff = false;
            variables.playoffStarted = false;

            pio.emit(socketEnum.SHOW_END_GAME_MONITOR, id, lotteryWinners, winnerMessage);
        });

    

        socket.on(socketEnum.SHOW_WAIT_GAME, function () {
            log('socket', 'show wait game = tablet sent show wait game info test');
            variables.isPlayoff = false;
            variables.playoffStarted = false;
            pio.emit(socketEnum.SHOW_WAIT_GAME_MONITOR);
        });

        socket.on(socketEnum.UPDATE_CREDITS, function (id, creditString, credits, creditBuffer, type, valute, value, channel, date, creditsGot, acumulatedMoney, acumulatedBonus) {
            log('socket', 'update credits = tablet sent update credit status info');
            console.log(acumulatedMoney, acumulatedBonus);

            pio.emit(socketEnum.UPDATE_CREDITS_MONITOR, id, creditString);

            if (type === constant.CREDIT_TYPE_BONUS) {
                log('socket', 'update credits = udateing bookeeping bonus');
                mongo.updateBookeepingBonus(id, creditsGot);
            } else if (type === constant.CREDIT_TYPE_COIN || type === constant.CREDIT_TYPE_BILL) {
                log('socket', 'update credits = updateing bills or coins bookeping');
                mongo.updateBookeeping(id, { value: value, valute: valute, creditsGot: creditsGot }, type);
            } else if (type === constant.CREDIT_TYPE_LOTTERY) {
                log('socket', 'update credits = updating bookkeeping lottery');
                mongo.updateBookeepingLottery(id, creditsGot);
            }
            mongo.updateCreditStatus(id, credits, creditBuffer, acumulatedMoney, acumulatedBonus);
        });

        socket.on(socketEnum.LEAVE_SERVISE_MODE, function (id) {
            log('socket', 'leave servis mode = tablet requested to leave servis mode on cpu and enter main mode');
            if (id !== variables.deviceId) {
                ErrorHandeler.newError(2, constant.NO_MESS);
                return;
            }

            serialPort.writeSerial(new Buffer(constant.mainModeEnter, constant.HEX_B));
        });

        socket.on(socketEnum.ENTER_TEST_TARGET, function (id) {
            log('socket', 'enter test target = tablet requested to enter test target mode on cpu');
            if (id !== variables.deviceId) {
                ErrorHandeler.newError(2, constant.NO_MESS);
                return;
            }

            if (variables.demoModeTimeout) {
                log('socket', 'enter test target = turning off demo animation');
                clearTimeout(variables.demoModeTimeout);
                variables.demoModeTimeout = undefined;
            }

            serialPort.writeSerial(new Buffer(constant.demoModeOff, constant.HEX_B));
            serialPort.writeSerial(new Buffer(constant.gameModeEnter, constant.HEX_B));
        });

        socket.on(socketEnum.TUP_SENSITIVITY, function (id, sens) {
            log('socket', 'tup sensitivity = tablet requested for changing tup sensitivity');
            if (id !== variables.deviceId) {
                ErrorHandeler.newError(2, constant.NO_MESS);
                return;
            }

            serialPort.writeSerial(fset.createSensitivityOrder(1, sens));
        });

        socket.on(socketEnum.IR_SENSITIVITY, function (id, sens) {
            log('socket', 'ir sensitivity = tablet requested for changing ir sensitivity');
            if (id !== variables.deviceId) {
                ErrorHandeler.newError(2, constant.NO_MESS);
                return;
            }

            serialPort.writeSerial(fset.createSensitivityOrder(0, sens));
        });

        socket.on('PorukaVelikeVaznosti', function (string) { 
            console.log('PRIMIO SAM PORUKU VELIKE VAZNOSTI U SOCKETU:', string);
        });
    });

    pio.on('PorukaVelikeVaznosti', function (string) { 
        console.log('PRIMIO SAM PORUKU VELIKE VAZNOSTI U PIO:', string);
    });
}
