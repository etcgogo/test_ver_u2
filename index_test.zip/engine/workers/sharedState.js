//socketWorker i serialPortWorker link
const EventEmitter = require("events");

class SharedState extends EventEmitter {
  constructor() {
    super();
    this._var_restart = 0;
  }

  set var_restart(value) {
    this._var_restart = value;
    this.emit("var_restart", value); // emit signal kad se promijeni
  }

  get var_restart() {
    return this._var_restart;
  }
}

module.exports = new SharedState();
