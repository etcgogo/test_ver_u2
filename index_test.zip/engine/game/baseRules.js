'use strict';

module.exports = class BaseRules {
	constructor(gameType, rounds, quatro, undo, handicap, teamRules) {
		this.gameType = gameType;
		this.rounds = rounds;
		this.teamRules = teamRules;
		this.quatro = quatro;
		this.undo = undo;
		this.handicap = handicap;
		this.uniqueId = this.getUniqueId();
	}
	validate() { return (true); }
	getUniqueId() {
		function S4() {
			return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
		}
		var timestamp = new Date().getTime();
		var delim = '-';
		return (S4() + S4() + delim + S4() + delim + S4() + delim + S4() + delim + S4() + S4() + S4() + delim + timestamp);
	}
}

const GameTypeEnum = {
	x01: 1,
	cricket: 2,
};
