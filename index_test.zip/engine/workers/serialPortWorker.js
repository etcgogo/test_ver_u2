var io = require('socket.io-client');
var Omx = require('node-omxplayer');
const { maxHeaderSize } = require('http');
const constant = require('../const/const');
const variables = require('../const/varibales');
const mongo = require('../objects/mongo');

const fs_log = require('fs');
const path_log = require('path');
const os = require('os');

// At the top of your WebSocket server file
const wsSockets = [];

const spawn = require('child_process').spawn;
// const {PythonShell} = require('python-shell')

// let options ={
// 	scriptPath:'./engine/workers/',
// 	args:['ivan',55]
// }
const shared = require('./sharedState');

const { exec } = require('child_process');

				// Kill any running omxplayer or omxplayer.bin processes
				exec('pkill -9 omxplayer && pkill -9 omxplayer.bin', (err, stdout, stderr) => {
				if (err) {
					console.error('Failed to kill omxplayer:', err.message);
				} else {
					console.log('Killed existing omxplayer instances');
				}
				});


const fs = require('fs');
const SerialPort = require("serialport").SerialPort;
const socketEnum = require('../const/socketEnums');
const fset = require('../objects/fset');
var Setup_data = require('../../current_data/Setup_data.json');
//const { dart, selectGame, gameActive, player_throw,Game_1, Cpu_data } = require('../const/varibales');
const video =  require('./video');

let socket = io.connect('http://localhost:3000');
var gameResume = require('../../current_data/gameResume.json');
const { updateHit } = require('../objects/mongo');
const { enableQuattro, pod_menu_value } = require('../const/const');
const varibales = require('../const/varibales');

const serialPort = new SerialPort({ // '/dev/ttyAMA0' za rpi zero i rpi3
	path:'/dev/ttyS0',
	baudRate: 57600,
	dataBits: 8,
	parity: 'none',
	stopBits: 1,
	flowControl: false,
});



//['','Equal','End','Run N Gun', 'Parchessi','Parchessi Equal','Parchessi End','Pick-it','Random','Crazy','Killer'];

let Game = [];
let hitStatus = [];
hitsavegametimeout = 1000;

dartHitupdate = false;

let gameOver = false;
let gameOver_counter = 0;
let hitvalid = false;
let transmute = new fset.Transmute();
// let testdart = {
// dart1:{
// 	dartStuck:false,
// 	dartUnStuck:false,
// 	hitValid:false,
// 	irSensor:false,
// 	isInner:false,
// 	isOuter:false,
// 	message:"",
// 	multiplier:0,
// 	playerButton:false,
// 	score:0
//   },
// dart2:{
// 	dartStuck:false,
// 	dartUnStuck:false,
// 	hitValid:false,
// 	irSensor:false,
// 	isInner:false,
// 	isOuter:false,
// 	message:"",
// 	multiplier:5,
// 	playerButton:false,
// 	score:5
// },
// dart3:{
// 		dartStuck:false,
// 		dartUnStuck:false,
// 		hitValid:false,
// 		irSensor:false,
// 		isInner:false,
// 		isOuter:false,
// 		message:"",
// 		multiplier:0,
// 		playerButton:false,
// 		score:0
// 	}
// };
let isPlaying = false;
dart1=null;
dart2=null;
dart3=null;
let nextPlayer = null;
let nextplayer = false;
let ladder=[];
let Playoff = false;
let players_in_playoff = [];
let players_in_playoff_number = 0

let settings ={
	command:'',
	pod_menu:'',
	pod_menu_value:'',
	value_parametar:'',
	max:'',
	min:'',
	step:''
};


const DATA_BUFFER_RX_SIZE = 4096;
let buffer_serial_rx_data = new Uint8Array(DATA_BUFFER_RX_SIZE);
let buffer_serial_rx_data_4 = new Uint8Array(DATA_BUFFER_RX_SIZE);
let buffer_serial_rx_data_boot = new Uint8Array(DATA_BUFFER_RX_SIZE);

let data_counter_rx_buffer = 0;
let data_counter_rx_buffer_4 = 0;
let data_counter_rx_buffer_boot = 0;

let data_counter_x_rx_read_buffer = 0;
let data_counter_rx_read_buffer = 0;
let data_counter_x_rx_read_buffer_boot = 0;

let podaci_len_protocolx = 0;
let flag_protocol_x_ready_to_reset = 0;
let flag_protocol_ready_to_reset = 0;
let flag_protocol_boot_ready_to_reset = 0;
let time_out_serial = 0;
let tic_tac_serial = 0;
let timerInterval1; // Varijabla za prvi timer
let prev_game_mode = 0;
let brojac_file_sector_boot = 0;

const C_GAME_MODE_SELECT_GAME		= 0;
const C_GAME_MODE_PLAY				= 1;
const C_GAME_MODE_GAME_END			= 2;
const C_GAME_MODE_PLAYOFF			= 3;
const C_GAME_MODE_LOTTERY			= 4;
const C_GAME_MODE_SWITCH_PLAYER		= 5;
const C_GAME_MODE_DEMO				= 6;
const C_GAME_MODE_PLAYER_ID			= 7;

const C_GAME_MODE_NULL				= 9;

const C_GAME_MODE_SETTINGS			= 10;
const C_GAME_MODE_TEST				= 11;
const C_GAME_MODE_DEFAULT			= 12;
const C_GAME_MODE_BOOK_MAIN			= 13;
const C_GAME_MODE_BOOK_SEC			= 14;
const C_GAME_MODE_HIDDEN_MENU		= 15;

const C_GAME_MODE_BUST				= 16;
const C_GAME_MODE_JEDI				= 17;

// console.log('tu pocinjemo spajanje s bazom')
// //mongo.updateBookeeping(12);

////////////////

//socket.emit(socketEnum.SHOW_NEW_GAME,variables.Game_data,variables.Cpu_data,hitStatus);
							
// socket_server.emit('CH01', 'me', 'test msg');

// socket_server.on('CH02', function (from, msg) {
//     console.log('MSG', from, ' saying ', msg);
//   });


//module.exports = function(wsServer, jsonfile, log) {
	//console.log('python------------------------')	
	/*const py = spawn('python3', ['./engine/workers/RFID.py']);
	py.stdout.on('data', function (data) {
		const out = JSON.parse(data);
		//console.log('Ime igraca ' + out.name);
		if(variables.Cpu_data.num_players !== 8){
			//console.log('rfid jel prazan',variables.Cpu_data.rfid)
			if(!variables.Cpu_data.rfid.includes(out.name)){
				//console.log('jel ude rfid ovdje')
				variables.Cpu_data.rfid.push({name:out.name,position:variables.Cpu_data.num_players})
				writeSerial(Buffer.from(mongo.sendGameData(constant.setgamedata), constant.HEX_B));
			}
		}
	});
	py.stderr.on('data', function (data) {
		console.log('stderr: ' + data);
	});*/
	//console.log('python+++++++++++++++++++++++++++++')
        serialPort.on('open', function() {
			console.log('serial', 'port opened');
			// serialPortWorker.js

			wsServer.on('request', function(request) {
				const connection = request.accept(null, request.origin);
				wsSockets.push(connection);
			
				console.log("✅ New WebSocket client connected. Total:", wsSockets.length);
			
				connection.on('close', function() {
					wsSockets.splice(wsSockets.indexOf(connection), 1);
					console.log("❌ Client disconnected. Total:", wsSockets.length);
				});
			
				// Optional welcome message
				connection.send(JSON.stringify({ msg: "Welcome! You are now connected." }));
				sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
				//socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		
			});
			


			
			if(variables.firstBoot){
				variables.firstBoot = false;
				//let test_data = [0, 4];
				//[AB][03][D2][00][04][D9][BA]
				//protocolx_write( new Uint8Array(test_data)
				//console.log('cmd sent');
				//protocolx_write("", constant.CMD_RETURN_GAME_SETTINGS);
				//protocolx_write("", constant.CMD_RETURN_GAME_DATA);
				//console.log('cmd sent');
				/*writeSerial(Buffer.from(constant.cmdReadGameSettings, constant.HEX_B));
				//writeSerial(Buffer.from(constant.cmdReadGameData, constant.HEX_B));
				console.log('data cpu');
				writeSerial(Buffer.from(constant.cmdReadGameSettings, constant.HEX_B));
				writeSerial(Buffer.from(constant.cmdReadGameData, constant.HEX_B));
				*/
				protocolx_write("", constant.CMD_RPI_TO_CPU_READY);
				console.log('rpi send cpu ready');
				protocolx_write("", constant.CMD_RPI_TO_CPU_READY);

				protocolx_write("", constant.CMD_RETURN_GAME_SETTINGS);
				console.log('data cpu');
				protocolx_write("", constant.CMD_RETURN_GAME_SETTINGS);
				protocolx_write("", constant.CMD_RETURN_GAME_DATA);
				
				//updateHitfirstBoot();
			}
			

			//writeSerial(fset.displayLED(2,9, 'v108', false));
			/*setTimeout(() => {    //trajanje timeouta u s 
				startUp();
			}, 600000);*/
			serialPort.on('data', function(untransmutedData) {
				let someThinslogs = new Uint8Array(untransmutedData);

				for (let i = 0; i < someThinslogs.length; i++) {
					buffer_serial_rx_data[data_counter_rx_buffer] = someThinslogs[i];
					buffer_serial_rx_data_4[data_counter_rx_buffer_4] = someThinslogs[i];
					buffer_serial_rx_data_boot[data_counter_rx_buffer_boot] = someThinslogs[i];
					
					data_counter_rx_buffer++;
					data_counter_rx_buffer_4++;
					data_counter_rx_buffer_boot++;
					if (data_counter_rx_buffer > DATA_BUFFER_RX_SIZE) data_counter_rx_buffer = 0;
					if (data_counter_rx_buffer_4 > DATA_BUFFER_RX_SIZE) data_counter_rx_buffer_4 = 0;
					if (data_counter_rx_buffer_boot > DATA_BUFFER_RX_SIZE) data_counter_rx_buffer_boot = 0;
					
					tic_tac_serial = 1;
					time_out_serial = 0;

				}

				serial_data_center();  //obradi podatke
				
            });
        });

//}


///zatvaranje serisjkoh porta
// // setTimeout(() => {
// // 	console.log('zatvaramo serijski port i updejtamo aplikaciju')
// // 	const { exec } = require('child_process');

// // 	exec('sh ./python_update/update.sh',
// //         (error, stdout, stderr) => {
// //             console.log(stdout);
// //             console.log(stderr);
// //             if (error !== null) {
// //                 console.log(`exec error: ${error}`);
// //             }
// //         });

 	
// //  	serialPort.close();
// // }, 10000);


function update_player_name(){
	console.log('dali ima igaraca',variables.Cpu_data.player,variables.Cpu_data.rfid)
	for (let i = 0; i < variables.Cpu_data.rfid.length; i++) {

		variables.Cpu_data.player[variables.Cpu_data.rfid[i].position].name= variables.Cpu_data.rfid[i].name
	}
}

function writeSerial(data) {
	if (!data) {
		return;
	}
	serialPort.write(data, function(err) {
		if (err) {
			ErrorHandeler.newError(139, err);
		}
		return;
	});
}

function checkArrayLength(array) {
	if (array.length === 0) {
	  return 0;
	} else {
	  return array.length;
	}
  }

function updateStatus(data) {
	console.log('GAME OVER lederboard',gameOver);
	gameOver = true;
	
	if(variables.Game_data.game.playOffStarted){
		
	}
}

Object.defineProperties(Array.prototype, {
    count: {
        value: function(value) {
            return this.filter(x => x==value).length;
        }
    }
});

function startUp(){
	fset.isInternetUp(function (result) {
		if (result) {
			console.log('Ima interneta!');
			mongo.retriveInitialData(function(data) {
				if (data) {
					//console.log('ovo je data',data.gameSettings.gameList[0]);
					mongo.updateMode(data);
					
					setTimeout(() => {
						//console.log('pisem na aparat serial',mongo.sendSetup())
						writeSerial(Buffer.from(mongo.sendSetup(), constant.HEX_B));
					}, 100);
					
					
				} else {
					console.log('nema podataka');
					
				}
            });
		mongo.addValuteList(null);
        } else {
            console.log('NEMA INTERNETA');
		}
	})
	
}
//**************** FUNKCIJE ZA SLANJE PREKO SOCKETA********************************
function update_socket_data(type_)
{
	//postavi trenutne vrijednosti
	if (type_ == 1)
	{
		variables.Cpu_data = {
			game_mode:variables.Cpu_game_data.c_game_mode,
			player:variables.Cpu_game_data.c_player_throw,
			currentRoundScore:variables.Cpu_game_data.c_round,
			dart:variables.Cpu_game_data.c_dart,
			round:variables.Cpu_game_data.c_round,
			player_throw:variables.Cpu_game_data.c_player_throw,
			credit:variables.Cpu_game_data.c_credit,
			game:variables.Cpu_game_data.c_game,

			
			option:variables.Cpu_game_data.c_option,
			num_players:variables.Cpu_game_data.c_num_players,
			cricket_numbers_closed:null,
			cricket_numbers:null,
			player_rank:null,
			playoff_flag:null,
			team_num:variables.Cpu_game_data.c_team_num,
			flags_data:null,
			sub_game:variables.Cpu_game_data.c_sub_game,
			darts_thrown:variables.Cpu_game_data.c_baceno_strelica,
			max_darts_thrown:variables.Cpu_game_data.c_max_strelica,
			dart_hit:null,
			parts_of_credit_in_dart:variables.Cpu_game_data.c_dijelova_kredita_u_aparatu,
			rfid:variables.Cpu_data.rfid
		}
	}	
	return 1;
}

/*
const C_GAME_MODE_SELECT_GAME		= 0;
const C_GAME_MODE_PLAY				= 1;
const C_GAME_MODE_GAME_END			= 2;
const C_GAME_MODE_PLAYOFF			= 3;
const C_GAME_MODE_LOTTERY			= 4;
const C_GAME_MODE_SWITCH_PLAYER		= 5;
const C_GAME_MODE_DEMO				= 6;
const C_GAME_MODE_PLAYER_ID			= 7;

const C_GAME_MODE_NULL				= 9;

const C_GAME_MODE_SETTINGS			= 10;
const C_GAME_MODE_TEST				= 11;
const C_GAME_MODE_DEFAULT			= 12;
const C_GAME_MODE_BOOK_MAIN			= 13;
const C_GAME_MODE_BOOK_SEC			= 14;
const C_GAME_MODE_HIDDEN_MENU		= 15;

const C_GAME_MODE_BUST				= 16;
const C_GAME_MODE_JEDI				= 17;
*/
function socket_send_data()
{
	console.log('socket_send_data');
	// Primer log funkcije
	//logToFile(variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data);
	//logToFile('Drugi zapis sa dodatnim podacima. socket_send_data variables.Cpu_game_data');
	//game status
	

	if (variables.Cpu_data.game_mode == C_GAME_MODE_SELECT_GAME || variables.Cpu_data.game_mode == C_GAME_MODE_DEMO){
		//mongo.updateGamesStatistics(variables.Cpu_data);
		if (variables.Cpu_data.game_mode == C_GAME_MODE_DEMO){
			if(variables.Cpu_data.credit == 0){
				
				console.log('serial','demo');
				//video.action(variables.Cpu_data.credit);
				if (isPlaying == false)
				{
					player = Omx('/home/hybrid3/Video/5sek.mp4','',true,'');
				}
				isPlaying = true;
				
			}else{
				//console.log('serial','demo else variables.credit',variables.credit);
				//video.action(variables.Cpu_data.credit);
				if (isPlaying) 
					{
						console.log('demo video zatvoren');
						player.quit();
						isPlaying = false;
					}
			}
		}
		else
		{
			if (isPlaying) 
			{
				console.log('demo video zatvoren');
				player.quit();
				isPlaying = false;
			}
		}	
		console.log('//**** C_GAME_MODE_SELECT_GAME *****//');
		//socket.emit(socketEnum.SHOW_NEW_GAME, variables.Cpu_game_data);
		//socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,hitStatus);
		socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	}
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_PLAY )
	{
		if (prev_game_mode != variables.Cpu_data.game_mode)
		{
			//Statistic_calculate()
			//update_player_name();
			//if(nextplayer){
				//nextplayer = false;
				hitStatus = { dart1: null, dart2: null, dart3: null }  //na početku ga isprazni
			//}
			//if(!hitvalid && !gameResume.gameActive){
			//	mongo.updateGameSave(Game);
		}
		//pio.emit('neki_moj_soc',variables.Game_data,variables.Cpu_data,hitStatus);
		console.log('//**** C_GAME_MODE_PLAY *****//');
		//socket.emit(socketEnum.SHOW_NEW_GAME, variables.Cpu_game_data);
		socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
		/*let pom_arr = [0x01, 0xFF, 0x00, 0x00];
		protocolx_write(pom_arr, 0x06);	*/	
	}
	
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_GAME_END){
		
		console.log('//**** C_GAME_MODE_GAME_END *****//',variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus);
		socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
		/*	updateStatus(variables.Cpu_data);
			socket.emit(socketEnum.SHOW_SCOREBOARD, variables.Cpu_game_data, variables.Cpu_data);
			setTimeout(() => {
				mongo.updateGamesStatistics(variables.Cpu_data);
			}, 100);
			mongo.updateHitsStatistics(variables.Game_data.game.darts)
			variables.Game_data.game.darts = [];*/
	}
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_LOTTERY){
		
		console.log('//**** C_GAME_MODE_LOTTERY *****//');
		socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
		/*	updateStatus(variables.Cpu_data);
			socket.emit(socketEnum.SHOW_SCOREBOARD, variables.Cpu_game_data, variables.Cpu_data);
			setTimeout(() => {
				mongo.updateGamesStatistics(variables.Cpu_data);
			}, 100);
			mongo.updateHitsStatistics(variables.Game_data.game.darts)
			variables.Game_data.game.darts = [];*/
	}
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_PLAYOFF){
		//if (prev_game_mode != variables.Cpu_data.game_mode)
		//{
			console.log('serial','playoff');
			hitStatus = { dart1: null, dart2: null, dart3: null }
			socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
			sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
			//}
	}
	/*else if (variables.Cpu_data.game_mode == C_GAME_MODE_LOTTERY){
		if (prev_game_mode != variables.Cpu_data.game_mode)
		{
			console.log('serial','lottery');
			updateStatus(variables.Cpu_data);
			socket.emit(socketEnum.SHOW_SCOREBOARD,ladder,variables.Cpu_data);
		}
	}*/
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_SWITCH_PLAYER){
		//if (prev_game_mode != variables.Cpu_data.game_mode)
		//{
			console.log('serial','switch player');
			//console.log('serial','switch player team data',nextPlayer,null);
			//socket.emit(socketEnum.NEXTING_PLAYER,variables.Cpu_data.player_throw);,hitStatus
			socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
			sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
			//}
	}
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_SETTINGS){
		
		console.log('//**** C_GAME_MODE_SETTINGS *****//');
		socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
		/*	updateStatus(variables.Cpu_data);
			socket.emit(socketEnum.SHOW_SCOREBOARD, variables.Cpu_game_data, variables.Cpu_data);
			setTimeout(() => {
				mongo.updateGamesStatistics(variables.Cpu_data);
			}, 100);
			mongo.updateHitsStatistics(variables.Game_data.game.darts)
			variables.Game_data.game.darts = [];*/
	}
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_TEST){
		
		console.log('//**** C_GAME_MODE_TEST *****//');
		console.log("Cpu_other_data before emit:", variables.Cpu_other_data);
		socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
		/*	updateStatus(variables.Cpu_data);
			socket.emit(socketEnum.SHOW_SCOREBOARD, variables.Cpu_game_data, variables.Cpu_data);
			setTimeout(() => {
				mongo.updateGamesStatistics(variables.Cpu_data);
			}, 100);
			mongo.updateHitsStatistics(variables.Game_data.game.darts)
			variables.Game_data.game.darts = [];*/
	}
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_DEFAULT){
		
		console.log('//**** C_GAME_MODE_DEFAULT *****//');
		socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
		/*	updateStatus(variables.Cpu_data);
			socket.emit(socketEnum.SHOW_SCOREBOARD, variables.Cpu_game_data, variables.Cpu_data);
			setTimeout(() => {
				mongo.updateGamesStatistics(variables.Cpu_data);
			}, 100);
			mongo.updateHitsStatistics(variables.Game_data.game.darts)
			variables.Game_data.game.darts = [];*/
	}
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_BOOK_MAIN){
		
		console.log('//**** C_GAME_MODE_BOOK_MAIN *****//');
		socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
		/*	updateStatus(variables.Cpu_data);
			socket.emit(socketEnum.SHOW_SCOREBOARD, variables.Cpu_game_data, variables.Cpu_data);
			setTimeout(() => {
				mongo.updateGamesStatistics(variables.Cpu_data);
			}, 100);
			mongo.updateHitsStatistics(variables.Game_data.game.darts)
			variables.Game_data.game.darts = [];*/
	}
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_BOOK_SEC){
		
		console.log('//**** C_GAME_MODE_BOOK_SEC *****//');
		socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
		/*	updateStatus(variables.Cpu_data);
			socket.emit(socketEnum.SHOW_SCOREBOARD, variables.Cpu_game_data, variables.Cpu_data);
			setTimeout(() => {
				mongo.updateGamesStatistics(variables.Cpu_data);
			}, 100);
			mongo.updateHitsStatistics(variables.Game_data.game.darts)
			variables.Game_data.game.darts = [];*/
	}
	else if (variables.Cpu_data.game_mode == C_GAME_MODE_HIDDEN_MENU){
		
		console.log('//**** C_GAME_MODE_HIDDEN_MENU *****//');
		socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	
		/*	updateStatus(variables.Cpu_data);
			socket.emit(socketEnum.SHOW_SCOREBOARD, variables.Cpu_game_data, variables.Cpu_data);
			setTimeout(() => {
				mongo.updateGamesStatistics(variables.Cpu_data);
			}, 100);
			mongo.updateHitsStatistics(variables.Game_data.game.darts)
			variables.Game_data.game.darts = [];*/
	}
	
	prev_game_mode = variables.Cpu_data.game_mode;
	return 1;
}
//************** FUNKCIJE ZA POPUNJAVANJE PODATAKA IZ MEMORIJE U JSON FORMAT ************* */
function update_json_data_players()
{
	console.log("dodajem u json update_json_data_players: ");
	//console.log(variables.Game_data);

	variables.Game_data.game.players = [];		//obrisi prethodne zapise
	for (i = 0; i < variables.Cpu_game_data.c_num_players; i++){
		variables.Game_data.game.players.push({

			'id': i+1,
			'name': "Player"+(i+1),
			'type': null,
			'copyOfType': null,
			'owner': {
				'id': i+1,
				'name': "Player"+(i+1),
				'type': null,
				'copyOfType': null
			},
			'avgStatistic': 0,
			'numbersHit': 0,
			'totalScore': variables.Cpu_game_data.c_score,	//currentRoundScore,
			'roundScores': [],
			'score': variables.Cpu_game_data.c_player_value[i],  //player_value[i],
			'penaltyScore': 0,
			'darts':[],
			'numbersToHit': [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],
			'noOfDartsRemaining': 0,
			'runAndGunEndTime': 0,
			'teamId':null,
			'isDoubledIn': false,
			'shangaiWin': 0,
			'shangaiNo': 0,
			'ladder': 0,
			'playoff':false,
			'total_score': 0,

		});

	}
	return 1;
}

function update_json_data_game_rules()
{
	//variables.Cpu_game_data.c_game = dataArray[startIndex + 23];
	//variables.Cpu_game_data.c_option
	console.log("dodajem u json update_json_data_game_rules: ");

	//postavi ih u default i promjeni ovisno o podatku iz aparata

	variables.Game_data.activeGame.teamCount = 0;
	variables.Display_data.GameOptionName = '';

	variables.Display_data.gameName = constant.GameName[variables.Cpu_game_data.c_game];
	variables.Display_data.sub_game = variables.Cpu_game_data.c_sub_game;
	variables.Display_data.teamOption = constant.teamOptionName[String(variables.Cpu_game_data.c_team_num)[0]];


		
	variables.Game_data.game.gameStatus.players = variables.Cpu_game_data.c_num_players;
	variables.Game_data.game.gameStatus.round = variables.Cpu_game_data.c_round;
	if (variables.Cpu_game_data.c_player_throw > 0){
		variables.Game_data.game.gameStatus.currentPlayer = variables.Cpu_game_data.c_player_throw - 1;
	}
		
	variables.Game_data.game.roundScore = variables.Cpu_game_data.c_score;
	if (variables.Cpu_game_data.c_game_mode == 0) variables.Game_data.activeGame.active = false;
	else if (variables.Cpu_game_data.c_game_mode == 1) variables.Game_data.activeGame.active = true;
	else if (variables.Cpu_game_data.game_mode == 5) {
		//variables.Game_data.game.awaitApproach = true; // await aproch se nigdje ne koristi
	}
	else if (variables.Cpu_game_data.game_mode == 6)
	{
		console.log('usao je u game cricket !!!!!!!!!!!!!!!!');
		/*let k = 7
		let helper = 0;
		for(i=1; i<=parsedStatusData.num_players; i++){
			for(k=0; k<7; k++){
				helper = 1<<k;
				for(j=3;j>0; j--){
					if(parsedStatusData.cricket_numbers_closed[0+(i-1)*3+(j-1)]&helper){ ///umjesto 0 stavi 30
						//console.log('ovo je ','pogodak',j,'stupac',k,'igrac',i);
						number_cricket = parsedStatusData.cricket_numbers[k];
						variables.Cpu_data.player[i-1].numbersToHit[number_cricket]=j;
						break;
					}
				}
			}
		}*/

	}
	variables.Display_data.Quatro = false;
	variables.Game_data.activeGame.quatro = false;
	if (Setup_data.ee_quatro_mode_on != 0){
		variables.Display_data.Quatro = true;
		variables.Game_data.activeGame.quatro = true;
	}
	//let price = Setup_data.ee_price_adjust[variables.game];

	// ********* SVE TIPKE ZA OPCIJE ***************************
		
	variables.Game_data.activeGame.doubleIn = false;
	variables.Game_data.activeGame.doubleOut = false;
	variables.Game_data.activeGame.masterOut = false;
	variables.Game_data.activeGame.parcheesi = false;
	variables.Game_data.activeGame.runAndGun = false;
	variables.Game_data.activeGame.equalOption = false;
	variables.Game_data.activeGame.endOption = false;
	
	variables.Game_data.game.rules.doubleIn = variables.Game_data.activeGame.doubleIn; ///imamo na dva mjesta u game_data
	variables.Game_data.game.rules.doubleOut = variables.Game_data.activeGame.doubleOut;
	variables.Game_data.game.rules.masterOut = variables.Game_data.activeGame.masterOut;
	variables.Game_data.game.rules.parcheesi = variables.Game_data.activeGame.parcheesi;
	variables.Game_data.game.rules.runAndGun = variables.Game_data.activeGame.runAndGun;
	variables.Game_data.game.rules.equalOption = variables.Game_data.activeGame.equalOption;
	variables.Game_data.game.rules.quatro = variables.Game_data.activeGame.quatro;
	variables.Game_data.game.rules.endOption = variables.Game_data.activeGame.endOption;
	variables.Game_data.activeGame.teamCount = 0;

	if (variables.Cpu_game_data.c_option & constant.OPTION_DOUBLE_IN){
		//console.log('double in je aktiviran',variables.Cpu_game_data.c_option, constant.OPTION_DOUBLE_IN)
		if (variables.Cpu_game_data.c_game == 6){
			variables.Game_data.activeGame.doubleIn = true;
			variables.Display_data.GameOptionName += constant.GameNameSub_int[variables.Cpu_game_data.c_sub_game];
		} else {
			variables.Game_data.activeGame.doubleIn = true;
			variables.Display_data.GameOptionName += 'Double In';
		}
	}
	if (variables.Cpu_game_data.c_option & constant.OPTION_DOUBLE_OUT){
		//console.log('double out je aktiviran',variables.Cpu_game_data.c_option, constant.OPTION_DOUBLE_OUT)
		variables.Game_data.activeGame.doubleOut = true
		if (variables.Game_data.activeGame.doubleIn){
			variables.Display_data.GameOptionName +='/'
		}
		variables.Display_data.GameOptionName += 'Double Out';
	}

	if ((variables.Cpu_game_data.c_option & constant.OPTION_DBLIN_OUT) && !variables.Game_data.activeGame.doubleIn 
			&& !variables.Game_data.activeGame.doubleOut){
		//console.log('DBIN_OUT je aktiviran',variables.Cpu_game_data.c_option,constant.OPTION_DBLIN_OUT)
		variables.Display_data.GameOptionName += 'Double In Double Out';
	}

	
	if (variables.Cpu_game_data.c_option & constant.OPTION_MASTEROUT){
		//console.log('MASTEROUT je aktiviran',variables.Cpu_game_data.c_option, constant.OPTION_MASTEROUT)
		if (variables.Cpu_game_data.c_game == 6){
			variables.Game_data.activeGame.masterOut = true;
			variables.Display_data.GameOptionName += constant.GameNameSub_int[variables.Cpu_game_data.c_sub_game];
		} else {
			variables.Game_data.activeGame.masterOut = true;
			if (variables.Game_data.activeGame.doubleIn)variables.Display_data.GameOptionName +='/'
			variables.Display_data.GameOptionName += 'Master Out';
		}
		
	}
	
	if (variables.Cpu_game_data.c_option & constant.OPTION_TEAM){
		console.log('TEAM je aktiviran', variables.Cpu_game_data.c_option, constant.OPTION_TEAM)
		if (variables.Cpu_game_data.c_team_num > 0) variables.Game_data.activeGame.teamCount = variables.Cpu_game_data.c_team_num % 10;
		
		if(variables.Game_data.activeGame.doubleIn || variables.Game_data.activeGame.doubleOut 
			|| variables.Game_data.activeGame.masterOut || variables.Game_data.activeGame.parcheesi){
			variables.Display_data.GameOptionName +='/'
		}
		variables.Display_data.GameOptionName += 'Team';
	}

	if (variables.Cpu_game_data.c_option & constant.OPTION_PARCHEESI){
		console.log('PARCHEESI je aktiviran', variables.Cpu_game_data.c_option, constant.OPTION_PARCHEESI)
		if(variables.Game_data.activeGame.doubleIn || variables.Game_data.activeGame.doubleOut 
			|| variables.Game_data.activeGame.masterOut || variables.Game_data.activeGame.teamCount){
			variables.Display_data.GameOptionName +='/'
		}
		if (variables.Cpu_game_data.c_sub_game == 10){
			variables.Game_data.activeGame.runAndGun = true;
		}
		else if (variables.Cpu_game_data.c_sub_game == 11){
			variables.Game_data.activeGame.parcheesi = true;
		}
		else if (variables.Cpu_game_data.c_sub_game == 12){
			variables.Game_data.activeGame.parcheesi = true;
			variables.Game_data.activeGame.equalOption = true;
		}
		else if (variables.Cpu_game_data.c_sub_game == 13){
			variables.Game_data.activeGame.parcheesi = true;
			variables.Game_data.activeGame.endOption = true;
		}
		variables.Display_data.GameOptionName += constant.GameNameSub[variables.Cpu_game_data.c_sub_game];
	}
	
	if ((variables.Cpu_game_data.c_option & constant.OPTION_EQUAL) && !variables.Game_data.activeGame.parcheesi){
		console.log('EQUAL je aktiviran', variables.Cpu_game_data.c_option, constant.OPTION_EQUAL)
		if(variables.Game_data.activeGame.doubleIn || variables.Game_data.activeGame.doubleOut 
			|| variables.Game_data.activeGame.masterOut || variables.Game_data.activeGame.teamCount){
			variables.Display_data.GameOptionName +='/'
		}
		if (variables.Cpu_game_data.c_sub_game == 1) variables.Game_data.activeGame.equalOption = true;
		else if (variables.Cpu_game_data.c_sub_game == 2) variables.Game_data.activeGame.endOption = true;
	
		variables.Display_data.GameOptionName += constant.GameNameSub_int[variables.Cpu_game_data.c_sub_game];
	}
	/*if(option === 16 && sub_game === 70){
		variables.gameName = constant.GameNameSub[sub_game];
	}
	if(variables.game === 6 && (sub_game === 26 || 
							   sub_game === 36 ||
							   sub_game === 27 ||
							   sub_game === 28
							   )){
		variables.Display_data.GameOptionName = constant.GameNameSub[sub_game];
	}*/


	variables.Game_data.game.isX01 = false;
	variables.Game_data.game.isCricket = false;
	variables.Game_data.game.isOther = false;
	if (variables.Cpu_game_data.c_game < 6)  variables.Game_data.game.isX01 = true; 			//igra x01
	else if (variables.Cpu_game_data.c_game == 6)  variables.Game_data.game.isCricket = true; 	//igra cricket
	else if (variables.Cpu_game_data.c_game > 6)  variables.Game_data.game.isOther = true; 		//neka igra
	
	return 1;
}

function init_val_json_game_data()
{
	
	variables.Game_data.game.gameStatus.players = []; //ok//
	variables.Game_data.game.gameStatus.teams = [];
	variables.Game_data.game.gameStatus.round = 0;//ok//
	variables.Game_data.game.gameStatus.currentPlayer = 0;//
	variables.Game_data.game.gameStatus.currentDart = 0;
	variables.Game_data.game.gameStatus.gameOver = false;
	variables.Game_data.game.gameStatus.message = "";
	variables.Game_data.game.gameStatus.roundStartScore = [];
	variables.Game_data.game.gameStatus.teamRoundStartScore = [];
	variables.Game_data.game.gameStatus.victor = "";
	variables.Game_data.game.gameStatus.bustScore = 0;
	variables.Game_data.game.gameStatus.fillScore = 0;
			
	variables.Game_data.game.playOffStarted = false;
			
	variables.Game_data.game.playoffGame.playOff_postion = 0;
	variables.Game_data.game.playoffGame.playOff_nextplayer = 0;
	variables.Game_data.game.playoffGame.players = [];

	variables.Game_data.game.rules.gameType = 0;
	variables.Game_data.game.rules.rounds = 0;
	variables.Game_data.game.rules.quatro = false;
	variables.Game_data.game.rules.undo = false;
	variables.Game_data.game.rules.handicap = false;
	variables.Game_data.game.rules.uniqueId = '';
	variables.Game_data.game.rules.score = 0;
	variables.Game_data.game.rules.parcheesi = false;
	variables.Game_data.game.rules.runAndGun = false;
	variables.Game_data.game.rules.runAndGunTime = 0;
	variables.Game_data.game.rules.playOff = false;
	variables.Game_data.game.rules.doubleIn = false;
	variables.Game_data.game.rules.doubleOut = false;
	variables.Game_data.game.rules.masterOut = false;
	variables.Game_data.game.rules.equalOption = false;
	variables.Game_data.game.rules.endOption = false;
	variables.Game_data.game.rules.bull = 0;
		
	variables.Game_data.game.isX01 = false;
	variables.Game_data.game.isCricket = false;
	variables.Game_data.game.isOther = false;
	variables.Game_data.game.teamCount = 0;
	variables.Game_data.game.darts = [];
	variables.Game_data.game.awaitApproach = false;
	variables.Game_data.game.lastPrice = 0;
	variables.Game_data.game.hit = {};
	variables.Game_data.game.isFullyClosed = false;
	variables.Game_data.game.dart1 = '';
	variables.Game_data.game.dart2 = '';
	variables.Game_data.game.dart3 = '';
	variables.Game_data.game.roundScore = 0;
	variables.Game_data.game.suggestNumbers =  [];
	variables.Game_data.game.isOnline = false;
	variables.Game_data.game.dartsThrown = 0;

	variables.Game_data.activeGame.active = false;
	variables.Game_data.activeGame.gameType = 0;// neznas sta je ovo
	variables.Game_data.activeGame.score = 0;
	variables.Game_data.activeGame.parcheesi = false;
	variables.Game_data.activeGame.rounds = ''; //ok
	variables.Game_data.activeGame.runAndGun = false;
	variables.Game_data.activeGame.runAndGunTime = 0;
	variables.Game_data.activeGame.playOff = false;
	variables.Game_data.activeGame.doubleIn = false;
	variables.Game_data.activeGame.doubleOut = false;
	variables.Game_data.activeGame.masterOut = false;
	variables.Game_data.activeGame.equalOption = false;
	variables.Game_data.activeGame.endOption = false;
	variables.Game_data.activeGame.quatro = false;
	variables.Game_data.activeGame.undo = false;
	variables.Game_data.activeGame.handicap = false;
	variables.Game_data.activeGame.bull = 0;
	variables.Game_data.activeGame.price = 0;

	variables.Game_data.playoffStarted = false;
	variables.Game_data.isPlayoff = false;

	return 1;
}
/*
// reagiraj odmah kad se promijeni var_restart
shared.on("var_restart", (value) => {
	if (value > 0) {
		console.log(`⚡ var_restart = ${value}, šaljem file...`);
		brojac_file_sector_boot = 0;
		shared.var_restart = 0;
		sendFileToCPU("./engine/workers/update_files/boot_loader1.hex");
	}
});

let hexLines = [];

function sendFileToCPU(filePath) 
{
	fs.readFile(filePath, "utf8", (err, data) => {
		if (err) {
			console.error("❌ Greška pri čitanju file-a:", err);
			return;
		}
		hexLines = data.split(/\r?\n/);   // spremi sve linije u globalno polje
		brojac_file_sector_boot = 0;
		console.log("📂 HEX file učitan, broj linija:", hexLines.length);

		// odmah pošalji prvu liniju
		sendHexLine(hexLines, brojac_file_sector_boot);
	});
}
// funkcija za slanje file-a na serial
/*function sendFileToCPU(filePath) {
	fs.readFile(filePath, (err, data) => {
	  if (err) {
		console.error("❌ Greška pri čitanju file-a:", err);
		return;
	  }
	  brojac_file_sector_boot += 1;
	  writeSerial(data_final_blok, constant.HEX_B);
	 console.log("✅ Poslano na serial:", filePath);
	});
}*/
/*
function sendHexLine(lines, index) {
	if (index >= lines.length) return false; // EOF
	const line = lines[index].trim();
	if (!line) return true; // preskoči prazne redove

	const data_final_blok = Buffer.from(line + "\r\n", "ascii");
	writeSerial(data_final_blok, constant.HEX_B);
	console.log("➡️ Poslana linija:", index, line);

	return true;
}*/

let hexLines = [];
let bootloaderReady = false;
let var_bootloader_running = 0;
let brojac_file_sector_boot_prev = 0;

// reagiraj odmah kad se promijeni var_restart
shared.on("var_restart", (value) => {
	if (value > 0) {
		console.log(`⚡ var_restart = ${value}, sending file...`);
		brojac_file_sector_boot = 0;
		shared.var_restart = 0;
		var_bootloader_running = 1;
		sendFileToCPU("./engine/workers/update_files/boot_loader111.hex");

	}
});

function sendFileToCPU(filePath) {
	fs.readFile(filePath, "utf8", (err, data) => {
		if (err) {
			console.error("❌ Error file loading:", err);
			return;
		}
		hexLines = data.split(/\r?\n/);
		brojac_file_sector_boot = 0;
		brojac_file_sector_boot_prev = 0;
		bootloaderReady = false;
		//socket.emit(socketEnum.SHOW_BOOT_LOADER,0,hexLines.length,0);
		//pio.emit('Monitor:Igra',game_data,Cpu_data,hit);
		//sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus); 
		//socket.emit('MONITOR>RPI:potreban_bootloader_update', temp);
		console.log("📂 HEX file loaded, num of lines:", hexLines.length);
		console.log("⏳ wait handshake from bootloader...");
		socket.emit(socketEnum.SHOW_BOOT_LOADER,1,hexLines.length,1);
		//socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
		
	});
}

function sendHexLine(lines, index) {
	if (index >= lines.length) return false; // EOF
	const line = lines[index].trim();
	if (!line) return true; // preskoči prazne redove

	const data_final_blok = Buffer.from(line + "\r\n", "ascii");
	writeSerial(data_final_blok, constant.HEX_B);
	/*console.log("➡️ Poslana linija:", index, line);*/
	const percent = ((index + 1) / lines.length * 100).toFixed(2);
    process.stdout.write(
        `\r➡️ Sending line ${index + 1}/${lines.length} (${percent}%) ${line}`
    );

	//socket.emit(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data);
	//sendToAllClients(socketEnum.SHOW_NEW_GAME,variables.Cpu_game_data,variables.Cpu_settings_data,variables.Cpu_other_data,hitStatus,variables.Cpu_settings_turnir_data); 
	const step = Math.floor(lines.length / 100) || 1;  // zaštita da ne bude 0
    if ((index + 1) % step === 0) {
        const percentCijeli = Math.floor((index + 1) / lines.length * 100);
        socket.emit(socketEnum.SHOW_BOOT_LOADER, index + 1, lines.length, percentCijeli);
    }

	return true;
}


//************** update funkcije

let var_update_running = 1;

// reagiraj odmah kad se promijeni var_start_update
shared.on("var_start_update", (value) => {
	if (value > 0) {
		console.log(`⚡ waiting front... `);
		shared.var_start_update = 0;
		if (var_update_running)
		{
			var_update_running = 1;
			console.log(`⚡ check-for-update = ${value}, front ready → starting update`);
			probaj_se_spojiti_na_server_za_update();
		}

	}
});

//jednostavnija verzija sa wget
// https://etcgogo.github.io/test_ver_u2/index_test.zip
function probaj_se_spojiti_na_server_za_update(socket) {
    const { exec } = require('child_process');
    const fs = require('fs');
    const https = require('https');

    const baseDir = '/home/hybrid3/server';
    const downloadDir = `${baseDir}/download`;
    const unzipDir = `${baseDir}/unzip`;
    const restoreDir = `${baseDir}/restore`;

    const versionFile = `${baseDir}/VERSION.txt`;
    const latestUrl = 'https://etcgogo.github.io/test_ver_u2/latest.txt';
    const zipUrl = 'https://etcgogo.github.io/test_ver_u2/index_test.zip';
    const zipPath = `${downloadDir}/update.zip`;

    // helper za frontend log
	function log(msg) {
		console.log(msg);
		shared.emit('update_log_front', msg);
	}
	  
    function compareVersions(a, b) {
        const pa = a.split('.').map(Number);
        const pb = b.split('.').map(Number);
        for (let i = 0; i < 3; i++) {
            const na = pa[i] || 0;
            const nb = pb[i] || 0;
            if (na > nb) return 1;
            if (na < nb) return -1;
        }
        return 0;
    }

    log('🔄 Cyberdine update check started');

    // 1. lokalna verzija
    let localVersion = '0.0.0';
    if (fs.existsSync(versionFile)) {
        localVersion = fs.readFileSync(versionFile, 'utf8').trim();
    }
    log(`📦 Current version: ${localVersion}`);

    // 2. provjera latest.txt
    https.get(latestUrl, (res) => {
        if (res.statusCode !== 200) {
            log('ℹ️ No update information found');
            return;
        }

        let data = '';
        res.on('data', d => data += d);
        res.on('end', () => {
            const remoteVersion = data.trim();
            log(`🌍 Latest version available: ${remoteVersion}`);

            if (!/^\d+\.\d+\.\d+$/.test(remoteVersion)) {
                log('⚠️ Invalid version format, skipping update');
                return;
            }

            if (compareVersions(remoteVersion, localVersion) <= 0) {
                log('✅ Already up to date');
                return;
            }

            log('⬆️ New version detected');
            startDownload(remoteVersion);
        });
    }).on('error', () => {
        log('⚠️ Cannot reach update server');
    });

    function startDownload(newVersion) {
        [downloadDir, unzipDir].forEach(d => {
            if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
        });

        log('📥 Downloading update...');
        exec(`curl -fL "${zipUrl}" -o "${zipPath}"`, (err) => {
            if (err) {
                log('❌ Download failed');
                return;
            }
            log('✅ Download done');
            unzipZip(newVersion);
        });
    }

    function unzipZip(newVersion) {
        log('📦 Unzipping...');
        exec(`rm -rf "${unzipDir}"/* && unzip -o "${zipPath}" -d "${unzipDir}"`, (err) => {
            if (err) {
                log('❌ Unzip failed');
                return;
            }
            log('✅ Unzip done');
            createRestore(newVersion);
        });
    }

    function createRestore(newVersion) {
        log('🛟 Creating restore...');
        exec(`rm -rf "${restoreDir}" && mkdir -p "${restoreDir}"`, (err) => {
            if (err) {
                log('❌ Restore folder failed');
                return;
            }

            const cmd = `
                for f in $(find "${unzipDir}" -type f); do
                    rel="\${f#${unzipDir}/}"
                    src="${baseDir}/$rel"
                    dst="${restoreDir}/$rel"
                    if [ -f "$src" ]; then
                        mkdir -p "$(dirname "$dst")"
                        cp -a "$src" "$dst"
                    fi
                done
            `;

            exec(cmd, (err) => {
                if (err) {
                    log('❌ Restore failed');
                    return;
                }
                log('✅ Restore done');
                applyUpdate(newVersion);
            });
        });
    }

    function applyUpdate(newVersion) {
        log('🚀 Applying update...');
        const cmd = `
            rsync -a --delete \
            --exclude=download \
            --exclude=unzip \
            --exclude=restore \
            "${unzipDir}/"*/ "${baseDir}/"
        `;

        exec(cmd, (err) => {
            if (err) {
                log('❌ Update failed');
                return;
            }

            fs.writeFileSync(versionFile, newVersion + '\n');
            log('✅ Update applied');
            rebootCountdown();
        });
    }

    function rebootCountdown() {
        let i = 3;
        const t = setInterval(() => {
            log(`🔁 Reboot in ${i}...`);
            i--;
            if (i === 0) {
                clearInterval(t);
                exec('reboot');
            }
        }, 1000);
    }
}
//************** FUNKCIJE ZA KOMUNIKACIJU PODATAKA IZ APARATA ************** */
function serial_data_center()
{ 
	let cmd_, cmdx_, cmd_boot_;
	let polje_podaci = new Uint8Array(DATA_BUFFER_RX_SIZE);
	

	if (data_counter_rx_buffer_boot > 0)
	{
		while (data_counter_rx_buffer_boot != data_counter_x_rx_read_buffer_boot)	
		{
			cmd_boot_ = protocol_boot_read(polje_podaci);
			if (cmd_boot_ == 0) break;  //ako je sve procitano
			else
			{ 
				if (var_bootloader_running == 1)
				{
					//console.log("komanda:", cmd_boot_);
					protokol_boot(cmd_boot_, polje_podaci);
				}
			}
			if (flag_protocol_boot_ready_to_reset)
			{
				data_counter_x_rx_read_buffer_boot = 0; //isprazni buffere
				data_counter_rx_buffer_boot = 0;	//isprazni buffere
				flag_protocol_boot_ready_to_reset = 0;
			}
		}
	}

	if (data_counter_rx_buffer > 0)
	{	
		if (brojac_file_sector_boot == 0)
		{
			//console.log('data_counter_read_buffer ', data_counter_rx_buffer);
			while (data_counter_rx_buffer != data_counter_x_rx_read_buffer)
			{
				cmdx_ = protocolx_read(polje_podaci);
				if (cmdx_ == 0) break;  //ako je sve procitano
				else
				{
					console.log("command:", fset.hexify(cmdx_));
					//console.log("polje_podaci:", polje_podaci);
					//console.log("podaci_len_protocolx:", podaci_len_protocolx);
					protokolx(cmdx_, polje_podaci, podaci_len_protocolx);
				}
			}
			while (data_counter_rx_buffer_4 != data_counter_rx_read_buffer)
			{
				cmdx_ = protocol4_read(polje_podaci);
				if (cmdx_ == 0) break;  //ako je sve procitano
				else
				{
					console.log("command_4:", fset.hexify(cmdx_));
					//console.log("polje_podaci:", polje_podaci);
					//console.log("podaci_len_protocolx:", podaci_len_protocolx);
					protokol4(cmdx_);
				}
			}
			if (flag_protocol_x_ready_to_reset || flag_protocol_ready_to_reset)
			{
				data_counter_x_rx_read_buffer = 0;  //isprazni buffere
				data_counter_rx_read_buffer = 0;  //isprazni buffere
				data_counter_rx_buffer = 0;
				data_counter_rx_buffer_4 = 0;
				flag_protocol_x_ready_to_reset = 0;
				flag_protocol_ready_to_reset = 0;
				console.log("resetiraj countere");
			}
		}
		/*else
		{
			/*sendFileToCPU("./engine/workers/update_files/boot_loader1.hex");

			console.log('shared.var_restart', shared.var_restart);
			console.log('brojac_file_sector_boot', brojac_file_sector_boot);
			//shared.var_restart = 0;
			console.log('data_counter_read_buffer ', data_counter_rx_buffer);
			// pošalji sljedeću liniju ako postoji*/
		/*	const ok = sendHexLine(hexLines, brojac_file_sector_boot);
			if (ok) {
				brojac_file_sector_boot++;
			} else {
				console.log("📌 EOF fajla, čekam 'K' od bootloadera...");
			}
			console.log("brojac_file_sector_boot =", brojac_file_sector_boot);
		}*/
		return 1;
	}
	return 0;
}
function protokol4(cmd_)
{
	
	if (cmd_ > 0)
	{

	}
	return 0;
}

function protokol_boot(cmd_, polje_podaci)
{
	// Primer log funkcije
	//logToFile('Ovo je testni zapis. protokolx', cmd_);
	//logToFile('protocolx ',polje_podaci);
	//console.log("cmd_podaci_len:", cmd_podaci_len);
	if (cmd_ == 1)   //CYB03
	{
		if (var_bootloader_running == 1 && bootloaderReady == false)    //samo ako je start cmd preko fronta
		{
			console.log("🔑 got handshake, bootloader ready!");
			bootloaderReady = true;
			brojac_file_sector_boot = 0;
			brojac_file_sector_boot_prev = brojac_file_sector_boot;
			writeSerial("BOOT", constant.HEX_B);
			sendHexLine(hexLines, brojac_file_sector_boot);
			brojac_file_sector_boot++;
		}
	}
	if (bootloaderReady == true)
	{
		if (cmd_ == 2)   //+ ok data
		{
			const ok = sendHexLine(hexLines, brojac_file_sector_boot);
			if (ok) 
			{
				brojac_file_sector_boot_prev = brojac_file_sector_boot;
				brojac_file_sector_boot++;
			} else {
				console.log("📌 EOF, wait end from bootloadera...");
			}
		} 
		else if (cmd_ == 3)   //- or ! wrong or missing data ponovi sektor
		{
			const ok = sendHexLine(hexLines, brojac_file_sector_boot_prev);
			console.log("RESEND line" , brojac_file_sector_boot_prev);
		}
		else if (cmd_ == 4)   //K eof
		{
			brojac_file_sector_boot = 0;
			bootloaderReady = false;
			var_bootloader_running = 0;
			console.log(" response end from bootloadera...DONE");
			socket.emit(socketEnum.SHOW_BOOT_LOADER, hexLines.length, hexLines.length, 100);
		} 
	} 
	return 0;
}

function protokolx(cmd_, polje_podaci, cmd_podaci_len)
{
	// Primer log funkcije
	//logToFile('Ovo je testni zapis. protokolx', cmd_);
	//logToFile('protocolx ',polje_podaci);
	//console.log("cmd_podaci_len:", cmd_podaci_len);
	if (cmd_ == constant.CMD_RETURN_GAME_DATA)   //usporedi sa const.js
	{
		//console.log("polje_podaci:", polje_podaci);
		copyDataToClassObject(polje_podaci, variables.Cpu_game_data, 0, 2);
		//console.log("Cpu_game_data:", variables.Cpu_game_data);
		console.log("Cpu_game_data.c_game_mode:", variables.Cpu_game_data.c_game_mode);
		console.log("Cpu_game_data.c_game:", variables.Cpu_game_data.c_game);
		console.log("Cpu_game_data.c_option:", variables.Cpu_game_data.c_option);
		//console.log("Cpu_game_data.c_sub_game:", variables.Cpu_game_data.c_sub_game);
		//console.log("Cpu_game_data.c_team_num:", variables.Cpu_game_data.c_team_num);
		//console.log("Cpu_game_data.c_num_players:", variables.Cpu_game_data.c_num_players);
		/*for (let i = 0; i < variables.Cpu_other_data.c_podaci.length; i++) {
			variables.Cpu_other_data.c_podaci[i] = 0; // Postavlja sve elemente na 255
		}*/
		init_val_json_game_data();	//postavi vrijednosti u default 0
		update_json_data_players();
		update_json_data_game_rules();
		update_socket_data(1);
		socket_send_data();
	}
	else if (cmd_ == constant.CMD_RETURN_GAME_SETTINGS)
	{
		//variables.Cpu_settings_data = polje_podaci;
		copyDataToClassObject(polje_podaci, variables.Cpu_settings_data, 0, 1);
		//console.log("Cpu_settings_data:", variables.Cpu_settings_data);
		console.log("Cpu_settings_data.ee_bull_value:", variables.Cpu_settings_data.ee_bull_value);
		socket_send_data();
	}
	else if (cmd_ == constant.CMD_RETURN_GAME_TURNIR_SETTINGS)
	{
		//variables.Cpu_settings_data = polje_podaci;
		copyDataToClassObject(polje_podaci, variables.Cpu_settings_turnir_data, 0, 4);
		//console.log("Cpu_settings_data:", variables.Cpu_settings_data);
		//console.log("Cpu_settings_turnir_data.ee_round_turnir_adjust[0]:", Cpu_settings_turnir_data.ee_round_turnir_adjust[0]);
		socket_send_data();
	}
	else if (cmd_ == constant.CMD_CURRENT_MENU_SETTINGS)
	{
		//variables.Cpu_settings_data = polje_podaci;
		copyDataToClassObject(polje_podaci, variables.Cpu_other_data, 0, 3);
		for (let i = 254; i > 0; i--) {
			variables.Cpu_other_data.c_podaci[i] = variables.Cpu_other_data.c_podaci[i - 1];
		}
		variables.Cpu_other_data.c_podaci[0] = constant.CMD_CURRENT_MENU_SETTINGS;
		//console.log("Cpu_settings_data:", variables.Cpu_settings_data);
		console.log("CMD_CURRENT_MENU_SETTINGS AC", variables.Cpu_other_data.c_podaci[0]);
		socket_send_data();
	}
	else if (cmd_ == constant.CMD_COUNTERS_MENU_SETTINGS)
	{
		//variables.Cpu_settings_data = polje_podaci;
		copyDataToClassObject(polje_podaci, variables.Cpu_other_data, 0, 3);
		for (let i = 254; i > 0; i--) {
			variables.Cpu_other_data.c_podaci[i] = variables.Cpu_other_data.c_podaci[i - 1];
		}
		variables.Cpu_other_data.c_podaci[0] = constant.CMD_COUNTERS_MENU_SETTINGS;
		//console.log("Cpu_settings_data:", variables.Cpu_settings_data);
		console.log("CMD_COUNTERS_MENU_SETTINGS AA", variables.Cpu_other_data.c_podaci[0]);
		socket_send_data();
	}
	else if (cmd_ == constant.CMD_RETURN_MENU_SETTINGS_MAIN)
	{
		//variables.Cpu_settings_data = polje_podaci;
		copyDataToClassObject(polje_podaci, variables.Cpu_other_data, 0, 3);
		for (let i = 254; i > 0; i--) {
			variables.Cpu_other_data.c_podaci[i] = variables.Cpu_other_data.c_podaci[i - 1]; 
		}
		variables.Cpu_other_data.c_podaci[0] = constant.CMD_RETURN_MENU_SETTINGS_MAIN;
		//console.log("Cpu_settings_data:", variables.Cpu_settings_data);
		console.log("CMD_RETURN_MENU_SETTINGS_MAIN AD", variables.Cpu_other_data.c_podaci[0]);
		socket_send_data();
	}
	else if (cmd_ == constant.CMD_RETURN_MENU_SETTINGS_SEC)
	{
		//variables.Cpu_settings_data = polje_podaci;
		copyDataToClassObject(polje_podaci, variables.Cpu_other_data, 0, 3);
		for (let i = 254; i > 0; i--) {
			variables.Cpu_other_data.c_podaci[i] = variables.Cpu_other_data.c_podaci[i - 1]; 
		}
		variables.Cpu_other_data.c_podaci[0] = constant.CMD_RETURN_MENU_SETTINGS_SEC;
		//console.log("Cpu_settings_data:", variables.Cpu_settings_data);
		console.log("CMD_RETURN_MENU_SETTINGS_SEC AE", variables.Cpu_other_data.c_podaci[0]);
		socket_send_data();
	}
	else if (cmd_ == constant.CMD_CURRENT_MENU_TEST)
	{
		//variables.Cpu_settings_data = polje_podaci;
		copyDataToClassObject(polje_podaci, variables.Cpu_other_data, 0, 3);
		for (let i = 254; i > 0; i--) {
			variables.Cpu_other_data.c_podaci[i] = variables.Cpu_other_data.c_podaci[i - 1]; 
		}
		variables.Cpu_other_data.c_podaci[0] = constant.CMD_CURRENT_MENU_TEST;
		//console.log("Cpu_settings_data:", variables.Cpu_settings_data);
		console.log("CMD_CURRENT_MENU_TEST AF", variables.Cpu_other_data.c_podaci[0]);
		socket_send_data();
	}
	else if (cmd_ == constant.CMD_CURRENT_MENU_SETUP)
	{
		//variables.Cpu_settings_data = polje_podaci;
		copyDataToClassObject(polje_podaci, variables.Cpu_other_data, 0, 3);
		for (let i = 254; i > 0; i--) {
			variables.Cpu_other_data.c_podaci[i] = variables.Cpu_other_data.c_podaci[i - 1]; 
		}
		variables.Cpu_other_data.c_podaci[0] = constant.CMD_CURRENT_MENU_SETUP;
		//console.log("Cpu_settings_data:", variables.Cpu_settings_data);
		console.log("CMD_CURRENT_MENU_SETUP BB", variables.Cpu_other_data.c_podaci[0]);
		socket_send_data();
	} 
	else if (cmd_ == constant.CMD_RPI_TO_CPU_READY)
	{
		protocolx_write("", constant.CMD_RPI_TO_CPU_READY);
		console.log('rpi rq send cpu ready');
	}
	//logToFile('protocolx ',polje_podaci);
	return 0;
}


function protocol4_read(data_podaci) 
{
	let start = 0, stop = 0, i = 0;
	let csum = 0, len_data = 0, cmd_; 
	flag_protocol_ready_to_reset = 0;
	start = data_counter_rx_read_buffer;
	stop = data_counter_rx_buffer_4;
	i = start;
	
	while (start < stop) {  //trazi podatke
		if (buffer_serial_rx_data_4[i] == constant.PREFIX1)  //ima prefix
		{
			i++;
			start++;
			if (i >= stop) return 0;   //prekini ako je kraj byta
			if (buffer_serial_rx_data_4[i] == constant.PREFIX2)  //ima prefix
			{
				i++;
				start++;
				if (i >= stop) return 0;   //prekini ako je kraj byta
				cmd_ = buffer_serial_rx_data_4[i];
				
				i++;
				start++;
				if (i >= stop) return 0;   //prekini ako je kraj byta
				//console.log("cmd_4_comp:", buffer_serial_rx_data[i]);
				if (buffer_serial_rx_data_4[i] == (255 - cmd_))  //ima komplement ok
				{
					data_counter_rx_read_buffer = start;
					if (data_counter_rx_read_buffer == data_counter_rx_buffer_4)
					{
						flag_protocol_ready_to_reset = 1;
						//data_counter_rx_read_buffer = 0;  //isprazni buffere
						//data_counter_rx_buffer = 0;
						//console.log("cmd_4_end:", cmd_);
						return cmd_; //sve procitano
					}
					/*console.log("data_counter_rx_read_buffer:", data_counter_rx_read_buffer);
					console.log("data_counter_rx_buffer_4:", data_counter_rx_buffer_4);
					console.log("cmd_4:", fset.hexify(cmd_));*/
					return cmd_; //jos nije sve procitano
				}
			}
		}
		else  //nema start byte
		{
			i++;
			start++;
		}
    }
	return 0;   //sve procitano
}
function protocol_boot_read(data_podaci)  //ovdje parsiraj buffer incoming serial data
{
	let start = 0, stop = 0, i = 0;
	let cmd_ = 0; 
	
	flag_protocol_boot_ready_to_reset = 0;
	start = data_counter_x_rx_read_buffer_boot;
	stop = data_counter_rx_buffer_boot;
	i = start;
	while (start < stop) {  //trazi podatke
		if (buffer_serial_rx_data_boot[i] == 0x43)  //ima start byte 'C'
		{
			i++; start++; if (i >= stop) return 0;   //prekini ako je kraj byta
			if (buffer_serial_rx_data_boot[i] == 0x59)  //ima start byte 'Y'
			{
				i++; start++; if (i >= stop) return 0;   //prekini ako je kraj byta
				if (buffer_serial_rx_data_boot[i] == 0x42)  //ima start byte 'B'
				{
					i++; start++; if (i >= stop) return 0;   //prekini ako je kraj byta
					if (buffer_serial_rx_data_boot[i] == 0x30)  //ima start byte '0'
					{
						i++; start++; if (i >= stop) return 0;   //prekini ako je kraj byta
						if (buffer_serial_rx_data_boot[i] == 0x33)  //ima start byte '3'
						{
							i++; start++; cmd_ = 1;   //prekini ako je kraj byta
						}
					}
				}
			}
		}
		else if (buffer_serial_rx_data_boot[i] == 0x2B)  //ima start byte '+'
		{
			i++; start++; cmd_ = 2;   //prekini ako je kraj byta
		}
		else if (buffer_serial_rx_data_boot[i] == 0x2D)  //ima start byte '-'
		{
			i++; start++; cmd_ = 3;   //prekini ako je kraj byta
		}
		else if (buffer_serial_rx_data_boot[i] == 0x21)  //ima start byte '!'
		{
			i++; start++; cmd_ = 3;   //prekini ako je kraj byta
		}
		else if (buffer_serial_rx_data_boot[i] == 0x4B)  //ima start byte 'K'
		{
			i++; start++; cmd_ = 4;   //prekini ako je kraj byta
		}
		else  //nema data byte
		{
			i++;
			start++;
			cmd_ = 0;
		}
		if (cmd_ > 0)
		{
			data_counter_x_rx_read_buffer_boot = start;
		}
		if (data_counter_x_rx_read_buffer_boot == data_counter_rx_buffer_boot)
		{
			flag_protocol_boot_ready_to_reset = 1;
		}
		if (cmd_ > 0)
		{
			return cmd_;
		}
	}
	return 0;
}

function protocolx_read(data_podaci) 
{
	let start = 0, stop = 0, i = 0;
	let csum = 0, len_data = 0, cmd_; 
	podaci_len_protocolx = 0;
	flag_protocol_x_ready_to_reset = 0;
	start = data_counter_x_rx_read_buffer;
	stop = data_counter_rx_buffer;
	i = start;
	while (start < stop) {  //trazi podatke
		if (buffer_serial_rx_data[i] == constant.START_BYTE)  //ima start byte
		{
			i++;
			start++;
			if (i >= stop) return 0;   //prekini ako je kraj byta
			len_data = buffer_serial_rx_data[i];	//ima duljinu
			if (i + len_data + 2 >= stop) return 0;   //pozicionioraj se na zadnji koji bi trerbao biti STOP BYTE prekini ako je kraj byta
			if (buffer_serial_rx_data[i + len_data + 2] == constant.STOP_BYTE)  //ima stop byte na kraju
			{	

				for (let j = i; j <= (i + len_data); j++) //provjeri csum
				{
					csum += buffer_serial_rx_data[j];
				}
				
				/*console.log("len_data = ", len_data);
				console.log("csum = ", csum % 256);
				console.log("csum_data = ", buffer_serial_rx_data[i + len_data + 1]);*/
				
				if ((csum % 256) == buffer_serial_rx_data[i + len_data + 1])  //csum ok analiziraj podatke
				{
					for (let j = i + 1; j <= (i + len_data); j++) 
					{
						if (j == (i + 1))  cmd_ = buffer_serial_rx_data[j];
						else
						{
							data_podaci[podaci_len_protocolx] = buffer_serial_rx_data[j];
							podaci_len_protocolx++;
						}
					}
					//console.log("komanda:", cmd_);
					//console.log("duljina:", buffer_serial_rx_data[i]);
					csum = 0;
					start = i + len_data + 3;   //odi na iduci podataka
					i = start;
					data_counter_x_rx_read_buffer = start;
					if (data_counter_x_rx_read_buffer == data_counter_rx_buffer)
					{
						flag_protocol_x_ready_to_reset = 1;
						//data_counter_x_rx_read_buffer = 0;  //isprazni buffere
						//data_counter_rx_buffer = 0;
						return cmd_; //sve procitano

					}
					return cmd_; //jos nije sve procitano
				}
				else //csum nije ok
				{
					console.log("********************* !!! CSUM ERROR check cable !!! *********************");
					csum = 0;
				}
			}
			else   //nema stop
			{
				csum = 0;
			}
		}
		else  //nema start byte
		{
			i++;
			start++;
			csum = 0;
		}
    }

	return 0;   //sve procitano
}

function protocolx_write(data_podaci, cmd_)   //salje na serijski port preko protokola podatke i komandu
{
	let csum = 0;  //csum za slanje na port
	let duljina = data_podaci.length;  //duljina buffera podataka
	let data_final = new Uint8Array(duljina + 5);
	csum += duljina + 1;  //ukupna duljina
	csum += cmd_;
	for (let i = 0; i < duljina; i++) {
        csum += data_podaci[i];
		data_final[3 + i] = data_podaci[i];
    }

	data_final[0] = constant.START_BYTE;
	data_final[1] = duljina + 1;
	data_final[2] = cmd_;
	
	data_final[duljina + 3] = csum;
	data_final[duljina + 4] = constant.STOP_BYTE;

	//console.log("Duljina niza:", duljina + 1);
    /*console.log("Zbroj podataka u nizu:", csum);*/
	console.log(data_final);
	writeSerial(data_final, constant.HEX_B);
	return 1;
}

//************** FUNKCIJE ZA POPUNJAVANJE PODATAKA IZ APARATA U MEMORIJU ************** */
// Function to copy data from dataArray to obj
function copyDataToClassObject(dataArray, obj, startIndex, cmd_type) {
    //copyDataToClassObject(polje_podaci, variables.Cpu_settings_data, 0, 1);
	if (cmd_type == 1)   //Cpu_settings_data
	{
		//variables.polje_from_Cpu_settings_data = dataArray.slice(startIndex + 0, startIndex + 173);
		variables.Cpu_settings_data.ee_price_adjust = dataArray.slice(startIndex + 0, startIndex + 30);
		variables.Cpu_settings_data.ee_happy_price_adjust = dataArray.slice(startIndex + 30, startIndex + 60);
		variables.Cpu_settings_data.ee_round_adjust = dataArray.slice(startIndex + 60, startIndex + 90);
		variables.Cpu_settings_data.ee_happy_round_adjust = dataArray.slice(startIndex + 90, startIndex + 120);
		variables.Cpu_settings_data.ee_setup_time = dataArray.slice(startIndex + 120, startIndex + 123);
		variables.Cpu_settings_data.ee_happy_setup_time = dataArray.slice(startIndex + 123, startIndex + 127);
		variables.Cpu_settings_data.ee_time_limit = dataArray[startIndex + 127];
		variables.Cpu_settings_data.ee_counter_pulses = dataArray[startIndex + 128];
		variables.Cpu_settings_data.ee_switch_credits = dataArray[startIndex + 129];
		variables.Cpu_settings_data.ee_tcr = dataArray[startIndex + 130];
		variables.Cpu_settings_data.ee_bonus_credit = dataArray[startIndex + 131];
		variables.Cpu_settings_data.ee_bonus_percent = dataArray[startIndex + 132];
		variables.Cpu_settings_data.ee_lottery= dataArray[startIndex + 133];
		variables.Cpu_settings_data.ee_option_remember = dataArray[startIndex + 134];
		variables.Cpu_settings_data.ee_demo_sound = dataArray[startIndex + 135];
		variables.Cpu_settings_data.ee_quatro_mode_on = dataArray[startIndex + 136];
		variables.Cpu_settings_data.ee_return_dart = dataArray[startIndex + 137];
		variables.Cpu_settings_data.ee_bull_value = dataArray[startIndex + 138];
		variables.Cpu_settings_data.ee_play_off	= dataArray[startIndex + 139];
		variables.Cpu_settings_data.ee_lamp_on = dataArray[startIndex + 140];
		variables.Cpu_settings_data.ee_main_lamp = dataArray[startIndex + 141];
		variables.Cpu_settings_data.ee_back_light = dataArray[startIndex + 142];
		variables.Cpu_settings_data.ee_infra_adjust = dataArray[startIndex + 143];
		variables.Cpu_settings_data.ee_acceptor_time_adjust = dataArray[startIndex + 144];
		variables.Cpu_settings_data.ee_ppd_statistics = dataArray.slice(startIndex + 145, startIndex + 153);
		variables.Cpu_settings_data.ee_ppr_statistics = dataArray.slice(startIndex + 153, startIndex + 161);
	
		variables.Cpu_settings_data.ee_location	= dataArray[startIndex + 161];
		variables.Cpu_settings_data.ee_coin_value = dataArray[startIndex + 162];
		variables.Cpu_settings_data.ee_led_light = dataArray[startIndex + 163];
		variables.Cpu_settings_data.ee_sett_language = dataArray[startIndex + 164];
		variables.Cpu_settings_data.ee_sett_num_acceptors = dataArray[startIndex + 165];
		variables.Cpu_settings_data.ee_sett_num_counters = dataArray[startIndex + 166];
		variables.Cpu_settings_data.ee_sett_led_mount = dataArray[startIndex + 167];
		variables.Cpu_settings_data.ee_sett_happy_day = dataArray[startIndex + 168];
		variables.Cpu_settings_data.ee_money_for_credit	= dataArray[startIndex + 169];
		variables.Cpu_settings_data.ee_sett_target_quattro_on = dataArray[startIndex + 170];
		variables.Cpu_settings_data.ee_model_type = dataArray[startIndex + 171];
		variables.Cpu_settings_data.ee_model_target = dataArray[startIndex + 172];
		variables.Cpu_settings_data.ee_tup_sense = dataArray[startIndex + 173];

		variables.Cpu_settings_data.ee_vrijednost_kanala_cctalka = dataArray.slice(startIndex + 174, startIndex + 206);
		variables.Cpu_settings_data.ee_vrijednost_impulsa_kanala = dataArray.slice(startIndex + 206, startIndex + 208);
		variables.Cpu_settings_data.ee_cijena_jednog_kredita = dataArray[startIndex + 208];
		variables.Cpu_settings_data.ee_coin_channel_inhibit = dataArray[startIndex + 209] + (dataArray[startIndex + 210] * 256);
		variables.Cpu_settings_data.ee_bill_channel_inhibit = dataArray[startIndex + 211] + (dataArray[startIndex + 212] * 256);
		variables.Cpu_settings_data.ee_coin_bill_table_extra_credits = dataArray.slice(startIndex + 213, startIndex + 245);
	}	
	//copyDataToClassObject(polje_podaci, variables.Cpu_game_data, 0, 2);
	else if (cmd_type == 2)  //Cpu_game_data
	{
		//variables.polje_from_Cpu_game_data = dataArray.slice(startIndex + 0, startIndex + 79);;
		variables.Cpu_game_data.c_game_mode = dataArray[startIndex + 0];
		for (let j = 0; j < 8; j++){
			variables.Cpu_game_data.c_player_value[j] = dataArray[startIndex + (j * 2) + 1] + (dataArray[startIndex + (j * 2) + 2] * 256);
		}
		//variables.Cpu_game_data.c_player_value = dataArray.slice(startIndex + 1, startIndex + 17);
		variables.Cpu_game_data.c_score = dataArray[startIndex + 17] + (dataArray[startIndex + 18] * 256);
		variables.Cpu_game_data.c_dart = dataArray[startIndex + 19];
		variables.Cpu_game_data.c_round = dataArray[startIndex + 20];
		variables.Cpu_game_data.c_player_throw = dataArray[startIndex + 21];
		variables.Cpu_game_data.c_credit = dataArray[startIndex + 22] + (dataArray[startIndex + 23] * 256);;

		variables.Cpu_game_data.c_game = dataArray[startIndex + 24];
		variables.Cpu_game_data.c_option = dataArray[startIndex + 25] + (dataArray[startIndex + 26] * 256);
		variables.Cpu_game_data.c_num_players = dataArray[startIndex + 27];
		variables.Cpu_game_data.c_player_cricket = dataArray.slice(startIndex + 28, startIndex + 52);
		variables.Cpu_game_data.c_player_rank = dataArray.slice(startIndex + 52, startIndex + 60);

		variables.Cpu_game_data.c_playoff_flag = dataArray[startIndex + 60];
		variables.Cpu_game_data.c_sub_game = dataArray[startIndex + 61];
		variables.Cpu_game_data.c_team_num = dataArray[startIndex + 62];
		variables.Cpu_game_data.c_flags_data = dataArray[startIndex + 63];
		variables.Cpu_game_data.c_cricket_broj = dataArray.slice(startIndex + 64, startIndex + 72);

		variables.Cpu_game_data.c_baceno_strelica = dataArray[startIndex + 72] + (dataArray[startIndex + 73] * 256);
		variables.Cpu_game_data.c_max_strelica = dataArray[startIndex + 74] + (dataArray[startIndex + 75] * 256);
		variables.Cpu_game_data.c_hits = dataArray.slice(startIndex + 76, startIndex + 79);
		variables.Cpu_game_data.c_dijelova_kredita_u_aparatu = dataArray[startIndex + 79];
		variables.Cpu_game_data.c_cijena_igre = dataArray[startIndex + 80];
		variables.Cpu_game_data.c_max_rounds = dataArray[startIndex + 81];
		variables.Cpu_game_data.c_show_msg = dataArray[startIndex + 82];
		variables.Cpu_game_data.c_jumpers = dataArray[startIndex + 83];

		variables.Cpu_game_data.c_ver_cpu[0] = dataArray[startIndex + 84];
		variables.Cpu_game_data.c_ver_cpu[1] = dataArray[startIndex + 85];
		variables.Cpu_game_data.c_ver_target[0] = dataArray[startIndex + 86];
		variables.Cpu_game_data.c_ver_target[1] = dataArray[startIndex + 87];
		variables.Cpu_game_data.c_ver_cctalk[0] = dataArray[startIndex + 88];
		variables.Cpu_game_data.c_ver_cctalk[1] = dataArray[startIndex + 89];

	}
	else if (cmd_type == 3)  //Cpu_other_data
	{
		//variables.polje_from_Cpu_game_data = dataArray.slice(startIndex + 0, startIndex + 79);;
		variables.Cpu_other_data.c_podaci = dataArray.slice(startIndex + 0, startIndex + 254);
	}
	else if (cmd_type == 4)  //Cpu_settings_turnir_data
	{
		variables.Cpu_settings_turnir_data.ee_round_turnir_adjust = dataArray.slice(startIndex + 0, startIndex + 30);

	}

}

//************** FUNKCIJE ZA POPUNJAVANJE PODATAKA IZ MEMORIJE U APARATA ************** */
// Function to copy data from  obj to dataArray 
function copyClassObjectToData(dataArray, obj, startIndex, cmd_type) {
    //copyClassObjectToData(polje_podaci, variables.Cpu_settings_data, 0, 1);
	if (cmd_type == 1)   //Cpu_settings_data
	{
			// dataArray.slice(startIndex + 0, startIndex + 173) = variables.polje_from_Cpu_settings_data;
		for (let i = 0; i < 30; i++) {
			dataArray[startIndex + 0 + i] = variables.Cpu_settings_data.ee_price_adjust[i];
		}	
		for (let i = 0; i < 30; i++) {
			dataArray[startIndex + 30 + i] = variables.Cpu_settings_data.ee_happy_price_adjust[i];
		}	
		for (let i = 0; i < 30; i++) {
			dataArray[startIndex + 60 + i] = variables.Cpu_settings_data.ee_round_adjust[i];
		}	
		for (let i = 0; i < 30; i++) {
			dataArray[startIndex + 90 + i] = variables.Cpu_settings_data.ee_happy_round_adjust[i];
		}
		for (let i = 0; i < 3; i++) {
			dataArray[startIndex + 120 + i] = variables.Cpu_settings_data.ee_setup_time[i];
		}
		for (let i = 0; i < 4; i++) {
			dataArray[startIndex + 123 + i] = variables.Cpu_settings_data.ee_happy_setup_time[i];
		}	
		
		dataArray[startIndex + 127] = variables.Cpu_settings_data.ee_time_limit;
		dataArray[startIndex + 128] = variables.Cpu_settings_data.ee_counter_pulses;
		dataArray[startIndex + 129] = variables.Cpu_settings_data.ee_switch_credits;
		dataArray[startIndex + 130] = variables.Cpu_settings_data.ee_tcr;
		dataArray[startIndex + 131] = variables.Cpu_settings_data.ee_bonus_credit;
		dataArray[startIndex + 132] = variables.Cpu_settings_data.ee_bonus_percent;
		dataArray[startIndex + 133] = variables.Cpu_settings_data.ee_lottery;
		dataArray[startIndex + 134] = variables.Cpu_settings_data.ee_option_remember;
		dataArray[startIndex + 135] = variables.Cpu_settings_data.ee_demo_sound;
		dataArray[startIndex + 136] = variables.Cpu_settings_data.ee_quatro_mode_on;
		dataArray[startIndex + 137] = variables.Cpu_settings_data.ee_return_dart;
		dataArray[startIndex + 138] = variables.Cpu_settings_data.ee_bull_value;
		dataArray[startIndex + 139] = variables.Cpu_settings_data.ee_play_off;
		dataArray[startIndex + 140] = variables.Cpu_settings_data.ee_lamp_on;
		dataArray[startIndex + 141] = variables.Cpu_settings_data.ee_main_lamp;
		dataArray[startIndex + 142] = variables.Cpu_settings_data.ee_back_light;
		dataArray[startIndex + 143] = variables.Cpu_settings_data.ee_infra_adjust;
		dataArray[startIndex + 144] = variables.Cpu_settings_data.ee_acceptor_time_adjust;
		for (let i = 0; i < 8; i++) {
			dataArray[startIndex + 145 + i] = variables.Cpu_settings_data.ee_ppd_statistics[i];
		}
		for (let i = 0; i < 8; i++) {
			dataArray[startIndex + 153 + i] = variables.Cpu_settings_data.ee_ppr_statistics[i];
		}
		
		dataArray[startIndex + 161] = variables.Cpu_settings_data.ee_location;
		dataArray[startIndex + 162] = variables.Cpu_settings_data.ee_coin_value;
		dataArray[startIndex + 163] = variables.Cpu_settings_data.ee_led_light;
		dataArray[startIndex + 164] = variables.Cpu_settings_data.ee_sett_language;
		dataArray[startIndex + 165] = variables.Cpu_settings_data.ee_sett_num_acceptors;
		dataArray[startIndex + 166] = variables.Cpu_settings_data.ee_sett_num_counters;
		dataArray[startIndex + 167] = variables.Cpu_settings_data.ee_sett_led_mount;
		dataArray[startIndex + 168] = variables.Cpu_settings_data.ee_sett_happy_day;
		dataArray[startIndex + 169] = variables.Cpu_settings_data.ee_money_for_credit;
		dataArray[startIndex + 170] = variables.Cpu_settings_data.ee_sett_target_quattro_on;
		dataArray[startIndex + 171] = variables.Cpu_settings_data.ee_model_type;
		dataArray[startIndex + 172] = variables.Cpu_settings_data.ee_model_target;
		dataArray[startIndex + 173] = variables.Cpu_settings_data.ee_tup_sense;

		for (let i = 0; i < 32; i++) {
			dataArray[startIndex + 174 + i] = variables.Cpu_settings_data.ee_vrijednost_kanala_cctalka[i];
		}
		dataArray[startIndex + 207] = variables.Cpu_settings_data.ee_vrijednost_impulsa_kanala[0];
		dataArray[startIndex + 208] = variables.Cpu_settings_data.ee_vrijednost_impulsa_kanala[1];
		dataArray[startIndex + 209] = variables.Cpu_settings_data.ee_cijena_jednog_kredita;
		
		dataArray[startIndex + 210] = variables.Cpu_settings_data.ee_coin_channel_inhibit & 0xFF;  // Lower byte
		dataArray[startIndex + 211] = (variables.Cpu_settings_data.ee_coin_channel_inhibit >> 8) & 0xFF;  // Higher byte
		dataArray[startIndex + 212] = variables.Cpu_settings_data.ee_bill_channel_inhibit & 0xFF;  // Lower byte
		dataArray[startIndex + 213] = (variables.Cpu_settings_data.ee_bill_channel_inhibit >> 8) & 0xFF;  // Higher byte

		for (let i = 0; i < 32; i++) {
			dataArray[startIndex + 214 + i] = variables.Cpu_settings_data.ee_coin_bill_table_extra_credits[i];
		}
	}
	// copyClassObjectToData(polje_podaci, variables.Cpu_game_data, 0, 2);
	
	else if (cmd_type == 2)  //Cpu_game_data
	{
		// dataArray.slice(startIndex + 0, startIndex + 79) = variables.polje_from_Cpu_game_data;
		dataArray[startIndex + 0] = variables.Cpu_game_data.c_game_mode;
		for (let j = 0; j < 8; j++) {
			dataArray[startIndex + (j * 2) + 1] = variables.Cpu_game_data.c_player_value[j] & 0xFF;
			dataArray[startIndex + (j * 2) + 2] = (variables.Cpu_game_data.c_player_value[j] >> 8) & 0xFF;
		}
		// dataArray.slice(startIndex + 1, startIndex + 17) = variables.Cpu_game_data.c_player_value;
		dataArray[startIndex + 17] = variables.Cpu_game_data.c_score & 0xFF;
		dataArray[startIndex + 18] = (variables.Cpu_game_data.c_score >> 8) & 0xFF;
		dataArray[startIndex + 19] = variables.Cpu_game_data.c_dart;
		dataArray[startIndex + 20] = variables.Cpu_game_data.c_round;
		dataArray[startIndex + 21] = variables.Cpu_game_data.c_player_throw;


		dataArray[startIndex + 22] = variables.Cpu_game_data.c_credit & 0xFF;
		dataArray[startIndex + 23] = (variables.Cpu_game_data.c_credit >> 8) & 0xFF;

		dataArray[startIndex + 24] = variables.Cpu_game_data.c_game;
		dataArray[startIndex + 25] = variables.Cpu_game_data.c_option & 0xFF;
		dataArray[startIndex + 26] = (variables.Cpu_game_data.c_option >> 8) & 0xFF;
		dataArray[startIndex + 27] = variables.Cpu_game_data.c_num_players;

		for (let i = 0; i < 24; i++) {
			dataArray[startIndex + 28 + i] = variables.Cpu_game_data.c_player_cricket[i];
		}

		for (let i = 0; i < 8; i++) {
			dataArray[startIndex + 52 + i] = variables.Cpu_game_data.c_player_rank[i];
		}

		dataArray[startIndex + 60] = variables.Cpu_game_data.c_playoff_flag;
		dataArray[startIndex + 61] = variables.Cpu_game_data.c_sub_game;
		dataArray[startIndex + 62] = variables.Cpu_game_data.c_team_num;
		dataArray[startIndex + 63] = variables.Cpu_game_data.c_flags_data;

		for (let i = 0; i < 8; i++) {
			dataArray[startIndex + 64 + i] = variables.Cpu_game_data.c_cricket_broj[i];
		}

		dataArray[startIndex + 72] = variables.Cpu_game_data.c_baceno_strelica & 0xFF;
		dataArray[startIndex + 73] = (variables.Cpu_game_data.c_baceno_strelica >> 8) & 0xFF;
		dataArray[startIndex + 74] = variables.Cpu_game_data.c_max_strelica & 0xFF;
		dataArray[startIndex + 75] = (variables.Cpu_game_data.c_max_strelica >> 8) & 0xFF;

		for (let i = 0; i < 3; i++) {
			dataArray[startIndex + 76 + i] = variables.Cpu_game_data.c_hits[i];
		}

		dataArray[startIndex + 79] = variables.Cpu_game_data.c_dijelova_kredita_u_aparatu;
		dataArray[startIndex + 80] = variables.Cpu_game_data.c_cijena_igre;
		dataArray[startIndex + 81] = variables.Cpu_game_data.c_max_rounds;
		dataArray[startIndex + 82] = variables.Cpu_game_data.c_show_msg;
		dataArray[startIndex + 83] = variables.Cpu_game_data.c_jumpers;

		dataArray[startIndex + 84] = variables.Cpu_game_data.c_ver_cpu[0];
		dataArray[startIndex + 85] = variables.Cpu_game_data.c_ver_cpu[1];
		dataArray[startIndex + 86] = variables.Cpu_game_data.c_ver_target[0];
		dataArray[startIndex + 87] = variables.Cpu_game_data.c_ver_target[1];
		dataArray[startIndex + 88] = variables.Cpu_game_data.c_ver_cctalk[0];
		dataArray[startIndex + 89] = variables.Cpu_game_data.c_ver_cctalk[1];

		
	}

}
function startTimer1() {
    timerInterval1 = setInterval(timerTick1, 10); // Pokretanje prvog intervala svakih 10 ms
}

function stopTimer1() {
    clearInterval(timerInterval1); // Zaustavljanje prvog intervala
}

function timerTick1() {
	tic_tac_serial++;
	
	if (tic_tac_serial % 50 == 0)
	{ 
		time_out_serial = 1; 
	}
}

// Funkcija za generisanje log fajla
function logToFile(data) {
	console.log('zapisujem u log podatke');
    // Dobijanje tekućeg datuma
    const today = new Date();
    const dateString = today.toISOString().split('T')[0]; // Format YYYY-MM-DD
    const logFileName = `${dateString}.log`;

    // Kreiranje putanje za log fajl
    const logFilePath = path_log.join('/home/hybrid3/server/data_logger', logFileName);

	console.log(logFilePath);
    // Formatiranje vremena za zapis
    const timeString = today.toISOString().split('T')[1].split('.')[0]; // Format HH:MM:SS

    // Kreiranje log poruke
    const logMessage = `[${dateString} ${timeString}] ${data} EOLG${os.EOL}`;

    // Dodavanje zapisa u fajl
    fs_log.appendFile(logFilePath, logMessage, (err) => {
       /* if (err) {
            console.error('Greška pri pisanju u log fajl:', err);
        } else {
            console.log('Zapis dodan u log fajl:', logFileName);
        }*/
    });
}
function sendToAllClients(SHOW_NEW_GAME, Cpu_game_data, Cpu_settings_data, Cpu_other_data, hitStatus) {
    const payload = {
        type: SHOW_NEW_GAME,        // event name
        Cpu_game_data: Cpu_game_data,
        Cpu_settings_data: Cpu_settings_data,
        Cpu_other_data: Cpu_other_data,
        hitStatus: hitStatus,
        testMessage: "This is a test message" // extra test field
    };

    // Loop through all connected clients
    for (let i = wsSockets.length - 1; i >= 0; i--) {
        const socket = wsSockets[i];
        try {
            socket.send(JSON.stringify(payload)); // send payload
            console.log("✅ Sent test message to client:", payload);
        } catch (err) {
            console.log("❌ Client not connected, removing from wsSockets");
            wsSockets.splice(i, 1); // remove disconnected client
        }
    }
}




startTimer1(); // Start prvog timera


module.exports = {
    writeSerial:writeSerial,
	protocolx_write:protocolx_write,
	copyDataToClassObject:copyDataToClassObject,
	copyClassObjectToData:copyClassObjectToData,
	socket_send_data:socket_send_data,
	logToFile:logToFile
}