const Game = require('./Game');
const x01Rules = require('./x01Rules');
const OtherRules = require('./otherGamerules');
const GameStatus = require('./gameStatus');
const Player = require('./player');
const Sounds = require('../workers/soundWorker')

module.exports = class x01Game extends Game {
	constructor() {
		super();
		//new Game();
		// Timed games
		this.timer = new Date();
		this.secondsElapsed = 0;
		this.secondsRemaining = 0;
		this.timerId = 0;
		this.COUNTDOWN_SECONDS = 5;
		// Equal/End
		this.isEqualStarted = false;
		this.equalRound = 0;
		this.equalPlayers = [];
		this.isEndStarted = false;
		this.endPlayers = [];
		this.equalEndHistory = [];
	}
	//	Resume game
	resumeGameData(gameService, darts, rules, awaitApproach) {
		console.log('uđe u resumeGameStatus u engineu');
		this.gameStatus.currentDart = gameService.currentDart;
		this.gameStatus.currentPlayer = gameService.currentPlayer;
		this.gameStatus.gameOver = gameService.gameOver;
		this.gameStatus.message = gameService.message;
		this.gameStatus.players = gameService.players;
		this.players = gameService.players;
		this.gameStatus.round = gameService.round;
		this.gameStatus.roundStartScore = gameService.roundStartScore;
		this.gameStatus.teamRoundStartScore = gameService.teamRoundStartScore;
		this.gameStatus.teams = gameService.teams;
		this.gameStatus.darts = darts;
	}
	// Create new game
	create(rules, players, teams, keepPlayersAsIs) {
		if (!(rules instanceof x01Rules || rules instanceof OtherRules)) {
			// Check if rules are valid
			return false;
		}
		if (!Game.prototype.create.call(this, rules, players, teams, true)) {
			return false;
		}
		this.secondsRemaining = this.rules.runAndGunTime;
		// Set starting scores to players and teams
		const startingScore = this.calculateStartingScore();
		console.log('SKOR JE ISKALKULIRAN')
		const isTeamGame = !!this.rules.teamRules;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		const hasStandardStackedRules = isStackedGame && !this.rules.parcheesi;
		this.players.forEach((_player, _index) => {
			_player.score = (hasStandardStackedRules) ? 0 : startingScore;
		});
		if (isTeamGame) {
			const playersPerTeam = this.players.filter((_player) => (_player.teamId === 0)).length;
			this.teams.forEach((_team, _index) => {
				_team.score = (hasStandardStackedRules && !this.rules.runAndGun) ? startingScore : startingScore * playersPerTeam;
			});
		}
		this.setHandicapScores();
		if (isStackedGame && this.rules.runAndGun) {
			this.setTeammatesToPlayInSequence();
		}
		// Create game status
		console.log('Kreiram GAMESTATUSSS SA OVIM IGRACIMAA :::!!!!', this.players);
		this.gameStatus = new GameStatus(this.players, this.teams);
		// Set starting scores for round start
		this.setRoundStartScore();
		this.setTeamRoundStartScore();
		if (this.rules.otherGameType === 5) {
			this.rules.runAndGunTime = 15;
			console.log('Startam timed game lokalno');
			this.startTimedGame();
		}
		return true;
	}
	// Add dart to game
	addDart(dart) {
		if (typeof this.rules.otherGameType !== 'undefined' && this.rules.otherGameType === 5) {
			if (typeof this.secondsRemaining !== 'undefined' && this.secondsRemaining > 10) {
				return this.gameStatus;
			}
		}
		if (Game.prototype.addDart.call(this, dart) === null) {
			return null;
		}
		if (this.rules.playOff === true &&
			this.gameStatus.gameOver === true &&
			this.playOffStarted === true) {
			this.playoffGame.addDart(dart);
			return this.playoffGame.gameStatus;
		}
		if (this.gameStatus.gameOver === true) {
			return this.gameStatus;
		}
		// Get current player
		let player = this.gameStatus.getCurrentPlayer();
		if (this.rules.runAndGun && this.countdownStarted) {
			this.resetTimer();
			this.countdownStarted = false;
		}
		if (this.rules.runAndGun === true && this.timerId <= 0 && this.rules.otherGameType !== 5) {
			console.log('Nema timera, kreni timer');
			if (this.gameStatus.currentDart === 1 && player.darts.length === 1) {
				this.startTimedGame();
			}
		}
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		const team = isTeamGame ? this.teams.find((_team) => (_team.id === player.teamId)) : undefined;
		// Calculate new scores
		const newScore = this.calculateScore(dart, player);
		const newTeamScore = isTeamGame ? this.calculateScore(dart, team) : 0;
		if (dart.isDouble) {
			player.isDoubledIn = true;
		}
		if (this.checkDoubleIn(player)) {
			if (this.rules.otherGameType === 2) {
				player.score += 50;
			}
			if (this.rules.otherGameType === 2 && isStackedGame) {
				team.score += 50;
			}
			this.gameStatus.message = 'You need to hit a double to start.';
			this.nextDart();
		}
		else if (this.rules.otherGameType === 3 && !(dart.isDouble || dart.isTriple || (dart.isQuatro && dart.quatroAllowed))) {
			this.nextDart();
			let totalPlayerDarts = this.darts.filter((_dart) => (_dart.player === player.id && [-2, -3, -4, -5].indexOf(_dart.hitEnum) < 0)).length;
			player.avgStatistic = (totalPlayerDarts > 0) ? (player.totalScore / totalPlayerDarts).toFixed(2) : '-';
		}
		else if (this.checkIsBust(dart, player, newScore, team, newTeamScore)) {
			const scoreBefore = player.score;
			this.handleBust(dart, player, newScore);
			this.handleBustStats(player, scoreBefore);
		}
		else if (this.checkIsFreeze(newScore, player)) {
			const scoreBefore = player.score;
			this.handleFreeze(player);
			// it is not a bust but is handled in the same manner
			this.handleBustStats(player, scoreBefore);
		}
		else {
			// player stats update
			player.totalScore += dart.score;
			const totalPlayerDarts = this.darts.filter((_dart) => (_dart.player === player.id && [-2, -3, -4, -5].indexOf(_dart.hitEnum) < 0)).length;
			player.avgStatistic = (totalPlayerDarts > 0) ? (player.totalScore / totalPlayerDarts).toFixed(2) : '-';
			let skipNext = false;
			if (this.checkIsWinner(player, newScore, team, newTeamScore)) {
				skipNext = this.handleWinner(player, newScore);
			}
			this.handleNewScore(player, newScore, skipNext, team, newTeamScore);
		}
		this.log(`Player ${player.name} [${player.id}] score: ${player.score}`);
		if (isTeamGame) {
			this.log(`Team ${team.name} [${team.id}] score: ${team.score}`);
		}
		return this.gameStatus;
	}
	// Approaching the board
	irApproach() {
		Game.prototype.irApproach.call(this);
	}
	// Leaving the board
	irLeave() {
		if (this.rules.otherGameType === 5) {
			this.resetTimer();
			this.startTimer();
		}
		Game.prototype.irLeave.call(this);
	}
	// Begin a timed game
	startTimedGame() {
		if (this.gameStatus.gameOver) {
			return;
		}
		if (this.rules.runAndGun === true) {
			this.resetTimer();
			this.startTimer();
			this.log('Timer started.');
		}
		else {
			this.gameStatus.message = 'This isn\'t a timed game.';
			this.log(this.gameStatus.message);
		}
	}
	// Begin countdown untill next player
	startCountdown() {
		if (this.gameStatus.gameOver) {
			return;
		}
		this.log("Countdown started.");
		this.timer = new Date();
		this.secondsElapsed = 0;
		this.secondsRemaining = this.COUNTDOWN_SECONDS;
		this.countdownStarted = true;
		//this.awaitApproach = true;
		console.log('pokrecem countdown');
		this.timerId = setInterval(() => (this.countdown()), 500);
	}
	// ENDREGION public
	// REGION Should be private ?
	// REGION Dart, player, round methods
	// Set players in the same team to play after one another
	setTeammatesToPlayInSequence() {
		if (!this.rules.teamRules) {
			return;
		}
		let shuffledPlayers = [];
		this.teams.forEach(_team => this.players.filter(_player => _player.teamId === _team.id)
			.forEach(_player => shuffledPlayers.push(_player)));
		this.players = shuffledPlayers;
	}
	// Set next dart
	nextDart() {
		let updatePlayer = false;
		// Set next dart, if last update next player
		let currentDart = this.gameStatus.currentDart + 1;
		if (currentDart > this.dartsPerRound) {
			currentDart = 1;
			updatePlayer = true;
			if (this.rules.runAndGun === true) {
				this.players[this.gameStatus.currentPlayer].roundScores.push(this.players[this.gameStatus.currentPlayer].score);
				this.gameStatus.roundStartScore[this.gameStatus.currentPlayer] = this.players[this.gameStatus.currentPlayer].score;
			}
			this.awaitApproach = true;
		}
		this.gameStatus.currentDart = currentDart;
		if (!((this.rules.runAndGun === true && this.timerId > 0) || (this.rules.runAndGun === true && this.gameStatus.getCurrentPlayer().score === 0))) {
			if (updatePlayer === true) {
				console.log('ne((run&gun i pokrenuto vrijeme) ili (runandgun i score 0)) nextplayer?');
				this.nextPlayer();
			}
		}
	}
	// Set next player
	nextPlayer() {
		const isTeamGame = !!this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		let updateRound = false;
		let updateTeamRoundStartScore = false;
		// If last player start over and update to next round
		let currentPlayer = this.gameStatus.currentPlayer;
		if (this.isEndStarted === true) {
			console.log('END STARTED JE TRUE, A PROSLI IGRAC JE: ', currentPlayer);
			let newPlayer = this.getNextPlayer(currentPlayer);
			while (this.endPlayers.length != this.players.length && this.endPlayers.indexOf(newPlayer) != -1) {
				newPlayer = this.getNextPlayer(newPlayer);
			}
			console.log('Novi igrac poslije logike je: ', newPlayer);
			if (newPlayer <= currentPlayer) {
				console.log('UPDATE RUNDE I SCOROVA');
				updateRound = true;
			}
			currentPlayer = newPlayer;
		}
		else {
			let newPlayer = this.getNextPlayer(currentPlayer);
			if (newPlayer <= currentPlayer) {
				updateRound = true;
			}
			if (newPlayer % this.teams.length === 0) {
				updateTeamRoundStartScore = true;
			}
			currentPlayer = newPlayer;
		}
		this.gameStatus.currentDart = 1;
		this.gameStatus.currentPlayer = currentPlayer;
		//Sounds.playNextPlayerSound();
		if (updateRound) {
			this.gameStatus.round++;
			this.setRoundStartScore();
		}
		if (updateTeamRoundStartScore) {
			this.setTeamRoundStartScore();
		}
		let maxRounds = this.rules.rounds;
		if (this.isEqualStarted === true) {
			maxRounds = this.equalRound;
		}
		// check if all rounds ended
		if (this.gameStatus.round > maxRounds) {
			this.gameStatus.gameOver = true;
			this.gameStatus.round--;
			this.log('Game over!');
			this.gameStatus.message = 'No more rounds';
			this.log('No more rounds');
			let leader;
			if (isTeamGame) {
				leader = this.getLeader(this.teams, this.calculateTeamStartingScore());
			}
			else {
				leader = this.getLeader(this.players, this.calculateStartingScore());
			}
			if (this.rules.playOff && leader.length > 1) {
				if (isTeamGame) {
					leader = leader.map(_team => {
						let teammates = this.gameStatus.players.filter(_player => _player.teamId === _team.id);
						teammates.sort((_p1, _p2) => _p1.score - _p2.score);
						return teammates[0];
					});
				}
				console.log('STARTAM PLAYOFF');
				this.startPlayoff(leader);
			} else {
				this.gameStatus.victor = leader.length > 1 ? leader[0].name : leader.name;
			}
		}
		if (this.gameStatus.currentPlayer.skip || this.gameStatus.currentPlayer.wait) {
			// TODO: check if this is ever called or needed 
			this.nextPlayer();
		}
	}
	// Get next player index
	getNextPlayer(currentPlayer) {
		if (currentPlayer < this.numberOfPlayers - 1) {
			currentPlayer++;
		}
		else {
			currentPlayer = 0;
		}
		if (this.gameStatus.players[currentPlayer].skip || this.gameStatus.players[currentPlayer].wait) {
			currentPlayer = this.getNextPlayer(currentPlayer);
		}
		return currentPlayer;
	}
	// Check if double in rules apply
	checkDoubleIn(player) {
		let doubleIn = false;
		// let teamDoubledIn = false;
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
        /*
        if (isTeamGame && this.rules.doubleIn && NOT TEAM DOUBLED IN ATRIBUTE /HAS TO BE ADDED/ ) {
            const team = this.players.filter(_player => _player.teamId === player.teamId);
            const playersDoubledIn = team.filter(_player => _player.isDoubledIn).length;
            const playersInTeam = team.length;
            // only one player has to be doubledInp
            if (isTeamGame && isStackedGame && playersDoubledIn >= 1) {
                teamDoubledIn = true;
            }
            // all players have to be doubledIn
            if (isTeamGame && !isStackedGame && playersDoubledIn === playersInTeam) {
                teamDoubledIn = true;
            }
            if (isTeamGame && !teamDoubledIn) {
                doubleIn = true;
            }
        } else */
		if (this.rules.doubleIn && !player.isDoubledIn) {
			doubleIn = true;
			this.log('Double in enabled, first dart must be double.');
		}
		return doubleIn;
	}
	// Check if new score is the same as another player's current score
	// and reset that player's score to 0 if necessary.
	// Return true if a player's score has been changed.
	handleParcheesiEqualScore(player, newScore) {
		if (!this.rules.parcheesi || newScore === 0) {
			return false;
		}
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		let equalPlayers = this.players.filter(_p => _p.id !== player.id
			&& _p.score === newScore
			&& !_p.wait // can't topple player who is waiting for teammate
			&& !(isStackedGame && _p.teamId === player.teamId)); // can't topple teammates in stacked
		if (equalPlayers.length === 0) {
			return false;
		}
		equalPlayers.forEach(_p => {
			_p.score = 0;
			this.gameStatus.message = 'Hit same score as ' + _p.name + '! His score is reset to 0!';
			if (this.onPlayerToppled) {
				this.onPlayerToppled(_p);
			}
			this.log(this.gameStatus.message);
		});
		this.updateAllTeamsScore();
		return true;
	}
	// Check if hit is BUST
	checkIsBust(dart, player, newScore, team, newTeamScore) {
		if (this.isPlayoff) {
			// Playoffs don't have busts
			return false;
		}
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		const hasStandardStackedRules = isStackedGame && !this.rules.parcheesi;
		const isFreeze = isTeamGame && this.rules.teamRules.freeze;
		const isParcheesiHandicap = this.rules.parcheesi && this.rules.handicap;
		const calculatingScore = (hasStandardStackedRules) ? newTeamScore : newScore;
		const endGameScore = isParcheesiHandicap ? player.endGameScore : this.calculateEndGameScore();
		if (this.rules.parcheesi && calculatingScore > endGameScore) {
			// Parcheesi over the score
			return true;
		}
		if (!this.rules.parcheesi && calculatingScore < endGameScore) {
			// Regular bust
			return true;
		}
		// non stacked game bust
		if (!this.rules.parcheesi && !this.rules.runAndGun && newScore === 0 && isTeamGame && !isStackedGame) {
			// if one of team mates scores > other team scores => BUST
			let teamMatesScores = this.players.filter(currPlayer => currPlayer.teamId === player.teamId && currPlayer.id !== player.id).map(currPlayer => currPlayer.score);
			let teamScore = 0;
			teamMatesScores.forEach(element => {
				teamScore += element;
			});
			let maxOpponentTeamScore = Math.min(...this.teams.filter(team => team.id !== player.teamId).map(team => team.score));
			if (teamScore > maxOpponentTeamScore) {
				// if freeze is true then no bust --> GAME OVER
				return !isFreeze;
			}
		}
		const masterOutUnreachableScore = (this.rules.parcheesi) ? endGameScore - 1 : 1;
		if (this.rules.doubleOut && (calculatingScore === endGameScore && !dart.isDouble)) {
			// Double out enabled, last dart must be double. BUST.
			return true;
		}
		else if (this.rules.doubleOut && (calculatingScore === masterOutUnreachableScore)) {
			// Double out enabled, double points cannot end game. BUST.
			return true;
		}
		else if (this.rules.masterOut && (calculatingScore === endGameScore && !dart.isDouble && !dart.isTriple && !dart.isQuatro)) {
			// Master out enabled, last dart must be double, triple or quatro. BUST.
			return true;
		}
		else if (this.rules.masterOut && (calculatingScore === masterOutUnreachableScore)) {
			// Master out enabled, double or triple points cannot end game. BUST.
			return true;
		}
		return false;
	}
	// Documented parcheesi bust condition, currently agreed to not be implemented
	checkParcheesiTeamBust(player) {
		const isTeamGame = this.rules.teamRules && this.teams;
		if (!this.rules.parcheesi || isTeamGame) {
			return;
		}
		const teammates = this.players.filter(_p => _p.id !== player.id && _p.teamId === player.teamId);
		if (this.rules.handicap) {
			const minTeamScoreDiff = Math.min(...this.teams.filter(_team => _team.id !== player.teamId)
				.map(_team => {
					let endScoreSum = 0;
					this.players.filter(_p => _p.teamId === _team.id)
						.forEach(_p => (endScoreSum += _p.endGameScore));
					return endScoreSum - _team.score;
				}));
			return !teammates.some(_player => (_player.endGameScore - _player.score) <= minTeamScoreDiff);
		}
		const minTeamScore = Math.min(...this.teams.filter(_team => _team.id !== player.teamId).map(_team => _team.score || 0));
		return !teammates.some(_player => _player.score <= minTeamScore);
	}
	// Handle what happens when BUST
	handleBust(dart, player, newScore) {
		this.gameStatus.message = 'Bust!';
		this.awaitApproach = true;
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		const isParcheesiHandicap = this.rules.parcheesi && this.rules.handicap;
		const endGameScore = isParcheesiHandicap ? player.endGameScore : this.calculateEndGameScore();
		let useParcheesiRules = false;
		if (this.rules.parcheesi) {
			// provjeriti
			const masterOutUnreachableScore = endGameScore - 1;
			if (this.rules.doubleOut) {
				if (newScore === endGameScore && !dart.isDouble) {
					useParcheesiRules = false;
				}
				else if (newScore === masterOutUnreachableScore) {
					useParcheesiRules = false;
				}
				else {
					useParcheesiRules = true;
				}
			}
			else if (this.rules.masterOut) {
				if (newScore === endGameScore && !dart.isDouble && !dart.isTriple) {
					useParcheesiRules = false;
				}
				else if (newScore === masterOutUnreachableScore) {
					useParcheesiRules = false;
				}
				else {
					useParcheesiRules = true;
				}
			}
			else {
				useParcheesiRules = true;
			}
		}
		if (useParcheesiRules === true) {
			let overhit = newScore - endGameScore;
			player.score = endGameScore - overhit;
			this.handleParcheesiEqualScore(player, player.score);
			this.log('Overhit by ' + overhit + '. Score reset to ' + player.score);
			Sounds.playBustSound();
		}
		else {
			player.score = this.gameStatus.roundStartScore[this.gameStatus.currentPlayer];
			this.log('Score reset to ' + player.score);
			this.gameStatus.bustScore = player.score - newScore;
			Sounds.playBustSound();
			if (isTeamGame) {
				this.teams[player.teamId].score = this.gameStatus.teamRoundStartScore[player.teamId];
				this.log('Team score reset to ' + this.teams[player.teamId].score);
			}
		}
		if (this.rules.runAndGun === true) {
			this.gameStatus.currentDart = 1;
			this.awaitApproach = true;
		}
		else {
			this.nextPlayer();
		}
	}
	handleBustStats(player, scoreBefore) {
		const scoreAfter = player.score;
		const diff = (scoreAfter > scoreBefore) ? scoreAfter - scoreBefore : scoreBefore - scoreAfter;
		player.totalScore = player.totalScore - diff;
		const totalPlayerDarts = this.darts.filter((_dart) => (_dart.player === player.id && [-2, -3, -4, -5].indexOf(_dart.hitEnum) < 0)).length;
		player.avgStatistic = (totalPlayerDarts > 0) ? (player.totalScore / totalPlayerDarts).toFixed(2) : '-';
	}
	checkIsFreeze(newScore, player) {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isFreeze = isTeamGame && this.rules.teamRules.freeze;
		if (newScore === 0 && isTeamGame && isFreeze) {
			// if one of team mates scores > other team scores => BUST
			let teamMatesScores = this.players.filter(currPlayer => currPlayer.teamId === player.teamId && currPlayer.id !== player.id).map(currPlayer => currPlayer.score);
			let maxOpponentTeamScore = Math.max(...this.teams.filter(team => team.id !== player.teamId).map(team => team.score));
			if (teamMatesScores.some((teamMateScore) => teamMateScore > maxOpponentTeamScore)) {
				// if freeze is true then no bust --> GAME OVER
				return true;
			}
		}
	}
	handleFreeze(player) {
		this.teams[player.teamId].freezeBust = 1;
		this.gameStatus.freezeLoss = true;
		this.gameStatus.message = 'Freeze loss!';
		this.log(this.gameStatus.message);
	}
	// Check if hit is a winner
	checkIsWinner(player, newScore, team, newTeamScore) {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		const hasStandardStackedRules = isStackedGame && !this.rules.parcheesi;
		const calculatingScore = (hasStandardStackedRules) ? newTeamScore : newScore;
		let unskippedPlayers = this.players.filter(_p => !_p.skip);
		if (this.isPlayoff && player === unskippedPlayers[unskippedPlayers.length - 1]) {
			// Check if the last dart of current playoff game
			player.score = newScore;
			if (isTeamGame) {
				team.score = newTeamScore;
			}
			let leader;
			if (isTeamGame) {
				leader = this.getLeader(this.teams, this.calculateTeamStartingScore());
			}
			else {
				leader = this.getLeader(this.players, this.calculateStartingScore());
			}
			if (leader.length === 1) {
				return true;
			}
			if (isTeamGame) {
				leader = leader.map(_team => {
					let teammates = this.gameStatus.players.filter(_player => _player.teamId === _team.id);
					teammates.sort((_p1, _p2) => _p1.score - _p2.score);
					return teammates[0];
				});
			}
			this.gameStatus.players.forEach((_player) => {
				if (leader.indexOf(_player) === -1) {
					_player.skip = true;
				}
			});
			return false;
		}
		if (this.rules.parcheesi) {
			// Parcheesi game
			const endGameScore = this.rules.handicap ? player.endGameScore : this.calculateEndGameScore();
			let finished = calculatingScore === endGameScore;
			if (finished && isTeamGame) {
				// wait until all teammates are done
				player.wait = true;
				this.handleParcheesiEqualScore(player, calculatingScore);
				this.gameStatus.message = 'Player ' + player.name + ' has finished!';
				this.log(this.gameStatus.message);
			}
			return finished;
		}
		if (this.rules.runAndGun) {
			// Run and gun check	
			if (this.rules.otherGameType === 1 || this.rules.otherGameType === 2 || this.rules.otherGameType === 3 || this.rules.otherGameType === 5 || this.rules.otherGameType === 13) {
				return false;
			}
			else {
				return calculatingScore === 0;
			}
		}
		if (this.rules.otherGameType === 2 || this.rules.otherGameType === 1 || this.rules.otherGameType === 3 || this.rules.otherGameType === 13) {
			// Low Score check
			return false;
		}
		// Regular game check
		return (!this.isPlayoff && calculatingScore === 0);
	}
	// Handle what happens when a player wins
	handleWinner(player, newScore) {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		let skipNext = false;
		if (this.rules.equalOption === true && this.gameStatus.currentPlayer < this.numberOfPlayers - 1) {
			if (this.isEqualStarted === false) {
				this.isEqualStarted = true;
				this.equalRound = this.gameStatus.round;
				this.equalPlayers.push(this.gameStatus.currentPlayer);
			}
			this.gameStatus.message = 'Game over. Equal option enabled means round can be played to the end.';
			this.log(this.gameStatus.message);
			this.nextPlayer();
			skipNext = true;
			this.awaitApproach = true;
		}
		else if (this.rules.endOption === true &&
			(this.gameStatus.round < this.rules.rounds || this.gameStatus.currentPlayer < this.numberOfPlayers - 1)) {
			if (this.isEndStarted === false) {
				this.isEndStarted = true;
				this.gameStatus.message = 'Game over. End option enabled means other players can play until the end.';
				this.log(this.gameStatus.message);
			}
			this.endPlayers.push(this.gameStatus.currentPlayer);
			if (this.endPlayers.length == this.players.length) {
				this.gameStatus.gameOver = true;
				this.gameStatus.message = 'Game over!';
				this.gameStatus.players
				this.log(this.gameStatus.message);
			}
			else {
				this.nextPlayer();
				skipNext = true;
				this.awaitApproach = true;
			}
		}
		else if (this.rules.runAndGun === true) {
			this.resetTimer();
			if (isStackedGame) {
				if (this.gameStatus.players[this.numberOfPlayers - 1].teamId === player.teamId) {
					// last team ended - set last player to current for game to end
					this.gameStatus.currentPlayer = this.numberOfPlayers - 1;
				}
				else {
					this.gameStatus.players.filter(_player => _player.teamId === player.teamId && _player.id !== player.id)
						.forEach(_player => _player.skip = true);
				}
			}
			if (this.gameStatus.currentPlayer < this.numberOfPlayers - 1) {
				this.awaitApproach = true;
			}
			else {
				this.gameStatus.gameOver = true;
				this.gameStatus.message = 'Game over!';
				this.gameStatus.victor = player.name;
				this.log(this.gameStatus.message);
			}
		}
		else if (this.rules.parcheesi && isTeamGame) {
			let hasWon = this.players.filter(_p => _p.teamId === player.teamId).every(_p => _p.wait);
			if (hasWon) {
				this.gameStatus.gameOver = true;
				this.gameStatus.message = 'Game over!';
				this.gameStatus.victor = player.name;
				this.log(this.gameStatus.message);
			}
			else {
				this.nextPlayer();
				skipNext = true;
				this.awaitApproach = true;
			}
		}
		else {
			this.gameStatus.gameOver = true;
			this.gameStatus.message = 'Game over!';
			//this.gameStatus.victor = player.name;
			this.log(this.gameStatus.message);
		}
		return skipNext;
	}
	// Handle what happens with a hit that is not bust or win
	handleNewScore(player, newScore, skipNext, team, newTeamScore) {
		// For parcheesi games, if a player hits the current score of another player, that other players score is reset to 0
		const isTeamGame = !!this.rules.teamRules;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		const hasStandardStackedRules = isStackedGame && !this.rules.parcheesi;
		const isParcheesiHandicap = this.rules.parcheesi && this.rules.handicap;
		const endGameScore = isParcheesiHandicap ? player.endGameScore : this.calculateEndGameScore();
		if (this.rules.parcheesi && newScore !== endGameScore) {
			this.handleParcheesiEqualScore(player, newScore);
		}
		player.score = newScore;
		if (isTeamGame) {
			if (hasStandardStackedRules) {
				team.score = newTeamScore;
			}
			else {
				this.updateAllTeamsScore();
			}
		}
		if (!skipNext) {
			this.nextDart();
		}
	}
	// Get the list of best players or teams (depending on entities) by score
	getLeader(entities, maxScore) {
		if (this.playOffStarted === true) {
			return this.playoffGame.getLeader(entities, 0);
		}
		let leader = [];
		if ((this.rules.otherGameType === 1 || this.rules.otherGameType === 2 || this.rules.otherGameType === 3 || this.rules.otherGameType === 13) && this.rules.playOff === true) {
			this.isPlayoff = true;
		}
		const isNewMaxScore = (_entity) => (this.rules.parcheesi === true || this.isPlayoff) ? _entity.score > maxScore : _entity.score < maxScore;
		var lowscore = 999999;
		if (this.rules.otherGameType === 2) {
			entities.forEach(_entity => {
				if (_entity.score === lowscore) {
					leader.push(_entity);
				}
				else if (_entity.score < lowscore) {
					leader = [_entity];
					lowscore = _entity.score;
				}
			});
		}
		else {
			entities.forEach(_entity => {
				if (_entity.score === maxScore) {
					leader.push(_entity);
				}
				else if (isNewMaxScore(_entity)) {
					leader = [_entity];
					maxScore = _entity.score;
				}
			});
		}
		return leader;
	}
	// ENDREGION Dart, player, round methods
	// REGION Score methods
	setHandicapScores() {
		if (!this.rules.handicap) {
			return;
		}
		const MAX_PLAYER_HANDICAP = 0.4;
		const MAX_TEAM_HANDICAP = 0.5;
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		const hasStandardStackedRules = isStackedGame && !this.rules.parcheesi;
		if (hasStandardStackedRules) {
			let teamPPDs = this.teams.map(_team => {
				let teammates = this.players.filter(_player => _player.teamId === _team.id);
				let totalPPD = 0;
				teammates.forEach(_player => totalPPD += +_player.owner.ppd || 0);
				return {
					teamId: _team.id,
					teamPPD: totalPPD / teammates.length
				};
			});
			const highPPD = Math.max(...teamPPDs.map(_e => _e.teamPPD));
			if (highPPD > 0) {
				this.teams.forEach(_team => {
					let diff = teamPPDs.find(_e => _e.teamId === _team.id).teamPPD / highPPD;
					_team.score = Math.ceil(_team.score * (diff >= MAX_TEAM_HANDICAP ? diff : MAX_TEAM_HANDICAP));
				});
			}
			return;
		}
		const highPPD = Math.max(...this.players.map(_player => +_player.owner.ppd || 0));
		if (highPPD > 0) {
			this.players.forEach(_player => {
				let diff = (+_player.owner.ppd || 0) / highPPD;
				if (this.rules.parcheesi) {
					_player.endGameScore = Math.ceil(this.rules.score * (diff >= MAX_PLAYER_HANDICAP ? diff : MAX_PLAYER_HANDICAP));
					this.log("End game score for player " + _player.name + " has been set to " + _player.endGameScore);
				}
				else {
					_player.score = Math.ceil(_player.score * (diff >= MAX_PLAYER_HANDICAP ? diff : MAX_PLAYER_HANDICAP));
				}
			});
		}
		this.updateAllTeamsScore();
	}
	calculateNonStackedTeamScore(teamId) {
		const teammates = this.players.filter(_player => _player.teamId === teamId);
		let newScore = 0;
		teammates.forEach(_player => newScore += _player.score || 0);
		return newScore;
	}
	updateAllTeamsScore() {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		const hasStandardStackedRules = isStackedGame && !this.rules.parcheesi;
		if (!isTeamGame || hasStandardStackedRules) {
			return;
		}
		// in a non stacked team game: team score is the sum of all the players in the team
		this.teams.forEach((_team) => _team.score = this.calculateNonStackedTeamScore(_team.id));
	}
	// Calculate score at the beggining of the game
	calculateStartingScore() {
		var startingScore = 0;
		if (this.rules.gameType === 1) {
			if (this.rules.parcheesi === true || this.rules.score === 0) {
				startingScore = 0;
			}
			else {
				startingScore = this.rules.score;
			}
		}
		return startingScore;
	}
	calculateTeamStartingScore() {
		const firstPlayer = this.gameStatus.players[0];
		const playersPerTeam = this.gameStatus.players.filter(_p => _p.teamId === firstPlayer.teamId).length;
		return this.calculateStartingScore() * playersPerTeam;
	}
	// Calculate score at the end of the game
	calculateEndGameScore() {
		var endGameScore = 0;
		const otherGameType = this.rules.otherGameType;
		if (this.rules.gameType === 1) {
			if (this.rules.parcheesi === true && (otherGameType !== 1 && otherGameType !== 3)) {
				endGameScore = this.rules.score;
			}
			else if (otherGameType === 1 || otherGameType === 2 || this.rules.otherGameType === 3 || this.rules.otherGameType === 13) {
				endGameScore = -1;
				if (this.rules.parcheesi) {
					endGameScore = 999999;
				}
			}
			else {
				endGameScore = 0;
			}
		}
		return endGameScore;
	}
	calculateScore(dart, entity) {
		const hit = dart.score;
		const currentScore = entity.score;
		const isParcheesi = this.rules.parcheesi;
		const isPlayoff = this.rules.score === 0;
		const otherGameType = this.rules.otherGameType;
		if (isParcheesi || (isPlayoff && otherGameType !== 2 && otherGameType !== 5) || otherGameType === 1 || otherGameType === 3 || otherGameType === 13) {
			return currentScore + hit;
		}
		else if (otherGameType === 2) {
			if (hit === 0 && this.postart !== true) {
				return currentScore + 50;
			}
			return currentScore + hit;
		}
		else if (otherGameType === 5) {
			if (this.secondsRemaining <= 10) {
				this.secondsRemaining = this.isTimerOver ? 1 : this.secondsRemaining;
				return currentScore + (hit * this.secondsRemaining);
			}
			else {
				return currentScore;
			}
		}
		return currentScore - hit;
	}
	// Set player scores at the beggining of the round
	setRoundStartScore() {
		if ((this.gameStatus.currentPlayer !== 0 || this.gameStatus.currentDart !== 1) && !this.isEndStarted) {
			// Not the first dart of the round
			return;
		}
		let currentScores = [];
		this.players.forEach(function (p) {
			currentScores.push(p.score);
			p.roundScores.push(p.score);
		});
		this.gameStatus.roundStartScore = currentScores;
		this.gameStatus.players = this.players;
	}
	// Set team scores at the beggining of the round
	setTeamRoundStartScore() {
		console.log(!!this.rules.teamRules, 'to je tutue');
		if (!!this.rules.teamRules && this.players[this.gameStatus.currentPlayer].teamId !== 0 || this.gameStatus.currentDart !== 1) {
			// Not the first dart of the round
			return;
		}
		let currentScores = [];
		this.teams.forEach((_team) => {
			currentScores.push(_team.score);
			_team.roundScores.push(_team.score);
		});
		this.gameStatus.teamRoundStartScore = currentScores;
		this.gameStatus.teams = this.teams;
	}
	// Starts timed game
	startTimer() {
		this.timer = new Date();
		this.secondsElapsed = 0;
		this.secondsRemaining = this.rules.runAndGunTime;
		this.isTimerOver = false;
		console.log('pokrenem timer');
		this.resetTimer();
		this.timerId = setInterval(() => (this.timeGame()), 500);
	}
	// Timing game callback
	timeGame() {
		const isTeamGame = this.rules.teamRules && this.teams;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		const now = new Date();
		const secondsElapsed = (now - this.timer) / 1000;
		this.secondsElapsed = Math.round(secondsElapsed);
		this.secondsRemaining = this.rules.runAndGunTime - this.secondsElapsed;
		this.log(this.secondsElapsed);
		// add time to player and team (for sorting)
		let player = this.gameStatus.getCurrentPlayer();
		player.runAndGunTime = Math.round(secondsElapsed);
		if (isTeamGame) {
			let team = this.teams.find(_team => _team.id === player.teamId);
			team.runAndGunTime = this.players.filter(_player => _player.teamId === team.id)
				.map(_player => _player.runAndGunTime)
				.reduce((_sum, _value) => (_sum + (_value || 0)), 0);
		}
		if (secondsElapsed >= this.rules.runAndGunTime) {
			this.resetTimer();
			this.isTimerOver = true;
			this.secondsRemaining = this.rules.runAndGunTime;
			this.secondsElapsed = 0;
			this.awaitApproach = true;
			if (this.gameStatus.currentPlayer < this.numberOfPlayers - 1) {
				this.nextPlayer();
			}
			else {
				this.awaitApproach = false;
				this.gameStatus.gameOver = true;
				this.gameStatus.message = 'Game over!';
				this.log(this.gameStatus.message);
			}
			// Player turn ended
		}
		else if (this.rules.otherGameType === 5 && player.darts.length > 2) {
			console.log('ulazi u provjeru trece');
			this.resetTimer();
			this.isTimerOver = true;
			this.secondsRemaining = this.rules.runAndGunTime;
			this.secondsElapsed = 0;
			this.awaitApproach = true;
			if (this.gameStatus.currentPlayer < this.numberOfPlayers - 1) {
				this.nextPlayer();
			}
			else {
				this.awaitApproach = false;
				this.gameStatus.gameOver = true;
				this.gameStatus.message = 'Game over!';
				this.log(this.gameStatus.message);
			}
			// Player turn ended
		}
		// Callback to the creator if subscribed
		if (this.callback) {
			this.callback();
		}
	}
	// Countdown until player start
	countdown() {
		const now = new Date();
		const secondsElapsed = (now - this.timer) / 1000;
		this.secondsElapsed = Math.round(secondsElapsed);
		this.secondsRemaining = this.COUNTDOWN_SECONDS - this.secondsElapsed;
		if (secondsElapsed >= this.COUNTDOWN_SECONDS) {
			this.log("Countdown ended.");
			this.resetTimer();
			//this.awaitApproach = false;
			this.startTimedGame();
		}
		if (this.callback) {
			this.callback();
		}
	}
	resetTimer() {
		console.log('resetiram timer');
		clearInterval(this.timerId);
		this.timerId = 0;
	}
	// For timed games, subscribe to the timer. The callback function provided as the parameter will get called about every 0.5 seconds.
	subscribeToTimeGame(callback) {
		x01Game.prototype.callback = callback;
	}
	// Override from Game, in addition to game status we need the history for equal and end options
	undoLastDart() {
		Game.prototype.undoLastDart.call(this);
		if (!this.equalEndHistory.length) {
			// Nothing to undo
			return;
		}
		const historyItem = this.equalEndHistory.pop();
		this.isEqualStarted = historyItem.isEqualStarted;
		this.equalRound = historyItem.equalRound;
		this.isEndStarted = historyItem.isEndStarted;
		this.endPlayers = historyItem.endPlayers;
		this.equalPlayers = historyItem.equalPlayers;
	}
	redoLastDart() {
		Game.prototype.redoLastDart.call(this);
	}
	// Override from Game, in addition to game status we need the history for equal and end options
	addStatusHistory() {
		Game.prototype.addStatusHistory.call(this);
		const historyItem = {
			isEqualStarted: this.isEqualStarted,
			equalRound: this.equalRound,
			isEndStarted: this.isEndStarted,
			endPlayers: [],
			equalPlayers: []
		};
		if (this.endPlayers !== null && this.endPlayers.length > 0) {
			historyItem.endPlayers = this.endPlayers.map(_player => Object.assign(new Player(), _player));
		}
		if (this.equalPlayers !== null && this.equalPlayers.length > 0) {
			historyItem.equalPlayers = this.equalPlayers.map(_player => Object.assign(new Player(), _player));
		}
		this.equalEndHistory.push(historyItem);
	}
	// ENDREGION
	// REGION Get leaders
	getLeaderBoard() {
		const isTeamGame = !!this.rules.teamRules;
		const sortByEntityRules = isTeamGame ? this.sortByTeamRules.bind(this) : this.sortByRules.bind(this);
		const isParcheesiHandicap = this.rules.parcheesi && this.rules.handicap;
		let entities = isTeamGame ? this.teams : this.players;
		if (entities[0].index === undefined) {
			entities.forEach((_e, _index) => _e.index = _index);
		}
		if (isParcheesiHandicap) {
			let players_copy = this.players.map(_p => Object.assign(new Player(), _p));
			let teams_copy = isTeamGame ? this.teams.map(_t => new Team(_t)) : [];
			players_copy.forEach(_player => _player.score = _player.endGameScore - _player.score);
			teams_copy.forEach(_team => {
				let endScoreSum = 0;
				this.players.filter(_p => _p.teamId === _team.id)
					.forEach(_p => (endScoreSum += _p.endGameScore));
				_team.score = endScoreSum - _team.score;
			});
			entities = isTeamGame ? teams_copy : players_copy;
		}
		if (this.playOffStarted === true && this.playoffGame != null) {
			// get players/teams in playoff, sort them in the playoff game
			let playOffEntities = this.playoffGame.getLeaderBoard();
			playOffEntities.forEach(_entity => {
				_entity.playOffScore = _entity.score;
				_entity.score = entities.find(_e => _e.id === _entity.id).score;
			});
			let playOffEntitiesIds = playOffEntities.map(_entity => _entity.id);
			// get all other players/teams and sort them here
			let nonPlayOffEntities = entities.filter(_entity => playOffEntitiesIds.indexOf(_entity.id) === -1);
			nonPlayOffEntities = sortByEntityRules(nonPlayOffEntities);
			return playOffEntities.concat(nonPlayOffEntities);
		}
		let result = sortByEntityRules(entities);
		result.forEach((_e, i) => _e.positionIndex = i);
		return result;
	}
	sortByRules(players) {
		const scoreSort = {
			name: 'score',
			primer: parseInt,
			reverse: false
		};
		if ((this.rules.parcheesi && !this.rules.handicap) || (this.isPlayoff && this.rules.otherGameType !== 2) || (this.rules.otherGameType === 1 && !this.rules.parcheesi) || (this.rules.otherGameType === 3 && !this.rules.parcheesi) || this.rules.otherGameType === 5 || (this.rules.otherGameType === 13 && !this.rules.parcheesi)) {
			scoreSort.reverse = true;
		}
		// was used before in run and gun
		const indexSort = {
			name: 'index',
			primer: parseInt,
			reverse: true
		};
		players.forEach((player, index, _players) => _players[index].index = index);
		if (this.isEqualStarted || this.isEndStarted) {
			const dartNoSort = {
				name: 'darts.length',
				primer: parseInt,
				reverse: false
			};
			return players.sort(sort_by(scoreSort, dartNoSort));
		}
		else if (this.rules.runAndGun === true) {
			const timeSort = {
				name: 'runAndGunTime',
				primer: parseInt,
				reverse: false
			};
			return players.sort(sort_by(scoreSort, timeSort));
		}
		else {
			return players.sort(sort_by(scoreSort));
		}
	}
	sortByTeamRules(teams) {
		const scoreSort = {
			name: 'score',
			primer: parseInt,
			reverse: false
		};
		if ((this.rules.parcheesi && !this.rules.handicap) || (this.isPlayoff && this.rules.otherGameType !== 2) || (this.rules.otherGameType === 1 && !this.rules.parcheesi) || (this.rules.otherGameType === 3 && !this.rules.parcheesi) || this.rules.otherGameType === 5 || (this.rules.otherGameType === 13 && !this.rules.parcheesi)) {
			scoreSort.reverse = true;
		}
		// was used before in run and gun
		const indexSort = {
			name: 'index',
			primer: parseInt,
			reverse: true
		};
		teams.forEach((team, index, _teams) => _teams[index].index = index);
		if (this.isEqualStarted || this.isEndStarted) {
			const dartNoSort = {
				name: 'darts.length',
				primer: parseInt,
				reverse: false
			};
			return teams.sort(sort_by(scoreSort, dartNoSort));
		}
		else if (this.rules.runAndGun === true) {
			const timeSort = {
				name: 'runAndGunTime',
				primer: parseInt,
				reverse: false
			};
			return teams.sort(sort_by(scoreSort, timeSort));
		}
		else if (this.rules.teamRules.freeze) {
			let sortedTeams = teams.slice().sort(sort_by(scoreSort));
			let frozenTeamIndex = sortedTeams.indexOf(sortedTeams.find((team) => team.freezeBust));
			let frozenTeam = sortedTeams.splice(frozenTeamIndex, 1);
			let newSortedTeams = sortedTeams.concat(frozenTeam);
			return newSortedTeams;
		}
		else {
			return teams.sort(sort_by(scoreSort));
		}
	}
	// ENDREGION
	getNumbersToClose() {
		Game.prototype.getNumbersToClose.call(this);
		let differences = [];
		let numbersToClose = [];
		let endGameScore = this.calculateEndGameScore();
		let player = this.gameStatus.getCurrentPlayer();
		differences.push(Math.abs(player.score - endGameScore));
		if (this.rules.parcheesi === true) {
			this.players.filter(_p => _p.id !== player.id && _p.score > player.score)
				.forEach(_p => differences.push(_p.score - player.score));
		}
		differences.filter(_diff => (_diff <= 80) && possibleHits[_diff])
			.map(_diff => possibleHits[_diff])
			.forEach(_nos => {
				if (_nos.standard && _nos.standard.length > 0) {
					_nos.standard.filter(_n => numbersToClose.indexOf(_n) === -1)
						.forEach(_n => numbersToClose.push(_n));
				}
				if (this.rules.quatro && _nos.quatro) {
					if (numbersToClose.indexOf(_nos.quatro) === -1) {
						numbersToClose.push(_nos.quatro);
					}
				}
			});
		return numbersToClose;
	}
	handleRunAndGunNexting() {
		if (!this.rules.runAndGun) {
			return;
		}
		const isTeamGame = !!this.rules.teamRules;
		const isStackedGame = isTeamGame && this.rules.teamRules.stacked;
		let activePlayer = this.gameStatus.getCurrentPlayer();
		let activeEntity = !isStackedGame ? activePlayer : this.teams.find((_team) => (_team.id === activePlayer.teamId));
		if (((activeEntity.score === 0 && typeof this.rules.otherGameType === 'undefined') || this.secondsRemaining === 0) && this.rules.otherGameType !== 5) {
			console.log('HANDLE RUN AND GUN STOPS TIMER AND NEXTS PLAYER?');
			this.resetTimer();
			this.secondsRemaining = this.rules.runAndGunTime;
			if (activeEntity.score === 0 && typeof this.rules.otherGameType === 'undefined') {
				if (isStackedGame) {
					if (this.gameStatus.players[this.numberOfPlayers - 1].teamId === activePlayer.teamId) {
						// last team ended - set last player to current for game to end
						this.gameStatus.currentPlayer = this.numberOfPlayers - 1;
					}
					else {
						this.gameStatus.players.filter(_player => _player.teamId === activePlayer.teamId && _player.id !== activePlayer.id)
							.forEach(_player => _player.skip = true);
					}
				}
				this.nextPlayer();
			}
		}
	}
}

function sort_by () {
    var fields = [].slice.call(arguments),
        n_fields = fields.length;

    return function (A, B) {
        var a, b, field, key, primer, reverse, result, i;

        for (i = 0; i < n_fields; i++) {
            result = 0;
            field = fields[i];

            key = typeof field === 'string' ? field : field.name;

            if (key.indexOf('.') !== -1) {
                var splitKey = key.split('.');
                a = A;
                b = B;
                for (var i = 0; i < splitKey.length; i++) {
                    var k = splitKey[i];
                    a = a[k];
                    b = b[k];
                }
            }
            else {
                a = A[key];
                b = B[key];
            }

            if (typeof field.primer !== 'undefined') {
                a = field.primer(a);
                b = field.primer(b);
            }

            reverse = (field.reverse) ? -1 : 1;

            if (a < b) result = reverse * -1;
            if (a > b) result = reverse * 1;
            if (result !== 0) break;
        }
        return result;
    }
}

const possibleHits = {
	1: {
		standard: [1],
		quatro: null
	},
	2: {
		standard: [2, 1],
		quatro: null
	},
	3: {
		standard: [3, 1],
		quatro: null
	},
	4: {
		standard: [4, 2],
		quatro: 1
	},
	5: {
		standard: [5],
		quatro: null
	},
	6: {
		standard: [6, 2, 3],
		quatro: null
	},
	7: {
		standard: [7],
		quatro: null
	},
	8: {
		standard: [8, 4],
		quatro: 2
	},
	9: {
		standard: [9, 3],
		quatro: null
	},
	10: {
		standard: [10, 5],
		quatro: null
	},
	11: {
		standard: [11],
		quatro: null
	},
	12: {
		standard: [12, 6, 4],
		quatro: 3
	},
	13: {
		standard: [13],
		quatro: null
	},
	14: {
		standard: [14, 7],
		quatro: null
	},
	15: {
		standard: [15, 5],
		quatro: null
	},
	16: {
		standard: [16, 8],
		quatro: 4
	},
	17: {
		standard: [17],
		quatro: null
	},
	18: {
		standard: [18, 9, 6],
		quatro: null
	},
	19: {
		standard: [19],
		quatro: null
	},
	20: {
		standard: [20, 10],
		quatro: 5
	},
	21: {
		standard: [7],
		quatro: null
	},
	22: {
		standard: [11],
		quatro: null
	},
	24: {
		standard: [12, 8],
		quatro: 6
	},
	25: {
		standard: [25],
		quatro: null
	},
	26: {
		standard: [13],
		quatro: null
	},
	27: {
		standard: [9],
		quatro: null
	},
	28: {
		standard: [14],
		quatro: 7
	},
	30: {
		standard: [15, 10],
		quatro: null
	},
	32: {
		standard: [16],
		quatro: 8
	},
	33: {
		standard: [11],
		quatro: null
	},
	34: {
		standard: [17],
		quatro: null
	},
	36: {
		standard: [18, 12],
		quatro: 9
	},
	38: {
		standard: [19],
		quatro: null
	},
	39: {
		standard: [13],
		quatro: null
	},
	40: {
		standard: [20],
		quatro: 10
	},
	42: {
		standard: [14],
		quatro: null
	},
	44: {
		standard: [],
		quatro: 11
	},
	45: {
		standard: [15],
		quatro: null
	},
	48: {
		standard: [16],
		quatro: 12
	},
	50: {
		standard: [25],
		quatro: null
	},
	51: {
		standard: [17],
		quatro: null
	},
	52: {
		standard: [],
		quatro: 13
	},
	54: {
		standard: [18],
		quatro: null
	},
	56: {
		standard: [],
		quatro: 14
	},
	57: {
		standard: [19],
		quatro: null
	},
	60: {
		standard: [20],
		quatro: 15
	},
	64: {
		standard: [],
		quatro: 16
	},
	68: {
		standard: [],
		quatro: 17
	},
	72: {
		standard: [],
		quatro: 18
	},
	76: {
		standard: [],
		quatro: 19
	},
	80: {
		standard: [],
		quatro: 20
	}
};
